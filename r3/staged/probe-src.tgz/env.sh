# Scratch: cross-build environment for x86_64-unknown-linux-musl on the Mac (p256 agent).
P=<home>/.claude/jobs/2280e09e/tmp/scratchpad/agents/p256
S=$P
O=<home>/.claude/jobs/2280e09e/tmp/scratchpad/agents/crypto-oracles
C=<home>/.claude/jobs/2280e09e/tmp/scratchpad/agents/chacha-avx2
W=<home>/Dev/jan/toyos-p256
TC=nightly-2026-07-22
BIN=$(rustc +$TC --print sysroot)/lib/rustlib/aarch64-apple-darwin/bin
export PATH="$BIN:$PATH"
SYSROOT=$O/sysroot-x86_64-musl
export CC_x86_64_unknown_linux_musl=/usr/bin/clang
export CXX_x86_64_unknown_linux_musl=/usr/bin/clang++
export AR_x86_64_unknown_linux_musl=$BIN/llvm-ar
export RANLIB_x86_64_unknown_linux_musl="$BIN/llvm-ar s"
export CFLAGS_x86_64_unknown_linux_musl="--target=x86_64-unknown-linux-musl --sysroot=$SYSROOT"
export CXXFLAGS_x86_64_unknown_linux_musl="$CFLAGS_x86_64_unknown_linux_musl"
export CARGO_TARGET_X86_64_UNKNOWN_LINUX_MUSL_LINKER=rust-lld
# snapshot <rev|WORK> <dest> [patch]: lib/crypto at a revision (WORK = working tree) into dest.
snapshot() {
  rm -rf "$2" && mkdir -p "$2"
  if [ "$1" = WORK ]; then (cd $W/lib/crypto && tar -cf - --exclude target .) | tar -x -m -C "$2"
  else git -C $W archive "$1" lib/crypto | tar -x -m --strip-components=2 -C "$2"; fi
  if [ -n "${3:-}" ]; then patch -d "$2" -p3 --forward < "$3"; fi
}
