
/// Scratch: the probe's P-256 parts, each run n times on a dependent chain
/// in the dispatched arithmetic. Never lands.
#[doc(hidden)]
pub mod parts {
    use super::*;
    use core::hint::black_box;
    pub type Part = (&'static str, fn(u64) -> u64);

    macro_rules! part {
        ($name:ident, $F:ident, $n:ident, $body:block) => {
            fn $name(n: u64) -> u64 {
                struct Op(u64);
                impl Computation<4> for Op {
                    type Output = u64;
                    fn run<$F: Modulus<4>>(self) -> u64 {
                        let $n = self.0;
                        $body
                    }
                }
                P256Field::dispatch(Op(n))
            }
        };
    }
    fn k() -> Scalar<P256, 4> {
        Scalar([0x0123456789abcdef, 0xfedcba9876543210, 0x0f1e2d3c4b5a6978, 0x7f6e5d4c3b2a1908], core::marker::PhantomData)
    }
    part!(field_mul, F, n, {
        let (mut x, y) = (Residue::<F, 4>::from_montgomery(P256::GX), Residue::<F, 4>::from_montgomery(P256::GY));
        for _ in 0..n { x = x.mul(&y); }
        x.integer()[0]
    });
    part!(field_square, F, n, {
        let mut x = Residue::<F, 4>::from_montgomery(P256::GX);
        for _ in 0..n { x = x.square(); }
        x.integer()[0]
    });
    part!(field_add, F, n, {
        let (mut x, y) = (Residue::<F, 4>::from_montgomery(P256::GX), Residue::<F, 4>::from_montgomery(P256::GY));
        for _ in 0..n { x = x.add(&y); }
        x.integer()[0]
    });
    part!(field_sub, F, n, {
        let (mut x, y) = (Residue::<F, 4>::from_montgomery(P256::GX), Residue::<F, 4>::from_montgomery(P256::GY));
        for _ in 0..n { x = x.sub(&y); }
        x.integer()[0]
    });
    part!(double, F, n, {
        let mut p = Point::<P256, 4, F>::base();
        for _ in 0..n { p = p.double(); }
        p.x.integer()[0]
    });
    part!(add, F, n, {
        let mut p = Point::<P256, 4, F>::base();
        let q = p.double().double();
        for _ in 0..n { p = p.add_incomplete(&q).0; }
        p.x.integer()[0]
    });
    part!(add_affine, F, n, {
        let mut p = Point::<P256, 4, F>::base().double();
        let q = Affine::<P256, 4, F>::from_table(&P256_G_ODD[1]);
        for _ in 0..n { p = p.add_affine(&q).0; }
        p.x.integer()[0]
    });
    part!(lookup, F, n, {
        let table = Point::<P256, 4, F>::base().double().multiples();
        for i in 0..n { black_box(Point::lookup(&table, (i % 33) as i8 - 16)); }
        0
    });
    part!(multiples, F, n, {
        let p = Point::<P256, 4, F>::base().double();
        for _ in 0..n { black_box(black_box(&p).multiples()); }
        0
    });
    part!(variable_mul, F, n, {
        let p = Point::<P256, 4, F>::base().double();
        for _ in 0..n { black_box(black_box(&p).mul(&k())); }
        0
    });
    part!(comb_mul, F, n, {
        for _ in 0..n { black_box(P256::base_mul::<F>(black_box(&k()))); }
        0
    });
    part!(affine, F, n, {
        let p = Point::<P256, 4, F>::base().double();
        let (mut x, mut y) = ([0; 4], [0; 4]);
        for _ in 0..n { black_box(&p).affine(&mut x, &mut y).unwrap(); black_box((x, y)); }
        0
    });
    part!(joint, F, n, {
        let p = Point::<P256, 4, F>::base().double();
        let (u1, u2) = (PublicScalar(k().0), PublicScalar([3, 5, 7, 0x0fff0000ffff0000]));
        for _ in 0..n { black_box(black_box(&p).joint(&u1, &u2)); }
        0
    });
    fn order_inverse(n: u64) -> u64 {
        for _ in 0..n { black_box(PublicScalar(black_box(k().0)).inverse::<P256Order>()); }
        0
    }
    pub const PARTS: [Part; 14] = [
        ("field-mul", field_mul), ("field-square", field_square), ("field-add", field_add), ("field-sub", field_sub),
        ("double", double), ("add", add), ("add-affine", add_affine), ("lookup-16", lookup),
        ("multiples", multiples), ("variable-mul", variable_mul), ("comb-mul", comb_mul), ("affine", affine),
        ("joint", joint), ("order-inverse", order_inverse),
    ];
}
