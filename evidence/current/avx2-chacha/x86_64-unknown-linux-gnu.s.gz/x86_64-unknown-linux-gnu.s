	.file	"toyos_crypto.fdfcf994e76f606-cgu.0"
	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj4_EEBG_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj4_EEBG_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj4_EEBG_:
	.cfi_startproc
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	movq	$0, 144(%rdi)
	movq	$0, 152(%rdi)
	#MEMBARRIER
	movq	$0, 160(%rdi)
	movq	$0, 168(%rdi)
	movq	$0, 176(%rdi)
	movq	$0, 184(%rdi)
	#MEMBARRIER
	movq	$0, 232(%rdi)
	movq	$0, 240(%rdi)
	movq	$0, 248(%rdi)
	movq	$0, 256(%rdi)
	#MEMBARRIER
	movq	$0, 264(%rdi)
	movq	$0, 272(%rdi)
	movq	$0, 280(%rdi)
	movq	$0, 288(%rdi)
	#MEMBARRIER
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	#MEMBARRIER
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	#MEMBARRIER
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end0:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj4_EEBG_, .Lfunc_end0-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj4_EEBG_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj6_EEBG_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj6_EEBG_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj6_EEBG_:
	.cfi_startproc
	movq	$0, 192(%rdi)
	movq	$0, 200(%rdi)
	movq	$0, 208(%rdi)
	movq	$0, 216(%rdi)
	movq	$0, 224(%rdi)
	movq	$0, 232(%rdi)
	#MEMBARRIER
	movq	$0, 240(%rdi)
	movq	$0, 248(%rdi)
	movq	$0, 256(%rdi)
	movq	$0, 264(%rdi)
	movq	$0, 272(%rdi)
	movq	$0, 280(%rdi)
	#MEMBARRIER
	movq	$0, 344(%rdi)
	movq	$0, 352(%rdi)
	movq	$0, 360(%rdi)
	movq	$0, 368(%rdi)
	movq	$0, 376(%rdi)
	movq	$0, 384(%rdi)
	#MEMBARRIER
	movq	$0, 392(%rdi)
	movq	$0, 400(%rdi)
	movq	$0, 408(%rdi)
	movq	$0, 416(%rdi)
	movq	$0, 424(%rdi)
	movq	$0, 432(%rdi)
	#MEMBARRIER
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	#MEMBARRIER
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	#MEMBARRIER
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	movq	$0, 120(%rdi)
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end1:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj6_EEBG_, .Lfunc_end1-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj6_EEBG_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_:
	.cfi_startproc
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	#MEMBARRIER
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	#MEMBARRIER
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	movq	$0, 120(%rdi)
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end2:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_, .Lfunc_end2-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_:
	.cfi_startproc
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end3:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_, .Lfunc_end3-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_:
	.cfi_startproc
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end4:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_, .Lfunc_end4-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj30_EEBG_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj30_EEBG_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj30_EEBG_:
	.cfi_startproc
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	movb	$0, 32(%rdi)
	movb	$0, 33(%rdi)
	movb	$0, 34(%rdi)
	movb	$0, 35(%rdi)
	movb	$0, 36(%rdi)
	movb	$0, 37(%rdi)
	movb	$0, 38(%rdi)
	movb	$0, 39(%rdi)
	movb	$0, 40(%rdi)
	movb	$0, 41(%rdi)
	movb	$0, 42(%rdi)
	movb	$0, 43(%rdi)
	movb	$0, 44(%rdi)
	movb	$0, 45(%rdi)
	movb	$0, 46(%rdi)
	movb	$0, 47(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end5:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj30_EEBG_, .Lfunc_end5-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj30_EEBG_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_:
	.cfi_startproc
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	movb	$0, 32(%rdi)
	movb	$0, 33(%rdi)
	movb	$0, 34(%rdi)
	movb	$0, 35(%rdi)
	movb	$0, 36(%rdi)
	movb	$0, 37(%rdi)
	movb	$0, 38(%rdi)
	movb	$0, 39(%rdi)
	movb	$0, 40(%rdi)
	movb	$0, 41(%rdi)
	movb	$0, 42(%rdi)
	movb	$0, 43(%rdi)
	movb	$0, 44(%rdi)
	movb	$0, 45(%rdi)
	movb	$0, 46(%rdi)
	movb	$0, 47(%rdi)
	movb	$0, 48(%rdi)
	movb	$0, 49(%rdi)
	movb	$0, 50(%rdi)
	movb	$0, 51(%rdi)
	movb	$0, 52(%rdi)
	movb	$0, 53(%rdi)
	movb	$0, 54(%rdi)
	movb	$0, 55(%rdi)
	movb	$0, 56(%rdi)
	movb	$0, 57(%rdi)
	movb	$0, 58(%rdi)
	movb	$0, 59(%rdi)
	movb	$0, 60(%rdi)
	movb	$0, 61(%rdi)
	movb	$0, 62(%rdi)
	movb	$0, 63(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end6:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_, .Lfunc_end6-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_:
	.cfi_startproc
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	movb	$0, 32(%rdi)
	movb	$0, 33(%rdi)
	movb	$0, 34(%rdi)
	movb	$0, 35(%rdi)
	movb	$0, 36(%rdi)
	movb	$0, 37(%rdi)
	movb	$0, 38(%rdi)
	movb	$0, 39(%rdi)
	movb	$0, 40(%rdi)
	movb	$0, 41(%rdi)
	movb	$0, 42(%rdi)
	movb	$0, 43(%rdi)
	movb	$0, 44(%rdi)
	movb	$0, 45(%rdi)
	movb	$0, 46(%rdi)
	movb	$0, 47(%rdi)
	movb	$0, 48(%rdi)
	movb	$0, 49(%rdi)
	movb	$0, 50(%rdi)
	movb	$0, 51(%rdi)
	movb	$0, 52(%rdi)
	movb	$0, 53(%rdi)
	movb	$0, 54(%rdi)
	movb	$0, 55(%rdi)
	movb	$0, 56(%rdi)
	movb	$0, 57(%rdi)
	movb	$0, 58(%rdi)
	movb	$0, 59(%rdi)
	movb	$0, 60(%rdi)
	movb	$0, 61(%rdi)
	movb	$0, 62(%rdi)
	movb	$0, 63(%rdi)
	#MEMBARRIER
	movl	$0, 64(%rdi)
	movl	$0, 68(%rdi)
	movl	$0, 72(%rdi)
	movl	$0, 76(%rdi)
	movl	$0, 80(%rdi)
	movl	$0, 84(%rdi)
	movl	$0, 88(%rdi)
	movl	$0, 92(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end7:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_, .Lfunc_end7-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto5mlkem16DecapsulationKeyEBF_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto5mlkem16DecapsulationKeyEBF_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto5mlkem16DecapsulationKeyEBF_:
	.cfi_startproc
	xorl	%eax, %eax
	.p2align	4
.LBB8_1:
	movw	$0, (%rdi,%rax)
	movw	$0, 2(%rdi,%rax)
	movw	$0, 4(%rdi,%rax)
	movw	$0, 6(%rdi,%rax)
	movw	$0, 8(%rdi,%rax)
	movw	$0, 10(%rdi,%rax)
	movw	$0, 12(%rdi,%rax)
	movw	$0, 14(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB8_1
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB8_3:
	movw	$0, 512(%rdi,%rax)
	movw	$0, 514(%rdi,%rax)
	movw	$0, 516(%rdi,%rax)
	movw	$0, 518(%rdi,%rax)
	movw	$0, 520(%rdi,%rax)
	movw	$0, 522(%rdi,%rax)
	movw	$0, 524(%rdi,%rax)
	movw	$0, 526(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB8_3
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB8_5:
	movw	$0, 1024(%rdi,%rax)
	movw	$0, 1026(%rdi,%rax)
	movw	$0, 1028(%rdi,%rax)
	movw	$0, 1030(%rdi,%rax)
	movw	$0, 1032(%rdi,%rax)
	movw	$0, 1034(%rdi,%rax)
	movw	$0, 1036(%rdi,%rax)
	movw	$0, 1038(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB8_5
	#MEMBARRIER
	movb	$0, 2752(%rdi)
	movb	$0, 2753(%rdi)
	movb	$0, 2754(%rdi)
	movb	$0, 2755(%rdi)
	movb	$0, 2756(%rdi)
	movb	$0, 2757(%rdi)
	movb	$0, 2758(%rdi)
	movb	$0, 2759(%rdi)
	movb	$0, 2760(%rdi)
	movb	$0, 2761(%rdi)
	movb	$0, 2762(%rdi)
	movb	$0, 2763(%rdi)
	movb	$0, 2764(%rdi)
	movb	$0, 2765(%rdi)
	movb	$0, 2766(%rdi)
	movb	$0, 2767(%rdi)
	movb	$0, 2768(%rdi)
	movb	$0, 2769(%rdi)
	movb	$0, 2770(%rdi)
	movb	$0, 2771(%rdi)
	movb	$0, 2772(%rdi)
	movb	$0, 2773(%rdi)
	movb	$0, 2774(%rdi)
	movb	$0, 2775(%rdi)
	movb	$0, 2776(%rdi)
	movb	$0, 2777(%rdi)
	movb	$0, 2778(%rdi)
	movb	$0, 2779(%rdi)
	movb	$0, 2780(%rdi)
	movb	$0, 2781(%rdi)
	movb	$0, 2782(%rdi)
	movb	$0, 2783(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end8:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto5mlkem16DecapsulationKeyEBF_, .Lfunc_end8-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto5mlkem16DecapsulationKeyEBF_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_:
	.cfi_startproc
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	movq	$0, 120(%rdi)
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	movq	$0, 144(%rdi)
	movq	$0, 152(%rdi)
	movq	$0, 160(%rdi)
	movq	$0, 168(%rdi)
	movq	$0, 176(%rdi)
	movq	$0, 184(%rdi)
	movq	$0, 192(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end9:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_, .Lfunc_end9-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_:
	.cfi_startproc
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 32(%rdi)
	#MEMBARRIER
	movq	$0, 40(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	#MEMBARRIER
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	#MEMBARRIER
	movq	$0, 120(%rdi)
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	movq	$0, 144(%rdi)
	movq	$0, 152(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end10:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_, .Lfunc_end10-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto8poly13058Poly1305EBF_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto8poly13058Poly1305EBF_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto8poly13058Poly1305EBF_:
	.cfi_startproc
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	#MEMBARRIER
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	#MEMBARRIER
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	#MEMBARRIER
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end11:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto8poly13058Poly1305EBF_, .Lfunc_end11-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto8poly13058Poly1305EBF_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p2569SecretKeyEBH_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p2569SecretKeyEBH_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p2569SecretKeyEBH_:
	.cfi_startproc
	movq	$0, 160(%rdi)
	movq	$0, 168(%rdi)
	movq	$0, 176(%rdi)
	movq	$0, 184(%rdi)
	#MEMBARRIER
	movq	$0, 192(%rdi)
	movq	$0, 200(%rdi)
	movq	$0, 208(%rdi)
	movq	$0, 216(%rdi)
	#MEMBARRIER
	movq	$0, 264(%rdi)
	movq	$0, 272(%rdi)
	movq	$0, 280(%rdi)
	movq	$0, 288(%rdi)
	#MEMBARRIER
	movq	$0, 296(%rdi)
	movq	$0, 304(%rdi)
	movq	$0, 312(%rdi)
	movq	$0, 320(%rdi)
	#MEMBARRIER
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	#MEMBARRIER
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	#MEMBARRIER
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	movq	$0, 120(%rdi)
	#MEMBARRIER
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end12:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p2569SecretKeyEBH_, .Lfunc_end12-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p2569SecretKeyEBH_
	.cfi_endproc

	.section	.text._RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p3849SecretKeyEBH_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p3849SecretKeyEBH_,@function
_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p3849SecretKeyEBH_:
	.cfi_startproc
	movq	$0, 192(%rdi)
	movq	$0, 200(%rdi)
	movq	$0, 208(%rdi)
	movq	$0, 216(%rdi)
	movq	$0, 224(%rdi)
	movq	$0, 232(%rdi)
	#MEMBARRIER
	movq	$0, 240(%rdi)
	movq	$0, 248(%rdi)
	movq	$0, 256(%rdi)
	movq	$0, 264(%rdi)
	movq	$0, 272(%rdi)
	movq	$0, 280(%rdi)
	#MEMBARRIER
	movq	$0, 344(%rdi)
	movq	$0, 352(%rdi)
	movq	$0, 360(%rdi)
	movq	$0, 368(%rdi)
	movq	$0, 376(%rdi)
	movq	$0, 384(%rdi)
	#MEMBARRIER
	movq	$0, 392(%rdi)
	movq	$0, 400(%rdi)
	movq	$0, 408(%rdi)
	movq	$0, 416(%rdi)
	movq	$0, 424(%rdi)
	movq	$0, 432(%rdi)
	#MEMBARRIER
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	#MEMBARRIER
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	#MEMBARRIER
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	movq	$0, 120(%rdi)
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	#MEMBARRIER
	movq	$0, 448(%rdi)
	movq	$0, 456(%rdi)
	movq	$0, 464(%rdi)
	movq	$0, 472(%rdi)
	movq	$0, 480(%rdi)
	movq	$0, 488(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end13:
	.size	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p3849SecretKeyEBH_, .Lfunc_end13-_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p3849SecretKeyEBH_
	.cfi_endproc

	.section	.text.unlikely._RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto,"ax",@progbits
	.globl	_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto
	.type	_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto,@function
_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%r9, %rax
	movq	%r8, %r10
	movq	%rcx, %r9
	leaq	8(%rsp), %r8
	movq	%rsi, (%r8)
	leaq	16(%rsp), %rcx
	movq	%rdx, (%rcx)
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.1(%rip), %rdx
	movq	%r8, %rsi
	movq	%rdx, %r8
	pushq	%rax
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking19assert_failed_inner@GOTPCREL(%rip)
.Lfunc_end14:
	.size	_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto, .Lfunc_end14-_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand:
.Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception0
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$296, %rsp
	.cfi_def_cfa_offset 352
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r14
	movq	%rdx, %r12
	movq	%rsi, %rbx
	movq	%rdi, 24(%rsp)
	xorl	%ebp, %ebp
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	movl	%ecx, %r13d
	andl	$33554432, %r13d
	movl	$240, %edx
	subq	%r12, %rdx
	leaq	(%rsp,%r12), %r15
	addq	$56, %r15
	movq	%r15, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	leaq	56(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 16(%rsp)
	movq	%r14, %rax
	movq	%r15, %r14
	shlq	$4, %rax
	subq	%r12, %rax
	leaq	16(%rax), %rcx
	xorl	%edx, %edx
	testb	$3, %al
	setne	%dl
	andq	$-4, %rcx
	leaq	(%rcx,%rdx,4), %rax
	movq	%rax, 40(%rsp)
	movb	$1, %r15b
	movq	%r12, %rax
	xorq	$32, %rax
	movq	%rax, 32(%rsp)
	movl	%r13d, 12(%rsp)
	.p2align	4
.LBB15_1:
	leaq	(%r12,%rbp), %rsi
	movl	-4(%r14,%rbp), %ebx
	movl	%ebx, 4(%rsp)
	movq	%rsi, %rax
	shrq	$32, %rax
	je	.LBB15_2
	movq	%rsi, %rax
	xorl	%edx, %edx
	divq	%r12
	testq	%rdx, %rdx
	je	.LBB15_11
.LBB15_8:
	movl	%esi, %eax
	andl	$31, %eax
	xorq	$16, %rax
	orq	32(%rsp), %rax
	jne	.LBB15_17
	testl	%r13d, %r13d
	jne	.LBB15_15
	movl	%ebx, %r13d
	shrl	$8, %r13d
	movl	%ebx, %r14d
	shrl	$16, %r14d
	movl	%ebx, %eax
	shrl	$24, %eax
	movl	%eax, 8(%rsp)
	movzbl	%bl, %edi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	movl	%eax, %ebx
	movb	%al, 4(%rsp)
	movzbl	%r13b, %edi
	movl	12(%rsp), %r13d
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	movb	%al, 5(%rsp)
	movzbl	%r14b, %edi
	leaq	(%rsp,%r12), %r14
	addq	$56, %r14
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	movb	%al, 6(%rsp)
	movzbl	8(%rsp), %edi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	movb	%al, 7(%rsp)
	jmp	.LBB15_16
	.p2align	4
.LBB15_2:
	movl	%esi, %eax
	xorl	%edx, %edx
	divl	%r12d
	testq	%rdx, %rdx
	jne	.LBB15_8
.LBB15_11:
	leaq	5(%rsp), %rcx
	movzwl	(%rcx), %eax
	movzbl	2(%rcx), %ecx
	movb	%cl, 6(%rsp)
	movw	%ax, 4(%rsp)
	movb	%bl, 7(%rsp)
	testl	%r13d, %r13d
	jne	.LBB15_13
	movl	4(%rsp), %edi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	movb	%al, 8(%rsp)
	movzbl	5(%rsp), %edi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	movb	%al, 5(%rsp)
	movzbl	6(%rsp), %edi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	movb	%al, 6(%rsp)
	movzbl	%bl, %edi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	movb	%al, 7(%rsp)
	movzbl	8(%rsp), %eax
	movl	%eax, %ebx
	jmp	.LBB15_14
.LBB15_13:
	leaq	4(%rsp), %rdi
	callq	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_647subword
	movzbl	4(%rsp), %ebx
.LBB15_14:
	xorb	%r15b, %bl
	movb	%bl, 4(%rsp)
	leal	(%r15,%r15), %eax
	shrb	$7, %r15b
	movzbl	%r15b, %ecx
	movq	%rcx, 48(%rsp)
	movq	48(%rsp), %r15
	negb	%r15b
	andb	$27, %r15b
	xorb	%al, %r15b
	jmp	.LBB15_16
.LBB15_15:
	leaq	4(%rsp), %rdi
	callq	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_647subword
	movzbl	4(%rsp), %ebx
.LBB15_16:
	leaq	(%r12,%rbp), %rsi
.LBB15_17:
	leaq	(%r12,%rbp), %rax
	addq	$-240, %rax
	testq	%rax, %rax
	je	.LBB15_23
	xorb	56(%rsp,%rbp), %bl
	movb	%bl, (%r14,%rbp)
	cmpq	$238, %rsi
	ja	.LBB15_23
	leaq	(%r12,%rbp), %rax
	addq	$-238, %rax
	movzbl	57(%rsp,%rbp), %ecx
	xorb	5(%rsp), %cl
	movb	%cl, 1(%r14,%rbp)
	testq	%rax, %rax
	je	.LBB15_23
	movzbl	58(%rsp,%rbp), %eax
	xorb	6(%rsp), %al
	movb	%al, 2(%r14,%rbp)
	cmpq	$236, %rsi
	ja	.LBB15_23
	movzbl	59(%rsp,%rbp), %eax
	xorb	7(%rsp), %al
	movb	%al, 3(%r14,%rbp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	#MEMBARRIER
	addq	$4, %rbp
	cmpq	%rbp, 40(%rsp)
	jne	.LBB15_1
	movl	$240, %edx
	movq	24(%rsp), %rbx
	movq	%rbx, %rdi
	leaq	56(%rsp), %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	16(%rsp), %rax
	movq	%rax, 240(%rbx)
	shrl	$25, %r13d
	movb	%r13b, 248(%rbx)
	addq	$296, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB15_23:
	.cfi_def_cfa_offset 352
.Ltmp0:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.7(%rip), %rdx
	movl	$240, %edi
	movl	$240, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp1:
	ud2
.LBB15_3:
.Ltmp2:
	movl	$7, %ecx
	.p2align	4
.LBB15_4:
	movb	$0, 49(%rsp,%rcx)
	movb	$0, 50(%rsp,%rcx)
	movb	$0, 51(%rsp,%rcx)
	movb	$0, 52(%rsp,%rcx)
	movb	$0, 53(%rsp,%rcx)
	movb	$0, 54(%rsp,%rcx)
	movb	$0, 55(%rsp,%rcx)
	movb	$0, 56(%rsp,%rcx)
	addq	$8, %rcx
	cmpq	$247, %rcx
	jne	.LBB15_4
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end15:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand, .Lfunc_end15-_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand,"a",@progbits
	.p2align	2, 0x0
GCC_except_table15:
.Lexception0:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end0-.Lcst_begin0
.Lcst_begin0:
	.uleb128 .Lfunc_begin0-.Lfunc_begin0
	.uleb128 .Ltmp0-.Lfunc_begin0
	.byte	0
	.byte	0
	.uleb128 .Ltmp0-.Lfunc_begin0
	.uleb128 .Ltmp1-.Ltmp0
	.uleb128 .Ltmp2-.Lfunc_begin0
	.byte	0
	.uleb128 .Ltmp1-.Lfunc_begin0
	.uleb128 .Lfunc_end15-.Ltmp1
	.byte	0
	.byte	0
.Lcst_end0:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$344, %rsp
	.cfi_def_cfa_offset 400
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %r12
	cmpb	$0, 248(%rdi)
	je	.LBB16_1
	movq	240(%rdi), %rsi
	movq	%r12, %rdx
	addq	$344, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414encrypt_native
.LBB16_1:
	.cfi_def_cfa_offset 400
	movups	(%rdi), %xmm0
	movups	(%r12), %xmm1
	xorps	%xmm0, %xmm1
	movups	%xmm1, (%r12)
	movq	240(%rdi), %r13
	testq	%r13, %r13
	je	.LBB16_9
	movl	$1, %eax
	movq	%r12, 72(%rsp)
	movq	%rdi, 48(%rsp)
	movq	%r13, 56(%rsp)
	.p2align	4
.LBB16_3:
	movq	%rax, 64(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB16_4:
	movq	%rax, 32(%rsp)
	movzbl	(%r12,%rax), %ecx
	movl	%ecx, %eax
	andl	$1, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	leal	(%rcx,%rcx), %r8d
	movl	%ecx, %eax
	shrl	$7, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r8b, %dl
	movl	%ecx, %edi
	shrl	%edi
	andl	$1, %edi
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	addb	%dl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	$27, %sil
	xorb	%dl, %sil
	movl	%ecx, %r8d
	shrl	$2, %r8d
	andl	$1, %r8d
	movq	%r8, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%sil, %r8b
	xorb	%dil, %r8b
	addb	%sil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%sil, %dl
	movl	%ecx, %edi
	shrl	$3, %edi
	andl	$1, %edi
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%r8b, %dil
	addb	%dl, %dl
	shrb	$7, %sil
	movzbl	%sil, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	$27, %sil
	xorb	%dl, %sil
	movl	%ecx, %r8d
	shrl	$4, %r8d
	andl	$1, %r8d
	movq	%r8, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%sil, %r8b
	xorb	%dil, %r8b
	addb	%sil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%sil, %dl
	movl	%ecx, %edi
	shrl	$5, %edi
	andl	$1, %edi
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%r8b, %dil
	addb	%dl, %dl
	shrb	$7, %sil
	movzbl	%sil, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	$27, %sil
	xorb	%dl, %sil
	shrl	$6, %ecx
	andl	$1, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%sil, %cl
	xorb	%dil, %cl
	addb	%sil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%sil, %dl
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%cl, %r9b
	shrb	$7, %sil
	movzbl	%sil, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movl	%r9d, %eax
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r9b, %cl
	leal	(%r9,%r9), %edx
	movl	%r9d, %eax
	shrb	$7, %al
	movzbl	%al, %r10d
	movq	%r10, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%dl, %al
	movl	%edx, %esi
	movl	%edx, 44(%rsp)
	movl	%r9d, %edx
	shrb	%dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	addb	%al, %al
	movl	%esi, %ecx
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 336(%rsp)
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r9d, %esi
	shrb	$2, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%r9d, %edx
	shrb	$3, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%sil, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r9d, %esi
	shrb	$4, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%r9d, %edx
	shrb	$5, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%sil, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r9d, %esi
	shrb	$6, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movq	%r10, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%sil, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movl	%eax, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 328(%rsp)
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	leal	(%rax,%rax), %edi
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %ebx
	movq	%rbx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dil, %cl
	movl	%eax, %esi
	shrb	%sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 320(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	addb	%cl, %cl
	shrb	$7, %dil
	movzbl	%dil, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %edi
	shrb	$2, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, 312(%rsp)
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	addb	%dl, %dl
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %esi
	shrb	$3, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 304(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dil, %sil
	addb	%cl, %cl
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %edi
	shrb	$4, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, 296(%rsp)
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	addb	%dl, %dl
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %esi
	shrb	$5, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 288(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$6, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 272(%rsp)
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %eax
	movq	%rax, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movq	%rbx, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%cl, %al
	xorb	%dil, %al
	shrb	$7, %dl
	movzbl	%dl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movl	%eax, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 280(%rsp)
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %r14d
	movq	%r14, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	leal	(%rax,%rax), %edi
	xorb	%dil, %cl
	movl	%eax, %esi
	shrb	%sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 264(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	shrb	$7, %dil
	movzbl	%dil, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %edi
	shrb	$2, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, 256(%rsp)
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %esi
	shrb	$3, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 248(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %edi
	shrb	$4, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, 240(%rsp)
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %esi
	shrb	$5, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 232(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$6, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 216(%rsp)
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %eax
	movq	%rax, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movq	%r14, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%cl, %al
	xorb	%dil, %al
	shrb	$7, %dl
	movzbl	%dl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movl	%eax, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 224(%rsp)
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %r15d
	movq	%r15, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	leal	(%rax,%rax), %edi
	xorb	%dil, %cl
	movl	%eax, %esi
	shrb	%sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 208(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	shrb	$7, %dil
	movzbl	%dil, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %edi
	shrb	$2, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, 200(%rsp)
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %esi
	shrb	$3, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 192(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %edi
	shrb	$4, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, 184(%rsp)
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %esi
	shrb	$5, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 176(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$6, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 160(%rsp)
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %eax
	movq	%rax, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movq	%r15, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%cl, %al
	xorb	%dil, %al
	shrb	$7, %dl
	movzbl	%dl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movl	%eax, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 168(%rsp)
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %r12d
	movq	%r12, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	leal	(%rax,%rax), %edi
	xorb	%dil, %cl
	movl	%eax, %esi
	shrb	%sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 152(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	shrb	$7, %dil
	movzbl	%dil, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %edi
	shrb	$2, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, 144(%rsp)
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %esi
	shrb	$3, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 136(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %edi
	shrb	$4, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, 128(%rsp)
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdi
	negb	%dil
	andb	%dl, %dil
	xorb	%sil, %dil
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %esi
	shrb	$5, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 120(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dil, %sil
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$6, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 112(%rsp)
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%sil, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movq	%r12, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%al, %r8b
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movl	%r8d, %eax
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 104(%rsp)
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%r8b, %al
	movl	%r8d, %ecx
	shrb	$7, %cl
	movzbl	%cl, %ebp
	movq	%rbp, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	leal	(%r8,%r8), %edx
	xorb	%dl, %cl
	movl	%r8d, %esi
	shrb	%sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 96(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%al, %sil
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%r8d, %eax
	shrb	$2, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 88(%rsp)
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%sil, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%dl, %dl
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%r8d, %esi
	shrb	$3, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 80(%rsp)
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%al, %sil
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %r13
	negb	%r13b
	andb	$27, %r13b
	xorb	%cl, %r13b
	movl	%r8d, %eax
	shrb	$4, %al
	andb	$1, %al
	movzbl	%al, %r11d
	movq	%r11, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%r13b, %al
	xorb	%sil, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%r13b, %r13b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%r13b, %cl
	movl	%r8d, %edx
	shrb	$5, %dl
	andb	$1, %dl
	movzbl	%dl, %edi
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%cl, %dl
	xorb	%al, %dl
	shrb	$7, %r13b
	movzbl	%r13b, %eax
	movq	%rax, 8(%rsp)
	addb	%cl, %cl
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	shrb	$6, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%al, %r8b
	xorb	%dl, %r8b
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	addb	%al, %al
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	%rbp, 8(%rsp)
	movq	8(%rsp), %r13
	negb	%r13b
	andb	%cl, %r13b
	xorb	%r8b, %r13b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	328(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%r9b, %al
	movq	%r10, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	44(%rsp), %cl
	movq	320(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%al, %r8b
	movq	336(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	312(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%cl, %cl
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	304(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	addb	%al, %al
	negb	%r8b
	andb	$27, %r8b
	xorb	%al, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	296(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	288(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	addb	%al, %al
	negb	%r8b
	andb	$27, %r8b
	xorb	%al, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	272(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movq	%rbx, 8(%rsp)
	addb	%al, %al
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	280(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%r8b, %al
	leal	(%r8,%r8), %edx
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	264(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	negb	%r8b
	andb	$27, %r8b
	xorb	%dl, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%al, %cl
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	256(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	248(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	addb	%al, %al
	negb	%r8b
	andb	$27, %r8b
	xorb	%al, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	240(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	232(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	addb	%al, %al
	negb	%r8b
	andb	$27, %r8b
	xorb	%al, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	216(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movq	%r14, 8(%rsp)
	addb	%al, %al
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	224(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%r8b, %al
	leal	(%r8,%r8), %edx
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	208(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	negb	%r8b
	andb	$27, %r8b
	xorb	%dl, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%al, %cl
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	200(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	192(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	addb	%al, %al
	negb	%r8b
	andb	$27, %r8b
	xorb	%al, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	184(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	176(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	addb	%al, %al
	negb	%r8b
	andb	$27, %r8b
	xorb	%al, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	160(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movq	%r15, 8(%rsp)
	addb	%al, %al
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	168(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%r8b, %al
	leal	(%r8,%r8), %edx
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	152(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	negb	%r8b
	andb	$27, %r8b
	xorb	%dl, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%al, %cl
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	144(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %r8
	movq	136(%rsp), %rcx
	movq	%rcx, 8(%rsp)
	addb	%al, %al
	negb	%r8b
	andb	$27, %r8b
	xorb	%al, %r8b
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	128(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	addb	%r8b, %r8b
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movq	120(%rsp), %r8
	movq	%r8, 8(%rsp)
	addb	%al, %al
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movq	112(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	%r12, 8(%rsp)
	movq	72(%rsp), %r12
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	movq	104(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	leal	(%r8,%r8), %r9d
	shrb	$7, %r8b
	movzbl	%r8b, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%r9b, %al
	movq	96(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	addb	%al, %al
	shrb	$7, %r9b
	movzbl	%r9b, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	88(%rsp), %r8
	movq	%r8, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movq	80(%rsp), %rdx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	%r11, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movq	%rdi, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movq	%rbp, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%sil, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	movl	%r13d, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	%al, %cl
	leal	(%rax,%rax), %esi
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%sil, %al
	movl	%r13d, %edx
	shrb	%dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	addb	%al, %al
	shrb	$7, %sil
	movzbl	%sil, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r13d, %esi
	shrb	$2, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%r13d, %edx
	shrb	$3, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%sil, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r13d, %esi
	shrb	$4, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%r13d, %edx
	shrb	$5, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%sil, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r13d, %esi
	shrb	$6, %sil
	andb	$1, %sil
	movzbl	%sil, %esi
	movq	%rsi, 8(%rsp)
	movq	8(%rsp), %rsi
	negb	%sil
	andb	%cl, %sil
	xorb	%dl, %sil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	shrb	$7, %r13b
	movzbl	%r13b, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%sil, %dl
	shrb	$7, %cl
	movzbl	%cl, %eax
	movl	%edx, %ecx
	rolb	%cl
	movq	%rax, 8(%rsp)
	movl	%edx, %eax
	rolb	$2, %al
	xorb	%cl, %al
	movl	%edx, %ecx
	rolb	$3, %cl
	movl	%edx, %esi
	rolb	$4, %sil
	xorb	%cl, %sil
	xorb	%al, %sil
	xorb	%dl, %sil
	movq	8(%rsp), %rax
	xorb	$99, %sil
	movq	32(%rsp), %rax
	movb	%sil, (%r12,%rax)
	incq	%rax
	cmpq	$16, %rax
	jne	.LBB16_4
	movq	56(%rsp), %r13
	movq	64(%rsp), %rcx
	cmpq	%r13, %rcx
	movq	%rcx, %rax
	adcq	$0, %rax
	movq	%rax, 32(%rsp)
	movzbl	1(%r12), %eax
	movzbl	2(%r12), %edx
	movzbl	3(%r12), %esi
	movzbl	5(%r12), %edi
	movzbl	6(%r12), %r8d
	movzbl	7(%r12), %r9d
	movzbl	9(%r12), %r10d
	movzbl	10(%r12), %r11d
	movzbl	11(%r12), %ebx
	movzbl	13(%r12), %ebp
	movzbl	14(%r12), %r14d
	movzbl	15(%r12), %r15d
	movb	%dil, 1(%r12)
	movb	%r10b, 5(%r12)
	movb	%bpl, 9(%r12)
	movb	%al, 13(%r12)
	movb	%r11b, 2(%r12)
	movb	%r14b, 6(%r12)
	movb	%dl, 10(%r12)
	movb	%r8b, 14(%r12)
	movb	%r15b, 3(%r12)
	movb	%sil, 7(%r12)
	movb	%r9b, 11(%r12)
	movb	%bl, 15(%r12)
	movb	$0, 8(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 17(%rsp)
	#MEMBARRIER
	cmpq	%r13, %rcx
	je	.LBB16_6
	movzbl	(%r12), %esi
	movzbl	1(%r12), %r9d
	movzbl	2(%r12), %r8d
	movzbl	3(%r12), %edx
	movl	%r9d, %edi
	xorb	%sil, %dil
	movl	%edi, %eax
	xorb	%r8b, %al
	movl	%eax, %r10d
	xorb	%dl, %r10b
	leal	(%rdi,%rdi), %r11d
	movl	%edi, %ebx
	shrb	$7, %bl
	movzbl	%bl, %ebx
	movq	%rbx, 8(%rsp)
	movq	8(%rsp), %rbx
	negb	%bl
	andb	$27, %bl
	xorb	%r11b, %bl
	xorb	%sil, %bl
	xorb	%r10b, %bl
	movb	%bl, (%r12)
	movl	%r8d, %r11d
	xorb	%r9b, %r11b
	leal	(%r11,%r11), %ebx
	shrb	$7, %r11b
	movzbl	%r11b, %r11d
	movq	%r11, 8(%rsp)
	movq	8(%rsp), %r11
	negb	%r11b
	andb	$27, %r11b
	xorb	%bl, %r11b
	xorb	%r9b, %r11b
	xorb	%r10b, %r11b
	movb	%r11b, 1(%r12)
	xorb	%dl, %r8b
	leal	(%r8,%r8), %r9d
	shrb	$7, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	$27, %r8b
	xorb	%r9b, %r8b
	xorb	%dl, %dil
	xorb	%r8b, %dil
	movb	%dil, 2(%r12)
	xorb	%sil, %dl
	leal	(%rdx,%rdx), %esi
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%sil, %dl
	xorb	%al, %dl
	movb	%dl, 3(%r12)
	movzbl	4(%r12), %esi
	movzbl	5(%r12), %r9d
	movzbl	6(%r12), %r8d
	movzbl	7(%r12), %edx
	movl	%r9d, %edi
	xorb	%sil, %dil
	movl	%edi, %eax
	xorb	%r8b, %al
	movl	%eax, %r10d
	xorb	%dl, %r10b
	leal	(%rdi,%rdi), %r11d
	movl	%edi, %ebx
	shrb	$7, %bl
	movzbl	%bl, %ebx
	movq	%rbx, 8(%rsp)
	movq	8(%rsp), %rbx
	negb	%bl
	andb	$27, %bl
	xorb	%r11b, %bl
	xorb	%sil, %bl
	xorb	%r10b, %bl
	movb	%bl, 4(%r12)
	movl	%r8d, %r11d
	xorb	%r9b, %r11b
	leal	(%r11,%r11), %ebx
	shrb	$7, %r11b
	movzbl	%r11b, %r11d
	movq	%r11, 8(%rsp)
	movq	8(%rsp), %r11
	negb	%r11b
	andb	$27, %r11b
	xorb	%bl, %r11b
	xorb	%r9b, %r11b
	xorb	%r10b, %r11b
	movb	%r11b, 5(%r12)
	xorb	%dl, %r8b
	leal	(%r8,%r8), %r9d
	shrb	$7, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	$27, %r8b
	xorb	%r9b, %r8b
	xorb	%dl, %dil
	xorb	%r8b, %dil
	movb	%dil, 6(%r12)
	xorb	%sil, %dl
	leal	(%rdx,%rdx), %esi
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%sil, %dl
	xorb	%al, %dl
	movb	%dl, 7(%r12)
	movzbl	8(%r12), %esi
	movzbl	9(%r12), %r9d
	movzbl	10(%r12), %r8d
	movzbl	11(%r12), %edx
	movl	%r9d, %edi
	xorb	%sil, %dil
	movl	%edi, %eax
	xorb	%r8b, %al
	movl	%eax, %r10d
	xorb	%dl, %r10b
	leal	(%rdi,%rdi), %r11d
	movl	%edi, %ebx
	shrb	$7, %bl
	movzbl	%bl, %ebx
	movq	%rbx, 8(%rsp)
	movq	8(%rsp), %rbx
	negb	%bl
	andb	$27, %bl
	xorb	%r11b, %bl
	xorb	%sil, %bl
	xorb	%r10b, %bl
	movb	%bl, 8(%r12)
	movl	%r8d, %r11d
	xorb	%r9b, %r11b
	leal	(%r11,%r11), %ebx
	shrb	$7, %r11b
	movzbl	%r11b, %r11d
	movq	%r11, 8(%rsp)
	movq	8(%rsp), %r11
	negb	%r11b
	andb	$27, %r11b
	xorb	%bl, %r11b
	xorb	%r9b, %r11b
	xorb	%r10b, %r11b
	movb	%r11b, 9(%r12)
	xorb	%dl, %r8b
	leal	(%r8,%r8), %r9d
	shrb	$7, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	$27, %r8b
	xorb	%r9b, %r8b
	xorb	%dl, %dil
	xorb	%r8b, %dil
	movb	%dil, 10(%r12)
	xorb	%sil, %dl
	leal	(%rdx,%rdx), %esi
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%sil, %dl
	xorb	%al, %dl
	movb	%dl, 11(%r12)
	movzbl	12(%r12), %esi
	movzbl	13(%r12), %r9d
	movzbl	14(%r12), %r8d
	movzbl	15(%r12), %edx
	movl	%r9d, %edi
	xorb	%sil, %dil
	movl	%edi, %eax
	xorb	%r8b, %al
	movl	%eax, %r10d
	xorb	%dl, %r10b
	leal	(%rdi,%rdi), %r11d
	movl	%edi, %ebx
	shrb	$7, %bl
	movzbl	%bl, %ebx
	movq	%rbx, 8(%rsp)
	movq	8(%rsp), %rbx
	negb	%bl
	andb	$27, %bl
	xorb	%r11b, %bl
	xorb	%sil, %bl
	xorb	%r10b, %bl
	movb	%bl, 12(%r12)
	movl	%r8d, %r11d
	xorb	%r9b, %r11b
	leal	(%r11,%r11), %ebx
	shrb	$7, %r11b
	movzbl	%r11b, %r11d
	movq	%r11, 8(%rsp)
	movq	8(%rsp), %r11
	negb	%r11b
	andb	$27, %r11b
	xorb	%bl, %r11b
	xorb	%r9b, %r11b
	xorb	%r10b, %r11b
	movb	%r11b, 13(%r12)
	xorb	%dl, %r8b
	leal	(%r8,%r8), %r9d
	shrb	$7, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 8(%rsp)
	movq	8(%rsp), %r8
	negb	%r8b
	andb	$27, %r8b
	xorb	%r9b, %r8b
	xorb	%dl, %dil
	xorb	%r8b, %dil
	movb	%dil, 14(%r12)
	xorb	%sil, %dl
	leal	(%rdx,%rdx), %esi
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%sil, %dl
	xorb	%al, %dl
	movb	%dl, 15(%r12)
.LBB16_6:
	movq	%rcx, %rax
	shlq	$4, %rax
	cmpq	$240, %rax
	jae	.LBB16_11
	movq	48(%rsp), %rdi
	movups	(%rdi,%rax), %xmm0
	movups	(%r12), %xmm1
	xorps	%xmm0, %xmm1
	movups	%xmm1, (%r12)
	cmpq	%r13, %rcx
	jae	.LBB16_9
	movq	32(%rsp), %rcx
	movq	%rcx, %rax
	cmpq	%r13, %rcx
	jbe	.LBB16_3
.LBB16_9:
	addq	$344, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB16_11:
	.cfi_def_cfa_offset 400
	leaq	16(%rax), %rsi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.6(%rip), %rcx
	movl	$240, %edx
	movq	%rax, %rdi
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Lfunc_end16:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt, .Lfunc_end16-_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI17_0:
	.short	65535
	.short	65535
	.short	65535
	.short	0
	.short	65535
	.short	65535
	.short	65535
	.short	65535
.LCPI17_1:
	.short	65535
	.short	0
	.short	65535
	.short	65535
	.short	65535
	.short	65535
	.short	65535
	.short	65535
.LCPI17_2:
	.short	65535
	.short	65535
	.short	65535
	.short	65535
	.short	65535
	.short	65535
	.short	65535
	.short	0
.LCPI17_3:
	.short	65535
	.short	65535
	.short	65535
	.short	65535
	.short	65535
	.short	0
	.short	65535
	.short	65535
	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3tag,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3tag,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3tag:
.Lfunc_begin1:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception1
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$200, %rsp
	.cfi_def_cfa_offset 256
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %r15
	movq	%rcx, %rax
	movq	(%rsi), %rcx
	movq	8(%rsi), %r12
	movq	%rcx, %r10
	movq	%r12, %r11
	movq	%r12, %r8
	shrq	$4, %r8
	movabsq	$1085102592571150095, %rbx
	andq	%rbx, %r8
	andq	%rbx, %r12
	shlq	$4, %r12
	orq	%r8, %r12
	movabsq	$3689348814741910323, %r14
	movq	%r12, %r8
	andq	%r14, %r8
	shrq	$2, %r12
	andq	%r14, %r12
	leaq	(%r12,%r8,4), %r13
	movabsq	$6148914691236517205, %r12
	movq	%r13, %r8
	andq	%r12, %r8
	shrq	%r13
	andq	%r12, %r13
	leaq	(,%r8,2), %r8
	addq	%r13, %r8
	movq	%r8, 176(%rsp)
	movq	%rcx, %r8
	shrq	$4, %r8
	andq	%rbx, %r8
	andq	%rbx, %rcx
	shlq	$4, %rcx
	orq	%r8, %rcx
	movq	%rcx, %r8
	andq	%r14, %r8
	shrq	$2, %rcx
	andq	%r14, %rcx
	leaq	(%rcx,%r8,4), %rcx
	movq	%rcx, %r8
	andq	%r12, %r8
	shrq	%rcx
	andq	%r12, %rcx
	leaq	(%rcx,%r8,2), %rcx
	movq	%rcx, 168(%rsp)
	movq	256(%rsp), %rcx
	xorps	%xmm0, %xmm0
	movaps	%xmm0, (%rsp)
	movq	$0, 32(%rsp)
	movq	$2, 40(%rsp)
	movq	%rax, 48(%rsp)
	movq	%r15, 56(%rsp)
	movq	%r9, 80(%rsp)
	movq	%r9, 64(%rsp)
	movq	%rcx, 72(%rsp)
	bswapq	%r10
	movq	%rsi, 160(%rsp)
	movzbl	272(%rsi), %ecx
	bswapq	%r11
	cmpb	$1, %cl
	movq	%rdi, 184(%rsp)
	movq	%rdx, 144(%rsp)
	movq	%r10, 104(%rsp)
	movq	%r11, 88(%rsp)
	movq	%r15, 152(%rsp)
	movb	%cl, 31(%rsp)
	jne	.LBB17_16
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	jmp	.LBB17_3
	.p2align	4
.LBB17_2:
	movl	$1, %eax
	testb	$1, 80(%rsp)
	movb	$1, %cl
	jne	.LBB17_35
.LBB17_3:
	movq	%rcx, 80(%rsp)
	shlq	$4, %rax
	leaq	48(%rsp), %rcx
	movq	(%rcx,%rax), %r13
	movq	8(%rcx,%rax), %r15
	movq	%r15, %rcx
	shrq	$4, %rcx
	movq	160(%rsp), %rdi
	movq	%rsp, %rsi
	movq	%r13, %rdx
	callq	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6411hash_blocks
	movq	%r15, %rbp
	andq	$15, %rbp
	je	.LBB17_2
	movabsq	$9223372036854775792, %rax
	andq	%rax, %r15
	addq	%r15, %r13
	jmp	.LBB17_6
	.p2align	4
.LBB17_5:
	addq	%r15, %r13
	movq	(%rsp), %rcx
	movq	8(%rsp), %rax
	movq	%rcx, %rdx
	shrq	$4, %rdx
	andq	%rbx, %rdx
	andq	%rbx, %rcx
	shlq	$4, %rcx
	orq	%rdx, %rcx
	movq	%rcx, %rdx
	andq	%r14, %rdx
	shrq	$2, %rcx
	andq	%r14, %rcx
	leaq	(%rcx,%rdx,4), %rcx
	movq	%rcx, %rdx
	andq	%r12, %rdx
	shrq	%rcx
	andq	%r12, %rcx
	leaq	(%rcx,%rdx,2), %rsi
	movq	%rax, %rcx
	shrq	$4, %rcx
	andq	%rbx, %rcx
	andq	%rbx, %rax
	shlq	$4, %rax
	orq	%rcx, %rax
	movq	%rax, %rcx
	andq	%r14, %rcx
	shrq	$2, %rax
	andq	%r14, %rax
	leaq	(%rax,%rcx,4), %rax
	movq	%rax, %rcx
	andq	%r12, %rcx
	shrq	%rax
	andq	%r12, %rax
	leaq	(%rax,%rcx,2), %rdx
	leaq	112(%rsp), %rdi
	movq	168(%rsp), %rcx
	movq	176(%rsp), %r8
	callq	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414product_native
	movq	128(%rsp), %rdx
	movq	136(%rsp), %r8
	movq	%r8, %rdi
	movq	%r8, %rcx
	movq	%r8, %rsi
	movq	%r8, %r9
	shldq	$2, %rdx, %r9
	movq	%r8, %rax
	shldq	$7, %rdx, %rax
	xorq	%r9, %rax
	xorq	%r8, %rax
	shrq	$63, %r8
	shrq	$62, %rdi
	xorq	%r8, %rdi
	shrq	$57, %rcx
	xorq	%rdi, %rcx
	leaq	(%rdx,%rdx), %r8
	shldq	$1, %rdx, %rsi
	leaq	(,%rdx,4), %r9
	movl	%ecx, %edi
	shll	$7, %edi
	xorq	%rdx, %rdi
	shlq	$7, %rdx
	xorq	%r9, %rdx
	leal	(%rcx,%rcx), %r9d
	xorq	%rdx, %r9
	leal	(,%rcx,4), %edx
	xorq	120(%rsp), %rsi
	xorq	112(%rsp), %r8
	xorq	%r9, %rdx
	xorq	%rdx, %r8
	xorq	%rsi, %rax
	xorq	%rcx, %rdi
	xorq	%r8, %rdi
	movq	%rdi, %rcx
	shrq	$4, %rcx
	andq	%rbx, %rcx
	andq	%rbx, %rdi
	shlq	$4, %rdi
	orq	%rcx, %rdi
	movq	%rdi, %rcx
	andq	%r14, %rcx
	shrq	$2, %rdi
	andq	%r14, %rdi
	leaq	(%rdi,%rcx,4), %rcx
	movq	%rcx, %rdx
	andq	%r12, %rdx
	shrq	%rcx
	andq	%r12, %rcx
	movq	%rax, %rsi
	shrq	$4, %rsi
	andq	%rbx, %rsi
	andq	%rbx, %rax
	shlq	$4, %rax
	orq	%rsi, %rax
	movq	%rax, %rsi
	andq	%r14, %rsi
	shrq	$2, %rax
	andq	%r14, %rax
	leaq	(%rax,%rsi,4), %rax
	movq	%rax, %rsi
	andq	%r12, %rsi
	shrq	%rax
	andq	%r12, %rax
	leaq	(%rcx,%rdx,2), %rcx
	leaq	(%rax,%rsi,2), %rax
	movq	%rax, 8(%rsp)
	movq	%rcx, (%rsp)
	subq	%r15, %rbp
	je	.LBB17_2
.LBB17_6:
	cmpq	$16, %rbp
	movl	$16, %r15d
	cmovbq	%rbp, %r15
	jb	.LBB17_7
	leaq	(%rsp,%r15), %rax
	leaq	(%r15,%r13), %rcx
	movq	%rsp, %rdx
	cmpq	%rcx, %rdx
	setb	%cl
	cmpq	%rax, %r13
	setb	%al
	testb	%al, %cl
	je	.LBB17_10
.LBB17_7:
	xorl	%eax, %eax
.LBB17_11:
	movq	%r15, %rdx
	movq	%rax, %rcx
	andq	$3, %rdx
	je	.LBB17_14
	movq	%rax, %rcx
	.p2align	4
.LBB17_13:
	movzbl	(%r13,%rcx), %esi
	xorb	%sil, (%rsp,%rcx)
	incq	%rcx
	decq	%rdx
	jne	.LBB17_13
.LBB17_14:
	subq	%r15, %rax
	cmpq	$-4, %rax
	ja	.LBB17_5
	.p2align	4
.LBB17_15:
	movzbl	(%r13,%rcx), %eax
	xorb	%al, (%rsp,%rcx)
	movzbl	1(%r13,%rcx), %eax
	xorb	%al, 1(%rsp,%rcx)
	movzbl	2(%r13,%rcx), %eax
	xorb	%al, 2(%rsp,%rcx)
	movzbl	3(%r13,%rcx), %eax
	xorb	%al, 3(%rsp,%rcx)
	addq	$4, %rcx
	cmpq	%rcx, %r15
	jne	.LBB17_15
	jmp	.LBB17_5
	.p2align	4
.LBB17_10:
	movl	%r15d, %eax
	andl	$16, %eax
	movups	(%r13), %xmm0
	xorps	(%rsp), %xmm0
	movaps	%xmm0, (%rsp)
	cmpq	%rax, %r15
	je	.LBB17_5
	jmp	.LBB17_11
.LBB17_16:
	testq	%r15, %r15
	je	.LBB17_26
	movabsq	$-2233785415175766016, %r10
	movq	152(%rsp), %rcx
	.p2align	4
.LBB17_18:
	cmpq	$16, %rcx
	movl	$16, %r8d
	movq	%rcx, 192(%rsp)
	cmovbq	%rcx, %r8
	jae	.LBB17_20
	xorl	%ecx, %ecx
	jmp	.LBB17_21
	.p2align	4
.LBB17_20:
	movl	%r8d, %ecx
	andl	$16, %ecx
	movups	(%rax), %xmm0
	xorps	(%rsp), %xmm0
	movaps	%xmm0, (%rsp)
	jmp	.LBB17_22
	.p2align	4
.LBB17_21:
	movzbl	(%rax,%rcx), %edx
	xorb	%dl, (%rsp,%rcx)
	incq	%rcx
.LBB17_22:
	cmpq	%rcx, %r8
	jne	.LBB17_21
	movq	%rax, 96(%rsp)
	movq	(%rsp), %rsi
	bswapq	%rsi
	movq	8(%rsp), %r9
	bswapq	%r9
	movl	$129, %ebp
	movq	88(%rsp), %rdi
	movq	104(%rsp), %rdx
	xorl	%r11d, %r11d
	xorl	%r15d, %r15d
	.p2align	4
.LBB17_24:
	leal	-2(%rbp), %ecx
	movq	%r9, %r13
	shrdq	%cl, %rsi, %r13
	movq	%r10, %rax
	movq	%rsi, %r10
	shrq	%cl, %r10
	testb	$64, %cl
	cmoveq	%r13, %r10
	andl	$1, %r10d
	movq	%r10, 112(%rsp)
	xorl	%ecx, %ecx
	subq	112(%rsp), %rcx
	movl	$0, %r10d
	sbbq	%r10, %r10
	andq	%rdx, %r10
	xorq	%r10, %r15
	xorl	%r10d, %r10d
	andq	%rdi, %rcx
	xorq	%rcx, %r11
	movl	%edi, %ecx
	andl	$1, %ecx
	movq	%rcx, 112(%rsp)
	cmpq	112(%rsp), %r10
	movq	%rax, %r10
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	shrdq	$1, %rdx, %rdi
	shrq	%rdx
	andq	%rax, %rcx
	xorq	%rcx, %rdx
	decl	%ebp
	cmpl	$1, %ebp
	ja	.LBB17_24
	bswapq	%r15
	bswapq	%r11
	movq	96(%rsp), %rax
	addq	%r8, %rax
	movq	%r11, 8(%rsp)
	movq	%r15, (%rsp)
	movq	192(%rsp), %rcx
	subq	%r8, %rcx
	jne	.LBB17_18
.LBB17_26:
	cmpq	$0, 256(%rsp)
	movq	80(%rsp), %r8
	je	.LBB17_35
	movabsq	$-2233785415175766016, %rdx
	movq	256(%rsp), %rax
	.p2align	4
.LBB17_28:
	cmpq	$16, %rax
	movl	$16, %edi
	cmovbq	%rax, %rdi
	movq	%rax, 96(%rsp)
	jae	.LBB17_30
	xorl	%ecx, %ecx
	movq	88(%rsp), %rbp
	jmp	.LBB17_31
	.p2align	4
.LBB17_30:
	movl	%edi, %ecx
	andl	$16, %ecx
	movups	(%r8), %xmm0
	xorps	(%rsp), %xmm0
	movaps	%xmm0, (%rsp)
	cmpq	%rcx, %rdi
	movq	88(%rsp), %rbp
	je	.LBB17_32
	.p2align	4
.LBB17_31:
	movzbl	(%r8,%rcx), %esi
	xorb	%sil, (%rsp,%rcx)
	incq	%rcx
	cmpq	%rcx, %rdi
	jne	.LBB17_31
.LBB17_32:
	movq	%r8, 80(%rsp)
	movq	(%rsp), %rax
	bswapq	%rax
	movq	8(%rsp), %r15
	bswapq	%r15
	movl	$129, %r13d
	movq	104(%rsp), %rsi
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	.p2align	4
.LBB17_33:
	leal	-2(%r13), %ecx
	movq	%r15, %r9
	shrdq	%cl, %rax, %r9
	movq	%rax, %r8
	shrq	%cl, %r8
	testb	$64, %cl
	cmoveq	%r9, %r8
	xorl	%r9d, %r9d
	andl	$1, %r8d
	movq	%r8, 112(%rsp)
	xorl	%ecx, %ecx
	subq	112(%rsp), %rcx
	movl	$0, %r8d
	sbbq	%r8, %r8
	andq	%rsi, %r8
	xorq	%r8, %r11
	andq	%rbp, %rcx
	xorq	%rcx, %r10
	movl	%ebp, %ecx
	andl	$1, %ecx
	movq	%rcx, 112(%rsp)
	cmpq	112(%rsp), %r9
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	shrdq	$1, %rsi, %rbp
	shrq	%rsi
	andq	%rdx, %rcx
	xorq	%rcx, %rsi
	decl	%r13d
	cmpl	$1, %r13d
	ja	.LBB17_33
	bswapq	%r11
	bswapq	%r10
	movq	80(%rsp), %r8
	addq	%rdi, %r8
	movq	%r10, 8(%rsp)
	movq	%r11, (%rsp)
	movq	96(%rsp), %rax
	subq	%rdi, %rax
	jne	.LBB17_28
.LBB17_35:
	movq	152(%rsp), %rcx
	movq	256(%rsp), %rsi
	shldq	$3, %rsi, %rcx
	shlq	$3, %rsi
	movq	(%rsp), %rax
	movq	8(%rsp), %rdx
	bswapq	%rdx
	xorq	%rsi, %rdx
	bswapq	%rax
	xorq	%rcx, %rax
	cmpb	$0, 31(%rsp)
	je	.LBB17_37
	bswapq	%rdx
	movq	%rdx, %rcx
	shrq	$4, %rcx
	andq	%rbx, %rcx
	andq	%rbx, %rdx
	shlq	$4, %rdx
	orq	%rcx, %rdx
	movq	%rdx, %rcx
	andq	%r14, %rcx
	shrq	$2, %rdx
	andq	%r14, %rdx
	leaq	(%rdx,%rcx,4), %rcx
	movq	%rcx, %rdx
	andq	%r12, %rdx
	shrq	%rcx
	andq	%r12, %rcx
	leaq	(%rcx,%rdx,2), %rdx
	bswapq	%rax
	movq	%rax, %rcx
	shrq	$4, %rcx
	andq	%rbx, %rcx
	andq	%rbx, %rax
	shlq	$4, %rax
	orq	%rcx, %rax
	movq	%rax, %rcx
	andq	%r14, %rcx
	shrq	$2, %rax
	andq	%r14, %rax
	leaq	(%rax,%rcx,4), %rax
	movq	%rax, %rcx
	andq	%r12, %rcx
	shrq	%rax
	andq	%r12, %rax
	leaq	(%rax,%rcx,2), %rsi
	leaq	32(%rsp), %rdi
	movq	168(%rsp), %rcx
	movq	176(%rsp), %r8
	callq	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414product_native
	movq	48(%rsp), %rdx
	movq	56(%rsp), %rdi
	leaq	(%rdx,%rdx), %rcx
	movq	%rdi, %r8
	movq	%rdi, %r9
	movq	%rdi, %rsi
	movq	%rdi, %r10
	shldq	$2, %rdx, %r10
	movq	%rdi, %rax
	shldq	$7, %rdx, %rax
	xorq	%r10, %rax
	xorq	%rdi, %rax
	movq	%rdi, %r10
	shldq	$1, %rdx, %r10
	xorq	40(%rsp), %r10
	xorq	32(%rsp), %rcx
	shrq	$63, %r8
	shrq	$62, %r9
	xorq	%r8, %r9
	shrq	$57, %rsi
	xorq	%r9, %rsi
	leaq	(,%rdx,4), %r8
	movl	%esi, %edi
	shll	$7, %edi
	xorq	%rdx, %rdi
	shlq	$7, %rdx
	xorq	%r8, %rdx
	leal	(%rsi,%rsi), %r8d
	xorq	%rdx, %r8
	leal	(,%rsi,4), %edx
	xorq	%r8, %rdx
	xorq	%rcx, %rdx
	xorq	%r10, %rax
	xorq	%rsi, %rdi
	xorq	%rdx, %rdi
	bswapq	%rdi
	movq	%rdi, %rcx
	shrq	$4, %rcx
	andq	%rbx, %rcx
	andq	%rbx, %rdi
	shlq	$4, %rdi
	orq	%rcx, %rdi
	movq	%rdi, %rcx
	andq	%r14, %rcx
	shrq	$2, %rdi
	andq	%r14, %rdi
	leaq	(%rdi,%rcx,4), %rcx
	movq	%rcx, %rdx
	andq	%r12, %rdx
	shrq	%rcx
	andq	%r12, %rcx
	leaq	(%rcx,%rdx,2), %r15
	bswapq	%rax
	movq	%rax, %rcx
	shrq	$4, %rcx
	andq	%rbx, %rcx
	andq	%rbx, %rax
	shlq	$4, %rax
	orq	%rcx, %rax
	movq	%rax, %rcx
	andq	%r14, %rcx
	shrq	$2, %rax
	andq	%r14, %rax
	leaq	(%rax,%rcx,4), %rax
	movq	%rax, %rcx
	andq	%r12, %rcx
	shrq	%rax
	andq	%r12, %rax
	leaq	(%rax,%rcx,2), %rbx
	movq	144(%rsp), %r11
	jmp	.LBB17_39
.LBB17_37:
	movl	$129, %esi
	xorl	%edi, %edi
	movabsq	$-2233785415175766016, %r8
	xorl	%ebx, %ebx
	xorl	%r15d, %r15d
	movq	144(%rsp), %r11
	movq	104(%rsp), %r14
	movq	88(%rsp), %r12
	.p2align	4
.LBB17_38:
	leal	-2(%rsi), %ecx
	movq	%rdx, %r9
	shrdq	%cl, %rax, %r9
	movq	%rax, %r10
	shrq	%cl, %r10
	testb	$64, %cl
	cmoveq	%r9, %r10
	andl	$1, %r10d
	movq	%r10, 32(%rsp)
	xorl	%ecx, %ecx
	subq	32(%rsp), %rcx
	movl	$0, %r9d
	sbbq	%r9, %r9
	andq	%r14, %r9
	xorq	%r9, %r15
	andq	%r12, %rcx
	xorq	%rcx, %rbx
	movl	%r12d, %ecx
	andl	$1, %ecx
	movq	%rcx, 32(%rsp)
	cmpq	32(%rsp), %rdi
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	shrdq	$1, %r14, %r12
	shrq	%r14
	andq	%r8, %rcx
	xorq	%rcx, %r14
	decl	%esi
	cmpl	$1, %esi
	ja	.LBB17_38
.LBB17_39:
	bswapq	%r15
	bswapq	%rbx
	movq	%rbx, 8(%rsp)
	movq	%r15, (%rsp)
	movb	$0, 46(%rsp)
	movw	$0, 44(%rsp)
	movq	(%r11), %rax
	movq	%rax, 32(%rsp)
	movl	8(%r11), %eax
	movl	%eax, 40(%rsp)
	movb	$1, 47(%rsp)
	movq	160(%rsp), %rdi
	addq	$16, %rdi
.Ltmp3:
	leaq	32(%rsp), %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt
.Ltmp4:
	movq	%rbx, %rdx
	shldq	$56, %r15, %rdx
	movq	%rbx, %r8
	shldq	$48, %r15, %r8
	movq	%rbx, %r9
	shldq	$40, %r15, %r9
	movq	%rbx, %r10
	shldq	$32, %r15, %r10
	movq	%rbx, %r11
	shldq	$24, %r15, %r11
	movq	%rbx, %r14
	shldq	$16, %r15, %r14
	movq	%rbx, %r12
	shldq	$8, %r15, %r12
	movq	%rbx, %rax
	shrq	$32, %rax
	movq	%rbx, %rcx
	shrq	$40, %rcx
	movq	%rbx, %rsi
	shrq	$48, %rsi
	movq	%rbx, %rdi
	shrq	$56, %rdi
	movq	%r12, %xmm0
	movq	%r14, %xmm1
	punpcklbw	%xmm0, %xmm1
	psllq	$48, %xmm1
	movdqa	.LCPI17_0(%rip), %xmm0
	movq	%r11, %xmm2
	movq	%r10, %xmm3
	punpcklbw	%xmm2, %xmm3
	pshufd	$80, %xmm3, %xmm2
	pand	%xmm0, %xmm2
	pandn	%xmm1, %xmm0
	por	%xmm2, %xmm0
	pshufd	$85, %xmm0, %xmm1
	movq	%r9, %xmm0
	movq	%r8, %xmm2
	punpcklbw	%xmm0, %xmm2
	pslld	$16, %xmm2
	movdqa	.LCPI17_1(%rip), %xmm0
	movq	%rdx, %xmm3
	movq	%r15, %xmm4
	punpcklbw	%xmm3, %xmm4
	pand	%xmm0, %xmm4
	pandn	%xmm2, %xmm0
	por	%xmm4, %xmm0
	punpckldq	%xmm1, %xmm0
	movd	%edi, %xmm1
	movd	%esi, %xmm2
	punpcklbw	%xmm1, %xmm2
	movd	%ecx, %xmm1
	movd	%eax, %xmm3
	punpcklbw	%xmm1, %xmm3
	pshufd	$0, %xmm3, %xmm1
	pand	.LCPI17_2(%rip), %xmm1
	pslldq	$14, %xmm2
	por	%xmm2, %xmm1
	movq	%rbx, %xmm2
	movdqa	%xmm2, %xmm3
	psrlq	$24, %xmm3
	movdqa	%xmm2, %xmm4
	psrlq	$16, %xmm4
	punpcklbw	%xmm3, %xmm4
	pslldq	$10, %xmm4
	movdqa	.LCPI17_3(%rip), %xmm3
	movdqa	%xmm2, %xmm5
	psrlq	$8, %xmm5
	punpcklbw	%xmm5, %xmm2
	pshufd	$68, %xmm2, %xmm2
	pand	%xmm3, %xmm2
	pandn	%xmm4, %xmm3
	por	%xmm2, %xmm3
	pshufd	$170, %xmm3, %xmm2
	punpckhdq	%xmm1, %xmm2
	movsd	%xmm0, %xmm2
	xorpd	32(%rsp), %xmm2
	movapd	%xmm2, (%rsp)
	movq	184(%rsp), %rax
	movupd	%xmm2, (%rax)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	#MEMBARRIER
	addq	$200, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB17_41:
	.cfi_def_cfa_offset 256
.Ltmp5:
	movq	%rax, %rbx
	leaq	32(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end17:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3tag, .Lfunc_end17-_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3tag
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3tag,"a",@progbits
	.p2align	2, 0x0
GCC_except_table17:
.Lexception1:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end1-.Lcst_begin1
.Lcst_begin1:
	.uleb128 .Ltmp3-.Lfunc_begin1
	.uleb128 .Ltmp4-.Ltmp3
	.uleb128 .Ltmp5-.Lfunc_begin1
	.byte	0
	.uleb128 .Ltmp4-.Lfunc_begin1
	.uleb128 .Lfunc_end17-.Ltmp4
	.byte	0
	.byte	0
.Lcst_end1:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3xor,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3xor,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3xor:
.Lfunc_begin2:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception2
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %rbx
	movq	%rdx, %r14
	movq	%rsi, %r15
	leaq	16(%rdi), %r12
	cmpb	$1, 264(%rdi)
	jne	.LBB18_3
	movq	256(%rdi), %rsi
	movq	%r12, %rdi
	movq	%r15, %rdx
	movq	%r14, %rcx
	movq	%rbx, %r8
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmp	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_643ctr
.LBB18_3:
	.cfi_def_cfa_offset 80
	testq	%rbx, %rbx
	je	.LBB18_11
	xorl	%ebp, %ebp
	jmp	.LBB18_6
	.p2align	4
.LBB18_5:
	addq	%r13, %r14
	subq	%r13, %rbx
	incl	%ebp
	testq	%rbx, %rbx
	je	.LBB18_11
.LBB18_6:
	cmpq	$16, %rbx
	movl	$16, %r13d
	cmovbq	%rbx, %r13
	movl	8(%r15), %eax
	movl	%eax, 8(%rsp)
	movq	(%r15), %rax
	movq	%rax, (%rsp)
	leal	2(%rbp), %eax
	bswapl	%eax
	movl	%eax, 12(%rsp)
.Ltmp6:
	movq	%r12, %rdi
	movq	%rsp, %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt
.Ltmp7:
	cmpq	$16, %rbx
	jae	.LBB18_12
	xorl	%eax, %eax
	jmp	.LBB18_9
	.p2align	4
.LBB18_12:
	movl	%r13d, %eax
	andl	$16, %eax
	movups	(%r14), %xmm0
	xorps	(%rsp), %xmm0
	movups	%xmm0, (%r14)
	jmp	.LBB18_10
	.p2align	4
.LBB18_9:
	movzbl	(%rsp,%rax), %ecx
	xorb	%cl, (%r14,%rax)
	incq	%rax
.LBB18_10:
	cmpq	%rax, %r13
	jne	.LBB18_9
	jmp	.LBB18_5
.LBB18_11:
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	#MEMBARRIER
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB18_2:
	.cfi_def_cfa_offset 80
.Ltmp8:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end18:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3xor, .Lfunc_end18-_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3xor
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3xor,"a",@progbits
	.p2align	2, 0x0
GCC_except_table18:
.Lexception2:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end2-.Lcst_begin2
.Lcst_begin2:
	.uleb128 .Ltmp6-.Lfunc_begin2
	.uleb128 .Ltmp7-.Ltmp6
	.uleb128 .Ltmp8-.Lfunc_begin2
	.byte	0
	.uleb128 .Ltmp7-.Lfunc_begin2
	.uleb128 .Lfunc_end18-.Ltmp7
	.byte	0
	.byte	0
.Lcst_end2:
	.p2align	2, 0x0

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI19_0:
	.long	1779033703
	.long	3144134277
	.long	1013904242
	.long	2773480762
.LCPI19_1:
	.long	1359893119
	.long	2600822924
	.long	528734635
	.long	1541459225
	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest:
.Lfunc_begin3:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception3
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$512, %rsp
	.cfi_def_cfa_offset 560
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rcx, %r14
	movq	%rdx, %r15
	movq	%rdi, %rbx
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 272(%rsp)
	movaps	%xmm0, 256(%rsp)
	movaps	%xmm0, 240(%rsp)
	movaps	%xmm0, 224(%rsp)
	testb	%sil, %sil
	je	.LBB19_8
	movzbl	%sil, %eax
	cmpl	$1, %eax
	jne	.LBB19_21
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movabsq	$-3766243637369397544, %rax
	movq	%rax, 128(%rsp)
	movabsq	$7105036623409894663, %rax
	movq	%rax, 136(%rsp)
	movabsq	$-7973340178411365097, %rax
	movq	%rax, 144(%rsp)
	movabsq	$1526699215303891257, %rax
	movq	%rax, 152(%rsp)
	movabsq	$7436329637833083697, %rax
	movq	%rax, 160(%rsp)
	movabsq	$-8163818279084223215, %rax
	movq	%rax, 168(%rsp)
	movabsq	$-2662702644619276377, %rax
	movq	%rax, 176(%rsp)
	movabsq	$5167115440072839076, %rax
	movq	%rax, 184(%rsp)
	movaps	%xmm0, 192(%rsp)
	movq	$0, 208(%rsp)
	shlq	$4, %r14
	movq	%rsp, %r12
	movq	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update@GOTPCREL(%rip), %r13
	.p2align	4
.LBB19_3:
	testq	%r14, %r14
	je	.LBB19_16
	movq	(%r15), %rsi
	movq	8(%r15), %rdx
.Ltmp12:
	movq	%r12, %rdi
	callq	*%r13
.Ltmp13:
	addq	$16, %r15
	addq	$-16, %r14
	cmpb	$-1, %al
	je	.LBB19_3
	movw	$1, (%rbx)
	xorl	%eax, %eax
	.p2align	4
.LBB19_7:
	movb	$0, (%rsp,%rax)
	movb	$0, 1(%rsp,%rax)
	movb	$0, 2(%rsp,%rax)
	movb	$0, 3(%rsp,%rax)
	movb	$0, 4(%rsp,%rax)
	movb	$0, 5(%rsp,%rax)
	movb	$0, 6(%rsp,%rax)
	movb	$0, 7(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB19_7
	jmp	.LBB19_27
.LBB19_8:
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movaps	.LCPI19_0(%rip), %xmm1
	movaps	%xmm1, 64(%rsp)
	movaps	.LCPI19_1(%rip), %xmm1
	movaps	%xmm1, 80(%rsp)
	movaps	%xmm0, 96(%rsp)
	movq	$0, 112(%rsp)
	shlq	$4, %r14
	movq	%rsp, %r12
	movq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update@GOTPCREL(%rip), %r13
	.p2align	4
.LBB19_9:
	testq	%r14, %r14
	je	.LBB19_13
	movq	(%r15), %rsi
	movq	8(%r15), %rdx
.Ltmp15:
	movq	%r12, %rdi
	callq	*%r13
.Ltmp16:
	addq	$16, %r15
	addq	$-16, %r14
	cmpb	$-1, %al
	je	.LBB19_9
	movw	$1, (%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	movl	$0, 64(%rsp)
	movl	$0, 68(%rsp)
	movl	$0, 72(%rsp)
	movl	$0, 76(%rsp)
	movl	$0, 80(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 92(%rsp)
	jmp	.LBB19_28
.LBB19_21:
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movabsq	$7640891576956012808, %rax
	movq	%rax, 128(%rsp)
	movabsq	$-4942790177534073029, %rax
	movq	%rax, 136(%rsp)
	movabsq	$4354685564936845355, %rax
	movq	%rax, 144(%rsp)
	movabsq	$-6534734903238641935, %rax
	movq	%rax, 152(%rsp)
	movabsq	$5840696475078001361, %rax
	movq	%rax, 160(%rsp)
	movabsq	$-7276294671716946913, %rax
	movq	%rax, 168(%rsp)
	movabsq	$2270897969802886507, %rax
	movq	%rax, 176(%rsp)
	movabsq	$6620516959819538809, %rax
	movq	%rax, 184(%rsp)
	movaps	%xmm0, 192(%rsp)
	movq	$0, 208(%rsp)
	shlq	$4, %r14
	movq	%rsp, %r12
	movq	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update@GOTPCREL(%rip), %r13
	.p2align	4
.LBB19_22:
	testq	%r14, %r14
	je	.LBB19_32
	movq	(%r15), %rsi
	movq	8(%r15), %rdx
.Ltmp9:
	movq	%r12, %rdi
	callq	*%r13
.Ltmp10:
	addq	$16, %r15
	addq	$-16, %r14
	cmpb	$-1, %al
	je	.LBB19_22
	movw	$1, (%rbx)
	xorl	%eax, %eax
	.p2align	4
.LBB19_26:
	movb	$0, (%rsp,%rax)
	movb	$0, 1(%rsp,%rax)
	movb	$0, 2(%rsp,%rax)
	movb	$0, 3(%rsp,%rax)
	movb	$0, 4(%rsp,%rax)
	movb	$0, 5(%rsp,%rax)
	movb	$0, 6(%rsp,%rax)
	movb	$0, 7(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB19_26
.LBB19_27:
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
.LBB19_28:
	#MEMBARRIER
	jmp	.LBB19_29
.LBB19_16:
	leaq	288(%rsp), %r14
	movq	%rsp, %rsi
	movl	$224, %edx
	movq	%r14, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	leaq	224(%rsp), %rdi
	movq	%r14, %rsi
	callq	*_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize@GOTPCREL(%rip)
	jmp	.LBB19_14
.LBB19_13:
	movaps	112(%rsp), %xmm0
	movaps	%xmm0, 400(%rsp)
	movaps	96(%rsp), %xmm0
	movaps	%xmm0, 384(%rsp)
	movaps	80(%rsp), %xmm0
	movaps	%xmm0, 368(%rsp)
	movaps	64(%rsp), %xmm0
	movaps	%xmm0, 352(%rsp)
	movaps	(%rsp), %xmm0
	movaps	16(%rsp), %xmm1
	movaps	32(%rsp), %xmm2
	movaps	48(%rsp), %xmm3
	movaps	%xmm3, 336(%rsp)
	movaps	%xmm2, 320(%rsp)
	movaps	%xmm1, 304(%rsp)
	movaps	%xmm0, 288(%rsp)
	leaq	224(%rsp), %rdi
	leaq	288(%rsp), %rsi
	callq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize@GOTPCREL(%rip)
	jmp	.LBB19_14
.LBB19_32:
	leaq	288(%rsp), %r14
	movq	%rsp, %rsi
	movl	$224, %edx
	movq	%r14, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	leaq	224(%rsp), %rdi
	movq	%r14, %rsi
	callq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize@GOTPCREL(%rip)
.LBB19_14:
	movaps	224(%rsp), %xmm0
	movaps	240(%rsp), %xmm1
	movaps	256(%rsp), %xmm2
	movaps	272(%rsp), %xmm3
	movups	%xmm3, 49(%rbx)
	movups	%xmm2, 33(%rbx)
	movups	%xmm1, 17(%rbx)
	movups	%xmm0, 1(%rbx)
	movb	$0, (%rbx)
.LBB19_29:
	addq	$512, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB19_30:
	.cfi_def_cfa_offset 560
.Ltmp11:
	movq	%rax, %rbx
	xorl	%eax, %eax
	.p2align	4
.LBB19_31:
	movb	$0, (%rsp,%rax)
	movb	$0, 1(%rsp,%rax)
	movb	$0, 2(%rsp,%rax)
	movb	$0, 3(%rsp,%rax)
	movb	$0, 4(%rsp,%rax)
	movb	$0, 5(%rsp,%rax)
	movb	$0, 6(%rsp,%rax)
	movb	$0, 7(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB19_31
	jmp	.LBB19_19
.LBB19_15:
.Ltmp17:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB19_17:
.Ltmp14:
	movq	%rax, %rbx
	xorl	%eax, %eax
	.p2align	4
.LBB19_18:
	movb	$0, (%rsp,%rax)
	movb	$0, 1(%rsp,%rax)
	movb	$0, 2(%rsp,%rax)
	movb	$0, 3(%rsp,%rax)
	movb	$0, 4(%rsp,%rax)
	movb	$0, 5(%rsp,%rax)
	movb	$0, 6(%rsp,%rax)
	movb	$0, 7(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB19_18
.LBB19_19:
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end19:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest, .Lfunc_end19-_RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest,"a",@progbits
	.p2align	2, 0x0
GCC_except_table19:
.Lexception3:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end3-.Lcst_begin3
.Lcst_begin3:
	.uleb128 .Ltmp12-.Lfunc_begin3
	.uleb128 .Ltmp13-.Ltmp12
	.uleb128 .Ltmp14-.Lfunc_begin3
	.byte	0
	.uleb128 .Ltmp15-.Lfunc_begin3
	.uleb128 .Ltmp16-.Ltmp15
	.uleb128 .Ltmp17-.Lfunc_begin3
	.byte	0
	.uleb128 .Ltmp9-.Lfunc_begin3
	.uleb128 .Ltmp10-.Ltmp9
	.uleb128 .Ltmp11-.Lfunc_begin3
	.byte	0
	.uleb128 .Ltmp10-.Lfunc_begin3
	.uleb128 .Lfunc_end19-.Ltmp10
	.byte	0
	.byte	0
.Lcst_end3:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3new,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3new,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3new:
	.cfi_startproc
	movzbl	(%rsi), %eax
	movb	%al, -19(%rsp)
	movzbl	1(%rsi), %eax
	movb	%al, -20(%rsp)
	movzbl	2(%rsi), %eax
	movb	%al, -21(%rsp)
	movzbl	3(%rsi), %eax
	movb	%al, -22(%rsp)
	movzbl	4(%rsi), %eax
	movb	%al, -23(%rsp)
	movzbl	5(%rsi), %eax
	movb	%al, -24(%rsp)
	movzbl	6(%rsi), %eax
	movb	%al, -25(%rsp)
	movzbl	7(%rsi), %eax
	movb	%al, -26(%rsp)
	movzbl	8(%rsi), %eax
	movb	%al, -27(%rsp)
	movzbl	9(%rsi), %eax
	movb	%al, -28(%rsp)
	movzbl	10(%rsi), %eax
	movb	%al, -29(%rsp)
	movzbl	11(%rsi), %eax
	movb	%al, -30(%rsp)
	movzbl	12(%rsi), %eax
	movb	%al, -31(%rsp)
	movzbl	13(%rsi), %eax
	movb	%al, -32(%rsp)
	movzbl	14(%rsi), %eax
	movb	%al, -33(%rsp)
	movzbl	15(%rsi), %eax
	movb	%al, -34(%rsp)
	movzbl	16(%rsi), %eax
	movb	%al, -35(%rsp)
	movzbl	17(%rsi), %eax
	movb	%al, -36(%rsp)
	movzbl	18(%rsi), %eax
	movb	%al, -37(%rsp)
	movzbl	19(%rsi), %eax
	movb	%al, -38(%rsp)
	movzbl	20(%rsi), %eax
	movb	%al, -39(%rsp)
	movzbl	21(%rsi), %eax
	movb	%al, -40(%rsp)
	movzbl	22(%rsi), %eax
	movb	%al, -41(%rsp)
	movzbl	23(%rsi), %eax
	movb	%al, -42(%rsp)
	movzbl	24(%rsi), %eax
	movb	%al, -43(%rsp)
	movzbl	25(%rsi), %eax
	movb	%al, -44(%rsp)
	movzbl	26(%rsi), %eax
	movb	%al, -45(%rsp)
	movzbl	27(%rsi), %eax
	movb	%al, -46(%rsp)
	movzbl	28(%rsi), %eax
	movb	%al, -47(%rsp)
	movzbl	29(%rsi), %eax
	movb	%al, -48(%rsp)
	movzbl	30(%rsi), %eax
	movb	%al, -49(%rsp)
	movzbl	31(%rsi), %eax
	movb	%al, -50(%rsp)
	movzbl	32(%rsi), %eax
	movb	%al, -51(%rsp)
	movzbl	33(%rsi), %eax
	movb	%al, -52(%rsp)
	movzbl	34(%rsi), %eax
	movb	%al, -53(%rsp)
	movzbl	35(%rsi), %eax
	movb	%al, -54(%rsp)
	movzbl	36(%rsi), %eax
	movb	%al, -55(%rsp)
	movzbl	37(%rsi), %eax
	movb	%al, -56(%rsp)
	movzbl	38(%rsi), %eax
	movb	%al, -57(%rsp)
	movzbl	39(%rsi), %eax
	movb	%al, -58(%rsp)
	movzbl	40(%rsi), %eax
	movb	%al, -59(%rsp)
	movzbl	41(%rsi), %eax
	movb	%al, -60(%rsp)
	movzbl	42(%rsi), %eax
	movb	%al, -61(%rsp)
	movzbl	43(%rsi), %eax
	movb	%al, -62(%rsp)
	movzbl	44(%rsi), %eax
	movb	%al, -63(%rsp)
	movzbl	45(%rsi), %eax
	movb	%al, -64(%rsp)
	movzbl	-19(%rsp), %eax
	movb	%al, (%rdi)
	movzbl	-20(%rsp), %eax
	movb	%al, 1(%rdi)
	movzbl	-21(%rsp), %eax
	movb	%al, 2(%rdi)
	movzbl	-22(%rsp), %eax
	movb	%al, 3(%rdi)
	movzbl	-23(%rsp), %eax
	movb	%al, 4(%rdi)
	movzbl	-24(%rsp), %eax
	movb	%al, 5(%rdi)
	movzbl	-25(%rsp), %eax
	movb	%al, 6(%rdi)
	movzbl	-26(%rsp), %eax
	movb	%al, 7(%rdi)
	movzbl	-27(%rsp), %eax
	movb	%al, 8(%rdi)
	movzbl	-28(%rsp), %eax
	movb	%al, 9(%rdi)
	movzbl	-29(%rsp), %eax
	movb	%al, 10(%rdi)
	movzbl	-30(%rsp), %eax
	movb	%al, 11(%rdi)
	movzbl	-31(%rsp), %eax
	movb	%al, 12(%rdi)
	movzbl	-32(%rsp), %eax
	movb	%al, 13(%rdi)
	movzbl	-33(%rsp), %eax
	movb	%al, 14(%rdi)
	movzbl	-34(%rsp), %eax
	movb	%al, 15(%rdi)
	movzbl	-35(%rsp), %eax
	movb	%al, 16(%rdi)
	movzbl	-36(%rsp), %eax
	movb	%al, 17(%rdi)
	movzbl	-37(%rsp), %eax
	movb	%al, 18(%rdi)
	movzbl	-38(%rsp), %eax
	movb	%al, 19(%rdi)
	movzbl	-39(%rsp), %eax
	movb	%al, 20(%rdi)
	movzbl	-40(%rsp), %eax
	movb	%al, 21(%rdi)
	movzbl	-41(%rsp), %eax
	movb	%al, 22(%rdi)
	movzbl	-42(%rsp), %eax
	movb	%al, 23(%rdi)
	movzbl	-43(%rsp), %eax
	movb	%al, 24(%rdi)
	movzbl	-44(%rsp), %eax
	movb	%al, 25(%rdi)
	movzbl	-45(%rsp), %eax
	movb	%al, 26(%rdi)
	movzbl	-46(%rsp), %eax
	movb	%al, 27(%rdi)
	movzbl	-47(%rsp), %eax
	movb	%al, 28(%rdi)
	movzbl	-48(%rsp), %eax
	movb	%al, 29(%rdi)
	movzbl	-49(%rsp), %eax
	movb	%al, 30(%rdi)
	movzbl	-50(%rsp), %eax
	movb	%al, 31(%rdi)
	movzbl	-51(%rsp), %eax
	movb	%al, 32(%rdi)
	movzbl	-52(%rsp), %eax
	movb	%al, 33(%rdi)
	movzbl	-53(%rsp), %eax
	movb	%al, 34(%rdi)
	movzbl	-54(%rsp), %eax
	movb	%al, 35(%rdi)
	movzbl	-55(%rsp), %eax
	movb	%al, 36(%rdi)
	movzbl	-56(%rsp), %eax
	movb	%al, 37(%rdi)
	movzbl	-57(%rsp), %eax
	movb	%al, 38(%rdi)
	movzbl	-58(%rsp), %eax
	movb	%al, 39(%rdi)
	movzbl	-59(%rsp), %eax
	movb	%al, 40(%rdi)
	movzbl	-60(%rsp), %eax
	movb	%al, 41(%rdi)
	movzbl	-61(%rsp), %eax
	movb	%al, 42(%rdi)
	movzbl	-62(%rsp), %eax
	movb	%al, 43(%rdi)
	movzbl	-63(%rsp), %eax
	movb	%al, 44(%rdi)
	movzbl	-64(%rsp), %eax
	movb	%al, 45(%rdi)
	movzbl	46(%rsi), %eax
	movb	%al, -1(%rsp)
	movb	%al, 46(%rdi)
	movzbl	47(%rsi), %eax
	movb	%al, -2(%rsp)
	movb	%al, 47(%rdi)
	movzbl	48(%rsi), %eax
	movb	%al, -3(%rsp)
	movb	%al, 48(%rdi)
	movzbl	49(%rsi), %eax
	movb	%al, -4(%rsp)
	movb	%al, 49(%rdi)
	movzbl	50(%rsi), %eax
	movb	%al, -5(%rsp)
	movb	%al, 50(%rdi)
	movzbl	51(%rsi), %eax
	movb	%al, -6(%rsp)
	movb	%al, 51(%rdi)
	movzbl	52(%rsi), %eax
	movb	%al, -7(%rsp)
	movb	%al, 52(%rdi)
	movzbl	53(%rsi), %eax
	movb	%al, -8(%rsp)
	movb	%al, 53(%rdi)
	movzbl	54(%rsi), %eax
	movb	%al, -9(%rsp)
	movb	%al, 54(%rdi)
	movzbl	55(%rsi), %eax
	movb	%al, -10(%rsp)
	movb	%al, 55(%rdi)
	movzbl	56(%rsi), %eax
	movb	%al, -11(%rsp)
	movb	%al, 56(%rdi)
	movzbl	57(%rsi), %eax
	movb	%al, -12(%rsp)
	movb	%al, 57(%rdi)
	movzbl	58(%rsi), %eax
	movb	%al, -13(%rsp)
	movb	%al, 58(%rdi)
	movzbl	59(%rsi), %eax
	movb	%al, -14(%rsp)
	movb	%al, 59(%rdi)
	movzbl	60(%rsi), %eax
	movb	%al, -15(%rsp)
	movb	%al, 60(%rdi)
	movzbl	61(%rsi), %eax
	movb	%al, -16(%rsp)
	movb	%al, 61(%rdi)
	movzbl	62(%rsi), %eax
	movb	%al, -17(%rsp)
	movb	%al, 62(%rdi)
	movzbl	63(%rsi), %eax
	movb	%al, -18(%rsp)
	movb	%al, 63(%rdi)
	movb	$0, -19(%rsp)
	movb	$0, -20(%rsp)
	movb	$0, -21(%rsp)
	movb	$0, -22(%rsp)
	movb	$0, -23(%rsp)
	movb	$0, -24(%rsp)
	movb	$0, -25(%rsp)
	movb	$0, -26(%rsp)
	movb	$0, -27(%rsp)
	movb	$0, -28(%rsp)
	movb	$0, -29(%rsp)
	movb	$0, -30(%rsp)
	movb	$0, -31(%rsp)
	movb	$0, -32(%rsp)
	movb	$0, -33(%rsp)
	movb	$0, -34(%rsp)
	movb	$0, -35(%rsp)
	movb	$0, -36(%rsp)
	movb	$0, -37(%rsp)
	movb	$0, -38(%rsp)
	movb	$0, -39(%rsp)
	movb	$0, -40(%rsp)
	movb	$0, -41(%rsp)
	movb	$0, -42(%rsp)
	movb	$0, -43(%rsp)
	movb	$0, -44(%rsp)
	movb	$0, -45(%rsp)
	movb	$0, -46(%rsp)
	movb	$0, -47(%rsp)
	movb	$0, -48(%rsp)
	movb	$0, -49(%rsp)
	movb	$0, -50(%rsp)
	movb	$0, -51(%rsp)
	movb	$0, -52(%rsp)
	movb	$0, -53(%rsp)
	movb	$0, -54(%rsp)
	movb	$0, -55(%rsp)
	movb	$0, -56(%rsp)
	movb	$0, -57(%rsp)
	movb	$0, -58(%rsp)
	movb	$0, -59(%rsp)
	movb	$0, -60(%rsp)
	movb	$0, -61(%rsp)
	movb	$0, -62(%rsp)
	movb	$0, -63(%rsp)
	movb	$0, -64(%rsp)
	movb	$0, -1(%rsp)
	movb	$0, -2(%rsp)
	movb	$0, -3(%rsp)
	movb	$0, -4(%rsp)
	movb	$0, -5(%rsp)
	movb	$0, -6(%rsp)
	movb	$0, -7(%rsp)
	movb	$0, -8(%rsp)
	movb	$0, -9(%rsp)
	movb	$0, -10(%rsp)
	movb	$0, -11(%rsp)
	movb	$0, -12(%rsp)
	movb	$0, -13(%rsp)
	movb	$0, -14(%rsp)
	movb	$0, -15(%rsp)
	movb	$0, -16(%rsp)
	movb	$0, -17(%rsp)
	movb	$0, -18(%rsp)
	#MEMBARRIER
	retq
.Lfunc_end20:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3new, .Lfunc_end20-_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3new
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI21_0:
	.quad	67108863
	.quad	67108863
	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3tag,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3tag,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3tag:
.Lfunc_begin4:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception4
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$360, %rsp
	.cfi_def_cfa_offset 416
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r9, 216(%rsp)
	movq	%r8, 208(%rsp)
	movq	%rcx, %r12
	movq	%rdi, 200(%rsp)
	bswapl	%edx
	movups	.Lanon.65f595193a40e4134698b8f1074b12b6.79(%rip), %xmm0
	movaps	%xmm0, 80(%rsp)
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm1, 112(%rsp)
	movq	$0, 128(%rsp)
	movl	$0, 136(%rsp)
	movl	%edx, 140(%rsp)
	leaq	2(%rsp), %rdi
	leaq	80(%rsp), %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds
	movl	$0, 80(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 92(%rsp)
	movl	$0, 96(%rsp)
	movl	$0, 100(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	#MEMBARRIER
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 256(%rsp)
	movzwl	2(%rsp), %r9d
	movzbl	4(%rsp), %eax
	movzbl	6(%rsp), %r8d
	movzbl	7(%rsp), %edi
	movzbl	8(%rsp), %esi
	movzbl	5(%rsp), %r11d
	movzbl	9(%rsp), %ebp
	movzbl	10(%rsp), %edx
	movzwl	11(%rsp), %r13d
	shll	$8, %r13d
	movzbl	13(%rsp), %r10d
	movzbl	14(%rsp), %ebx
	movzbl	15(%rsp), %ecx
	movzbl	16(%rsp), %r14d
	movzbl	17(%rsp), %r15d
	andb	$15, %r11b
	andb	$15, %bpl
	andb	$15, %r10b
	andb	$15, %r15b
	movzbl	%r15b, %r15d
	shlq	$56, %r15
	shlq	$48, %r14
	orq	%r15, %r14
	shlq	$40, %rcx
	orq	%r14, %rcx
	andl	$-4, %ebx
	shlq	$32, %rbx
	movzbl	%r10b, %r10d
	shll	$24, %r10d
	orq	%rbx, %r10
	orq	%r13, %r10
	andl	$-4, %edx
	movzbl	%bpl, %ebx
	shlq	$56, %rbx
	shlq	$48, %rsi
	orq	%rbx, %rsi
	shlq	$40, %rdi
	andl	$-4, %r8d
	shlq	$32, %r8
	movzbl	%r11b, %r11d
	shll	$24, %r11d
	shll	$16, %eax
	orq	%r9, %rax
	orq	%r11, %rax
	orq	%r8, %rax
	orq	%rdi, %rax
	movups	18(%rsp), %xmm1
	movaps	%xmm1, 240(%rsp)
	movups	%xmm0, 328(%rsp)
	movups	%xmm0, 312(%rsp)
	movq	$0, 344(%rsp)
	orq	%rcx, %r10
	shrq	$40, %rcx
	orq	%r10, %rdx
	orq	%rsi, %rax
	movl	%eax, %edi
	andl	$67108863, %edi
	shrq	$26, %rax
	shldq	$12, %rsi, %rdx
	andl	$67108863, %eax
	movq	%r10, %xmm0
	psrlq	$14, %xmm0
	movq	%rdx, %xmm1
	punpcklqdq	%xmm0, %xmm1
	pand	.LCPI21_0(%rip), %xmm1
	movq	%rdi, 272(%rsp)
	movq	%rax, 280(%rsp)
	movdqa	%xmm1, 288(%rsp)
	movq	%rcx, 304(%rsp)
	movq	$0, 352(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 224(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 66(%rsp)
	#MEMBARRIER
.Ltmp18:
	leaq	240(%rsp), %rdi
	movl	$4, %edx
	movq	%r12, %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
.Ltmp19:
.Ltmp20:
	leaq	240(%rsp), %rdi
	movq	208(%rsp), %rsi
	movq	216(%rsp), %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
.Ltmp21:
	movq	352(%rsp), %rax
	movq	%rax, 192(%rsp)
	movaps	336(%rsp), %xmm0
	movaps	%xmm0, 176(%rsp)
	movaps	320(%rsp), %xmm0
	movaps	%xmm0, 160(%rsp)
	movaps	304(%rsp), %xmm0
	movaps	%xmm0, 144(%rsp)
	movaps	240(%rsp), %xmm0
	movaps	256(%rsp), %xmm1
	movaps	272(%rsp), %xmm2
	movaps	288(%rsp), %xmm3
	movaps	%xmm3, 128(%rsp)
	movaps	%xmm2, 112(%rsp)
	movaps	%xmm1, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
.Ltmp23:
	leaq	224(%rsp), %rdi
	leaq	80(%rsp), %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056finish
.Ltmp24:
	movups	224(%rsp), %xmm0
	movq	200(%rsp), %rax
	movups	%xmm0, (%rax)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	#MEMBARRIER
	addq	$360, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB21_6:
	.cfi_def_cfa_offset 416
.Ltmp25:
	movq	%rax, %rbx
	leaq	2(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB21_4:
.Ltmp22:
	movq	%rax, %rbx
	leaq	240(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto8poly13058Poly1305EBF_
	leaq	2(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end21:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3tag, .Lfunc_end21-_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3tag
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3tag,"a",@progbits
	.p2align	2, 0x0
GCC_except_table21:
.Lexception4:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end4-.Lcst_begin4
.Lcst_begin4:
	.uleb128 .Ltmp18-.Lfunc_begin4
	.uleb128 .Ltmp21-.Ltmp18
	.uleb128 .Ltmp22-.Lfunc_begin4
	.byte	0
	.uleb128 .Ltmp23-.Lfunc_begin4
	.uleb128 .Ltmp24-.Ltmp23
	.uleb128 .Ltmp25-.Lfunc_begin4
	.byte	0
	.uleb128 .Ltmp24-.Lfunc_begin4
	.uleb128 .Lfunc_end21-.Ltmp24
	.byte	0
	.byte	0
.Lcst_end4:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm,"ax",@progbits
	.globl	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm:
.Lfunc_begin5:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception5
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$568, %rsp
	.cfi_def_cfa_offset 608
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r14
	movq	%rdi, %rbx
	movups	(%rsi), %xmm0
	movaps	%xmm0, (%rsp)
.Ltmp26:
	leaq	32(%rsp), %rdi
	movl	$16, %edx
	movl	$10, %ecx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand
.Ltmp27:
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 16(%rsp)
.Ltmp29:
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt
.Ltmp30:
	leaq	304(%rsp), %rdi
	leaq	32(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r15
	movl	$256, %edx
	callq	*%r15
	movaps	16(%rsp), %xmm0
	movaps	%xmm0, 288(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	movl	%ecx, %ebp
	shrb	%bpl
	andb	$1, %bpl
	leaq	288(%rsp), %rsi
	movl	$272, %edx
	movq	%rbx, %rdi
	callq	*%r15
	movb	%bpl, 272(%rbx)
	movq	(%r14), %rax
	movq	%rax, 288(%rbx)
	movl	8(%r14), %eax
	movl	%eax, 296(%rbx)
	movq	$0, 280(%rbx)
	movb	$0, 300(%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$568, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB22_3:
	.cfi_def_cfa_offset 608
.Ltmp31:
	movq	%rax, %rbx
	leaq	16(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movl	$7, %eax
	.p2align	4
.LBB22_4:
	movb	$0, 25(%rsp,%rax)
	movb	$0, 26(%rsp,%rax)
	movb	$0, 27(%rsp,%rax)
	movb	$0, 28(%rsp,%rax)
	movb	$0, 29(%rsp,%rax)
	movb	$0, 30(%rsp,%rax)
	movb	$0, 31(%rsp,%rax)
	movb	$0, 32(%rsp,%rax)
	addq	$8, %rax
	cmpq	$247, %rax
	jne	.LBB22_4
	#MEMBARRIER
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB22_6:
.Ltmp28:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end22:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm, .Lfunc_end22-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm,"a",@progbits
	.p2align	2, 0x0
GCC_except_table22:
.Lexception5:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end5-.Lcst_begin5
.Lcst_begin5:
	.uleb128 .Ltmp26-.Lfunc_begin5
	.uleb128 .Ltmp27-.Ltmp26
	.uleb128 .Ltmp28-.Lfunc_begin5
	.byte	0
	.uleb128 .Ltmp29-.Lfunc_begin5
	.uleb128 .Ltmp30-.Ltmp29
	.uleb128 .Ltmp31-.Lfunc_begin5
	.byte	0
	.uleb128 .Ltmp30-.Lfunc_begin5
	.uleb128 .Lfunc_end22-.Ltmp30
	.byte	0
	.byte	0
.Lcst_end5:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm,"ax",@progbits
	.globl	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm:
.Lfunc_begin6:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception6
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$584, %rsp
	.cfi_def_cfa_offset 624
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r14
	movq	%rdi, %rbx
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
.Ltmp32:
	leaq	48(%rsp), %rdi
	movl	$32, %edx
	movl	$14, %ecx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand
.Ltmp33:
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 32(%rsp)
.Ltmp35:
	leaq	48(%rsp), %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt
.Ltmp36:
	leaq	320(%rsp), %rdi
	leaq	48(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r15
	movl	$256, %edx
	callq	*%r15
	movaps	32(%rsp), %xmm0
	movaps	%xmm0, 304(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	movl	%ecx, %ebp
	shrb	%bpl
	andb	$1, %bpl
	leaq	304(%rsp), %rsi
	movl	$272, %edx
	movq	%rbx, %rdi
	callq	*%r15
	movb	%bpl, 272(%rbx)
	movq	(%r14), %rax
	movq	%rax, 288(%rbx)
	movl	8(%r14), %eax
	movl	%eax, 296(%rbx)
	movq	$0, 280(%rbx)
	movb	$0, 300(%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$584, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB23_3:
	.cfi_def_cfa_offset 624
.Ltmp37:
	movq	%rax, %rbx
	leaq	32(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movl	$7, %eax
	.p2align	4
.LBB23_4:
	movb	$0, 41(%rsp,%rax)
	movb	$0, 42(%rsp,%rax)
	movb	$0, 43(%rsp,%rax)
	movb	$0, 44(%rsp,%rax)
	movb	$0, 45(%rsp,%rax)
	movb	$0, 46(%rsp,%rax)
	movb	$0, 47(%rsp,%rax)
	movb	$0, 48(%rsp,%rax)
	addq	$8, %rax
	cmpq	$247, %rax
	jne	.LBB23_4
	#MEMBARRIER
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB23_6:
.Ltmp34:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end23:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm, .Lfunc_end23-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm,"a",@progbits
	.p2align	2, 0x0
GCC_except_table23:
.Lexception6:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end6-.Lcst_begin6
.Lcst_begin6:
	.uleb128 .Ltmp32-.Lfunc_begin6
	.uleb128 .Ltmp33-.Ltmp32
	.uleb128 .Ltmp34-.Lfunc_begin6
	.byte	0
	.uleb128 .Ltmp35-.Lfunc_begin6
	.uleb128 .Ltmp36-.Ltmp35
	.uleb128 .Ltmp37-.Lfunc_begin6
	.byte	0
	.uleb128 .Ltmp36-.Lfunc_begin6
	.uleb128 .Lfunc_end23-.Ltmp36
	.byte	0
	.byte	0
.Lcst_end6:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey4seal,"ax",@progbits
	.globl	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey4seal
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey4seal,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey4seal:
	.cfi_startproc
	movq	%rdi, %rax
	cmpb	$1, 300(%rsi)
	jne	.LBB24_3
	movw	$1537, (%rax)
	retq
.LBB24_3:
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	296(%rsi), %edi
	movl	%edi, 40(%rsp)
	movq	288(%rsi), %rdi
	movq	%rdi, 32(%rsp)
	movq	280(%rsi), %rdi
	movq	%rdi, %r10
	bswapq	%r10
	xorq	%r10, 36(%rsp)
	movzbl	272(%rsi), %r10d
	cmpb	$2, %r10b
	setne	%r11b
	movl	$4294967294, %ebx
	cmpq	%rbx, %rdi
	seta	%bl
	movb	$6, %dil
	testb	%bl, %r11b
	jne	.LBB24_7
	cmpb	$2, %r10b
	je	.LBB24_8
	movabsq	$68719476704, %rdi
	cmpq	%rdi, %r9
	seta	%dil
	movq	%rcx, %r10
	shrq	$61, %r10
	setne	%r10b
	orb	%dil, %r10b
	jne	.LBB24_6
	movq	%rax, 48(%rsp)
	leaq	32(%rsp), %r14
	movq	%rsi, %rdi
	movq	%rsi, %r15
	movq	%r14, %rsi
	movq	%rdx, %r12
	movq	%r8, %rdx
	movq	%rcx, %r13
	movq	%r9, %rcx
	movq	%r8, %rbp
	movq	%r9, %rbx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3xor
	movq	%rbx, (%rsp)
	leaq	16(%rsp), %rdi
	movq	%r15, %rbx
	movq	%r15, %rsi
	movq	%r14, %rdx
	movq	%r12, %rcx
	movq	%r13, %r8
	movq	%rbp, %r9
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3tag
	jmp	.LBB24_12
.LBB24_8:
	movabsq	$274877906880, %rdi
	cmpq	%rdi, %r9
	jbe	.LBB24_9
.LBB24_6:
	xorl	%edi, %edi
	jmp	.LBB24_7
.LBB24_9:
	movq	%rdx, %r15
	movq	%rcx, %r14
	movq	%rax, 48(%rsp)
	leaq	32(%rsp), %rax
	movq	%rsi, %rbx
	movq	%rsi, %rdi
	movq	%rax, %rsi
	movq	%r8, %r12
	movq	%r8, %rdx
	movq	%r9, %r13
	movq	%r9, %rcx
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha3xor
	cmpb	$-1, %al
	je	.LBB24_11
	xorl	%edi, %edi
	movq	48(%rsp), %rax
.LBB24_7:
	movb	%dil, 1(%rax)
	movb	$1, (%rax)
.LBB24_16:
	addq	$72, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	.cfi_restore %r12
	.cfi_restore %r13
	.cfi_restore %r14
	.cfi_restore %r15
	.cfi_restore %rbp
	retq
.LBB24_11:
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -56
	.cfi_offset %rbp, -16
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	movq	%r13, (%rsp)
	leaq	16(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movq	%rbx, %rsi
	movq	%r15, %rcx
	movq	%r14, %r8
	movq	%r12, %r9
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4aead10chacha_tag
.LBB24_12:
	movzbl	16(%rsp), %ecx
	movq	17(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 63(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
	movq	280(%rbx), %rdx
	cmpq	$-1, %rdx
	movq	48(%rsp), %rax
	je	.LBB24_13
	incq	%rdx
	movq	%rdx, 280(%rbx)
	jmp	.LBB24_15
.LBB24_13:
	movb	$1, 300(%rbx)
.LBB24_15:
	movl	40(%rsp), %edx
	movl	%edx, 9(%rax)
	movq	32(%rsp), %rdx
	movq	%rdx, 1(%rax)
	movb	%cl, 13(%rax)
	movq	56(%rsp), %rcx
	movq	63(%rsp), %rdx
	movq	%rcx, 14(%rax)
	movq	%rdx, 21(%rax)
	movb	$0, (%rax)
	jmp	.LBB24_16
.Lfunc_end24:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey4seal, .Lfunc_end24-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4aeadNtB2_10SealingKey4seal
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI25_0:
	.long	1779033703
	.long	3144134277
	.long	1013904242
	.long	2773480762
.LCPI25_1:
	.long	1359893119
	.long	2600822924
	.long	528734635
	.long	1541459225
	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566digest,"ax",@progbits
	.globl	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566digest
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566digest,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566digest:
.Lfunc_begin7:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception7
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$256, %rsp
	.cfi_def_cfa_offset 272
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movaps	.LCPI25_0(%rip), %xmm1
	movaps	%xmm1, 64(%rsp)
	movaps	.LCPI25_1(%rip), %xmm1
	movaps	%xmm1, 80(%rsp)
	movaps	%xmm0, 96(%rsp)
	movq	$0, 112(%rsp)
.Ltmp38:
	movq	%rsp, %rdi
	callq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update@GOTPCREL(%rip)
.Ltmp39:
	cmpb	$-1, %al
	je	.LBB25_3
	movw	$1, (%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	movl	$0, 64(%rsp)
	movl	$0, 68(%rsp)
	movl	$0, 72(%rsp)
	movl	$0, 76(%rsp)
	movl	$0, 80(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 92(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$256, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB25_3:
	.cfi_def_cfa_offset 272
	movaps	112(%rsp), %xmm0
	movaps	%xmm0, 240(%rsp)
	movaps	96(%rsp), %xmm0
	movaps	%xmm0, 224(%rsp)
	movaps	80(%rsp), %xmm0
	movaps	%xmm0, 208(%rsp)
	movaps	64(%rsp), %xmm0
	movaps	%xmm0, 192(%rsp)
	movaps	(%rsp), %xmm0
	movaps	16(%rsp), %xmm1
	movaps	32(%rsp), %xmm2
	movaps	48(%rsp), %xmm3
	movaps	%xmm3, 176(%rsp)
	movaps	%xmm2, 160(%rsp)
	movaps	%xmm1, 144(%rsp)
	movaps	%xmm0, 128(%rsp)
	leaq	1(%rbx), %rdi
	leaq	128(%rsp), %rsi
	callq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize@GOTPCREL(%rip)
	movb	$0, (%rbx)
	movq	%rbx, %rax
	addq	$256, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB25_5:
	.cfi_def_cfa_offset 272
.Ltmp40:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end25:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566digest, .Lfunc_end25-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566digest
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566digest,"a",@progbits
	.p2align	2, 0x0
GCC_except_table25:
.Lexception7:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end7-.Lcst_begin7
.Lcst_begin7:
	.uleb128 .Ltmp38-.Lfunc_begin7
	.uleb128 .Ltmp39-.Ltmp38
	.uleb128 .Ltmp40-.Lfunc_begin7
	.byte	0
	.uleb128 .Ltmp39-.Lfunc_begin7
	.uleb128 .Lfunc_end25-.Ltmp39
	.byte	0
	.byte	0
.Lcst_end7:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update,"ax",@progbits
	.globl	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	104(%rdi), %rax
	movq	96(%rdi), %rcx
	addq	%rdx, %rcx
	adcq	$0, %rax
	setb	%dl
	movq	%rcx, %rsi
	shrq	$61, %rsi
	orq	%rax, %rsi
	setne	%sil
	orb	%dl, %sil
	je	.LBB26_2
	xorl	%eax, %eax
	jmp	.LBB26_13
.LBB26_2:
	movq	%rdi, %r14
	movq	%rcx, 96(%rdi)
	movq	%rax, 104(%rdi)
	movq	112(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB26_6
	movl	$64, %r12d
	subq	%rdi, %r12
	cmpq	%rbx, %r12
	cmovaeq	%rbx, %r12
	leaq	(%r12,%rdi), %rsi
	cmpq	%rdi, %rsi
	jb	.LBB26_5
	cmpq	$65, %rsi
	jae	.LBB26_5
	addq	%r14, %rdi
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	112(%r14), %rax
	addq	%r12, %rax
	movq	%rax, 112(%r14)
	subq	%r12, %rbx
	addq	%r12, %r15
	cmpq	$64, %rax
	jne	.LBB26_6
	leaq	64(%r14), %rdi
	movq	%r14, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256
	movq	$0, 112(%r14)
.LBB26_6:
	cmpq	$64, %rbx
	jb	.LBB26_9
	leaq	64(%r14), %r12
	.p2align	4
.LBB26_8:
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256
	addq	$-64, %rbx
	addq	$64, %r15
	cmpq	$63, %rbx
	ja	.LBB26_8
.LBB26_9:
	movb	$-1, %al
	testq	%rbx, %rbx
	je	.LBB26_13
	movq	112(%r14), %rdi
	leaq	(%rdi,%rbx), %rsi
	cmpq	%rdi, %rsi
	jb	.LBB26_5
	cmpq	$65, %rsi
	jae	.LBB26_5
	addq	%r14, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movb	$-1, %al
	addq	%rbx, 112(%r14)
.LBB26_13:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB26_5:
	.cfi_def_cfa_offset 48
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.11(%rip), %rcx
	movl	$64, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Lfunc_end26:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update, .Lfunc_end26-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize,"ax",@progbits
	.globl	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize:
.Lfunc_begin8:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception8
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movq	112(%rsi), %rdi
	cmpq	$63, %rdi
	ja	.LBB27_6
	movb	$-128, (%rbx,%rdi)
	movq	112(%rbx), %rax
	leaq	1(%rax), %rdi
	movq	%rdi, 112(%rbx)
	cmpq	$64, %rdi
	ja	.LBB27_8
	movl	$63, %edx
	subq	%rax, %rdx
	addq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	cmpq	$56, 112(%rbx)
	jbe	.LBB27_4
	leaq	64(%rbx), %rdi
	movq	%rbx, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 48(%rbx)
	movaps	%xmm0, 32(%rbx)
	movaps	%xmm0, 16(%rbx)
	movaps	%xmm0, (%rbx)
.LBB27_4:
	movq	96(%rbx), %rax
	shlq	$3, %rax
	bswapq	%rax
	movq	%rax, 56(%rbx)
	leaq	64(%rbx), %rdi
	movq	%rbx, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256
	movdqa	64(%rbx), %xmm0
	pxor	%xmm1, %xmm1
	movdqa	%xmm0, %xmm2
	punpckhbw	%xmm1, %xmm2
	pshuflw	$27, %xmm2, %xmm2
	pshufhw	$27, %xmm2, %xmm2
	punpcklbw	%xmm1, %xmm0
	pshuflw	$27, %xmm0, %xmm0
	pshufhw	$27, %xmm0, %xmm0
	packuswb	%xmm2, %xmm0
	movdqu	%xmm0, (%r14)
	movdqa	80(%rbx), %xmm0
	movdqa	%xmm0, %xmm2
	punpckhbw	%xmm1, %xmm2
	pshuflw	$27, %xmm2, %xmm2
	pshufhw	$27, %xmm2, %xmm2
	punpcklbw	%xmm1, %xmm0
	pshuflw	$27, %xmm0, %xmm0
	pshufhw	$27, %xmm0, %xmm0
	packuswb	%xmm2, %xmm0
	movdqu	%xmm0, 16(%r14)
	movb	$0, (%rbx)
	movb	$0, 1(%rbx)
	movb	$0, 2(%rbx)
	movb	$0, 3(%rbx)
	movb	$0, 4(%rbx)
	movb	$0, 5(%rbx)
	movb	$0, 6(%rbx)
	movb	$0, 7(%rbx)
	movb	$0, 8(%rbx)
	movb	$0, 9(%rbx)
	movb	$0, 10(%rbx)
	movb	$0, 11(%rbx)
	movb	$0, 12(%rbx)
	movb	$0, 13(%rbx)
	movb	$0, 14(%rbx)
	movb	$0, 15(%rbx)
	movb	$0, 16(%rbx)
	movb	$0, 17(%rbx)
	movb	$0, 18(%rbx)
	movb	$0, 19(%rbx)
	movb	$0, 20(%rbx)
	movb	$0, 21(%rbx)
	movb	$0, 22(%rbx)
	movb	$0, 23(%rbx)
	movb	$0, 24(%rbx)
	movb	$0, 25(%rbx)
	movb	$0, 26(%rbx)
	movb	$0, 27(%rbx)
	movb	$0, 28(%rbx)
	movb	$0, 29(%rbx)
	movb	$0, 30(%rbx)
	movb	$0, 31(%rbx)
	movb	$0, 32(%rbx)
	movb	$0, 33(%rbx)
	movb	$0, 34(%rbx)
	movb	$0, 35(%rbx)
	movb	$0, 36(%rbx)
	movb	$0, 37(%rbx)
	movb	$0, 38(%rbx)
	movb	$0, 39(%rbx)
	movb	$0, 40(%rbx)
	movb	$0, 41(%rbx)
	movb	$0, 42(%rbx)
	movb	$0, 43(%rbx)
	movb	$0, 44(%rbx)
	movb	$0, 45(%rbx)
	movb	$0, 46(%rbx)
	movb	$0, 47(%rbx)
	movb	$0, 48(%rbx)
	movb	$0, 49(%rbx)
	movb	$0, 50(%rbx)
	movb	$0, 51(%rbx)
	movb	$0, 52(%rbx)
	movb	$0, 53(%rbx)
	movb	$0, 54(%rbx)
	movb	$0, 55(%rbx)
	movb	$0, 56(%rbx)
	movb	$0, 57(%rbx)
	movb	$0, 58(%rbx)
	movb	$0, 59(%rbx)
	movb	$0, 60(%rbx)
	movb	$0, 61(%rbx)
	movb	$0, 62(%rbx)
	movb	$0, 63(%rbx)
	#MEMBARRIER
	movl	$0, 64(%rbx)
	movl	$0, 68(%rbx)
	movl	$0, 72(%rbx)
	movl	$0, 76(%rbx)
	movl	$0, 80(%rbx)
	movl	$0, 84(%rbx)
	movl	$0, 88(%rbx)
	movl	$0, 92(%rbx)
	#MEMBARRIER
	movq	%r14, %rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB27_8:
	.cfi_def_cfa_offset 32
.Ltmp43:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.11(%rip), %rcx
	movl	$64, %esi
	movl	$64, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Ltmp44:
	jmp	.LBB27_7
.LBB27_6:
.Ltmp41:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.11(%rip), %rdx
	movl	$64, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp42:
.LBB27_7:
	ud2
.LBB27_5:
.Ltmp45:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end27:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize, .Lfunc_end27-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize,"a",@progbits
	.p2align	2, 0x0
GCC_except_table27:
.Lexception8:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end8-.Lcst_begin8
.Lcst_begin8:
	.uleb128 .Lfunc_begin8-.Lfunc_begin8
	.uleb128 .Ltmp43-.Lfunc_begin8
	.byte	0
	.byte	0
	.uleb128 .Ltmp43-.Lfunc_begin8
	.uleb128 .Ltmp42-.Ltmp43
	.uleb128 .Ltmp45-.Lfunc_begin8
	.byte	0
	.uleb128 .Ltmp42-.Lfunc_begin8
	.uleb128 .Lfunc_end27-.Ltmp42
	.byte	0
	.byte	0
.Lcst_end8:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_:
.Lfunc_begin9:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception9
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$888, %rsp
	.cfi_def_cfa_offset 944
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r13
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %r12
	leaq	96(%rcx), %rbp
	leaq	64(%rsi), %rbx
	leaq	680(%rsp), %rdi
	movq	%rbp, %rsi
	movq	%rbx, %rdx
	movq	%rbx, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	64(%r14), %rcx
.Ltmp46:
	leaq	712(%rsp), %rdi
	movq	%rbp, %rsi
	movq	%rcx, %rdx
	movq	%rcx, 816(%rsp)
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp47:
.Ltmp49:
	leaq	344(%rsp), %rdi
	leaq	712(%rsp), %rcx
	movq	%rbp, %rsi
	movq	%r15, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp50:
.Ltmp52:
	leaq	472(%rsp), %rdi
	leaq	680(%rsp), %rcx
	movq	%rbp, %rsi
	movq	%r14, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp53:
.Ltmp55:
	movq	%rsp, %rdi
	leaq	712(%rsp), %rcx
	movq	%rbp, %rsi
	leaq	64(%r14), %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp56:
	leaq	32(%r15), %rdx
.Ltmp58:
	leaq	376(%rsp), %rdi
	movq	%rsp, %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp59:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
.Ltmp61:
	movq	%rsp, %rdi
	leaq	680(%rsp), %rcx
	movq	%rbp, %rsi
	movq	%rbx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp62:
	movq	%r12, 776(%rsp)
	movq	%r15, 808(%rsp)
	movq	%rbx, 792(%rsp)
	movq	%r14, 784(%rsp)
	leaq	32(%r14), %rdx
.Ltmp64:
	leaq	504(%rsp), %rdi
	movq	%rsp, %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp65:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	472(%rsp), %rsi
	movq	480(%rsp), %rdx
	subq	344(%rsp), %rsi
	movl	$1, %eax
	sbbq	$0, %rax
	subq	352(%rsp), %rdx
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %rdx
	adcq	$0, %rcx
	addq	$-1, %rdx
	adcq	$-1, %rcx
	movq	488(%rsp), %rdi
	xorq	$-2, %rcx
	subq	360(%rsp), %rdi
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%rcx, %rdi
	adcq	$-1, %rax
	addq	$1, %rdi
	adcq	$0, %rax
	xorq	$-2, %rax
	movq	496(%rsp), %rcx
	subq	368(%rsp), %rcx
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rax, %rcx
	adcq	$-1, %r8
	movq	%rcx, %rax
	addq	$1, %rax
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, (%rsp)
	xorl	%eax, %eax
	xorl	%r8d, %r8d
	subq	(%rsp), %r8
	movq	96(%r13), %r15
	movq	104(%r13), %r14
	movq	%r15, %r11
	andq	%r8, %r11
	movq	%r14, %r10
	andq	%r8, %r10
	movq	112(%r13), %r12
	movq	%r12, %r9
	andq	%r8, %r9
	movq	%r13, 800(%rsp)
	movq	120(%r13), %r13
	andq	%r13, %r8
	addq	%rsi, %r11
	adcq	%rdx, %r10
	adcq	%rdi, %r9
	adcq	$1, %rcx
	addq	%r8, %rcx
	movq	504(%rsp), %rsi
	movq	512(%rsp), %rdx
	subq	376(%rsp), %rsi
	movl	$1, %edi
	sbbq	$0, %rdi
	subq	384(%rsp), %rdx
	movl	$1, %r8d
	movl	$1, %ebx
	sbbq	$0, %rbx
	movq	%r11, 120(%rsp)
	addq	%rdi, %rdx
	adcq	$0, %rbx
	movq	%r10, 128(%rsp)
	addq	$-1, %rdx
	adcq	$-1, %rbx
	movq	520(%rsp), %rdi
	xorq	$-2, %rbx
	subq	392(%rsp), %rdi
	movq	%r9, 136(%rsp)
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%rbx, %rdi
	adcq	$-1, %r10
	addq	$1, %rdi
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	528(%rsp), %r9
	subq	400(%rsp), %r9
	sbbq	$0, %r8
	movq	%rcx, 144(%rsp)
	addq	%r10, %r9
	adcq	$-1, %r8
	movq	%r9, %rcx
	addq	$1, %rcx
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, (%rsp)
	subq	(%rsp), %rax
	movq	%r15, 272(%rsp)
	andq	%rax, %r15
	movq	%r14, 264(%rsp)
	andq	%rax, %r14
	movq	%r12, 256(%rsp)
	andq	%rax, %r12
	movq	%r13, 248(%rsp)
	andq	%r13, %rax
	addq	%rsi, %r15
	adcq	%rdx, %r14
	adcq	%rdi, %r12
	adcq	$1, %r9
	addq	%rax, %r9
	movq	%r15, 280(%rsp)
	movq	%r14, 288(%rsp)
	movq	%r12, 296(%rsp)
	movq	%r9, 304(%rsp)
.Ltmp67:
	leaq	744(%rsp), %rdi
	leaq	120(%rsp), %rcx
	movq	%rbp, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp68:
.Ltmp70:
	leaq	408(%rsp), %rdi
	leaq	120(%rsp), %rdx
	leaq	744(%rsp), %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp71:
.Ltmp73:
	leaq	440(%rsp), %rdi
	leaq	344(%rsp), %rdx
	leaq	744(%rsp), %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp74:
.Ltmp76:
	leaq	584(%rsp), %rdi
	leaq	280(%rsp), %rcx
	movq	%rbp, 536(%rsp)
	movq	%rbp, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp77:
	movq	584(%rsp), %rcx
	movq	592(%rsp), %rax
	subq	408(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	416(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	600(%rsp), %rdx
	xorq	$-2, %rsi
	subq	424(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	xorq	$-2, %rdi
	movq	608(%rsp), %r12
	subq	432(%rsp), %r12
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdi, %r12
	adcq	$-1, %rsi
	movq	%r12, %rdi
	addq	$1, %rdi
	adcq	$0, %rsi
	xorq	$1, %rsi
	movq	%rsi, (%rsp)
	xorl	%r15d, %r15d
	xorl	%esi, %esi
	subq	(%rsp), %rsi
	movq	272(%rsp), %rbp
	andq	%rsi, %rbp
	movq	264(%rsp), %r14
	andq	%rsi, %r14
	movq	256(%rsp), %rbx
	andq	%rsi, %rbx
	andq	248(%rsp), %rsi
	addq	%rcx, %rbp
	adcq	%rax, %r14
	adcq	%rdx, %rbx
	movl	$1, %r13d
	adcq	$1, %r12
	addq	%rsi, %r12
	movq	%rbp, 856(%rsp)
	movq	%r14, 112(%rsp)
	movq	%rbx, 104(%rsp)
	movq	%r12, 96(%rsp)
	movq	%rsp, %rdi
	leaq	440(%rsp), %rcx
	movq	536(%rsp), %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	subq	(%rsp), %rbp
	movl	$1, %eax
	sbbq	$0, %rax
	subq	8(%rsp), %r14
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r14
	adcq	$0, %rcx
	addq	$-1, %r14
	adcq	$-1, %rcx
	xorq	$-2, %rcx
	subq	16(%rsp), %rbx
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%rcx, %rbx
	adcq	$-1, %rax
	addq	$1, %rbx
	adcq	$0, %rax
	xorq	$-2, %rax
	subq	24(%rsp), %r12
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r12
	adcq	$-1, %rcx
	movq	%r12, %rax
	addq	$1, %rax
	adcq	$0, %rcx
	xorq	$1, %rcx
	movq	%rcx, 152(%rsp)
	xorl	%eax, %eax
	subq	152(%rsp), %rax
	movq	272(%rsp), %r8
	movq	%r8, %rcx
	andq	%rax, %rcx
	movq	264(%rsp), %r9
	movq	%r9, %rdx
	andq	%rax, %rdx
	movq	256(%rsp), %r10
	movq	%r10, %rsi
	andq	%rax, %rsi
	movq	248(%rsp), %r11
	andq	%r11, %rax
	addq	%rbp, %rcx
	movq	536(%rsp), %rbp
	adcq	%r14, %rdx
	adcq	%rbx, %rsi
	adcq	$1, %r12
	addq	%rax, %r12
	movq	%rcx, 336(%rsp)
	movq	%rdx, 328(%rsp)
	movq	%rsi, 320(%rsp)
	movq	%r12, 312(%rsp)
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 856(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	movq	440(%rsp), %rcx
	movq	448(%rsp), %rax
	subq	336(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	328(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	456(%rsp), %rdx
	xorq	$-2, %rsi
	subq	320(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	xorq	$-2, %rdi
	movq	464(%rsp), %rsi
	subq	312(%rsp), %rsi
	sbbq	$0, %r13
	addq	%rdi, %rsi
	adcq	$-1, %r13
	movq	%rsi, %rdi
	addq	$1, %rdi
	adcq	$0, %r13
	xorq	$1, %r13
	movq	%r13, (%rsp)
	subq	(%rsp), %r15
	movq	%r8, %rdi
	andq	%r15, %rdi
	movq	%r9, %r8
	andq	%r15, %r8
	movq	%r10, %r9
	andq	%r15, %r9
	andq	%r11, %r15
	addq	%rcx, %rdi
	adcq	%rax, %r8
	adcq	%rdx, %r9
	adcq	$1, %rsi
	addq	%r15, %rsi
	movq	%rdi, 584(%rsp)
	movq	%r8, 592(%rsp)
	movq	%r9, 600(%rsp)
	movq	%rsi, 608(%rsp)
.Ltmp79:
	leaq	152(%rsp), %rdi
	leaq	280(%rsp), %rdx
	leaq	584(%rsp), %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp80:
.Ltmp82:
	movq	%rsp, %rdi
	leaq	376(%rsp), %rdx
	leaq	408(%rsp), %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp83:
	movq	808(%rsp), %r15
	movq	800(%rsp), %rbx
	movq	152(%rsp), %rcx
	movq	160(%rsp), %rax
	subq	(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	8(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	168(%rsp), %rdx
	xorq	$-2, %rsi
	subq	16(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	xorq	$-2, %rdi
	movq	176(%rsp), %rsi
	subq	24(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	movq	%rsi, %rdi
	addq	$1, %rdi
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, 856(%rsp)
	xorl	%edi, %edi
	subq	856(%rsp), %rdi
	movq	272(%rsp), %r8
	andq	%rdi, %r8
	movq	264(%rsp), %r9
	andq	%rdi, %r9
	movq	256(%rsp), %r10
	andq	%rdi, %r10
	movq	248(%rsp), %r11
	andq	%rdi, %r11
	addq	%rcx, %r8
	adcq	%rax, %r9
	adcq	%rdx, %r10
	adcq	$1, %rsi
	addq	%r11, %rsi
	movq	%r8, 568(%rsp)
	movq	%r9, 560(%rsp)
	movq	%r10, 552(%rsp)
	movq	%rsi, 544(%rsp)
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
.Ltmp85:
	movq	%rsp, %rdi
	movq	%rbp, %rsi
	movq	792(%rsp), %rdx
	movq	816(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp86:
.Ltmp88:
	leaq	856(%rsp), %rdi
	leaq	120(%rsp), %rdx
	movq	%rsp, %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp89:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	336(%rsp), %rax
	movq	328(%rsp), %rcx
	movq	320(%rsp), %rdx
	movq	312(%rsp), %rsi
	movq	568(%rsp), %rdi
	movq	560(%rsp), %r8
	movq	552(%rsp), %r9
	movq	544(%rsp), %r10
	movups	856(%rsp), %xmm0
	movups	872(%rsp), %xmm1
	movups	%xmm0, 216(%rsp)
	movups	%xmm1, 232(%rsp)
	movq	%rax, 152(%rsp)
	movq	%rcx, 160(%rsp)
	movq	%rdx, 168(%rsp)
	movq	%rsi, 176(%rsp)
	movq	%rdi, 184(%rsp)
	movq	%r8, 192(%rsp)
	movq	%r9, 200(%rsp)
	movq	%r10, 208(%rsp)
.Ltmp91:
	movq	%rsp, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_
.Ltmp92:
	movq	$0, 848(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 824(%rsp)
	movdqu	120(%rsp), %xmm0
	movdqu	136(%rsp), %xmm1
	movdqu	280(%rsp), %xmm2
	por	%xmm0, %xmm2
	movdqu	296(%rsp), %xmm0
	por	%xmm1, %xmm0
	por	%xmm2, %xmm0
	pxor	%xmm1, %xmm1
	pcmpeqd	%xmm1, %xmm0
	movmskps	%xmm0, %eax
	xorl	%ecx, %ecx
	xorl	$15, %eax
	sete	%cl
	leaq	584(%rsp), %r14
	leaq	152(%rsp), %rsi
	movq	%rsp, %rdx
	movq	%r14, %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, 848(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 824(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	784(%rsp), %rbx
	movdqu	64(%rbx), %xmm0
	movdqu	80(%rbx), %xmm1
	por	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	pcmpeqd	%xmm0, %xmm1
	movmskps	%xmm1, %eax
	xorl	%ecx, %ecx
	xorl	$15, %eax
	sete	%cl
	movq	%rsp, %r12
	movq	%r12, %rdi
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movdqu	64(%r15), %xmm0
	movdqu	80(%r15), %xmm1
	por	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	pcmpeqd	%xmm0, %xmm1
	movmskps	%xmm1, %eax
	xorl	%ecx, %ecx
	xorl	$15, %eax
	sete	%cl
	movq	776(%rsp), %rdi
	movq	%r12, %rsi
	movq	%rbx, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	#MEMBARRIER
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	#MEMBARRIER
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	#MEMBARRIER
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	#MEMBARRIER
	addq	$888, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB28_17:
	.cfi_def_cfa_offset 944
.Ltmp93:
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	jmp	.LBB28_26
.LBB28_18:
.Ltmp90:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	jmp	.LBB28_20
.LBB28_19:
.Ltmp87:
.LBB28_20:
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	jmp	.LBB28_24
.LBB28_21:
.Ltmp84:
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	jmp	.LBB28_23
.LBB28_22:
.Ltmp81:
.LBB28_23:
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
.LBB28_24:
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	jmp	.LBB28_26
.LBB28_25:
.Ltmp78:
.LBB28_26:
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
.LBB28_27:
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
.LBB28_28:
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	#MEMBARRIER
.LBB28_29:
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
.LBB28_30:
	#MEMBARRIER
.LBB28_31:
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
.LBB28_32:
	#MEMBARRIER
.LBB28_33:
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	#MEMBARRIER
.LBB28_34:
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
.LBB28_35:
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	#MEMBARRIER
.LBB28_36:
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.LBB28_37:
.Ltmp75:
	jmp	.LBB28_27
.LBB28_38:
.Ltmp72:
	jmp	.LBB28_28
.LBB28_39:
.Ltmp69:
	jmp	.LBB28_29
.LBB28_40:
.Ltmp66:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	jmp	.LBB28_30
.LBB28_41:
.Ltmp63:
	jmp	.LBB28_31
.LBB28_42:
.Ltmp60:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	jmp	.LBB28_32
.LBB28_43:
.Ltmp57:
	jmp	.LBB28_33
.LBB28_44:
.Ltmp54:
	jmp	.LBB28_34
.LBB28_45:
.Ltmp51:
	jmp	.LBB28_35
.LBB28_46:
.Ltmp48:
	jmp	.LBB28_36
.Lfunc_end28:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_, .Lfunc_end28-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table28:
.Lexception9:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end9-.Lcst_begin9
.Lcst_begin9:
	.uleb128 .Lfunc_begin9-.Lfunc_begin9
	.uleb128 .Ltmp46-.Lfunc_begin9
	.byte	0
	.byte	0
	.uleb128 .Ltmp46-.Lfunc_begin9
	.uleb128 .Ltmp47-.Ltmp46
	.uleb128 .Ltmp48-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp49-.Lfunc_begin9
	.uleb128 .Ltmp50-.Ltmp49
	.uleb128 .Ltmp51-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp52-.Lfunc_begin9
	.uleb128 .Ltmp53-.Ltmp52
	.uleb128 .Ltmp54-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp55-.Lfunc_begin9
	.uleb128 .Ltmp56-.Ltmp55
	.uleb128 .Ltmp57-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp58-.Lfunc_begin9
	.uleb128 .Ltmp59-.Ltmp58
	.uleb128 .Ltmp60-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp61-.Lfunc_begin9
	.uleb128 .Ltmp62-.Ltmp61
	.uleb128 .Ltmp63-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp64-.Lfunc_begin9
	.uleb128 .Ltmp65-.Ltmp64
	.uleb128 .Ltmp66-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp67-.Lfunc_begin9
	.uleb128 .Ltmp68-.Ltmp67
	.uleb128 .Ltmp69-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp70-.Lfunc_begin9
	.uleb128 .Ltmp71-.Ltmp70
	.uleb128 .Ltmp72-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp73-.Lfunc_begin9
	.uleb128 .Ltmp74-.Ltmp73
	.uleb128 .Ltmp75-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp76-.Lfunc_begin9
	.uleb128 .Ltmp77-.Ltmp76
	.uleb128 .Ltmp78-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp79-.Lfunc_begin9
	.uleb128 .Ltmp80-.Ltmp79
	.uleb128 .Ltmp81-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp82-.Lfunc_begin9
	.uleb128 .Ltmp83-.Ltmp82
	.uleb128 .Ltmp84-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp85-.Lfunc_begin9
	.uleb128 .Ltmp86-.Ltmp85
	.uleb128 .Ltmp87-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp88-.Lfunc_begin9
	.uleb128 .Ltmp89-.Ltmp88
	.uleb128 .Ltmp90-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp91-.Lfunc_begin9
	.uleb128 .Ltmp92-.Ltmp91
	.uleb128 .Ltmp93-.Lfunc_begin9
	.byte	0
	.uleb128 .Ltmp92-.Lfunc_begin9
	.uleb128 .Lfunc_end28-.Ltmp92
	.byte	0
	.byte	0
.Lcst_end9:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_:
.Lfunc_begin10:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception10
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$392, %rsp
	.cfi_def_cfa_offset 448
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r14
	movq	%rdx, %r15
	movq	%rsi, %r12
	movq	%rdi, 192(%rsp)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	movups	160(%rcx), %xmm1
	movups	176(%rcx), %xmm2
	movaps	%xmm1, 32(%rsp)
	movaps	%xmm2, 48(%rsp)
	movaps	%xmm0, (%rsp)
	movaps	%xmm0, 16(%rsp)
	movl	$255, %ebp
	leaq	96(%rsp), %r13
	leaq	200(%rsp), %rbx
	.p2align	4
.LBB29_1:
.Ltmp94:
	movq	%r13, %rdi
	movq	%rsp, %rsi
	movq	%r14, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_
.Ltmp95:
.Ltmp97:
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	movq	%r14, %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_
.Ltmp98:
	movq	%rbp, %rax
	shrq	$6, %rax
	movq	(%r15,%rax,8), %rax
	xorl	%ecx, %ecx
	btq	%rbp, %rax
	setb	%cl
	leaq	296(%rsp), %rdi
	movq	%r13, %rsi
	movq	%rbx, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movups	376(%rsp), %xmm0
	movaps	%xmm0, 80(%rsp)
	movups	360(%rsp), %xmm0
	movaps	%xmm0, 64(%rsp)
	movups	296(%rsp), %xmm0
	movups	312(%rsp), %xmm1
	movups	328(%rsp), %xmm2
	movups	344(%rsp), %xmm3
	movaps	%xmm3, 48(%rsp)
	movaps	%xmm2, 32(%rsp)
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	addq	$-1, %rbp
	jb	.LBB29_1
	movaps	80(%rsp), %xmm0
	movq	192(%rsp), %rax
	movups	%xmm0, 80(%rax)
	movaps	64(%rsp), %xmm0
	movups	%xmm0, 64(%rax)
	movaps	(%rsp), %xmm0
	movaps	16(%rsp), %xmm1
	movaps	32(%rsp), %xmm2
	movaps	48(%rsp), %xmm3
	movups	%xmm3, 48(%rax)
	movups	%xmm2, 32(%rax)
	movups	%xmm1, 16(%rax)
	movups	%xmm0, (%rax)
	addq	$392, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB29_5:
	.cfi_def_cfa_offset 448
.Ltmp96:
	jmp	.LBB29_6
.LBB29_7:
.Ltmp99:
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
.LBB29_6:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end29:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_, .Lfunc_end29-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table29:
.Lexception10:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end10-.Lcst_begin10
.Lcst_begin10:
	.uleb128 .Ltmp94-.Lfunc_begin10
	.uleb128 .Ltmp95-.Ltmp94
	.uleb128 .Ltmp96-.Lfunc_begin10
	.byte	0
	.uleb128 .Ltmp97-.Lfunc_begin10
	.uleb128 .Ltmp98-.Ltmp97
	.uleb128 .Ltmp99-.Lfunc_begin10
	.byte	0
	.uleb128 .Ltmp98-.Lfunc_begin10
	.uleb128 .Lfunc_end29-.Ltmp98
	.byte	0
	.byte	0
.Lcst_end10:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_:
.Lfunc_begin11:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception11
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$296, %rsp
	.cfi_def_cfa_offset 352
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movdqu	64(%rsi), %xmm0
	movdqu	80(%rsi), %xmm1
	por	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	pcmpeqd	%xmm1, %xmm0
	movmskps	%xmm0, %eax
	xorl	$15, %eax
	movq	$0, (%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	je	.LBB30_1
	movq	%rdx, %r14
	movq	%rsi, %r15
	leaq	64(%rsi), %rdx
	addq	$96, %r14
	leaq	168(%rsp), %r12
	movq	%r12, %rdi
	movq	%r14, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_
.Ltmp100:
	leaq	72(%rsp), %rdi
	movq	%r14, %rsi
	movq	%r12, %rdx
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp101:
.Ltmp103:
	leaq	200(%rsp), %rdi
	leaq	72(%rsp), %rcx
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp104:
	leaq	16(%rsp), %r13
	leaq	24(%rsp), %rbp
	xorps	%xmm0, %xmm0
	movups	%xmm0, 8(%rsp)
	movq	$0, 24(%rsp)
	movq	$1, (%rsp)
.Ltmp106:
	leaq	104(%rsp), %r12
	leaq	200(%rsp), %rdx
	movq	%rsp, %rcx
	movq	%r12, %rdi
	movq	%r14, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp107:
	leaq	120(%rsp), %r13
	leaq	128(%rsp), %rbp
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
.Ltmp109:
	leaq	136(%rsp), %rdi
	leaq	72(%rsp), %rdx
	leaq	168(%rsp), %rcx
	movq	%r14, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp110:
	addq	$32, %r15
.Ltmp112:
	leaq	232(%rsp), %rdi
	leaq	136(%rsp), %rcx
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp113:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 8(%rsp)
	movq	$0, 24(%rsp)
	movq	$1, (%rsp)
.Ltmp115:
	leaq	264(%rsp), %rdi
	leaq	232(%rsp), %r12
	movq	%rsp, %rcx
	movq	%r14, %rsi
	movq	%r12, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp116:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movups	104(%rsp), %xmm0
	movdqu	120(%rsp), %xmm1
	movaps	%xmm0, (%rsp)
	movdqa	%xmm1, 16(%rsp)
	movups	264(%rsp), %xmm2
	movups	280(%rsp), %xmm3
	movaps	%xmm2, 32(%rsp)
	movaps	%xmm3, 48(%rsp)
	movups	%xmm3, 56(%rbx)
	movups	%xmm2, 40(%rbx)
	movdqu	%xmm1, 24(%rbx)
	movups	%xmm0, 8(%rbx)
	movb	$0, (%rbx)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	jmp	.LBB30_2
.LBB30_1:
	movw	$769, (%rbx)
.LBB30_2:
	addq	$296, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB30_18:
	.cfi_def_cfa_offset 352
.Ltmp117:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	jmp	.LBB30_19
.LBB30_17:
.Ltmp114:
.LBB30_19:
	leaq	152(%rsp), %r13
	leaq	160(%rsp), %rbp
	movq	$0, (%r12)
	movq	$0, 8(%r12)
	movq	$0, 16(%r12)
	movq	$0, 24(%r12)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	jmp	.LBB30_15
.LBB30_16:
.Ltmp111:
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	jmp	.LBB30_15
.LBB30_14:
.Ltmp108:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
.LBB30_15:
	movq	$0, (%r13)
	movq	$0, (%rbp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	jmp	.LBB30_13
.LBB30_12:
.Ltmp105:
.LBB30_13:
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
.LBB30_4:
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.LBB30_3:
.Ltmp102:
	jmp	.LBB30_4
.Lfunc_end30:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_, .Lfunc_end30-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table30:
.Lexception11:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end11-.Lcst_begin11
.Lcst_begin11:
	.uleb128 .Lfunc_begin11-.Lfunc_begin11
	.uleb128 .Ltmp100-.Lfunc_begin11
	.byte	0
	.byte	0
	.uleb128 .Ltmp100-.Lfunc_begin11
	.uleb128 .Ltmp101-.Ltmp100
	.uleb128 .Ltmp102-.Lfunc_begin11
	.byte	0
	.uleb128 .Ltmp103-.Lfunc_begin11
	.uleb128 .Ltmp104-.Ltmp103
	.uleb128 .Ltmp105-.Lfunc_begin11
	.byte	0
	.uleb128 .Ltmp106-.Lfunc_begin11
	.uleb128 .Ltmp107-.Ltmp106
	.uleb128 .Ltmp108-.Lfunc_begin11
	.byte	0
	.uleb128 .Ltmp109-.Lfunc_begin11
	.uleb128 .Ltmp110-.Ltmp109
	.uleb128 .Ltmp111-.Lfunc_begin11
	.byte	0
	.uleb128 .Ltmp112-.Lfunc_begin11
	.uleb128 .Ltmp113-.Ltmp112
	.uleb128 .Ltmp114-.Lfunc_begin11
	.byte	0
	.uleb128 .Ltmp115-.Lfunc_begin11
	.uleb128 .Ltmp116-.Ltmp115
	.uleb128 .Ltmp117-.Lfunc_begin11
	.byte	0
	.uleb128 .Ltmp116-.Lfunc_begin11
	.uleb128 .Lfunc_end30-.Ltmp116
	.byte	0
	.byte	0
.Lcst_end11:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_:
.Lfunc_begin12:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception12
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$616, %rsp
	.cfi_def_cfa_offset 672
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r13
	movq	%rsi, %rbx
	movq	%rdi, %r14
	leaq	96(%rdx), %r12
	leaq	64(%rsi), %rcx
	leaq	272(%rsp), %rdi
	movq	%r12, %rsi
	movq	%rcx, %rdx
	movq	%rcx, 480(%rsp)
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	32(%rbx), %r15
.Ltmp118:
	leaq	344(%rsp), %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	movq	%r15, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp119:
.Ltmp121:
	leaq	520(%rsp), %rdi
	leaq	344(%rsp), %rcx
	movq	%r12, %rsi
	movq	%rbx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp122:
	movq	%r15, 600(%rsp)
	movq	%r14, 592(%rsp)
	leaq	48(%rsp), %r14
	leaq	56(%rsp), %r15
	xorps	%xmm0, %xmm0
	movups	%xmm0, 40(%rsp)
	movq	$0, 56(%rsp)
	movq	$3, 32(%rsp)
	leaq	128(%r13), %rcx
.Ltmp124:
	leaq	136(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movq	%r12, %rsi
	movq	%rcx, 304(%rsp)
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp125:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	(%rbx), %rcx
	movq	8(%rbx), %rax
	subq	272(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	280(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	16(%rbx), %rdx
	xorq	$-2, %rsi
	subq	288(%rsp), %rdx
	movl	$1, %edi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rsi, %rdx
	adcq	$-1, %r8
	addq	$1, %rdx
	adcq	$0, %r8
	xorq	$-2, %r8
	movq	24(%rbx), %rsi
	subq	296(%rsp), %rsi
	sbbq	$0, %rdi
	addq	%r8, %rsi
	adcq	$-1, %rdi
	movq	%rsi, %r8
	addq	$1, %r8
	adcq	$0, %rdi
	xorq	$1, %rdi
	movq	%rdi, 32(%rsp)
	xorl	%edi, %edi
	subq	32(%rsp), %rdi
	movq	96(%r13), %r14
	movq	104(%r13), %r15
	movq	%r14, %r8
	andq	%rdi, %r8
	movq	%r15, %r9
	andq	%rdi, %r9
	movq	112(%r13), %rbp
	movq	%rbp, %r10
	andq	%rdi, %r10
	movq	%r13, 584(%rsp)
	movq	120(%r13), %r11
	movq	%r11, 264(%rsp)
	andq	%r11, %rdi
	addq	%rcx, %r8
	adcq	%rax, %r9
	adcq	%rdx, %r10
	adcq	$1, %rsi
	addq	%rdi, %rsi
	movq	%r8, 168(%rsp)
	movq	%r9, 176(%rsp)
	movq	%r10, 184(%rsp)
	movq	%rsi, 192(%rsp)
	leaq	32(%rsp), %r13
	leaq	272(%rsp), %rcx
	movq	%r13, %rdi
	movq	%r12, %rsi
	movq	%rbx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
.Ltmp127:
	movq	%rsp, %rdi
	leaq	168(%rsp), %rdx
	movq	%r12, %rsi
	movq	%r13, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp128:
.Ltmp130:
	leaq	552(%rsp), %rdi
	leaq	136(%rsp), %rdx
	movq	%rsp, %rcx
	movq	%r12, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp131:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
.Ltmp133:
	movq	%rsp, %rdi
	leaq	552(%rsp), %rcx
	movq	%r12, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp134:
	leaq	48(%rsp), %rbx
	leaq	56(%rsp), %r13
	xorps	%xmm0, %xmm0
	movups	%xmm0, 40(%rsp)
	movq	$0, 56(%rsp)
	movq	$8, 32(%rsp)
.Ltmp136:
	leaq	168(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movq	%r12, %rsi
	movq	304(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp137:
	leaq	184(%rsp), %rbx
	leaq	192(%rsp), %r13
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
.Ltmp139:
	leaq	32(%rsp), %rdi
	leaq	168(%rsp), %rdx
	leaq	520(%rsp), %rcx
	movq	%r12, 472(%rsp)
	movq	%r12, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp140:
	movq	(%rsp), %rcx
	movq	8(%rsp), %rax
	subq	32(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	40(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	16(%rsp), %rdx
	xorq	$-2, %rsi
	subq	48(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	xorq	$-2, %rdi
	movq	24(%rsp), %rsi
	subq	56(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	movq	%rsi, %rdi
	addq	$1, %rdi
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, 136(%rsp)
	xorl	%edi, %edi
	subq	136(%rsp), %rdi
	movq	%r14, %r8
	andq	%rdi, %r8
	movq	%r15, %r9
	andq	%rdi, %r9
	movq	%rbp, %r10
	andq	%rdi, %r10
	andq	264(%rsp), %rdi
	addq	%rcx, %r8
	adcq	%rax, %r9
	adcq	%rdx, %r10
	movl	$1, %r13d
	adcq	$1, %rsi
	addq	%rdi, %rsi
	movq	%r8, 336(%rsp)
	movq	%r9, 328(%rsp)
	movq	%r10, 320(%rsp)
	movq	%rsi, 312(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	leaq	32(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r14, %r12
	movq	472(%rsp), %r14
	movq	%r14, %rsi
	movq	600(%rsp), %rdx
	movq	480(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
.Ltmp142:
	leaq	168(%rsp), %rdi
	movq	%r14, %rsi
	movq	%rbx, %rdx
	movq	%rbx, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp143:
	movq	168(%rsp), %r9
	movq	176(%rsp), %r8
	subq	344(%rsp), %r9
	movl	$1, %eax
	sbbq	$0, %rax
	subq	352(%rsp), %r8
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r8
	adcq	$0, %rcx
	addq	$-1, %r8
	adcq	$-1, %rcx
	movq	184(%rsp), %r10
	xorq	$-2, %rcx
	subq	360(%rsp), %r10
	movl	$1, %edx
	sbbq	$0, %rdx
	addq	%rcx, %r10
	adcq	$-1, %rdx
	addq	$1, %r10
	adcq	$0, %rdx
	xorq	$-2, %rdx
	movq	192(%rsp), %rax
	subq	368(%rsp), %rax
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rdx, %rax
	adcq	$-1, %rcx
	movq	%rax, %rdx
	addq	$1, %rdx
	adcq	$0, %rcx
	xorq	$1, %rcx
	movq	%rcx, (%rsp)
	xorl	%ecx, %ecx
	xorl	%r11d, %r11d
	subq	(%rsp), %r11
	movq	%r12, %r14
	movq	%r12, %rdx
	andq	%r11, %rdx
	movq	%r15, %rsi
	andq	%r11, %rsi
	movq	%rbp, %rdi
	andq	%r11, %rdi
	movq	264(%rsp), %r12
	andq	%r12, %r11
	addq	%r9, %rdx
	adcq	%r8, %rsi
	adcq	%r10, %rdi
	adcq	$1, %rax
	addq	%r11, %rax
	subq	272(%rsp), %rdx
	movl	$1, %r8d
	sbbq	$0, %r8
	subq	280(%rsp), %rsi
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rsi
	adcq	$0, %r9
	addq	$-1, %rsi
	adcq	$-1, %r9
	xorq	$-2, %r9
	subq	288(%rsp), %rdi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%r9, %rdi
	adcq	$-1, %r8
	addq	$1, %rdi
	adcq	$0, %r8
	xorq	$-2, %r8
	subq	296(%rsp), %rax
	sbbq	$0, %r13
	addq	%r8, %rax
	adcq	$-1, %r13
	movq	%rax, %r8
	addq	$1, %r8
	adcq	$0, %r13
	xorq	$1, %r13
	movq	%r13, (%rsp)
	subq	(%rsp), %rcx
	movq	%r14, %r8
	andq	%rcx, %r8
	movq	%r15, %rbx
	andq	%rcx, %r15
	movq	%rbp, %r13
	andq	%rcx, %rbp
	andq	%r12, %rcx
	addq	%rdx, %r8
	adcq	%rsi, %r15
	adcq	%rdi, %rbp
	adcq	$1, %rax
	addq	%rcx, %rax
	movq	%r8, 512(%rsp)
	movq	%r15, 504(%rsp)
	movq	%rbp, 496(%rsp)
	leaq	48(%rsp), %r15
	movq	%rax, 488(%rsp)
	leaq	56(%rsp), %rbp
	movq	$0, (%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	xorps	%xmm0, %xmm0
	movups	%xmm0, 40(%rsp)
	movq	$0, 56(%rsp)
	movq	$4, 32(%rsp)
.Ltmp145:
	leaq	136(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movq	472(%rsp), %r12
	movq	%r12, %rsi
	movq	304(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp146:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
.Ltmp148:
	leaq	408(%rsp), %rdi
	leaq	136(%rsp), %rdx
	leaq	520(%rsp), %rcx
	movq	%r12, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp149:
	movq	408(%rsp), %rcx
	movq	416(%rsp), %rax
	subq	336(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	328(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	424(%rsp), %rdx
	xorq	$-2, %rsi
	subq	320(%rsp), %rdx
	movl	$1, %edi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rsi, %rdx
	adcq	$-1, %r8
	addq	$1, %rdx
	adcq	$0, %r8
	xorq	$-2, %r8
	movq	432(%rsp), %rsi
	subq	312(%rsp), %rsi
	sbbq	$0, %rdi
	addq	%r8, %rsi
	adcq	$-1, %rdi
	movq	%rsi, %r8
	addq	$1, %r8
	adcq	$0, %rdi
	xorq	$1, %rdi
	movq	%rdi, 32(%rsp)
	xorl	%edi, %edi
	subq	32(%rsp), %rdi
	movq	%r14, %r8
	andq	%rdi, %r8
	movq	%rbx, %r15
	movq	%rbx, %r9
	andq	%rdi, %r9
	movq	%r13, %rbp
	movq	%r13, %r10
	andq	%rdi, %r10
	andq	264(%rsp), %rdi
	addq	%rcx, %r8
	adcq	%rax, %r9
	adcq	%rdx, %r10
	adcq	$1, %rsi
	addq	%rdi, %rsi
	movq	%r8, 376(%rsp)
	movq	%r9, 384(%rsp)
	movq	%r10, 392(%rsp)
	movq	%rsi, 400(%rsp)
.Ltmp151:
	leaq	440(%rsp), %rdi
	leaq	552(%rsp), %rdx
	leaq	376(%rsp), %rcx
	movq	%r12, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp152:
	leaq	48(%rsp), %rbx
	leaq	56(%rsp), %r13
	xorps	%xmm0, %xmm0
	movups	%xmm0, 40(%rsp)
	movq	$0, 56(%rsp)
	movq	$8, 32(%rsp)
.Ltmp154:
	leaq	168(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movq	%r12, %rsi
	movq	304(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp155:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
.Ltmp157:
	leaq	32(%rsp), %rdi
	leaq	344(%rsp), %rcx
	movq	%r12, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp158:
.Ltmp160:
	movq	%rsp, %rdi
	leaq	168(%rsp), %rdx
	leaq	32(%rsp), %rcx
	movq	%r12, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp161:
	movq	584(%rsp), %rbx
	movq	264(%rsp), %r9
	movq	440(%rsp), %rdx
	movq	448(%rsp), %rcx
	subq	(%rsp), %rdx
	movl	$1, %eax
	sbbq	$0, %rax
	subq	8(%rsp), %rcx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rax, %rcx
	adcq	$0, %rdi
	addq	$-1, %rcx
	adcq	$-1, %rdi
	movq	456(%rsp), %rsi
	xorq	$-2, %rdi
	subq	16(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	addq	$1, %rsi
	adcq	$0, %r8
	xorq	$-2, %r8
	movq	464(%rsp), %rax
	subq	24(%rsp), %rax
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%r8, %rax
	adcq	$-1, %rdi
	movq	%rax, %r8
	addq	$1, %r8
	adcq	$0, %rdi
	xorq	$1, %rdi
	movq	%rdi, 608(%rsp)
	xorl	%edi, %edi
	subq	608(%rsp), %rdi
	andq	%rdi, %r14
	andq	%rdi, %r15
	andq	%rdi, %rbp
	andq	%rdi, %r9
	addq	%rdx, %r14
	adcq	%rcx, %r15
	adcq	%rsi, %rbp
	adcq	$1, %rax
	addq	%r9, %rax
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	336(%rsp), %rcx
	movq	328(%rsp), %rdx
	movq	320(%rsp), %rsi
	movq	312(%rsp), %rdi
	movq	512(%rsp), %r8
	movq	504(%rsp), %r9
	movq	496(%rsp), %r10
	movq	488(%rsp), %r11
	movq	%rcx, 168(%rsp)
	movq	%rdx, 176(%rsp)
	movq	%rsi, 184(%rsp)
	movq	%rdi, 192(%rsp)
	movq	%r14, 200(%rsp)
	movq	%r15, 208(%rsp)
	movq	%rbp, 216(%rsp)
	movq	%rax, 224(%rsp)
	movq	%r8, 232(%rsp)
	movq	%r9, 240(%rsp)
	movq	%r10, 248(%rsp)
	movq	%r11, 256(%rsp)
	movdqu	160(%rbx), %xmm0
	movups	176(%rbx), %xmm1
	movaps	%xmm1, 80(%rsp)
	movdqa	%xmm0, 64(%rsp)
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, 32(%rsp)
	movdqa	%xmm0, 48(%rsp)
	movdqa	%xmm0, 96(%rsp)
	movdqa	%xmm0, 112(%rsp)
	movq	480(%rsp), %rax
	movdqu	(%rax), %xmm1
	movdqu	16(%rax), %xmm2
	por	%xmm1, %xmm2
	pcmpeqd	%xmm0, %xmm2
	movmskps	%xmm2, %eax
	xorl	%ecx, %ecx
	xorl	$15, %eax
	sete	%cl
	leaq	168(%rsp), %rsi
	leaq	32(%rsp), %rdx
	movq	592(%rsp), %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, (%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	addq	$616, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB31_37:
	.cfi_def_cfa_offset 672
.Ltmp162:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	jmp	.LBB31_36
.LBB31_35:
.Ltmp159:
.LBB31_36:
	leaq	184(%rsp), %rbx
	leaq	192(%rsp), %r13
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	jmp	.LBB31_34
.LBB31_33:
.Ltmp156:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
.LBB31_34:
	movq	$0, (%rbx)
	movq	$0, (%r13)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	jmp	.LBB31_32
.LBB31_31:
.Ltmp153:
.LBB31_32:
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	jmp	.LBB31_30
.LBB31_29:
.Ltmp150:
.LBB31_30:
	leaq	152(%rsp), %r15
	leaq	160(%rsp), %rbp
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
.LBB31_39:
	movq	$0, (%r15)
	movq	$0, (%rbp)
	#MEMBARRIER
	movq	$0, 512(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 488(%rsp)
.LBB31_40:
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	jmp	.LBB31_24
.LBB31_38:
.Ltmp147:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	jmp	.LBB31_39
.LBB31_28:
.Ltmp144:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	jmp	.LBB31_40
.LBB31_27:
.Ltmp141:
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	jmp	.LBB31_26
.LBB31_25:
.Ltmp138:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
.LBB31_26:
	movq	$0, (%rbx)
	movq	$0, (%r13)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	jmp	.LBB31_24
.LBB31_23:
.Ltmp135:
.LBB31_24:
	leaq	568(%rsp), %r14
	leaq	576(%rsp), %r15
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
.LBB31_19:
	movq	$0, (%r14)
	movq	$0, (%r15)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
.LBB31_17:
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
.LBB31_42:
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.LBB31_22:
.Ltmp132:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	jmp	.LBB31_21
.LBB31_20:
.Ltmp129:
.LBB31_21:
	leaq	152(%rsp), %r14
	leaq	160(%rsp), %r15
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	jmp	.LBB31_19
.LBB31_18:
.Ltmp126:
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	jmp	.LBB31_19
.LBB31_16:
.Ltmp123:
	jmp	.LBB31_17
.LBB31_41:
.Ltmp120:
	jmp	.LBB31_42
.Lfunc_end31:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_, .Lfunc_end31-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table31:
.Lexception12:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end12-.Lcst_begin12
.Lcst_begin12:
	.uleb128 .Lfunc_begin12-.Lfunc_begin12
	.uleb128 .Ltmp118-.Lfunc_begin12
	.byte	0
	.byte	0
	.uleb128 .Ltmp118-.Lfunc_begin12
	.uleb128 .Ltmp119-.Ltmp118
	.uleb128 .Ltmp120-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp121-.Lfunc_begin12
	.uleb128 .Ltmp122-.Ltmp121
	.uleb128 .Ltmp123-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp124-.Lfunc_begin12
	.uleb128 .Ltmp125-.Ltmp124
	.uleb128 .Ltmp126-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp127-.Lfunc_begin12
	.uleb128 .Ltmp128-.Ltmp127
	.uleb128 .Ltmp129-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp130-.Lfunc_begin12
	.uleb128 .Ltmp131-.Ltmp130
	.uleb128 .Ltmp132-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp133-.Lfunc_begin12
	.uleb128 .Ltmp134-.Ltmp133
	.uleb128 .Ltmp135-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp136-.Lfunc_begin12
	.uleb128 .Ltmp137-.Ltmp136
	.uleb128 .Ltmp138-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp139-.Lfunc_begin12
	.uleb128 .Ltmp140-.Ltmp139
	.uleb128 .Ltmp141-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp142-.Lfunc_begin12
	.uleb128 .Ltmp143-.Ltmp142
	.uleb128 .Ltmp144-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp145-.Lfunc_begin12
	.uleb128 .Ltmp146-.Ltmp145
	.uleb128 .Ltmp147-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp148-.Lfunc_begin12
	.uleb128 .Ltmp149-.Ltmp148
	.uleb128 .Ltmp150-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp151-.Lfunc_begin12
	.uleb128 .Ltmp152-.Ltmp151
	.uleb128 .Ltmp153-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp154-.Lfunc_begin12
	.uleb128 .Ltmp155-.Ltmp154
	.uleb128 .Ltmp156-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp157-.Lfunc_begin12
	.uleb128 .Ltmp158-.Ltmp157
	.uleb128 .Ltmp159-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp160-.Lfunc_begin12
	.uleb128 .Ltmp161-.Ltmp160
	.uleb128 .Ltmp162-.Lfunc_begin12
	.byte	0
	.uleb128 .Ltmp161-.Lfunc_begin12
	.uleb128 .Lfunc_end31-.Ltmp161
	.byte	0
	.byte	0
.Lcst_end12:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_:
	.cfi_startproc
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm7
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm7
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm6
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm6
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm5
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm5
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm3
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm3
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm1
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm1
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm2
	punpcklqdq	%xmm2, %xmm0
	movdqu	(%rsi), %xmm8
	movdqu	(%rdx), %xmm4
	pxor	%xmm2, %xmm2
	pxor	%xmm9, %xmm9
	psubq	%xmm7, %xmm9
	pand	%xmm4, %xmm9
	pcmpeqd	%xmm4, %xmm4
	paddq	%xmm4, %xmm7
	pand	%xmm8, %xmm7
	por	%xmm9, %xmm7
	movdqu	%xmm7, (%rdi)
	movdqu	16(%rsi), %xmm7
	movdqu	16(%rdx), %xmm8
	pxor	%xmm9, %xmm9
	psubq	%xmm6, %xmm9
	pand	%xmm8, %xmm9
	paddq	%xmm4, %xmm6
	pand	%xmm7, %xmm6
	por	%xmm9, %xmm6
	movdqu	%xmm6, 16(%rdi)
	movdqu	32(%rsi), %xmm6
	movdqu	32(%rdx), %xmm7
	pxor	%xmm8, %xmm8
	psubq	%xmm5, %xmm8
	pand	%xmm7, %xmm8
	paddq	%xmm4, %xmm5
	pand	%xmm6, %xmm5
	por	%xmm8, %xmm5
	movdqu	%xmm5, 32(%rdi)
	movdqu	48(%rsi), %xmm5
	movdqu	48(%rdx), %xmm6
	pxor	%xmm7, %xmm7
	psubq	%xmm3, %xmm7
	pand	%xmm6, %xmm7
	paddq	%xmm4, %xmm3
	pand	%xmm5, %xmm3
	por	%xmm7, %xmm3
	movdqu	%xmm3, 48(%rdi)
	movdqu	64(%rsi), %xmm3
	movdqu	64(%rdx), %xmm5
	pxor	%xmm6, %xmm6
	psubq	%xmm1, %xmm6
	pand	%xmm5, %xmm6
	paddq	%xmm4, %xmm1
	pand	%xmm3, %xmm1
	por	%xmm6, %xmm1
	movdqu	%xmm1, 64(%rdi)
	movdqu	80(%rsi), %xmm1
	movdqu	80(%rdx), %xmm3
	psubq	%xmm0, %xmm2
	pand	%xmm3, %xmm2
	paddq	%xmm4, %xmm0
	pand	%xmm1, %xmm0
	por	%xmm2, %xmm0
	movdqu	%xmm0, 80(%rdi)
	retq
.Lfunc_end32:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_, .Lfunc_end32-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_:
.Lfunc_begin13:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception13
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1320, %rsp
	.cfi_def_cfa_offset 1376
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r12
	movq	%rdx, %r15
	movq	%rsi, %r14
	movq	%rdi, %rbx
	leaq	144(%rcx), %r13
	leaq	96(%rsi), %rbp
	leaq	1056(%rsp), %rdi
	movq	%r13, %rsi
	movq	%rbp, %rdx
	movq	%rbp, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	96(%r15), %rcx
.Ltmp163:
	leaq	1104(%rsp), %rdi
	movq	%r13, %rsi
	movq	%rcx, %rdx
	movq	%rcx, 1240(%rsp)
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp164:
.Ltmp166:
	leaq	616(%rsp), %rdi
	leaq	1104(%rsp), %rcx
	movq	%r13, %rsi
	movq	%r14, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp167:
.Ltmp169:
	leaq	760(%rsp), %rdi
	leaq	1056(%rsp), %rcx
	movq	%r13, %rsi
	movq	%r15, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp170:
.Ltmp172:
	leaq	8(%rsp), %rdi
	leaq	1104(%rsp), %rcx
	movq	%r13, %rsi
	leaq	96(%r15), %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp173:
	leaq	48(%r14), %rdx
.Ltmp175:
	leaq	664(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movq	%r13, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp176:
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
.Ltmp178:
	leaq	8(%rsp), %rdi
	leaq	1056(%rsp), %rcx
	movq	%r13, %rsi
	movq	%rbp, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp179:
	movq	%rbp, 1224(%rsp)
	movq	%r14, 1232(%rsp)
	movq	%rbx, 1200(%rsp)
	movq	%r15, 1208(%rsp)
	leaq	48(%r15), %rdx
.Ltmp181:
	leaq	808(%rsp), %rdi
	leaq	8(%rsp), %rcx
	movq	%r13, 856(%rsp)
	movq	%r13, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp182:
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	760(%rsp), %rsi
	movq	768(%rsp), %rdx
	subq	616(%rsp), %rsi
	movl	$1, %eax
	sbbq	$0, %rax
	subq	624(%rsp), %rdx
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %rdx
	adcq	$0, %rcx
	addq	$-1, %rdx
	adcq	$-1, %rcx
	movq	776(%rsp), %rdi
	xorq	$-2, %rcx
	subq	632(%rsp), %rdi
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%rcx, %rdi
	adcq	$-1, %rax
	addq	$1, %rdi
	adcq	$0, %rax
	movq	784(%rsp), %r13
	xorq	$-2, %rax
	subq	640(%rsp), %r13
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r13
	adcq	$-1, %rcx
	addq	$1, %r13
	adcq	$0, %rcx
	movq	792(%rsp), %rbp
	xorq	$-2, %rcx
	subq	648(%rsp), %rbp
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%rcx, %rbp
	adcq	$-1, %rax
	addq	$1, %rbp
	adcq	$0, %rax
	xorq	$-2, %rax
	movq	800(%rsp), %rcx
	subq	656(%rsp), %rcx
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rax, %rcx
	adcq	$-1, %r8
	movq	%rcx, %rax
	addq	$1, %rax
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, 8(%rsp)
	xorl	%ebx, %ebx
	subq	8(%rsp), %rbx
	movq	144(%r12), %r14
	movq	%r14, 168(%rsp)
	movq	152(%r12), %r11
	movq	%r11, 160(%rsp)
	andq	%rbx, %r14
	andq	%rbx, %r11
	movq	160(%r12), %r10
	movq	%r10, 152(%rsp)
	andq	%rbx, %r10
	movq	168(%r12), %r15
	movq	%r15, %r8
	andq	%rbx, %r8
	movq	176(%r12), %r9
	movq	%r9, 344(%rsp)
	andq	%rbx, %r9
	movq	%r12, 1216(%rsp)
	movq	184(%r12), %r12
	andq	%r12, %rbx
	xorl	%eax, %eax
	addq	%rsi, %r14
	adcq	%rdx, %r11
	adcq	%rdi, %r10
	adcq	%r13, %r8
	adcq	%rbp, %r9
	adcq	$1, %rcx
	addq	%rbx, %rcx
	movq	808(%rsp), %rdx
	subq	664(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	movq	816(%rsp), %rsi
	subq	672(%rsp), %rsi
	movl	$1, %ebx
	sbbq	$0, %rbx
	addq	%rdi, %rsi
	adcq	$0, %rbx
	addq	$-1, %rsi
	adcq	$-1, %rbx
	xorq	$-2, %rbx
	movq	824(%rsp), %rdi
	subq	680(%rsp), %rdi
	movl	$1, %ebp
	sbbq	$0, %rbp
	addq	%rbx, %rdi
	adcq	$-1, %rbp
	addq	$1, %rdi
	adcq	$0, %rbp
	xorq	$-2, %rbp
	movq	832(%rsp), %r13
	subq	688(%rsp), %r13
	movq	%r14, 288(%rsp)
	movl	$1, %ebx
	sbbq	$0, %rbx
	movq	%r11, 296(%rsp)
	addq	%rbp, %r13
	adcq	$-1, %rbx
	movq	%r10, 304(%rsp)
	addq	$1, %r13
	adcq	$0, %rbx
	xorq	$-2, %rbx
	movq	840(%rsp), %r10
	subq	696(%rsp), %r10
	movq	%r8, 312(%rsp)
	movl	$1, %r8d
	sbbq	$0, %r8
	movq	%r9, 320(%rsp)
	addq	%rbx, %r10
	adcq	$-1, %r8
	movq	%rcx, 328(%rsp)
	addq	$1, %r10
	adcq	$0, %r8
	xorq	$-2, %r8
	movq	848(%rsp), %rcx
	subq	704(%rsp), %rcx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rcx
	adcq	$-1, %r9
	movq	%rcx, %r8
	addq	$1, %r8
	adcq	$0, %r9
	xorq	$1, %r9
	movq	%r9, 8(%rsp)
	subq	8(%rsp), %rax
	movq	168(%rsp), %r8
	andq	%rax, %r8
	movq	160(%rsp), %r9
	andq	%rax, %r9
	movq	152(%rsp), %r11
	andq	%rax, %r11
	movq	%r15, 208(%rsp)
	movq	344(%rsp), %rbp
	andq	%rax, %r15
	movq	%rbp, %r14
	andq	%rax, %r14
	movq	%r12, 200(%rsp)
	andq	%r12, %rax
	addq	%rdx, %r8
	adcq	%rsi, %r9
	adcq	%rdi, %r11
	adcq	%r13, %r15
	adcq	%r10, %r14
	adcq	$1, %rcx
	addq	%rax, %rcx
	movq	%r8, 424(%rsp)
	movq	%r9, 432(%rsp)
	movq	%r11, 440(%rsp)
	movq	%r15, 448(%rsp)
	movq	%r14, 456(%rsp)
	movq	%rcx, 464(%rsp)
.Ltmp184:
	leaq	1152(%rsp), %rdi
	leaq	288(%rsp), %rcx
	movq	856(%rsp), %rbx
	movq	%rbx, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp185:
.Ltmp187:
	leaq	712(%rsp), %rdi
	leaq	288(%rsp), %rdx
	leaq	1152(%rsp), %rcx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp188:
.Ltmp190:
	leaq	240(%rsp), %rdi
	leaq	616(%rsp), %rdx
	leaq	1152(%rsp), %rcx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp191:
.Ltmp193:
	leaq	472(%rsp), %rdi
	leaq	424(%rsp), %rcx
	movq	%rbx, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp194:
	movq	472(%rsp), %rcx
	movq	480(%rsp), %rax
	subq	712(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	720(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	488(%rsp), %rdx
	xorq	$-2, %rsi
	subq	728(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	movq	496(%rsp), %rsi
	xorq	$-2, %rdi
	subq	736(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	addq	$1, %rsi
	adcq	$0, %r8
	movq	504(%rsp), %rdi
	xorq	$-2, %r8
	subq	744(%rsp), %rdi
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdi
	adcq	$-1, %r9
	addq	$1, %rdi
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	512(%rsp), %r8
	subq	752(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	movq	%r8, %r9
	addq	$1, %r9
	adcq	$0, %r10
	xorq	$1, %r10
	movq	%r10, 8(%rsp)
	xorl	%r13d, %r13d
	xorl	%r9d, %r9d
	subq	8(%rsp), %r9
	movq	168(%rsp), %r10
	andq	%r9, %r10
	movq	160(%rsp), %r11
	andq	%r9, %r11
	movq	152(%rsp), %rbx
	andq	%r9, %rbx
	movq	208(%rsp), %r14
	andq	%r9, %r14
	andq	%r9, %rbp
	andq	200(%rsp), %r9
	addq	%rcx, %r10
	adcq	%rax, %r11
	adcq	%rdx, %rbx
	adcq	%rsi, %r14
	adcq	%rdi, %rbp
	adcq	$1, %r8
	addq	%r9, %r8
	movq	%r10, 192(%rsp)
	movq	%r11, 184(%rsp)
	movq	%rbx, 176(%rsp)
	movq	%r14, 232(%rsp)
	movq	%rbp, 224(%rsp)
	movq	%r8, 216(%rsp)
	movq	240(%rsp), %rax
	leaq	(%rax,%rax), %rcx
	movq	248(%rsp), %rdx
	shrdq	$63, %rdx, %rax
	movq	%rcx, 912(%rsp)
	movq	256(%rsp), %rcx
	shrdq	$63, %rcx, %rdx
	movq	%rax, 920(%rsp)
	movq	264(%rsp), %rax
	shrdq	$63, %rax, %rcx
	movq	%rdx, 928(%rsp)
	movq	272(%rsp), %rdx
	shrdq	$63, %rdx, %rax
	movq	%rcx, 936(%rsp)
	movq	280(%rsp), %rcx
	shrdq	$63, %rcx, %rdx
	movq	%rax, 944(%rsp)
	movq	%rdx, 952(%rsp)
	movl	$1, %r14d
	shrq	$63, %rcx
	leaq	8(%rsp), %rdi
	leaq	912(%rsp), %rdx
	movq	856(%rsp), %r12
	movq	%r12, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 912(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	#MEMBARRIER
	movq	184(%rsp), %rax
	movq	192(%rsp), %rcx
	subq	8(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	16(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	176(%rsp), %rdx
	xorq	$-2, %rsi
	subq	24(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	movq	232(%rsp), %rsi
	xorq	$-2, %rdi
	subq	32(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	addq	$1, %rsi
	adcq	$0, %r8
	movq	224(%rsp), %rdi
	xorq	$-2, %r8
	subq	40(%rsp), %rdi
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdi
	adcq	$-1, %r9
	addq	$1, %rdi
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	216(%rsp), %r8
	subq	48(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	movq	%r8, %r9
	addq	$1, %r9
	adcq	$0, %r10
	xorq	$1, %r10
	movq	%r10, 8(%rsp)
	xorl	%r9d, %r9d
	subq	8(%rsp), %r9
	movq	168(%rsp), %r10
	andq	%r9, %r10
	movq	160(%rsp), %r11
	andq	%r9, %r11
	movq	152(%rsp), %rbx
	andq	%r9, %rbx
	movq	208(%rsp), %rbp
	andq	%r9, %rbp
	movq	344(%rsp), %r15
	andq	%r9, %r15
	andq	200(%rsp), %r9
	addq	%rcx, %r10
	adcq	%rax, %r11
	adcq	%rdx, %rbx
	adcq	%rsi, %rbp
	adcq	%rdi, %r15
	adcq	$1, %r8
	addq	%r9, %r8
	movq	%r10, 392(%rsp)
	movq	%r11, 384(%rsp)
	movq	%rbx, 376(%rsp)
	movq	%rbp, 368(%rsp)
	movq	%r12, %rbp
	movq	344(%rsp), %r12
	movq	%r15, 360(%rsp)
	movq	%r8, 352(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 1272(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	240(%rsp), %rcx
	movq	248(%rsp), %rax
	subq	392(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	384(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	256(%rsp), %rdx
	xorq	$-2, %rsi
	subq	376(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	movq	264(%rsp), %rsi
	xorq	$-2, %rdi
	subq	368(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	addq	$1, %rsi
	adcq	$0, %r8
	movq	272(%rsp), %rdi
	xorq	$-2, %r8
	subq	360(%rsp), %rdi
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdi
	adcq	$-1, %r9
	addq	$1, %rdi
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	280(%rsp), %r8
	subq	352(%rsp), %r8
	sbbq	$0, %r14
	addq	%r9, %r8
	adcq	$-1, %r14
	movq	%r8, %r9
	addq	$1, %r9
	adcq	$0, %r14
	xorq	$1, %r14
	movq	%r14, 8(%rsp)
	subq	8(%rsp), %r13
	movq	168(%rsp), %r9
	andq	%r13, %r9
	movq	160(%rsp), %r10
	andq	%r13, %r10
	movq	152(%rsp), %r11
	andq	%r13, %r11
	movq	208(%rsp), %rbx
	andq	%r13, %rbx
	movq	%r12, %r14
	andq	%r13, %r14
	andq	200(%rsp), %r13
	addq	%rcx, %r9
	adcq	%rax, %r10
	adcq	%rdx, %r11
	adcq	%rsi, %rbx
	adcq	%rdi, %r14
	adcq	$1, %r8
	addq	%r13, %r8
	movq	%r9, 912(%rsp)
	movq	%r10, 920(%rsp)
	movq	%r11, 928(%rsp)
	movq	%rbx, 936(%rsp)
	movq	%r14, 944(%rsp)
	movq	%r8, 952(%rsp)
.Ltmp196:
	leaq	472(%rsp), %rdi
	leaq	424(%rsp), %rdx
	leaq	912(%rsp), %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp197:
.Ltmp199:
	leaq	8(%rsp), %rdi
	leaq	664(%rsp), %rdx
	leaq	712(%rsp), %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp200:
	movq	1232(%rsp), %r13
	movq	472(%rsp), %rcx
	movq	480(%rsp), %rax
	subq	8(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	16(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	488(%rsp), %rdx
	xorq	$-2, %rsi
	subq	24(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	movq	496(%rsp), %rsi
	xorq	$-2, %rdi
	subq	32(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	addq	$1, %rsi
	adcq	$0, %r8
	movq	504(%rsp), %rdi
	xorq	$-2, %r8
	subq	40(%rsp), %rdi
	movl	$1, %r9d
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r8, %rdi
	adcq	$-1, %r10
	addq	$1, %rdi
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	512(%rsp), %r8
	subq	48(%rsp), %r8
	sbbq	$0, %r9
	addq	%r10, %r8
	adcq	$-1, %r9
	movq	%r8, %r10
	addq	$1, %r10
	adcq	$0, %r9
	xorq	$1, %r9
	movq	%r9, 1272(%rsp)
	xorl	%r9d, %r9d
	subq	1272(%rsp), %r9
	movq	168(%rsp), %r10
	andq	%r9, %r10
	movq	160(%rsp), %r11
	andq	%r9, %r11
	movq	152(%rsp), %rbx
	andq	%r9, %rbx
	movq	208(%rsp), %r14
	andq	%r9, %r14
	andq	%r9, %r12
	movq	200(%rsp), %r15
	andq	%r9, %r15
	addq	%rcx, %r10
	adcq	%rax, %r11
	adcq	%rdx, %rbx
	adcq	%rsi, %r14
	adcq	%rdi, %r12
	adcq	$1, %r8
	addq	%r15, %r8
	movq	%r10, 904(%rsp)
	movq	%r11, 896(%rsp)
	movq	%rbx, 888(%rsp)
	movq	%r14, 880(%rsp)
	movq	%r12, 872(%rsp)
	movq	%r8, 864(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	$0, 912(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	#MEMBARRIER
.Ltmp202:
	leaq	8(%rsp), %rdi
	movq	%rbp, %rsi
	movq	1224(%rsp), %rdx
	movq	1240(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp203:
.Ltmp205:
	leaq	1272(%rsp), %rdi
	leaq	288(%rsp), %rdx
	leaq	8(%rsp), %rcx
	movq	%rbp, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp206:
	movq	1216(%rsp), %rdx
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	392(%rsp), %rax
	movq	384(%rsp), %rcx
	movq	376(%rsp), %r12
	movq	368(%rsp), %rsi
	movq	360(%rsp), %rdi
	movq	352(%rsp), %r8
	movq	904(%rsp), %r9
	movq	896(%rsp), %r10
	movq	888(%rsp), %r11
	movq	880(%rsp), %rbx
	movq	872(%rsp), %r14
	movq	864(%rsp), %r15
	movups	1272(%rsp), %xmm0
	movups	1288(%rsp), %xmm1
	movups	1304(%rsp), %xmm2
	movups	%xmm0, 568(%rsp)
	movups	%xmm1, 584(%rsp)
	movups	%xmm2, 600(%rsp)
	movq	%rax, 472(%rsp)
	movq	%rcx, 480(%rsp)
	movq	%r12, 488(%rsp)
	movq	%rsi, 496(%rsp)
	movq	%rdi, 504(%rsp)
	movq	%r8, 512(%rsp)
	movq	%r9, 520(%rsp)
	movq	%r10, 528(%rsp)
	movq	%r11, 536(%rsp)
	movq	%rbx, 544(%rsp)
	movq	%r14, 552(%rsp)
	movq	%r15, 560(%rsp)
.Ltmp208:
	leaq	8(%rsp), %rdi
	movq	%r13, %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_
.Ltmp209:
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 1264(%rsp)
	movq	$0, 1256(%rsp)
	movq	$0, 1248(%rsp)
	movdqu	424(%rsp), %xmm0
	movdqu	440(%rsp), %xmm1
	movdqu	456(%rsp), %xmm2
	por	320(%rsp), %xmm1
	por	304(%rsp), %xmm0
	por	288(%rsp), %xmm1
	por	%xmm2, %xmm0
	por	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	pcmpeqd	%xmm1, %xmm0
	movmskps	%xmm0, %eax
	xorl	%ecx, %ecx
	xorl	$15, %eax
	sete	%cl
	leaq	912(%rsp), %r14
	leaq	472(%rsp), %rsi
	leaq	8(%rsp), %rdx
	movq	%r14, %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 416(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 1264(%rsp)
	movq	$0, 1256(%rsp)
	movq	$0, 1248(%rsp)
	#MEMBARRIER
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	1208(%rsp), %rbx
	movdqu	96(%rbx), %xmm0
	movdqu	112(%rbx), %xmm1
	por	%xmm0, %xmm1
	pshufd	$238, %xmm1, %xmm0
	por	%xmm1, %xmm0
	movq	%xmm0, %rax
	orq	128(%rbx), %rax
	xorl	%ecx, %ecx
	orq	136(%rbx), %rax
	sete	%cl
	leaq	8(%rsp), %r12
	movq	%r12, %rdi
	movq	%r14, %rsi
	movq	%r13, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 416(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movdqu	96(%r13), %xmm0
	movdqu	112(%r13), %xmm1
	por	%xmm0, %xmm1
	pshufd	$238, %xmm1, %xmm0
	por	%xmm1, %xmm0
	movq	%xmm0, %rax
	orq	128(%r13), %rax
	xorl	%ecx, %ecx
	orq	136(%r13), %rax
	sete	%cl
	movq	1200(%rsp), %rdi
	movq	%r12, %rsi
	movq	%rbx, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 416(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 912(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	#MEMBARRIER
	movq	$0, 960(%rsp)
	movq	$0, 968(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	#MEMBARRIER
	movq	$0, 1008(%rsp)
	movq	$0, 1016(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	#MEMBARRIER
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	#MEMBARRIER
	movq	$0, 1152(%rsp)
	movq	$0, 1160(%rsp)
	movq	$0, 1168(%rsp)
	movq	$0, 1176(%rsp)
	movq	$0, 1184(%rsp)
	movq	$0, 1192(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	#MEMBARRIER
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	#MEMBARRIER
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	#MEMBARRIER
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	#MEMBARRIER
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	#MEMBARRIER
	movq	$0, 1056(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	#MEMBARRIER
	addq	$1320, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB33_17:
	.cfi_def_cfa_offset 1376
.Ltmp210:
	movq	%rax, %rbx
	leaq	472(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	jmp	.LBB33_26
.LBB33_18:
.Ltmp207:
	movq	%rax, %rbx
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	jmp	.LBB33_20
.LBB33_19:
.Ltmp204:
	movq	%rax, %rbx
.LBB33_20:
	movq	$0, 904(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 872(%rsp)
	movq	$0, 864(%rsp)
	jmp	.LBB33_24
.LBB33_21:
.Ltmp201:
	movq	%rax, %rbx
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	jmp	.LBB33_23
.LBB33_22:
.Ltmp198:
	movq	%rax, %rbx
.LBB33_23:
	movq	$0, 912(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
.LBB33_24:
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	#MEMBARRIER
	jmp	.LBB33_26
.LBB33_25:
.Ltmp195:
	movq	%rax, %rbx
.LBB33_26:
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
.LBB33_27:
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	#MEMBARRIER
.LBB33_28:
	movq	$0, 1152(%rsp)
	movq	$0, 1160(%rsp)
	movq	$0, 1168(%rsp)
	movq	$0, 1176(%rsp)
	movq	$0, 1184(%rsp)
	movq	$0, 1192(%rsp)
	#MEMBARRIER
.LBB33_29:
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
.LBB33_30:
	#MEMBARRIER
.LBB33_31:
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
.LBB33_32:
	#MEMBARRIER
.LBB33_33:
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	#MEMBARRIER
.LBB33_34:
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	#MEMBARRIER
.LBB33_35:
	movq	$0, 1104(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1136(%rsp)
	movq	$0, 1144(%rsp)
	#MEMBARRIER
.LBB33_36:
	movq	$0, 1056(%rsp)
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	#MEMBARRIER
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB33_37:
.Ltmp192:
	movq	%rax, %rbx
	jmp	.LBB33_27
.LBB33_38:
.Ltmp189:
	movq	%rax, %rbx
	jmp	.LBB33_28
.LBB33_39:
.Ltmp186:
	movq	%rax, %rbx
	jmp	.LBB33_29
.LBB33_40:
.Ltmp183:
	movq	%rax, %rbx
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	jmp	.LBB33_30
.LBB33_41:
.Ltmp180:
	movq	%rax, %rbx
	jmp	.LBB33_31
.LBB33_42:
.Ltmp177:
	movq	%rax, %rbx
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	jmp	.LBB33_32
.LBB33_43:
.Ltmp174:
	movq	%rax, %rbx
	jmp	.LBB33_33
.LBB33_44:
.Ltmp171:
	movq	%rax, %rbx
	jmp	.LBB33_34
.LBB33_45:
.Ltmp168:
	movq	%rax, %rbx
	jmp	.LBB33_35
.LBB33_46:
.Ltmp165:
	movq	%rax, %rbx
	jmp	.LBB33_36
.Lfunc_end33:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_, .Lfunc_end33-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table33:
.Lexception13:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end13-.Lcst_begin13
.Lcst_begin13:
	.uleb128 .Lfunc_begin13-.Lfunc_begin13
	.uleb128 .Ltmp163-.Lfunc_begin13
	.byte	0
	.byte	0
	.uleb128 .Ltmp163-.Lfunc_begin13
	.uleb128 .Ltmp164-.Ltmp163
	.uleb128 .Ltmp165-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp166-.Lfunc_begin13
	.uleb128 .Ltmp167-.Ltmp166
	.uleb128 .Ltmp168-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp169-.Lfunc_begin13
	.uleb128 .Ltmp170-.Ltmp169
	.uleb128 .Ltmp171-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp172-.Lfunc_begin13
	.uleb128 .Ltmp173-.Ltmp172
	.uleb128 .Ltmp174-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp175-.Lfunc_begin13
	.uleb128 .Ltmp176-.Ltmp175
	.uleb128 .Ltmp177-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp178-.Lfunc_begin13
	.uleb128 .Ltmp179-.Ltmp178
	.uleb128 .Ltmp180-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp181-.Lfunc_begin13
	.uleb128 .Ltmp182-.Ltmp181
	.uleb128 .Ltmp183-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp184-.Lfunc_begin13
	.uleb128 .Ltmp185-.Ltmp184
	.uleb128 .Ltmp186-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp187-.Lfunc_begin13
	.uleb128 .Ltmp188-.Ltmp187
	.uleb128 .Ltmp189-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp190-.Lfunc_begin13
	.uleb128 .Ltmp191-.Ltmp190
	.uleb128 .Ltmp192-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp193-.Lfunc_begin13
	.uleb128 .Ltmp194-.Ltmp193
	.uleb128 .Ltmp195-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp196-.Lfunc_begin13
	.uleb128 .Ltmp197-.Ltmp196
	.uleb128 .Ltmp198-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp199-.Lfunc_begin13
	.uleb128 .Ltmp200-.Ltmp199
	.uleb128 .Ltmp201-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp202-.Lfunc_begin13
	.uleb128 .Ltmp203-.Ltmp202
	.uleb128 .Ltmp204-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp205-.Lfunc_begin13
	.uleb128 .Ltmp206-.Ltmp205
	.uleb128 .Ltmp207-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp208-.Lfunc_begin13
	.uleb128 .Ltmp209-.Ltmp208
	.uleb128 .Ltmp210-.Lfunc_begin13
	.byte	0
	.uleb128 .Ltmp209-.Lfunc_begin13
	.uleb128 .Lfunc_end33-.Ltmp209
	.byte	0
	.byte	0
.Lcst_end13:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_:
.Lfunc_begin14:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception14
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$616, %rsp
	.cfi_def_cfa_offset 672
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r14
	movq	%rdx, 16(%rsp)
	movq	%rsi, 24(%rsp)
	movq	%rdi, 8(%rsp)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm0, 128(%rsp)
	movups	240(%rcx), %xmm1
	movups	256(%rcx), %xmm2
	movups	272(%rcx), %xmm3
	movaps	%xmm1, 80(%rsp)
	movaps	%xmm2, 96(%rsp)
	movaps	%xmm3, 112(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 64(%rsp)
	movl	$383, %r12d
	leaq	184(%rsp), %r13
	leaq	32(%rsp), %rbp
	leaq	328(%rsp), %rbx
	leaq	472(%rsp), %r15
	.p2align	4
.LBB34_1:
.Ltmp211:
	movq	%r13, %rdi
	movq	%rbp, %rsi
	movq	%r14, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_
.Ltmp212:
.Ltmp214:
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	24(%rsp), %rdx
	movq	%r14, %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_
.Ltmp215:
	movq	%r12, %rax
	shrq	$6, %rax
	movq	16(%rsp), %rcx
	movq	(%rcx,%rax,8), %rax
	xorl	%ecx, %ecx
	btq	%r12, %rax
	setb	%cl
	movq	%r15, %rdi
	movq	%r13, %rsi
	movq	%rbx, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	movl	$144, %edx
	movq	%rbp, %rdi
	movq	%r15, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	addq	$-1, %r12
	jb	.LBB34_1
	leaq	32(%rsp), %rsi
	movl	$144, %edx
	movq	8(%rsp), %rdi
	callq	*memcpy@GOTPCREL(%rip)
	addq	$616, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB34_5:
	.cfi_def_cfa_offset 672
.Ltmp213:
	movq	%rax, %rbx
	leaq	32(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB34_7:
.Ltmp216:
	movq	%rax, %rbx
	leaq	184(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	leaq	32(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end34:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_, .Lfunc_end34-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table34:
.Lexception14:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end14-.Lcst_begin14
.Lcst_begin14:
	.uleb128 .Ltmp211-.Lfunc_begin14
	.uleb128 .Ltmp212-.Ltmp211
	.uleb128 .Ltmp213-.Lfunc_begin14
	.byte	0
	.uleb128 .Ltmp214-.Lfunc_begin14
	.uleb128 .Ltmp215-.Ltmp214
	.uleb128 .Ltmp216-.Lfunc_begin14
	.byte	0
	.uleb128 .Ltmp215-.Lfunc_begin14
	.uleb128 .Lfunc_end34-.Ltmp215
	.byte	0
	.byte	0
.Lcst_end14:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_:
.Lfunc_begin15:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception15
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$440, %rsp
	.cfi_def_cfa_offset 496
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movdqu	96(%rsi), %xmm0
	movdqu	112(%rsi), %xmm1
	por	%xmm0, %xmm1
	pshufd	$238, %xmm1, %xmm0
	por	%xmm1, %xmm0
	movq	%xmm0, %rax
	orq	128(%rsi), %rax
	orq	136(%rsi), %rax
	movq	$0, (%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	je	.LBB35_1
	movq	%rdx, %r14
	movq	%rsi, %r15
	leaq	96(%rsi), %rdx
	addq	$144, %r14
	leaq	296(%rsp), %r12
	movq	%r12, %rdi
	movq	%r14, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_
.Ltmp217:
	leaq	152(%rsp), %rdi
	movq	%r14, %rsi
	movq	%r12, %rdx
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp218:
.Ltmp220:
	leaq	200(%rsp), %rdi
	leaq	152(%rsp), %rcx
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp221:
	leaq	32(%rsp), %r13
	leaq	40(%rsp), %rbp
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, 24(%rsp)
	movdqu	%xmm0, 8(%rsp)
	movq	$0, 40(%rsp)
	movq	$1, (%rsp)
.Ltmp223:
	leaq	104(%rsp), %r12
	leaq	200(%rsp), %rdx
	movq	%rsp, %rcx
	movq	%r12, %rdi
	movq	%r14, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp224:
	leaq	136(%rsp), %r13
	leaq	144(%rsp), %rbp
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
.Ltmp226:
	leaq	248(%rsp), %rdi
	leaq	152(%rsp), %rdx
	leaq	296(%rsp), %rcx
	movq	%r14, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp227:
	addq	$48, %r15
.Ltmp229:
	leaq	344(%rsp), %rdi
	leaq	248(%rsp), %rcx
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp230:
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, 24(%rsp)
	movdqu	%xmm0, 8(%rsp)
	movq	$0, 40(%rsp)
	movq	$1, (%rsp)
.Ltmp232:
	leaq	392(%rsp), %rdi
	leaq	344(%rsp), %r12
	movq	%rsp, %rcx
	movq	%r14, %rsi
	movq	%r12, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp233:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movdqu	104(%rsp), %xmm0
	movdqu	120(%rsp), %xmm1
	movups	136(%rsp), %xmm2
	movdqa	%xmm0, (%rsp)
	movdqa	%xmm1, 16(%rsp)
	movaps	%xmm2, 32(%rsp)
	movups	392(%rsp), %xmm3
	movups	408(%rsp), %xmm4
	movups	424(%rsp), %xmm5
	movaps	%xmm3, 48(%rsp)
	movaps	%xmm4, 64(%rsp)
	movaps	%xmm5, 80(%rsp)
	movups	%xmm5, 88(%rbx)
	movups	%xmm4, 72(%rbx)
	movups	%xmm3, 56(%rbx)
	movups	%xmm2, 40(%rbx)
	movdqu	%xmm1, 24(%rbx)
	movdqu	%xmm0, 8(%rbx)
	movb	$0, (%rbx)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	#MEMBARRIER
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	jmp	.LBB35_2
.LBB35_1:
	movw	$769, (%rbx)
.LBB35_2:
	addq	$440, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB35_18:
	.cfi_def_cfa_offset 496
.Ltmp234:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	jmp	.LBB35_19
.LBB35_17:
.Ltmp231:
.LBB35_19:
	leaq	264(%rsp), %rcx
	leaq	272(%rsp), %rdx
	leaq	280(%rsp), %r13
	leaq	288(%rsp), %rbp
	movq	$0, (%r12)
	movq	$0, 8(%r12)
	movq	$0, 16(%r12)
	movq	$0, 24(%r12)
	movq	$0, 32(%r12)
	movq	$0, 40(%r12)
	#MEMBARRIER
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	jmp	.LBB35_15
.LBB35_16:
.Ltmp228:
	leaq	128(%rsp), %rdx
	leaq	120(%rsp), %rcx
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	jmp	.LBB35_15
.LBB35_14:
.Ltmp225:
	leaq	24(%rsp), %rdx
	leaq	16(%rsp), %rcx
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
.LBB35_15:
	movq	$0, (%rcx)
	movq	$0, (%rdx)
	movq	$0, (%r13)
	movq	$0, (%rbp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	jmp	.LBB35_13
.LBB35_12:
.Ltmp222:
.LBB35_13:
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
.LBB35_4:
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.LBB35_3:
.Ltmp219:
	jmp	.LBB35_4
.Lfunc_end35:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_, .Lfunc_end35-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table35:
.Lexception15:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end15-.Lcst_begin15
.Lcst_begin15:
	.uleb128 .Lfunc_begin15-.Lfunc_begin15
	.uleb128 .Ltmp217-.Lfunc_begin15
	.byte	0
	.byte	0
	.uleb128 .Ltmp217-.Lfunc_begin15
	.uleb128 .Ltmp218-.Ltmp217
	.uleb128 .Ltmp219-.Lfunc_begin15
	.byte	0
	.uleb128 .Ltmp220-.Lfunc_begin15
	.uleb128 .Ltmp221-.Ltmp220
	.uleb128 .Ltmp222-.Lfunc_begin15
	.byte	0
	.uleb128 .Ltmp223-.Lfunc_begin15
	.uleb128 .Ltmp224-.Ltmp223
	.uleb128 .Ltmp225-.Lfunc_begin15
	.byte	0
	.uleb128 .Ltmp226-.Lfunc_begin15
	.uleb128 .Ltmp227-.Ltmp226
	.uleb128 .Ltmp228-.Lfunc_begin15
	.byte	0
	.uleb128 .Ltmp229-.Lfunc_begin15
	.uleb128 .Ltmp230-.Ltmp229
	.uleb128 .Ltmp231-.Lfunc_begin15
	.byte	0
	.uleb128 .Ltmp232-.Lfunc_begin15
	.uleb128 .Ltmp233-.Ltmp232
	.uleb128 .Ltmp234-.Lfunc_begin15
	.byte	0
	.uleb128 .Ltmp233-.Lfunc_begin15
	.uleb128 .Lfunc_end35-.Ltmp233
	.byte	0
	.byte	0
.Lcst_end15:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_:
.Lfunc_begin16:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception16
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$952, %rsp
	.cfi_def_cfa_offset 1008
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %rbp
	movq	%rsi, %r13
	movq	%rdi, %rbx
	leaq	144(%rdx), %r14
	leaq	96(%rsi), %rcx
	leaq	480(%rsp), %rdi
	movq	%r14, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	48(%r13), %rcx
.Ltmp235:
	leaq	600(%rsp), %rdi
	movq	%r14, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp236:
.Ltmp238:
	leaq	800(%rsp), %rdi
	leaq	600(%rsp), %rcx
	movq	%r14, 192(%rsp)
	movq	%r14, %rsi
	movq	%r13, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp239:
	movq	%rbx, 944(%rsp)
	leaq	64(%rsp), %rbx
	leaq	72(%rsp), %r14
	leaq	80(%rsp), %r15
	leaq	88(%rsp), %r12
	xorps	%xmm0, %xmm0
	movups	%xmm0, 72(%rsp)
	movups	%xmm0, 56(%rsp)
	movq	$0, 88(%rsp)
	movq	$3, 48(%rsp)
	movq	%rbp, 744(%rsp)
	leaq	192(%rbp), %rcx
.Ltmp241:
	leaq	200(%rsp), %rdi
	leaq	48(%rsp), %rdx
	movq	192(%rsp), %rsi
	movq	%rcx, 536(%rsp)
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp242:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	leaq	392(%rsp), %rbp
	leaq	480(%rsp), %rcx
	movq	%rbp, %rdi
	movq	192(%rsp), %rbx
	movq	%rbx, %rsi
	movq	%r13, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_
	movq	480(%rsp), %rax
	addq	(%r13), %rax
	movq	8(%r13), %rcx
	adcq	$0, %rcx
	movq	%rax, 248(%rsp)
	setb	%al
	addq	488(%rsp), %rcx
	movzbl	%al, %eax
	adcq	16(%r13), %rax
	movq	%rcx, 256(%rsp)
	setb	%cl
	addq	496(%rsp), %rax
	movzbl	%cl, %ecx
	adcq	24(%r13), %rcx
	movq	%rax, 264(%rsp)
	setb	%al
	addq	504(%rsp), %rcx
	movzbl	%al, %eax
	adcq	32(%r13), %rax
	movq	%rcx, 272(%rsp)
	setb	%cl
	addq	512(%rsp), %rax
	movzbl	%cl, %edx
	adcq	40(%r13), %rdx
	movq	%rax, 280(%rsp)
	setb	%al
	addq	520(%rsp), %rdx
	movzbl	%al, %ecx
	adcq	$0, %rcx
	movq	%rdx, 288(%rsp)
	leaq	48(%rsp), %rdi
	leaq	248(%rsp), %rdx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movups	48(%rsp), %xmm0
	movups	64(%rsp), %xmm1
	movups	80(%rsp), %xmm2
	movaps	%xmm2, 32(%rsp)
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
.Ltmp244:
	leaq	48(%rsp), %rdi
	movq	%rsp, %rcx
	movq	%rbx, %rsi
	movq	%rbp, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp245:
.Ltmp247:
	leaq	848(%rsp), %rdi
	leaq	200(%rsp), %rdx
	leaq	48(%rsp), %rcx
	movq	%rbx, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp248:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
.Ltmp250:
	movq	%rsp, %rdi
	leaq	848(%rsp), %rcx
	movq	%rbx, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp251:
	movq	744(%rsp), %rbp
	leaq	64(%rsp), %rbx
	leaq	72(%rsp), %r14
	leaq	80(%rsp), %r15
	leaq	88(%rsp), %r12
	xorps	%xmm0, %xmm0
	movups	%xmm0, 72(%rsp)
	movups	%xmm0, 56(%rsp)
	movq	$0, 88(%rsp)
	movq	$8, 48(%rsp)
.Ltmp253:
	leaq	248(%rsp), %rdi
	leaq	48(%rsp), %rdx
	movq	192(%rsp), %rsi
	movq	536(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp254:
	leaq	264(%rsp), %rbx
	leaq	272(%rsp), %r14
	leaq	280(%rsp), %r15
	leaq	288(%rsp), %r12
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
.Ltmp256:
	leaq	48(%rsp), %rdi
	leaq	248(%rsp), %rdx
	leaq	800(%rsp), %rcx
	movq	192(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp257:
	movq	(%rsp), %rcx
	movq	8(%rsp), %rax
	subq	48(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	56(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	16(%rsp), %rdx
	xorq	$-2, %rsi
	subq	64(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	movq	24(%rsp), %rsi
	xorq	$-2, %rdi
	subq	72(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	addq	$1, %rsi
	adcq	$0, %r8
	movq	32(%rsp), %rdi
	xorq	$-2, %r8
	subq	80(%rsp), %rdi
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdi
	adcq	$-1, %r9
	addq	$1, %rdi
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	40(%rsp), %r8
	subq	88(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	movq	%r8, %r9
	addq	$1, %r9
	adcq	$0, %r10
	xorq	$1, %r10
	movq	%r10, 392(%rsp)
	xorl	%r9d, %r9d
	subq	392(%rsp), %r9
	movq	144(%rbp), %r10
	movq	152(%rbp), %r11
	movq	%r10, 472(%rsp)
	andq	%r9, %r10
	movq	%r11, 464(%rsp)
	andq	%r9, %r11
	movq	160(%rbp), %rbx
	movq	%rbx, 456(%rsp)
	andq	%r9, %rbx
	movq	168(%rbp), %r14
	movq	%r14, 448(%rsp)
	andq	%r9, %r14
	movq	176(%rbp), %r12
	movq	%r12, 440(%rsp)
	andq	%r9, %r12
	movq	184(%rbp), %r15
	movq	%r15, 528(%rsp)
	andq	%r15, %r9
	addq	%rcx, %r10
	adcq	%rax, %r11
	adcq	%rdx, %rbx
	adcq	%rsi, %r14
	adcq	%rdi, %r12
	adcq	$1, %r8
	addq	%r9, %r8
	movq	%r10, 584(%rsp)
	movq	%r11, 576(%rsp)
	movq	%rbx, 568(%rsp)
	movq	%r14, 560(%rsp)
	movq	%r12, 552(%rsp)
	movq	%r8, 544(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	96(%r13), %rcx
	movq	48(%r13), %rax
	movq	%rcx, 936(%rsp)
	addq	%rcx, %rax
	movq	%rax, 248(%rsp)
	movq	56(%r13), %rax
	adcq	$0, %rax
	movq	104(%r13), %rdx
	setb	%cl
	movzbl	%cl, %ecx
	movq	%rdx, 928(%rsp)
	addq	%rdx, %rax
	movq	%rax, 256(%rsp)
	adcq	64(%r13), %rcx
	movq	112(%r13), %rdx
	setb	%al
	movzbl	%al, %eax
	movq	%rdx, 896(%rsp)
	addq	%rdx, %rcx
	movq	%rcx, 264(%rsp)
	adcq	72(%r13), %rax
	movq	120(%r13), %rdx
	setb	%cl
	movzbl	%cl, %ecx
	movq	%rdx, 920(%rsp)
	addq	%rdx, %rax
	movq	%rax, 272(%rsp)
	adcq	80(%r13), %rcx
	movq	128(%r13), %rdx
	setb	%al
	movzbl	%al, %eax
	movq	%rdx, 912(%rsp)
	addq	%rdx, %rcx
	movq	%rcx, 280(%rsp)
	adcq	88(%r13), %rax
	movq	136(%r13), %rdx
	setb	%cl
	movq	%rdx, 904(%rsp)
	addq	%rdx, %rax
	movq	%rax, 288(%rsp)
	movl	$1, %ebx
	movzbl	%cl, %ecx
	adcq	$0, %rcx
	leaq	48(%rsp), %rdi
	leaq	248(%rsp), %rdx
	movq	192(%rsp), %r14
	movq	%r14, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movups	48(%rsp), %xmm0
	movups	64(%rsp), %xmm1
	movups	80(%rsp), %xmm2
	movaps	%xmm2, 32(%rsp)
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
.Ltmp259:
	leaq	48(%rsp), %rdi
	movq	%rsp, %rcx
	movq	%r14, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp260:
	movq	48(%rsp), %r11
	movq	56(%rsp), %r10
	subq	600(%rsp), %r11
	movl	$1, %eax
	sbbq	$0, %rax
	subq	608(%rsp), %r10
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r10
	adcq	$0, %rcx
	addq	$-1, %r10
	adcq	$-1, %rcx
	movq	64(%rsp), %rbp
	xorq	$-2, %rcx
	subq	616(%rsp), %rbp
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%rcx, %rbp
	adcq	$-1, %rax
	addq	$1, %rbp
	adcq	$0, %rax
	movq	72(%rsp), %r12
	xorq	$-2, %rax
	subq	624(%rsp), %r12
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r12
	adcq	$-1, %rcx
	addq	$1, %r12
	adcq	$0, %rcx
	movq	80(%rsp), %r14
	xorq	$-2, %rcx
	subq	632(%rsp), %r14
	movl	$1, %edx
	sbbq	$0, %rdx
	addq	%rcx, %r14
	adcq	$-1, %rdx
	addq	$1, %r14
	adcq	$0, %rdx
	xorq	$-2, %rdx
	movq	88(%rsp), %rax
	subq	640(%rsp), %rax
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rdx, %rax
	adcq	$-1, %rcx
	movq	%rax, %rdx
	addq	$1, %rdx
	adcq	$0, %rcx
	xorq	$1, %rcx
	movq	%rcx, 248(%rsp)
	xorl	%ecx, %ecx
	xorl	%r15d, %r15d
	subq	248(%rsp), %r15
	movq	472(%rsp), %rdx
	andq	%r15, %rdx
	movq	464(%rsp), %rsi
	andq	%r15, %rsi
	movq	456(%rsp), %rdi
	andq	%r15, %rdi
	movq	448(%rsp), %r8
	andq	%r15, %r8
	movq	440(%rsp), %r13
	andq	%r15, %r13
	movq	528(%rsp), %r9
	andq	%r9, %r15
	addq	%r11, %rdx
	adcq	%r10, %rsi
	adcq	%rbp, %rdi
	adcq	%r12, %r8
	adcq	%r14, %r13
	adcq	$1, %rax
	addq	%r15, %rax
	subq	480(%rsp), %rdx
	movl	$1, %r10d
	sbbq	$0, %r10
	subq	488(%rsp), %rsi
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%r10, %rsi
	adcq	$0, %r11
	addq	$-1, %rsi
	adcq	$-1, %r11
	xorq	$-2, %r11
	subq	496(%rsp), %rdi
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r11, %rdi
	adcq	$-1, %r10
	addq	$1, %rdi
	adcq	$0, %r10
	xorq	$-2, %r10
	subq	504(%rsp), %r8
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%r10, %r8
	adcq	$-1, %r11
	addq	$1, %r8
	adcq	$0, %r11
	xorq	$-2, %r11
	subq	512(%rsp), %r13
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r11, %r13
	adcq	$-1, %r10
	addq	$1, %r13
	adcq	$0, %r10
	xorq	$-2, %r10
	subq	520(%rsp), %rax
	sbbq	$0, %rbx
	addq	%r10, %rax
	adcq	$-1, %rbx
	movq	%rax, %r10
	addq	$1, %r10
	adcq	$0, %rbx
	xorq	$1, %rbx
	movq	%rbx, 248(%rsp)
	subq	248(%rsp), %rcx
	movq	472(%rsp), %r10
	andq	%rcx, %r10
	movq	464(%rsp), %r11
	andq	%rcx, %r11
	movq	456(%rsp), %r14
	andq	%rcx, %r14
	movq	448(%rsp), %r15
	andq	%rcx, %r15
	movq	440(%rsp), %r12
	andq	%rcx, %r12
	andq	%r9, %rcx
	addq	%rdx, %r10
	adcq	%rsi, %r11
	adcq	%rdi, %r14
	adcq	%r8, %r15
	adcq	%r13, %r12
	adcq	$1, %rax
	addq	%rcx, %rax
	movq	%r10, 792(%rsp)
	movq	%r11, 784(%rsp)
	movq	%r14, 776(%rsp)
	leaq	64(%rsp), %rbx
	movq	%r15, 768(%rsp)
	leaq	72(%rsp), %rbp
	movq	%r12, 760(%rsp)
	leaq	80(%rsp), %r12
	movq	%rax, 752(%rsp)
	leaq	88(%rsp), %r13
	movq	$0, 248(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 592(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	xorps	%xmm0, %xmm0
	movups	%xmm0, 72(%rsp)
	movups	%xmm0, 56(%rsp)
	movq	$0, 88(%rsp)
	movq	$4, 48(%rsp)
.Ltmp262:
	leaq	392(%rsp), %rdi
	leaq	48(%rsp), %rdx
	movq	192(%rsp), %r14
	movq	%r14, %rsi
	movq	536(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp263:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
.Ltmp265:
	leaq	200(%rsp), %rdi
	leaq	392(%rsp), %rdx
	leaq	800(%rsp), %rcx
	movq	%r14, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp266:
	movq	200(%rsp), %rcx
	movq	208(%rsp), %rax
	subq	584(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	576(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%rdx, %rax
	adcq	$0, %rsi
	addq	$-1, %rax
	adcq	$-1, %rsi
	movq	216(%rsp), %rdx
	xorq	$-2, %rsi
	subq	568(%rsp), %rdx
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rdx
	adcq	$-1, %rdi
	addq	$1, %rdx
	adcq	$0, %rdi
	movq	224(%rsp), %rsi
	xorq	$-2, %rdi
	subq	560(%rsp), %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	addq	$1, %rsi
	adcq	$0, %r8
	movq	232(%rsp), %rdi
	xorq	$-2, %r8
	subq	552(%rsp), %rdi
	movl	$1, %r9d
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r8, %rdi
	adcq	$-1, %r10
	addq	$1, %rdi
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	240(%rsp), %r8
	subq	544(%rsp), %r8
	sbbq	$0, %r9
	addq	%r10, %r8
	adcq	$-1, %r9
	movq	%r8, %r10
	addq	$1, %r10
	adcq	$0, %r9
	xorq	$1, %r9
	movq	%r9, 48(%rsp)
	xorl	%r9d, %r9d
	subq	48(%rsp), %r9
	movq	472(%rsp), %r10
	andq	%r9, %r10
	movq	464(%rsp), %r11
	andq	%r9, %r11
	movq	456(%rsp), %r14
	andq	%r9, %r14
	movq	448(%rsp), %r15
	andq	%r9, %r15
	movq	440(%rsp), %r12
	andq	%r9, %r12
	andq	528(%rsp), %r9
	addq	%rcx, %r10
	adcq	%rax, %r11
	adcq	%rdx, %r14
	adcq	%rsi, %r15
	adcq	%rdi, %r12
	adcq	$1, %r8
	addq	%r9, %r8
	movq	%r10, 696(%rsp)
	movq	%r11, 704(%rsp)
	movq	%r14, 712(%rsp)
	movq	%r15, 720(%rsp)
	movq	%r12, 728(%rsp)
	movq	%r8, 736(%rsp)
.Ltmp268:
	leaq	648(%rsp), %rdi
	leaq	848(%rsp), %rdx
	leaq	696(%rsp), %rcx
	movq	192(%rsp), %r15
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp269:
	leaq	64(%rsp), %r14
	leaq	72(%rsp), %r12
	leaq	80(%rsp), %r13
	leaq	88(%rsp), %rbp
	xorps	%xmm0, %xmm0
	movups	%xmm0, 72(%rsp)
	movups	%xmm0, 56(%rsp)
	movq	$0, 88(%rsp)
	movq	$8, 48(%rsp)
.Ltmp271:
	leaq	248(%rsp), %rdi
	leaq	48(%rsp), %rdx
	movq	%r15, %rsi
	movq	536(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp272:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
.Ltmp274:
	leaq	48(%rsp), %rdi
	leaq	600(%rsp), %rcx
	movq	%r15, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp275:
.Ltmp277:
	movq	%rsp, %rdi
	leaq	248(%rsp), %rdx
	leaq	48(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp278:
	movq	944(%rsp), %rbx
	movq	744(%rsp), %rdi
	movq	472(%rsp), %r15
	movq	464(%rsp), %r12
	movq	456(%rsp), %r13
	movq	448(%rsp), %rbp
	movq	648(%rsp), %rcx
	subq	(%rsp), %rcx
	movl	$1, %eax
	sbbq	$0, %rax
	movq	656(%rsp), %rdx
	subq	8(%rsp), %rdx
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rax, %rdx
	adcq	$0, %r8
	addq	$-1, %rdx
	adcq	$-1, %r8
	xorq	$-2, %r8
	movq	664(%rsp), %rsi
	subq	16(%rsp), %rsi
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%r8, %rsi
	adcq	$-1, %rax
	addq	$1, %rsi
	adcq	$0, %rax
	xorq	$-2, %rax
	movq	672(%rsp), %r11
	subq	24(%rsp), %r11
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%rax, %r11
	adcq	$-1, %r9
	addq	$1, %r11
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	680(%rsp), %r8
	subq	32(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	688(%rsp), %rax
	subq	40(%rsp), %rax
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r10, %rax
	adcq	$-1, %r9
	movq	%rax, %r10
	addq	$1, %r10
	adcq	$0, %r9
	xorq	$1, %r9
	movq	%r9, 592(%rsp)
	xorl	%r9d, %r9d
	subq	592(%rsp), %r9
	andq	%r9, %r15
	andq	%r9, %r12
	andq	%r9, %r13
	andq	%r9, %rbp
	movq	440(%rsp), %r10
	andq	%r9, %r10
	movq	528(%rsp), %r14
	andq	%r9, %r14
	addq	%rcx, %r15
	adcq	%rdx, %r12
	adcq	%rsi, %r13
	adcq	%r11, %rbp
	adcq	%r8, %r10
	adcq	$1, %rax
	addq	%r14, %rax
	movq	928(%rsp), %rcx
	orq	936(%rsp), %rcx
	movq	896(%rsp), %rdx
	orq	920(%rsp), %rdx
	orq	%rcx, %rdx
	orq	912(%rsp), %rdx
	xorl	%ecx, %ecx
	orq	904(%rsp), %rdx
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	#MEMBARRIER
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	584(%rsp), %rdx
	movq	%rdx, 248(%rsp)
	movq	576(%rsp), %rdx
	movq	%rdx, 256(%rsp)
	movq	568(%rsp), %rdx
	movq	%rdx, 264(%rsp)
	movq	560(%rsp), %rdx
	movq	%rdx, 272(%rsp)
	movq	552(%rsp), %rdx
	movq	%rdx, 280(%rsp)
	movq	544(%rsp), %rdx
	movq	%rdx, 288(%rsp)
	movq	%r15, 296(%rsp)
	movq	%r12, 304(%rsp)
	movq	%r13, 312(%rsp)
	movq	%rbp, 320(%rsp)
	movq	%r10, 328(%rsp)
	movq	%rax, 336(%rsp)
	movq	792(%rsp), %rax
	movq	%rax, 344(%rsp)
	movq	784(%rsp), %rax
	movq	%rax, 352(%rsp)
	movq	776(%rsp), %rax
	movq	%rax, 360(%rsp)
	movq	768(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	760(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	752(%rsp), %rax
	movq	%rax, 384(%rsp)
	movups	240(%rdi), %xmm0
	movups	256(%rdi), %xmm1
	movups	272(%rdi), %xmm2
	movaps	%xmm2, 128(%rsp)
	movaps	%xmm1, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 176(%rsp)
	sete	%cl
	leaq	248(%rsp), %rsi
	leaq	48(%rsp), %rdx
	movq	%rbx, %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, (%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 592(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	#MEMBARRIER
	movq	$0, 848(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 864(%rsp)
	movq	$0, 872(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 888(%rsp)
	#MEMBARRIER
	movq	$0, 800(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	#MEMBARRIER
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	#MEMBARRIER
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	#MEMBARRIER
	addq	$952, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB36_37:
	.cfi_def_cfa_offset 1008
.Ltmp279:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	jmp	.LBB36_36
.LBB36_35:
.Ltmp276:
.LBB36_36:
	leaq	264(%rsp), %r14
	leaq	272(%rsp), %r12
	leaq	280(%rsp), %r13
	leaq	288(%rsp), %rbp
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	jmp	.LBB36_34
.LBB36_33:
.Ltmp273:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
.LBB36_34:
	movq	$0, (%r14)
	movq	$0, (%r12)
	movq	$0, (%r13)
	movq	$0, (%rbp)
	#MEMBARRIER
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	#MEMBARRIER
	jmp	.LBB36_32
.LBB36_31:
.Ltmp270:
.LBB36_32:
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	jmp	.LBB36_30
.LBB36_29:
.Ltmp267:
.LBB36_30:
	leaq	408(%rsp), %rbx
	leaq	416(%rsp), %rbp
	leaq	424(%rsp), %r12
	leaq	432(%rsp), %r13
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
.LBB36_39:
	movq	$0, (%rbx)
	movq	$0, (%rbp)
	movq	$0, (%r12)
	movq	$0, (%r13)
	#MEMBARRIER
	movq	$0, 792(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 752(%rsp)
.LBB36_40:
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	jmp	.LBB36_24
.LBB36_38:
.Ltmp264:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	jmp	.LBB36_39
.LBB36_28:
.Ltmp261:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	jmp	.LBB36_40
.LBB36_27:
.Ltmp258:
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	jmp	.LBB36_26
.LBB36_25:
.Ltmp255:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
.LBB36_26:
	movq	$0, (%rbx)
	movq	$0, (%r14)
	movq	$0, (%r15)
	movq	$0, (%r12)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	jmp	.LBB36_24
.LBB36_23:
.Ltmp252:
.LBB36_24:
	leaq	864(%rsp), %rbx
	leaq	872(%rsp), %r14
	leaq	880(%rsp), %r15
	leaq	888(%rsp), %r12
	movq	$0, 848(%rsp)
	movq	$0, 856(%rsp)
.LBB36_19:
	movq	$0, (%rbx)
	movq	$0, (%r14)
	movq	$0, (%r15)
	movq	$0, (%r12)
	#MEMBARRIER
	movq	$0, 800(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	#MEMBARRIER
.LBB36_17:
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	#MEMBARRIER
.LBB36_42:
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.LBB36_22:
.Ltmp249:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	jmp	.LBB36_21
.LBB36_20:
.Ltmp246:
.LBB36_21:
	leaq	216(%rsp), %rbx
	leaq	224(%rsp), %r14
	leaq	232(%rsp), %r15
	leaq	240(%rsp), %r12
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	jmp	.LBB36_19
.LBB36_18:
.Ltmp243:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	jmp	.LBB36_19
.LBB36_16:
.Ltmp240:
	jmp	.LBB36_17
.LBB36_41:
.Ltmp237:
	jmp	.LBB36_42
.Lfunc_end36:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_, .Lfunc_end36-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table36:
.Lexception16:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end16-.Lcst_begin16
.Lcst_begin16:
	.uleb128 .Lfunc_begin16-.Lfunc_begin16
	.uleb128 .Ltmp235-.Lfunc_begin16
	.byte	0
	.byte	0
	.uleb128 .Ltmp235-.Lfunc_begin16
	.uleb128 .Ltmp236-.Ltmp235
	.uleb128 .Ltmp237-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp238-.Lfunc_begin16
	.uleb128 .Ltmp239-.Ltmp238
	.uleb128 .Ltmp240-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp241-.Lfunc_begin16
	.uleb128 .Ltmp242-.Ltmp241
	.uleb128 .Ltmp243-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp244-.Lfunc_begin16
	.uleb128 .Ltmp245-.Ltmp244
	.uleb128 .Ltmp246-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp247-.Lfunc_begin16
	.uleb128 .Ltmp248-.Ltmp247
	.uleb128 .Ltmp249-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp250-.Lfunc_begin16
	.uleb128 .Ltmp251-.Ltmp250
	.uleb128 .Ltmp252-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp253-.Lfunc_begin16
	.uleb128 .Ltmp254-.Ltmp253
	.uleb128 .Ltmp255-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp256-.Lfunc_begin16
	.uleb128 .Ltmp257-.Ltmp256
	.uleb128 .Ltmp258-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp259-.Lfunc_begin16
	.uleb128 .Ltmp260-.Ltmp259
	.uleb128 .Ltmp261-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp262-.Lfunc_begin16
	.uleb128 .Ltmp263-.Ltmp262
	.uleb128 .Ltmp264-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp265-.Lfunc_begin16
	.uleb128 .Ltmp266-.Ltmp265
	.uleb128 .Ltmp267-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp268-.Lfunc_begin16
	.uleb128 .Ltmp269-.Ltmp268
	.uleb128 .Ltmp270-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp271-.Lfunc_begin16
	.uleb128 .Ltmp272-.Ltmp271
	.uleb128 .Ltmp273-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp274-.Lfunc_begin16
	.uleb128 .Ltmp275-.Ltmp274
	.uleb128 .Ltmp276-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp277-.Lfunc_begin16
	.uleb128 .Ltmp278-.Ltmp277
	.uleb128 .Ltmp279-.Lfunc_begin16
	.byte	0
	.uleb128 .Ltmp278-.Lfunc_begin16
	.uleb128 .Lfunc_end36-.Ltmp278
	.byte	0
	.byte	0
.Lcst_end16:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_:
	.cfi_startproc
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm10
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm10
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm9
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm9
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm8
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm8
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm7
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm7
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm6
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm6
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm5
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm5
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm3
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm3
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm1
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm1
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm0
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %xmm2
	punpcklqdq	%xmm2, %xmm0
	movdqu	(%rsi), %xmm11
	movdqu	(%rdx), %xmm4
	pxor	%xmm2, %xmm2
	pxor	%xmm12, %xmm12
	psubq	%xmm10, %xmm12
	pand	%xmm4, %xmm12
	pcmpeqd	%xmm4, %xmm4
	paddq	%xmm4, %xmm10
	pand	%xmm11, %xmm10
	por	%xmm12, %xmm10
	movdqu	%xmm10, (%rdi)
	movdqu	16(%rsi), %xmm10
	movdqu	16(%rdx), %xmm11
	pxor	%xmm12, %xmm12
	psubq	%xmm9, %xmm12
	pand	%xmm11, %xmm12
	paddq	%xmm4, %xmm9
	pand	%xmm10, %xmm9
	por	%xmm12, %xmm9
	movdqu	%xmm9, 16(%rdi)
	movdqu	32(%rsi), %xmm9
	movdqu	32(%rdx), %xmm10
	pxor	%xmm11, %xmm11
	psubq	%xmm8, %xmm11
	pand	%xmm10, %xmm11
	paddq	%xmm4, %xmm8
	pand	%xmm9, %xmm8
	por	%xmm11, %xmm8
	movdqu	%xmm8, 32(%rdi)
	movdqu	48(%rsi), %xmm8
	movdqu	48(%rdx), %xmm9
	pxor	%xmm10, %xmm10
	psubq	%xmm7, %xmm10
	pand	%xmm9, %xmm10
	paddq	%xmm4, %xmm7
	pand	%xmm8, %xmm7
	por	%xmm10, %xmm7
	movdqu	%xmm7, 48(%rdi)
	movdqu	64(%rsi), %xmm7
	movdqu	64(%rdx), %xmm8
	pxor	%xmm9, %xmm9
	psubq	%xmm6, %xmm9
	pand	%xmm8, %xmm9
	paddq	%xmm4, %xmm6
	pand	%xmm7, %xmm6
	por	%xmm9, %xmm6
	movdqu	%xmm6, 64(%rdi)
	movdqu	80(%rsi), %xmm6
	movdqu	80(%rdx), %xmm7
	pxor	%xmm8, %xmm8
	psubq	%xmm5, %xmm8
	pand	%xmm7, %xmm8
	paddq	%xmm4, %xmm5
	pand	%xmm6, %xmm5
	por	%xmm8, %xmm5
	movdqu	%xmm5, 80(%rdi)
	movdqu	96(%rsi), %xmm5
	movdqu	96(%rdx), %xmm6
	pxor	%xmm7, %xmm7
	psubq	%xmm3, %xmm7
	pand	%xmm6, %xmm7
	paddq	%xmm4, %xmm3
	pand	%xmm5, %xmm3
	por	%xmm7, %xmm3
	movdqu	%xmm3, 96(%rdi)
	movdqu	112(%rsi), %xmm3
	movdqu	112(%rdx), %xmm5
	pxor	%xmm6, %xmm6
	psubq	%xmm1, %xmm6
	pand	%xmm5, %xmm6
	paddq	%xmm4, %xmm1
	pand	%xmm3, %xmm1
	por	%xmm6, %xmm1
	movdqu	%xmm1, 112(%rdi)
	movdqu	128(%rsi), %xmm1
	movdqu	128(%rdx), %xmm3
	psubq	%xmm0, %xmm2
	pand	%xmm3, %xmm2
	paddq	%xmm4, %xmm0
	pand	%xmm1, %xmm0
	por	%xmm2, %xmm0
	movdqu	%xmm0, 128(%rdi)
	retq
.Lfunc_end37:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_, .Lfunc_end37-_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point11small_order,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point11small_order,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point11small_order:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$800, %rsp
	.cfi_def_cfa_offset 848
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rdx
	leaq	480(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%rdx, %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add
	leaq	640(%rsp), %r14
	movq	%r14, %rdi
	movq	%rbx, %rsi
	movq	%rbx, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add
	leaq	320(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r14, %rsi
	movq	%r14, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add
	xorps	%xmm0, %xmm0
	movups	%xmm0, 136(%rsp)
	movups	%xmm0, 120(%rsp)
	movq	$0, 152(%rsp)
	movaps	%xmm0, (%rsp)
	movaps	%xmm0, 16(%rsp)
	movq	$0, 32(%rsp)
	leaq	40(%rsp), %r14
	movq	$1, 40(%rsp)
	leaq	80(%rsp), %r15
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 64(%rsp)
	movq	$1, 80(%rsp)
	movups	%xmm0, 88(%rsp)
	movups	%xmm0, 104(%rsp)
	leaq	160(%rsp), %r12
	movq	%r12, %rdi
	movq	%rbx, %rsi
	movq	%r15, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	leaq	400(%rsp), %r13
	leaq	200(%rsp), %rbx
	movq	%rsp, %rsi
	movq	%rbx, %rdi
	movq	%r13, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r12, %rdi
	movq	%rbx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq
	movq	%rax, %rbx
	leaq	360(%rsp), %rsi
	leaq	240(%rsp), %r12
	movq	%r12, %rdi
	movq	%r15, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	leaq	280(%rsp), %r15
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%r13, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	andl	%ebx, %eax
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	#MEMBARRIER
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	#MEMBARRIER
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	#MEMBARRIER
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	#MEMBARRIER
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	#MEMBARRIER
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	#MEMBARRIER
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	#MEMBARRIER
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	#MEMBARRIER
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	#MEMBARRIER
	addq	$800, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end38:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point11small_order, .Lfunc_end38-_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point11small_order
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point2eq,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point2eq,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point2eq:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$168, %rsp
	.cfi_def_cfa_offset 224
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %r14
	movq	%rdi, %r15
	leaq	80(%rsi), %r12
	leaq	8(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	leaq	80(%r15), %r13
	leaq	48(%rsp), %rbp
	movq	%rbp, %rdi
	movq	%r14, %rsi
	movq	%r13, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	%rbx, %rdi
	movq	%rbp, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq
	movq	%rax, %rbx
	addq	$40, %r15
	leaq	88(%rsp), %rbp
	movq	%rbp, %rdi
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	addq	$40, %r14
	leaq	128(%rsp), %r15
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%r13, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	%rbp, %rdi
	movq	%r15, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	andl	%ebx, %eax
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	addq	$168, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end39:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point2eq, .Lfunc_end39-_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point2eq
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$488, %rsp
	.cfi_def_cfa_offset 544
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, 456(%rsp)
	leaq	40(%rsi), %r12
	leaq	48(%rsp), %rbp
	movq	%rbp, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3sub
	leaq	40(%r14), %r13
	movq	%rsp, %rbx
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3sub
	leaq	208(%rsp), %rdi
	movq	%rbp, %rsi
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	leaq	48(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3add
	movq	%rsp, %r12
	movq	%r12, %rdi
	movq	%r13, %rsi
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3add
	leaq	248(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	leaq	120(%r15), %rsi
	leaq	120(%r14), %rdx
	leaq	96(%rsp), %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movq	$0, 32(%rsp)
	xorl	%esi, %esi
	movabsq	$-6872316419617283935, %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.12(%rip), %r8
	.p2align	4
.LBB40_1:
	movq	%rsi, %rax
	mulq	%rdi
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%sil, %eax
	imull	$161, %eax, %eax
	movq	%rsi, %rdx
	shrq	$3, %rdx
	movzbl	(%rdx,%r8), %edx
	movl	%esi, %r9d
	andl	$7, %r9d
	xorl	%r10d, %r10d
	btl	%r9d, %edx
	setb	%r10b
	addl	%esi, %ecx
	shlq	%cl, %r10
	shrl	$13, %eax
	orq	%r10, (%rsp,%rax,8)
	incq	%rsi
	cmpq	$255, %rsi
	jne	.LBB40_1
	movq	32(%rsp), %rax
	movq	%rax, 80(%rsp)
	movaps	(%rsp), %xmm0
	movaps	16(%rsp), %xmm1
	movaps	%xmm1, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	leaq	160(%rsp), %rbx
	leaq	96(%rsp), %rsi
	leaq	48(%rsp), %rdx
	movq	%rbx, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$2, (%rsp)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 8(%rsp)
	movups	%xmm0, 24(%rsp)
	leaq	288(%rsp), %rdi
	movq	%rsp, %rdx
	movq	%rbx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	addq	$80, %r15
	addq	$80, %r14
	leaq	48(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$2, (%rsp)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 8(%rsp)
	movups	%xmm0, 24(%rsp)
	leaq	328(%rsp), %rdi
	movq	%rsp, %rdx
	movq	%rbx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	xorl	%r9d, %r9d
	movq	248(%rsp), %r11
	movq	256(%rsp), %rax
	subq	208(%rsp), %r11
	movl	$0, %r10d
	sbbq	%r10, %r10
	movabsq	$4503599627370458, %r8
	addq	%r8, %r11
	adcq	$0, %r10
	subq	216(%rsp), %rax
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	movq	%r10, %rbx
	shldq	$13, %r11, %r10
	shrq	$51, %rbx
	addq	%rax, %r10
	adcq	%rcx, %rbx
	movq	264(%rsp), %rax
	subq	224(%rsp), %rax
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	movabsq	$4503599627370494, %rdi
	addq	%rdi, %r10
	adcq	$0, %rbx
	movq	%rbx, %r14
	shldq	$13, %r10, %rbx
	shrq	$51, %r14
	addq	%rax, %rbx
	adcq	%rcx, %r14
	movq	272(%rsp), %rax
	subq	232(%rsp), %rax
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%rdi, %rbx
	adcq	$0, %r14
	movq	%r14, %r15
	shldq	$13, %rbx, %r14
	shrq	$51, %r15
	addq	%rax, %r14
	adcq	%rcx, %r15
	movq	280(%rsp), %rax
	subq	240(%rsp), %rax
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%rdi, %r14
	adcq	$0, %r15
	movq	%r15, %r12
	shldq	$13, %r14, %r15
	shrq	$51, %r12
	addq	%rax, %r15
	adcq	%rcx, %r12
	movabsq	$2251799813685247, %rsi
	andq	%rsi, %r11
	andq	%rsi, %r10
	andq	%rsi, %rbx
	andq	%rsi, %r14
	addq	%rdi, %r15
	adcq	$0, %r12
	movq	%r12, %rax
	shldq	$13, %r15, %rax
	shrq	$51, %r12
	andq	%rsi, %r15
	leaq	(%r12,%r12,8), %r13
	movl	$19, %ecx
	mulq	%rcx
	leaq	(%r12,%r13,2), %r12
	addq	%r11, %rax
	adcq	%r12, %rdx
	shldq	$13, %rax, %rdx
	andq	%rsi, %rax
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%rsi, %r10
	shrq	$51, %rdx
	addq	%rbx, %rdx
	movq	%rdx, %r12
	andq	%rsi, %r12
	shrq	$51, %rdx
	addq	%r14, %rdx
	movq	%rdx, %r14
	andq	%rsi, %r14
	shrq	$51, %rdx
	addq	%r15, %rdx
	movq	%rdx, %r11
	shrq	$51, %r11
	andq	%rsi, %rdx
	leaq	(%r11,%r11,8), %rbx
	leaq	(%r11,%rbx,2), %rbx
	addq	%rax, %rbx
	movq	%rbx, %r15
	andq	%rsi, %r15
	shrq	$51, %rbx
	addq	%r10, %rbx
	movq	%rbx, %r11
	shrq	$51, %r11
	addq	%r12, %r11
	movq	%r11, %r10
	shrq	$51, %r10
	addq	%r14, %r10
	movq	%r10, %rcx
	shrq	$51, %rcx
	addq	%rdx, %rcx
	movq	%rcx, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r14
	leaq	(%rdx,%r14,2), %rdx
	addq	%r15, %rdx
	andq	%rsi, %rbx
	andq	%rsi, %r11
	andq	%rsi, %r10
	andq	%rsi, %rcx
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	328(%rsp), %r15
	movq	336(%rsp), %r12
	subq	288(%rsp), %r15
	movl	$0, %r14d
	sbbq	%r14, %r14
	addq	%r8, %r15
	adcq	$0, %r14
	subq	296(%rsp), %r12
	movl	$0, %r13d
	sbbq	%r13, %r13
	movq	%r14, %r8
	shldq	$13, %r15, %r14
	shrq	$51, %r8
	addq	%r12, %r14
	adcq	%r13, %r8
	movq	344(%rsp), %r13
	subq	304(%rsp), %r13
	movl	$0, %ebp
	sbbq	%rbp, %rbp
	addq	%rdi, %r14
	adcq	$0, %r8
	movq	%r8, %r12
	shldq	$13, %r14, %r8
	shrq	$51, %r12
	addq	%r13, %r8
	adcq	%rbp, %r12
	movq	352(%rsp), %rbp
	subq	312(%rsp), %rbp
	movl	$0, %eax
	sbbq	%rax, %rax
	addq	%rdi, %r8
	adcq	$0, %r12
	movq	%r12, %r13
	shrq	$51, %r13
	shldq	$13, %r8, %r12
	addq	%rbp, %r12
	adcq	%rax, %r13
	movq	360(%rsp), %rax
	subq	320(%rsp), %rax
	sbbq	%r9, %r9
	movq	%rdx, 392(%rsp)
	addq	%rdi, %r12
	adcq	$0, %r13
	movq	%rbx, 400(%rsp)
	movq	%r13, %rdx
	shldq	$13, %r12, %r13
	shrq	$51, %rdx
	addq	%rax, %r13
	adcq	%r9, %rdx
	movq	%r11, 408(%rsp)
	andq	%rsi, %r15
	andq	%rsi, %r14
	andq	%rsi, %r8
	andq	%rsi, %r12
	movq	%rsi, %rbp
	addq	%rdi, %r13
	adcq	$0, %rdx
	movq	%r10, 416(%rsp)
	movq	%rdx, %rax
	shldq	$13, %r13, %rax
	shrq	$51, %rdx
	andq	%rsi, %r13
	leaq	(%rdx,%rdx,8), %rsi
	leaq	(%rdx,%rsi,2), %rsi
	movl	$19, %edx
	mulq	%rdx
	addq	%r15, %rax
	adcq	%rsi, %rdx
	movq	%rcx, 424(%rsp)
	shldq	$13, %rax, %rdx
	andq	%rbp, %rax
	addq	%r14, %rdx
	movq	%rdx, %rdi
	andq	%rbp, %rdi
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %rcx
	andq	%rbp, %rcx
	shrq	$51, %rdx
	addq	%r12, %rdx
	movq	%rdx, %r8
	andq	%rbp, %r8
	shrq	$51, %rdx
	addq	%r13, %rdx
	movq	%rdx, %rsi
	shrq	$51, %rsi
	andq	%rbp, %rdx
	leaq	(%rsi,%rsi,8), %r9
	leaq	(%rsi,%r9,2), %rsi
	addq	%rax, %rsi
	movq	%rsi, %r10
	andq	%rbp, %r10
	shrq	$51, %rsi
	addq	%rdi, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	addq	%rcx, %rdi
	movq	%rdi, %r9
	shrq	$51, %r9
	addq	%r8, %r9
	movq	%r9, %rax
	shrq	$51, %rax
	addq	%rdx, %rax
	movq	%rax, %rcx
	shrq	$51, %rcx
	leaq	(%rcx,%rcx,8), %rdx
	leaq	(%rcx,%rdx,2), %rcx
	addq	%r10, %rcx
	andq	%rbp, %rsi
	andq	%rbp, %rdi
	andq	%rbp, %r9
	andq	%rbp, %rax
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	%rcx, 160(%rsp)
	movq	%rsi, 168(%rsp)
	movq	%rdi, 176(%rsp)
	movq	288(%rsp), %r8
	movq	296(%rsp), %r11
	xorl	%edx, %edx
	addq	328(%rsp), %r8
	setb	%dl
	xorl	%esi, %esi
	addq	336(%rsp), %r11
	setb	%sil
	movq	304(%rsp), %rbx
	xorl	%edi, %edi
	addq	344(%rsp), %rbx
	movq	%r9, 184(%rsp)
	setb	%dil
	movq	312(%rsp), %r14
	xorl	%r9d, %r9d
	addq	352(%rsp), %r14
	setb	%r9b
	movq	320(%rsp), %r15
	xorl	%r10d, %r10d
	addq	360(%rsp), %r15
	setb	%r10b
	shldq	$13, %r8, %rdx
	andq	%rbp, %r8
	addq	%r11, %rdx
	adcq	$0, %rsi
	shldq	$13, %rdx, %rsi
	andq	%rbp, %rdx
	addq	%rbx, %rsi
	adcq	$0, %rdi
	shldq	$13, %rsi, %rdi
	andq	%rbp, %rsi
	addq	%r14, %rdi
	adcq	$0, %r9
	shldq	$13, %rdi, %r9
	andq	%rbp, %rdi
	addq	%r15, %r9
	adcl	$0, %r10d
	movq	%rax, 192(%rsp)
	movq	%r9, %rax
	shrq	$51, %rax
	shll	$13, %r10d
	orq	%rax, %r10
	andq	%rbp, %r9
	leaq	(%r10,%r10,8), %rax
	leaq	(%r10,%rax,2), %r10
	addq	%r8, %r10
	movq	%r10, %rax
	andq	%rbp, %rax
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %r8
	andq	%rbp, %r8
	shrq	$51, %r10
	addq	%rsi, %r10
	movq	%r10, %rcx
	andq	%rbp, %rcx
	shrq	$51, %r10
	addq	%rdi, %r10
	movq	%r10, %rdi
	andq	%rbp, %rdi
	shrq	$51, %r10
	addq	%r9, %r10
	movq	%r10, %rdx
	shrq	$51, %rdx
	andq	%rbp, %r10
	leaq	(%rdx,%rdx,8), %rsi
	leaq	(%rdx,%rsi,2), %rdx
	addq	%rax, %rdx
	movq	%rdx, %r11
	andq	%rbp, %r11
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %rsi
	shrq	$51, %rsi
	addq	%rcx, %rsi
	movq	%rsi, %r9
	shrq	$51, %r9
	addq	%rdi, %r9
	movq	%r9, %rax
	shrq	$51, %rax
	addq	%r10, %rax
	movq	%rax, %rcx
	shrq	$51, %rcx
	leaq	(%rcx,%rcx,8), %rdi
	leaq	(%rcx,%rdi,2), %rcx
	addq	%r11, %rcx
	andq	%rbp, %rdx
	andq	%rbp, %rsi
	andq	%rbp, %r9
	andq	%rbp, %rax
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	%rcx, 96(%rsp)
	movq	%rdx, 104(%rsp)
	movq	%rsi, 112(%rsp)
	movq	208(%rsp), %r8
	movq	216(%rsp), %r11
	xorl	%edx, %edx
	addq	248(%rsp), %r8
	setb	%dl
	xorl	%esi, %esi
	addq	256(%rsp), %r11
	setb	%sil
	movq	224(%rsp), %rbx
	xorl	%edi, %edi
	addq	264(%rsp), %rbx
	movq	%r9, 120(%rsp)
	setb	%dil
	movq	232(%rsp), %r14
	xorl	%r9d, %r9d
	addq	272(%rsp), %r14
	setb	%r9b
	movq	240(%rsp), %r15
	xorl	%r10d, %r10d
	addq	280(%rsp), %r15
	setb	%r10b
	shldq	$13, %r8, %rdx
	andq	%rbp, %r8
	addq	%r11, %rdx
	adcq	$0, %rsi
	shldq	$13, %rdx, %rsi
	andq	%rbp, %rdx
	addq	%rbx, %rsi
	adcq	$0, %rdi
	shldq	$13, %rsi, %rdi
	andq	%rbp, %rsi
	addq	%r14, %rdi
	adcq	$0, %r9
	shldq	$13, %rdi, %r9
	andq	%rbp, %rdi
	addq	%r15, %r9
	adcl	$0, %r10d
	movq	%rax, 128(%rsp)
	movq	%r9, %rax
	shrq	$51, %rax
	shll	$13, %r10d
	orq	%rax, %r10
	andq	%rbp, %r9
	leaq	(%r10,%r10,8), %rax
	leaq	(%r10,%rax,2), %rax
	addq	%r8, %rax
	movq	%rax, %r8
	andq	%rbp, %r8
	shrq	$51, %rax
	addq	%rdx, %rax
	movq	%rax, %r10
	andq	%rbp, %r10
	shrq	$51, %rax
	addq	%rsi, %rax
	movq	%rax, %rcx
	andq	%rbp, %rcx
	shrq	$51, %rax
	addq	%rdi, %rax
	movq	%rax, %r11
	andq	%rbp, %r11
	shrq	$51, %rax
	addq	%r9, %rax
	movq	%rax, %rdx
	shrq	$51, %rdx
	andq	%rbp, %rax
	leaq	(%rdx,%rdx,8), %rsi
	leaq	(%rdx,%rsi,2), %rdx
	addq	%r8, %rdx
	movq	%rdx, %r9
	andq	%rbp, %r9
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %rsi
	shrq	$51, %rsi
	addq	%rcx, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	addq	%r11, %rdi
	movq	%rdi, %r8
	shrq	$51, %r8
	addq	%rax, %r8
	movq	%r8, %rax
	shrq	$51, %rax
	leaq	(%rax,%rax,8), %rcx
	leaq	(%rax,%rcx,2), %rax
	addq	%r9, %rax
	andq	%rbp, %rdx
	andq	%rbp, %rsi
	andq	%rbp, %rdi
	andq	%rbp, %r8
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%rsi, 64(%rsp)
	movq	%rdi, 72(%rsp)
	movq	%r8, 80(%rsp)
	leaq	392(%rsp), %rbx
	leaq	160(%rsp), %r14
	movq	456(%rsp), %r13
	movq	%r13, %rdi
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	leaq	40(%r13), %rdi
	leaq	96(%rsp), %r15
	leaq	48(%rsp), %r12
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	%rsp, %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	leaq	80(%r13), %rdi
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	32(%rsp), %rax
	movq	%rax, 152(%r13)
	movups	(%rsp), %xmm0
	movups	16(%rsp), %xmm1
	movups	%xmm1, 136(%r13)
	movups	%xmm0, 120(%r13)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	addq	$488, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end40:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add, .Lfunc_end40-_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3mul,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3mul,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3mul:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$520, %rsp
	.cfi_def_cfa_offset 576
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, 184(%rsp)
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, 152(%rsp)
	movdqu	%xmm0, 136(%rsp)
	movq	$0, 168(%rsp)
	movdqa	%xmm0, 16(%rsp)
	movdqa	%xmm0, 32(%rsp)
	movq	$0, 48(%rsp)
	movq	$1, 56(%rsp)
	movdqa	%xmm0, 64(%rsp)
	movdqa	%xmm0, 80(%rsp)
	movq	$1, 96(%rsp)
	movdqu	%xmm0, 104(%rsp)
	movdqu	%xmm0, 120(%rsp)
	movl	$255, %ebx
	leaq	192(%rsp), %r12
	leaq	16(%rsp), %r13
	leaq	352(%rsp), %rbp
	.p2align	4
.LBB41_1:
	movq	%r12, %rdi
	movq	%r13, %rsi
	movq	%r13, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add
	movq	%rbp, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add
	movq	%rbx, %rax
	shrq	$3, %rax
	movzbl	(%r14,%rax), %ecx
	movl	%ebx, %edx
	andl	$7, %edx
	xorl	%eax, %eax
	btl	%edx, %ecx
	setb	%al
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm6
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm6
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm9
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm9
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm11
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm11
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm10
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm10
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm8
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm8
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm7
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm7
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm5
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm5
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm4
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm4
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm1
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm1
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm3
	movq	%rax, 8(%rsp)
	movq	8(%rsp), %xmm2
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	pxor	%xmm0, %xmm0
	psubq	%xmm6, %xmm0
	pcmpeqd	%xmm12, %xmm12
	paddq	%xmm12, %xmm6
	pand	192(%rsp), %xmm6
	pand	352(%rsp), %xmm0
	punpcklqdq	%xmm2, %xmm3
	pxor	%xmm2, %xmm2
	psubq	%xmm9, %xmm2
	paddq	%xmm12, %xmm9
	pand	208(%rsp), %xmm9
	pand	368(%rsp), %xmm2
	por	%xmm6, %xmm0
	pxor	%xmm6, %xmm6
	psubq	%xmm11, %xmm6
	paddq	%xmm12, %xmm11
	pand	224(%rsp), %xmm11
	pand	384(%rsp), %xmm6
	por	%xmm9, %xmm2
	pxor	%xmm9, %xmm9
	psubq	%xmm10, %xmm9
	paddq	%xmm12, %xmm10
	pand	240(%rsp), %xmm10
	pand	400(%rsp), %xmm9
	por	%xmm11, %xmm6
	pxor	%xmm11, %xmm11
	psubq	%xmm8, %xmm11
	paddq	%xmm12, %xmm8
	pand	256(%rsp), %xmm8
	pand	416(%rsp), %xmm11
	por	%xmm10, %xmm9
	pxor	%xmm10, %xmm10
	psubq	%xmm7, %xmm10
	paddq	%xmm12, %xmm7
	pand	272(%rsp), %xmm7
	pand	432(%rsp), %xmm10
	por	%xmm8, %xmm11
	pxor	%xmm8, %xmm8
	psubq	%xmm5, %xmm8
	paddq	%xmm12, %xmm5
	pand	288(%rsp), %xmm5
	pand	448(%rsp), %xmm8
	por	%xmm7, %xmm10
	pxor	%xmm7, %xmm7
	psubq	%xmm4, %xmm7
	paddq	%xmm12, %xmm4
	pand	304(%rsp), %xmm4
	pand	464(%rsp), %xmm7
	por	%xmm5, %xmm8
	pxor	%xmm5, %xmm5
	psubq	%xmm1, %xmm5
	paddq	%xmm12, %xmm1
	pand	320(%rsp), %xmm1
	pand	480(%rsp), %xmm5
	por	%xmm4, %xmm7
	pxor	%xmm4, %xmm4
	psubq	%xmm3, %xmm4
	paddq	%xmm12, %xmm3
	pand	336(%rsp), %xmm3
	pand	496(%rsp), %xmm4
	por	%xmm1, %xmm5
	por	%xmm3, %xmm4
	#MEMBARRIER
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	movdqa	%xmm0, 16(%rsp)
	movdqa	%xmm2, 32(%rsp)
	movdqa	%xmm6, 48(%rsp)
	movdqa	%xmm9, 64(%rsp)
	movdqa	%xmm11, 80(%rsp)
	movdqa	%xmm10, 96(%rsp)
	movdqa	%xmm8, 112(%rsp)
	movdqa	%xmm7, 128(%rsp)
	movdqa	%xmm5, 144(%rsp)
	movdqa	%xmm4, 160(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	#MEMBARRIER
	addq	$-1, %rbx
	jb	.LBB41_1
	leaq	16(%rsp), %rsi
	movl	$160, %edx
	movq	184(%rsp), %rdi
	callq	*memcpy@GOTPCREL(%rip)
	addq	$520, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end41:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3mul, .Lfunc_end41-_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3mul
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI42_0:
	.zero	16,102
	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point4base,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point4base,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point4base:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$208, %rsp
	.cfi_def_cfa_offset 224
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movaps	.LCPI42_0(%rip), %xmm0
	movups	%xmm0, 24(%rsp)
	movups	%xmm0, 9(%rsp)
	movb	$88, 8(%rsp)
	leaq	40(%rsp), %rdi
	leaq	8(%rsp), %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point6decode
	cmpb	$1, 40(%rsp)
	je	.LBB42_2
	leaq	48(%rsp), %rsi
	movl	$160, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	addq	$208, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB42_2:
	.cfi_def_cfa_offset 224
	movzbl	41(%rsp), %eax
	movb	%al, 7(%rsp)
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.14(%rip), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.25(%rip), %rcx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.15(%rip), %r8
	leaq	7(%rsp), %rdx
	movl	$18, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core6result13unwrap_failed@GOTPCREL(%rip)
.Lfunc_end42:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point4base, .Lfunc_end42-_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point4base
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point6decode,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point6decode,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point6decode:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$712, %rsp
	.cfi_def_cfa_offset 768
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movaps	%xmm1, 656(%rsp)
	movaps	%xmm0, 640(%rsp)
	movzbl	671(%rsp), %r13d
	movl	%r13d, %eax
	andb	$127, %al
	movb	%al, 671(%rsp)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movq	$0, 112(%rsp)
	xorl	%esi, %esi
	movabsq	$-6872316419617283935, %rbp
	.p2align	4
.LBB43_1:
	movq	%rsi, %rax
	mulq	%rbp
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%sil, %eax
	imull	$161, %eax, %eax
	movq	%rsi, %rdx
	shrq	$3, %rdx
	movzbl	640(%rsp,%rdx), %edx
	movl	%esi, %edi
	andl	$7, %edi
	xorl	%r8d, %r8d
	btl	%edi, %edx
	setb	%r8b
	addl	%esi, %ecx
	shlq	%cl, %r8
	shrl	$13, %eax
	orq	%r8, 80(%rsp,%rax,8)
	incq	%rsi
	cmpq	$255, %rsi
	jne	.LBB43_1
	movq	112(%rsp), %rax
	movq	%rax, 544(%rsp)
	movaps	80(%rsp), %xmm0
	movaps	96(%rsp), %xmm1
	movaps	%xmm1, 528(%rsp)
	movaps	%xmm0, 512(%rsp)
	leaq	80(%rsp), %rdi
	leaq	512(%rsp), %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes
	movdqu	80(%rsp), %xmm0
	movdqu	96(%rsp), %xmm1
	pcmpeqb	656(%rsp), %xmm1
	pcmpeqb	640(%rsp), %xmm0
	pand	%xmm1, %xmm0
	pmovmskb	%xmm0, %eax
	xorl	%ecx, %ecx
	xorl	$65535, %eax
	setne	%cl
	movq	%rcx, 32(%rsp)
	cmpq	$0, 32(%rsp)
	je	.LBB43_5
	movw	$769, (%rbx)
	jmp	.LBB43_4
.LBB43_5:
	movl	%r13d, %eax
	shrb	$7, %al
	movb	%al, 15(%rsp)
	movabsq	$2251799813685247, %r12
	leaq	312(%rsp), %rdi
	leaq	512(%rsp), %rdx
	movq	%rdx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$1, 272(%rsp)
	movabsq	$4503599627370457, %rdi
	xorl	%ecx, %ecx
	addq	312(%rsp), %rdi
	movq	$0, 560(%rsp)
	setb	%cl
	shldq	$13, %rdi, %rcx
	xorl	%esi, %esi
	addq	320(%rsp), %rcx
	setb	%sil
	movabsq	$4503599627370494, %rdx
	addq	%rdx, %rcx
	adcq	$0, %rsi
	movq	$0, 16(%rsp)
	shldq	$13, %rcx, %rsi
	xorl	%r8d, %r8d
	addq	328(%rsp), %rsi
	setb	%r8b
	addq	%rdx, %rsi
	adcq	$0, %r8
	shldq	$13, %rsi, %r8
	movq	$0, 448(%rsp)
	xorl	%r9d, %r9d
	addq	336(%rsp), %r8
	setb	%r9b
	addq	%rdx, %r8
	adcq	$0, %r9
	movq	$0, 432(%rsp)
	shldq	$13, %r8, %r9
	xorl	%eax, %eax
	addq	344(%rsp), %r9
	setb	%al
	andq	%r12, %rdi
	andq	%r12, %rcx
	andq	%r12, %rsi
	andq	%r12, %r8
	addq	%rdx, %r9
	adcq	$0, %rax
	shldq	$13, %r9, %rax
	movl	$19, %edx
	mulq	%rdx
	andq	%r12, %r9
	addq	%rdi, %rax
	movq	%rax, %rdi
	andq	%r12, %rdi
	shrq	$51, %rax
	shll	$13, %edx
	orq	%rax, %rdx
	addq	%rcx, %rdx
	movq	%rdx, %rcx
	andq	%r12, %rcx
	shrq	$51, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	andq	%r12, %rsi
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r12, %r8
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %rax
	shrq	$51, %rax
	andq	%r12, %rdx
	leaq	(%rax,%rax,8), %r9
	leaq	(%rax,%r9,2), %rax
	addq	%rdi, %rax
	movq	%rax, %r9
	andq	%r12, %r9
	shrq	$51, %rax
	addq	%rcx, %rax
	movq	%rax, %rcx
	shrq	$51, %rcx
	addq	%rsi, %rcx
	movq	%rcx, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	addq	%rdx, %rdi
	movq	%rdi, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r8
	leaq	(%rdx,%r8,2), %rdx
	addq	%r9, %rdx
	andq	%r12, %rax
	andq	%r12, %rcx
	andq	%r12, %rsi
	andq	%r12, %rdi
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	#MEMBARRIER
	movq	%rdx, 392(%rsp)
	movq	%rax, 400(%rsp)
	movq	%rcx, 408(%rsp)
	movq	%rsi, 416(%rsp)
	movq	%rdi, 424(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, 96(%rsp)
	movdqa	%xmm0, 80(%rsp)
	movq	$0, 112(%rsp)
	xorl	%esi, %esi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.12(%rip), %rdi
	.p2align	4
.LBB43_6:
	movq	%rsi, %rax
	mulq	%rbp
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%sil, %eax
	imull	$161, %eax, %eax
	movq	%rsi, %rdx
	shrq	$3, %rdx
	movzbl	(%rdx,%rdi), %edx
	movl	%esi, %r8d
	andl	$7, %r8d
	xorl	%r9d, %r9d
	btl	%r8d, %edx
	setb	%r9b
	addl	%esi, %ecx
	shlq	%cl, %r9
	shrl	$13, %eax
	orq	%r9, 80(%rsp,%rax,8)
	incq	%rsi
	cmpq	$255, %rsi
	jne	.LBB43_6
	movq	112(%rsp), %rax
	movq	%rax, 64(%rsp)
	movdqa	80(%rsp), %xmm0
	movaps	96(%rsp), %xmm1
	movaps	%xmm1, 48(%rsp)
	movdqa	%xmm0, 32(%rsp)
	leaq	80(%rsp), %rdi
	leaq	32(%rsp), %rsi
	leaq	312(%rsp), %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$1, 448(%rsp)
	movq	$0, 432(%rsp)
	movq	80(%rsp), %rcx
	xorl	%eax, %eax
	incq	%rcx
	sete	%al
	shldq	$13, %rcx, %rax
	andq	%r12, %rcx
	xorl	%edx, %edx
	addq	88(%rsp), %rax
	movq	$0, 592(%rsp)
	setb	%dl
	shldq	$13, %rax, %rdx
	andq	%r12, %rax
	xorl	%esi, %esi
	addq	96(%rsp), %rdx
	movq	$0, 168(%rsp)
	setb	%sil
	shldq	$13, %rdx, %rsi
	andq	%r12, %rdx
	xorl	%edi, %edi
	addq	104(%rsp), %rsi
	movq	$0, 160(%rsp)
	setb	%dil
	shldq	$13, %rsi, %rdi
	andq	%r12, %rsi
	xorl	%r8d, %r8d
	addq	112(%rsp), %rdi
	setb	%r8b
	movq	%rdi, %r9
	shrq	$51, %r9
	shll	$13, %r8d
	orq	%r9, %r8
	andq	%r12, %rdi
	leaq	(%r8,%r8,8), %r9
	leaq	(%r8,%r9,2), %r8
	addq	%rcx, %r8
	movq	%r8, %rcx
	andq	%r12, %rcx
	shrq	$51, %r8
	addq	%rax, %r8
	movq	%r8, %r9
	andq	%r12, %r9
	shrq	$51, %r8
	addq	%rdx, %r8
	movq	%r8, %rdx
	andq	%r12, %rdx
	shrq	$51, %r8
	addq	%rsi, %r8
	movq	%r8, %rsi
	andq	%r12, %rsi
	shrq	$51, %r8
	addq	%rdi, %r8
	movq	%r8, %rax
	shrq	$51, %rax
	andq	%r12, %r8
	leaq	(%rax,%rax,8), %rdi
	leaq	(%rax,%rdi,2), %rax
	addq	%rcx, %rax
	movq	%rax, %rdi
	andq	%r12, %rdi
	shrq	$51, %rax
	addq	%r9, %rax
	movq	%rax, %rcx
	shrq	$51, %rcx
	addq	%rdx, %rcx
	movq	%rcx, %rdx
	shrq	$51, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	movq	%rsi, %r8
	shrq	$51, %r8
	leaq	(%r8,%r8,8), %r9
	leaq	(%r8,%r9,2), %r8
	addq	%rdi, %r8
	andq	%r12, %rax
	andq	%r12, %rcx
	andq	%r12, %rdx
	andq	%r12, %rsi
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	#MEMBARRIER
	movq	%r8, 272(%rsp)
	movq	%rax, 280(%rsp)
	movq	%rcx, 288(%rsp)
	movq	%rdx, 296(%rsp)
	movq	%rsi, 304(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	pcmpeqd	%xmm0, %xmm0
	movdqu	%xmm0, 47(%rsp)
	movdqu	%xmm0, 33(%rsp)
	movb	$-21, 32(%rsp)
	movb	$127, 63(%rsp)
	leaq	80(%rsp), %r14
	leaq	272(%rsp), %rsi
	leaq	32(%rsp), %rdx
	movl	$255, %ecx
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3pow
	leaq	352(%rsp), %r15
	leaq	392(%rsp), %rsi
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	pcmpeqd	%xmm0, %xmm0
	movdqu	%xmm0, 575(%rsp)
	movdqu	%xmm0, 561(%rsp)
	movb	$-2, 560(%rsp)
	movb	$15, 591(%rsp)
	leaq	176(%rsp), %rdi
	leaq	560(%rsp), %rdx
	movl	$252, %ecx
	movq	%r15, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3pow
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, 96(%rsp)
	movdqa	%xmm0, 80(%rsp)
	movq	$0, 112(%rsp)
	xorl	%esi, %esi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.16(%rip), %rdi
	.p2align	4
.LBB43_8:
	movq	%rsi, %rax
	mulq	%rbp
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%sil, %eax
	imull	$161, %eax, %eax
	movq	%rsi, %rdx
	shrq	$3, %rdx
	movzbl	(%rdx,%rdi), %edx
	movl	%esi, %r8d
	andl	$7, %r8d
	xorl	%r9d, %r9d
	btl	%r8d, %edx
	setb	%r9b
	addl	%esi, %ecx
	shlq	%cl, %r9
	shrl	$13, %eax
	orq	%r9, 80(%rsp,%rax,8)
	incq	%rsi
	cmpq	$255, %rsi
	jne	.LBB43_8
	movq	112(%rsp), %rax
	movq	%rax, 64(%rsp)
	movaps	80(%rsp), %xmm0
	movaps	96(%rsp), %xmm1
	movaps	%xmm1, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	leaq	224(%rsp), %rdi
	leaq	176(%rsp), %r14
	leaq	32(%rsp), %rdx
	movq	%r14, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	leaq	80(%rsp), %r15
	movq	%r15, %rdi
	movq	%r14, %rsi
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	leaq	352(%rsp), %r14
	movq	%r15, %rdi
	movq	%r14, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq
	movq	%rax, 16(%rsp)
	movq	16(%rsp), %xmm1
	movq	%rax, 16(%rsp)
	movq	16(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm1
	movq	%rax, 16(%rsp)
	movq	16(%rsp), %xmm0
	movq	%rax, 16(%rsp)
	movq	16(%rsp), %xmm2
	punpcklqdq	%xmm2, %xmm0
	movq	256(%rsp), %rcx
	movq	208(%rsp), %rdx
	movq	%rax, 16(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, %rsi
	negq	%rsi
	andq	%rdx, %rsi
	decq	%rax
	andq	%rcx, %rax
	orq	%rsi, %rax
	pxor	%xmm2, %xmm2
	psubq	%xmm1, %xmm2
	pcmpeqd	%xmm3, %xmm3
	paddq	%xmm3, %xmm1
	pand	224(%rsp), %xmm1
	pand	176(%rsp), %xmm2
	por	%xmm1, %xmm2
	movdqa	%xmm2, 32(%rsp)
	pxor	%xmm1, %xmm1
	psubq	%xmm0, %xmm1
	paddq	%xmm3, %xmm0
	pand	240(%rsp), %xmm0
	pand	192(%rsp), %xmm1
	por	%xmm0, %xmm1
	movdqa	%xmm1, 48(%rsp)
	movq	%rax, 64(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	leaq	80(%rsp), %r15
	leaq	32(%rsp), %rdx
	movq	%r15, %rdi
	movq	%rdx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r15, %rdi
	movq	%r14, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	testq	%rax, %rax
	je	.LBB43_11
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, 96(%rsp)
	movdqa	%xmm0, 80(%rsp)
	movq	$0, 112(%rsp)
	leaq	32(%rsp), %rdi
	leaq	80(%rsp), %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq
	testq	%rax, %rax
	sete	%al
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	testb	%r13b, %r13b
	setns	%cl
	orb	%al, %cl
	je	.LBB43_11
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 632(%rsp)
	xorl	%ecx, %ecx
	movabsq	$4503599627370458, %r8
	subq	32(%rsp), %r8
	movq	$0, 624(%rsp)
	sbbq	%rcx, %rcx
	movq	%rcx, %rsi
	shrq	$51, %rsi
	shldq	$13, %r8, %rcx
	andq	%r12, %r8
	subq	40(%rsp), %rcx
	sbbq	$0, %rsi
	movabsq	$4503599627370494, %rax
	addq	%rax, %rcx
	adcq	$0, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	shldq	$13, %rcx, %rsi
	andq	%r12, %rcx
	subq	48(%rsp), %rsi
	sbbq	$0, %rdi
	addq	%rax, %rsi
	adcq	$0, %rdi
	movq	%rdi, %r9
	shrq	$51, %r9
	shldq	$13, %rsi, %rdi
	andq	%r12, %rsi
	subq	56(%rsp), %rdi
	sbbq	$0, %r9
	addq	%rax, %rdi
	adcq	$0, %r9
	movq	%r9, %rdx
	shrq	$51, %rdx
	shldq	$13, %rdi, %r9
	andq	%r12, %rdi
	subq	64(%rsp), %r9
	sbbq	$0, %rdx
	movq	$0, 616(%rsp)
	addq	%rax, %r9
	adcq	$0, %rdx
	movq	%rdx, %rax
	shldq	$13, %r9, %rax
	shrq	$51, %rdx
	andq	%r12, %r9
	leaq	(%rdx,%rdx,8), %r10
	leaq	(%rdx,%r10,2), %r10
	movl	$19, %edx
	mulq	%rdx
	addq	%r8, %rax
	adcq	%r10, %rdx
	shldq	$13, %rax, %rdx
	andq	%r12, %rax
	addq	%rcx, %rdx
	movq	%rdx, %r8
	andq	%r12, %r8
	shrq	$51, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	andq	%r12, %rsi
	shrq	$51, %rdx
	addq	%rdi, %rdx
	movq	%rdx, %rdi
	andq	%r12, %rdi
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r12, %rdx
	leaq	(%rcx,%rcx,8), %r9
	leaq	(%rcx,%r9,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %r9
	andq	%r12, %r9
	shrq	$51, %rcx
	addq	%r8, %rcx
	movq	%rcx, %rax
	shrq	$51, %rax
	addq	%rsi, %rax
	movq	%rax, %rsi
	shrq	$51, %rsi
	addq	%rdi, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	addq	%rdx, %rdi
	movq	%rdi, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r8
	leaq	(%rdx,%r8,2), %rdx
	addq	%r9, %rdx
	andq	%r12, %rcx
	andq	%r12, %rax
	andq	%r12, %rsi
	andq	%r12, %rdi
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 592(%rsp)
	#MEMBARRIER
	movq	%rdx, 504(%rsp)
	movq	%rcx, 496(%rsp)
	movq	%rax, 488(%rsp)
	movq	%rsi, 480(%rsp)
	movq	%rdi, 472(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 616(%rsp)
	#MEMBARRIER
	leaq	80(%rsp), %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes
	movzbl	80(%rsp), %eax
	andb	$1, %al
	xorb	15(%rsp), %al
	movzbl	%al, %ecx
	movq	504(%rsp), %r8
	movq	%rcx, 16(%rsp)
	movq	16(%rsp), %r9
	movq	496(%rsp), %r11
	movq	%rcx, 16(%rsp)
	movq	16(%rsp), %r10
	movq	488(%rsp), %rdi
	movq	%rcx, 16(%rsp)
	movq	16(%rsp), %rax
	movq	480(%rsp), %rdx
	movq	%rcx, 16(%rsp)
	movq	16(%rsp), %rsi
	movq	64(%rsp), %r14
	movq	472(%rsp), %r15
	movq	%rcx, 16(%rsp)
	movq	16(%rsp), %r12
	movq	%r12, %rcx
	negq	%rcx
	decq	%r12
	andq	%r14, %r12
	andq	%r15, %rcx
	orq	%r12, %rcx
	movq	%r9, %xmm0
	negq	%r9
	movq	%r10, %xmm1
	negq	%r10
	punpcklqdq	%xmm1, %xmm0
	pcmpeqd	%xmm1, %xmm1
	paddq	%xmm1, %xmm0
	pand	32(%rsp), %xmm0
	andq	%r11, %r10
	andq	%r8, %r9
	movq	%r9, %xmm2
	movq	%r10, %xmm3
	punpcklqdq	%xmm3, %xmm2
	por	%xmm0, %xmm2
	movdqa	%xmm2, 672(%rsp)
	movq	%rax, %xmm0
	negq	%rax
	andq	%rdi, %rax
	movq	%rsi, %xmm2
	negq	%rsi
	punpcklqdq	%xmm2, %xmm0
	paddq	%xmm1, %xmm0
	pand	48(%rsp), %xmm0
	andq	%rdx, %rsi
	movq	%rax, %xmm1
	movq	%rsi, %xmm2
	punpcklqdq	%xmm2, %xmm1
	por	%xmm0, %xmm1
	movdqa	%xmm1, 688(%rsp)
	movq	%rcx, 704(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
	leaq	128(%rbx), %rdi
	leaq	672(%rsp), %rsi
	leaq	512(%rsp), %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	544(%rsp), %rax
	movq	%rax, 152(%rsp)
	movaps	512(%rsp), %xmm0
	movaps	528(%rsp), %xmm1
	movups	%xmm1, 136(%rsp)
	movups	%xmm0, 120(%rsp)
	movq	704(%rsp), %rax
	movq	%rax, 112(%rsp)
	movaps	672(%rsp), %xmm0
	movdqa	688(%rsp), %xmm1
	movdqa	%xmm1, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movdqu	%xmm1, 24(%rbx)
	movups	%xmm0, 8(%rbx)
	movq	144(%rsp), %rax
	movq	%rax, 72(%rbx)
	movq	152(%rsp), %rax
	movq	%rax, 80(%rbx)
	movdqa	128(%rsp), %xmm0
	movdqu	%xmm0, 56(%rbx)
	movq	112(%rsp), %rax
	movq	%rax, 40(%rbx)
	movq	120(%rsp), %rax
	movq	%rax, 48(%rbx)
	movq	$1, 88(%rbx)
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, 112(%rbx)
	movdqu	%xmm0, 96(%rbx)
	movb	$0, (%rbx)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	jmp	.LBB43_13
.LBB43_11:
	movw	$769, (%rbx)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	#MEMBARRIER
.LBB43_4:
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
.LBB43_13:
	#MEMBARRIER
	addq	$712, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end43:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point6decode, .Lfunc_end43-_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point6decode
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056absorb,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056absorb,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056absorb:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %r15
	movl	%esi, %ebx
	andl	$67108863, %ebx
	addq	72(%rdi), %rbx
	movq	%rdx, %rdi
	shldq	$12, %rsi, %rdi
	shrq	$26, %rsi
	andl	$67108863, %esi
	addq	80(%r15), %rsi
	andl	$67108863, %edi
	addq	88(%r15), %rdi
	movq	%rdx, %r9
	shrq	$14, %r9
	andl	$67108863, %r9d
	addq	96(%r15), %r9
	movl	%ecx, %r11d
	shrq	$40, %rdx
	addq	104(%r15), %rdx
	shll	$24, %r11d
	addq	%rdx, %r11
	movq	32(%r15), %rax
	movq	%rax, -48(%rsp)
	movq	40(%r15), %rcx
	movq	%rcx, -72(%rsp)
	movq	%rbx, %rcx
	imulq	%rax, %rcx
	movq	64(%r15), %r12
	movq	%rsi, %rdx
	imulq	%r12, %rdx
	leaq	(%rdx,%rdx,4), %rdx
	addq	%rcx, %rdx
	movq	56(%r15), %r8
	leaq	(%rdi,%rdi,4), %r13
	movq	%r13, %rbp
	imulq	%r8, %rbp
	movq	%r8, -64(%rsp)
	addq	%rdx, %rbp
	movq	48(%r15), %rax
	movq	%rax, -56(%rsp)
	leaq	(%r9,%r9,4), %rdx
	movq	%rdx, %rcx
	imulq	%rax, %rcx
	leaq	(%r11,%r11,4), %r10
	movq	%r10, %r14
	movq	-72(%rsp), %rax
	imulq	%rax, %r14
	addq	%rcx, %r14
	addq	%rbp, %r14
	movq	%rbx, %rcx
	imulq	%rax, %rcx
	movq	%rsi, %rbp
	movq	-48(%rsp), %rax
	imulq	%rax, %rbp
	addq	%rcx, %rbp
	movq	%rdx, %rcx
	imulq	%r8, %rcx
	addq	%rbp, %rcx
	imulq	%r12, %r13
	addq	%r13, %rcx
	movq	%r10, %r13
	movq	-56(%rsp), %r8
	imulq	%r8, %r13
	addq	%rcx, %r13
	movq	%rbx, %rcx
	imulq	%r8, %rcx
	movq	%rsi, %rbp
	movq	-72(%rsp), %r8
	imulq	%r8, %rbp
	addq	%rcx, %rbp
	movq	%rdi, %rcx
	imulq	%rax, %rcx
	addq	%rbp, %rcx
	movq	%r12, %rax
	imulq	%r12, %rdx
	movq	%r10, %rbp
	movq	-64(%rsp), %r12
	imulq	%r12, %rbp
	addq	%rdx, %rbp
	addq	%rcx, %rbp
	movq	%rbx, %rcx
	imulq	%r12, %rcx
	movq	%rsi, %rdx
	movq	-56(%rsp), %r12
	imulq	%r12, %rdx
	addq	%rcx, %rdx
	movq	%rdi, %rcx
	imulq	%r8, %rcx
	addq	%rdx, %rcx
	movq	%r9, %rdx
	movq	-48(%rsp), %r8
	imulq	%r8, %rdx
	imulq	%rax, %r10
	addq	%rdx, %r10
	addq	%rcx, %r10
	imulq	%rax, %rbx
	imulq	-64(%rsp), %rsi
	addq	%rbx, %rsi
	imulq	%r12, %rdi
	addq	%rsi, %rdi
	imulq	-72(%rsp), %r9
	imulq	%r8, %r11
	addq	%r9, %r11
	addq	%rdi, %r11
	movq	%r14, %rax
	shrq	$26, %rax
	addq	%r13, %rax
	movq	%rax, %rcx
	shrq	$26, %rcx
	addq	%rbp, %rcx
	movq	%rcx, %rdx
	shrq	$26, %rdx
	addq	%r10, %rdx
	andl	$67108863, %ecx
	movq	%rcx, 88(%r15)
	movq	%rdx, %rcx
	shrq	$26, %rcx
	addq	%r11, %rcx
	andl	$67108863, %edx
	movq	%rdx, 96(%r15)
	movl	%ecx, %edx
	andl	$67108863, %edx
	movq	%rdx, 104(%r15)
	andl	$67108863, %r14d
	andl	$67108863, %eax
	shrq	$26, %rcx
	leaq	(%rcx,%rcx,4), %rcx
	addq	%r14, %rcx
	movq	%rcx, %rdx
	shrq	$26, %rdx
	addq	%rax, %rdx
	movq	%rdx, 80(%r15)
	andl	$67108863, %ecx
	movq	%rcx, 72(%r15)
	movq	$0, -8(%rsp)
	movq	$0, -16(%rsp)
	movq	$0, -24(%rsp)
	movq	$0, -32(%rsp)
	movq	$0, -40(%rsp)
	#MEMBARRIER
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end44:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056absorb, .Lfunc_end44-_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056absorb
	.cfi_endproc

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056finish,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056finish,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056finish:
.Lfunc_begin17:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception17
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movq	112(%rsi), %rdi
	testq	%rdi, %rdi
	je	.LBB45_4
	cmpq	$16, %rdi
	jae	.LBB45_6
	movb	$1, 16(%rbx,%rdi)
	movq	112(%rbx), %rcx
	leaq	1(%rcx), %rdi
	cmpq	$16, %rdi
	ja	.LBB45_8
	leaq	16(%rbx), %rax
	movl	$15, %edx
	subq	%rcx, %rdx
	addq	%rdi, %rax
	movq	%rax, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movzbl	16(%rbx), %eax
	movzbl	17(%rbx), %esi
	movzbl	18(%rbx), %ecx
	movzbl	19(%rbx), %edx
	movzbl	20(%rbx), %edi
	movzbl	21(%rbx), %r8d
	movzbl	22(%rbx), %r9d
	movzbl	23(%rbx), %r10d
	shlq	$56, %r10
	shlq	$48, %r9
	orq	%r10, %r9
	shlq	$40, %r8
	orq	%r9, %r8
	shlq	$32, %rdi
	orq	%r8, %rdi
	shll	$24, %edx
	orq	%rdi, %rdx
	shll	$16, %ecx
	orq	%rdx, %rcx
	shll	$8, %esi
	orq	%rcx, %rsi
	orq	%rax, %rsi
	movq	24(%rbx), %rdx
	movq	%rbx, %rdi
	xorl	%ecx, %ecx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056absorb
	movb	$0, (%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 13(%rsp)
	#MEMBARRIER
.LBB45_4:
	movq	72(%rbx), %rdx
	movq	%rdx, %rax
	shrq	$26, %rax
	addq	80(%rbx), %rax
	andl	$67108863, %edx
	movq	%rax, %rcx
	shrq	$26, %rcx
	addq	88(%rbx), %rcx
	movq	%rcx, %r8
	shrq	$26, %r8
	addq	96(%rbx), %r8
	andl	$67108863, %eax
	andl	$67108863, %ecx
	movq	%r8, %r9
	shrq	$26, %r9
	addq	104(%rbx), %r9
	andl	$67108863, %r8d
	movq	%r9, %rsi
	shrq	$26, %rsi
	leaq	(%rsi,%rsi,4), %rdi
	addq	%rdx, %rdi
	andl	$67108863, %r9d
	movq	%rdi, %rsi
	shrq	$26, %rsi
	addl	%eax, %esi
	andl	$67108863, %edi
	movl	%esi, %edx
	shrl	$26, %edx
	addl	%ecx, %edx
	andl	$67108863, %esi
	movl	%edx, %ecx
	shrl	$26, %ecx
	addl	%r8d, %ecx
	andl	$67108863, %edx
	movl	%ecx, %eax
	shrl	$26, %eax
	addq	%r9, %rax
	andl	$67108863, %ecx
	movl	%eax, %r8d
	shrl	$26, %r8d
	leal	(%r8,%r8,4), %r8d
	andl	$67108863, %eax
	leal	(%rdi,%r8), %r12d
	addl	$5, %r12d
	movl	%r8d, %r9d
	addl	%edi, %r9d
	movl	%r12d, %r15d
	shrl	$26, %r15d
	addl	%esi, %r15d
	movl	%r15d, %ebp
	shrl	$26, %ebp
	addl	%edx, %ebp
	movl	%ebp, %r11d
	shrl	$26, %r11d
	addl	%ecx, %r11d
	movl	%r11d, %r8d
	shrl	$26, %r8d
	addq	%rax, %r8
	xorl	%r10d, %r10d
	cmpq	$67108864, %r8
	setae	%r10b
	movq	%r10, (%rsp)
	movq	(%rsp), %r13
	movl	%r13d, %edi
	negl	%edi
	andl	%r12d, %edi
	decl	%r13d
	andl	%r9d, %r13d
	andl	$67108863, %edi
	orl	%r13d, %edi
	movq	%rdi, 72(%rbx)
	movq	%r10, (%rsp)
	movq	(%rsp), %r12
	movl	%r12d, %r9d
	negl	%r9d
	andl	%r15d, %r9d
	decl	%r12d
	andl	%esi, %r12d
	andl	$67108863, %r9d
	orl	%r12d, %r9d
	movq	%r9, 80(%rbx)
	movq	%r10, (%rsp)
	movq	(%rsp), %r15
	movl	%r15d, %esi
	negl	%esi
	andl	%ebp, %esi
	decl	%r15d
	andl	%edx, %r15d
	andl	$67108863, %esi
	orl	%r15d, %esi
	movq	%rsi, 88(%rbx)
	movq	%r10, (%rsp)
	movq	(%rsp), %r15
	movl	%r15d, %edx
	negl	%edx
	andl	%r11d, %edx
	decl	%r15d
	andl	%ecx, %r15d
	andl	$67108863, %edx
	orl	%r15d, %edx
	movq	%rdx, 96(%rbx)
	movq	%r10, (%rsp)
	movq	(%rsp), %r10
	movl	%r10d, %ecx
	negl	%ecx
	andl	%r8d, %ecx
	decl	%r10d
	andl	%r10d, %eax
	andl	$67108863, %ecx
	orl	%eax, %ecx
	movq	%rcx, 104(%rbx)
	shlq	$26, %r9
	orq	%rdi, %r9
	movl	%esi, %eax
	shrl	$12, %eax
	shlq	$52, %rsi
	orq	%r9, %rsi
	shlq	$14, %rdx
	orq	%rax, %rdx
	shlq	$40, %rcx
	orq	%rdx, %rcx
	addq	(%rbx), %rsi
	adcq	8(%rbx), %rcx
	movq	%rcx, 8(%r14)
	movq	%rsi, (%r14)
	movq	$0, (%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rbx)
	movq	$0, 40(%rbx)
	movq	$0, 48(%rbx)
	movq	$0, 56(%rbx)
	movq	$0, 64(%rbx)
	#MEMBARRIER
	movq	$0, 72(%rbx)
	movq	$0, 80(%rbx)
	movq	$0, 88(%rbx)
	movq	$0, 96(%rbx)
	movq	$0, 104(%rbx)
	#MEMBARRIER
	movb	$0, 16(%rbx)
	movb	$0, 17(%rbx)
	movb	$0, 18(%rbx)
	movb	$0, 19(%rbx)
	movb	$0, 20(%rbx)
	movb	$0, 21(%rbx)
	movb	$0, 22(%rbx)
	movb	$0, 23(%rbx)
	movb	$0, 24(%rbx)
	movb	$0, 25(%rbx)
	movb	$0, 26(%rbx)
	movb	$0, 27(%rbx)
	movb	$0, 28(%rbx)
	movb	$0, 29(%rbx)
	movb	$0, 30(%rbx)
	movb	$0, 31(%rbx)
	#MEMBARRIER
	movb	$0, (%rbx)
	movb	$0, 1(%rbx)
	movb	$0, 2(%rbx)
	movb	$0, 3(%rbx)
	movb	$0, 4(%rbx)
	movb	$0, 5(%rbx)
	movb	$0, 6(%rbx)
	movb	$0, 7(%rbx)
	movb	$0, 8(%rbx)
	movb	$0, 9(%rbx)
	movb	$0, 10(%rbx)
	movb	$0, 11(%rbx)
	movb	$0, 12(%rbx)
	movb	$0, 13(%rbx)
	movb	$0, 14(%rbx)
	movb	$0, 15(%rbx)
	#MEMBARRIER
	addq	$56, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB45_8:
	.cfi_def_cfa_offset 112
.Ltmp282:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.21(%rip), %rcx
	movl	$16, %esi
	movl	$16, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Ltmp283:
	jmp	.LBB45_7
.LBB45_6:
.Ltmp280:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.20(%rip), %rdx
	movl	$16, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp281:
.LBB45_7:
	ud2
.LBB45_5:
.Ltmp284:
	movq	%rax, %r14
	movq	%rbx, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto8poly13058Poly1305EBF_
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end45:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056finish, .Lfunc_end45-_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056finish
	.cfi_endproc
	.section	.gcc_except_table._RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056finish,"a",@progbits
	.p2align	2, 0x0
GCC_except_table45:
.Lexception17:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end17-.Lcst_begin17
.Lcst_begin17:
	.uleb128 .Lfunc_begin17-.Lfunc_begin17
	.uleb128 .Ltmp282-.Lfunc_begin17
	.byte	0
	.byte	0
	.uleb128 .Ltmp282-.Lfunc_begin17
	.uleb128 .Ltmp281-.Ltmp282
	.uleb128 .Ltmp284-.Lfunc_begin17
	.byte	0
	.uleb128 .Ltmp281-.Lfunc_begin17
	.uleb128 .Lfunc_end45-.Ltmp281
	.byte	0
	.byte	0
.Lcst_end17:
	.p2align	2, 0x0

	.section	.text._RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update,"ax",@progbits
	.p2align	4
	.type	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update,@function
_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	%rdi, %r14
	movq	112(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB46_4
	movl	$16, %r12d
	subq	%rdi, %r12
	cmpq	%rbx, %r12
	cmovaeq	%rbx, %r12
	leaq	(%r12,%rdi), %rsi
	cmpq	%rdi, %rsi
	jb	.LBB46_3
	cmpq	$17, %rsi
	jae	.LBB46_3
	leaq	16(%r14), %rax
	addq	%rdi, %rax
	movq	%rax, %rdi
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	112(%r14), %rax
	addq	%r12, %rax
	movq	%rax, 112(%r14)
	subq	%r12, %rbx
	addq	%r12, %r15
	cmpq	$16, %rax
	jne	.LBB46_4
	movzbl	16(%r14), %eax
	movzbl	17(%r14), %esi
	movzbl	18(%r14), %ecx
	movzbl	19(%r14), %edx
	movzbl	20(%r14), %edi
	movzbl	21(%r14), %r8d
	movzbl	22(%r14), %r9d
	movzbl	23(%r14), %r10d
	shlq	$56, %r10
	shlq	$48, %r9
	orq	%r10, %r9
	shlq	$40, %r8
	orq	%r9, %r8
	shlq	$32, %rdi
	orq	%r8, %rdi
	shll	$24, %edx
	orq	%rdi, %rdx
	shll	$16, %ecx
	orq	%rdx, %rcx
	shll	$8, %esi
	orq	%rcx, %rsi
	orq	%rax, %rsi
	movq	24(%r14), %rdx
	movq	%r14, %rdi
	movl	$1, %ecx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056absorb
	movb	$0, 23(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 8(%rsp)
	#MEMBARRIER
	movq	$0, 112(%r14)
.LBB46_4:
	cmpq	$16, %rbx
	jb	.LBB46_5
	.p2align	4
.LBB46_13:
	movq	(%r15), %rsi
	movq	8(%r15), %rdx
	movq	%r14, %rdi
	movl	$1, %ecx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056absorb
	addq	$-16, %rbx
	addq	$16, %r15
	cmpq	$15, %rbx
	ja	.LBB46_13
.LBB46_5:
	testq	%rbx, %rbx
	je	.LBB46_12
	movq	112(%r14), %rdi
	leaq	(%rdi,%rbx), %rsi
	cmpq	%rdi, %rsi
	jb	.LBB46_8
	cmpq	$17, %rsi
	jae	.LBB46_8
	addq	%r14, %rdi
	addq	$16, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	addq	%rbx, 112(%r14)
.LBB46_12:
	addq	$24, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB46_3:
	.cfi_def_cfa_offset 64
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.23(%rip), %rcx
	movl	$16, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB46_8:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.22(%rip), %rcx
	movl	$16, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Lfunc_end46:
	.size	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update, .Lfunc_end46-_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
	.cfi_endproc

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	(%rdx), %r10
	addq	(%rcx), %r10
	movq	8(%rdx), %r9
	adcq	$0, %r9
	setb	%al
	addq	8(%rcx), %r9
	movzbl	%al, %r8d
	adcq	16(%rdx), %r8
	setb	%al
	addq	16(%rcx), %r8
	movzbl	%al, %eax
	adcq	24(%rdx), %rax
	setb	%dl
	movzbl	%dl, %r14d
	addq	24(%rcx), %rax
	adcq	$0, %r14
	movq	%r10, %r11
	subq	(%rsi), %r11
	movl	$1, %edx
	sbbq	$0, %rdx
	movq	%r9, %rcx
	subq	8(%rsi), %rcx
	movl	$1, %ebx
	sbbq	$0, %rbx
	addq	%rdx, %rcx
	adcq	$0, %rbx
	movq	%r10, -32(%rsp)
	addq	$-1, %rcx
	adcq	$-1, %rbx
	xorq	$-2, %rbx
	movq	%r8, %rdx
	subq	16(%rsi), %rdx
	movl	$1, %r12d
	movl	$1, %r15d
	sbbq	$0, %r15
	addq	%rbx, %rdx
	adcq	$-1, %r15
	addq	$1, %rdx
	adcq	$0, %r15
	xorq	$-2, %r15
	movq	%rax, %rbx
	subq	24(%rsi), %rbx
	sbbq	$0, %r12
	movq	%r9, -40(%rsp)
	addq	%r15, %rbx
	adcq	$-1, %r12
	movq	%r8, -48(%rsp)
	addq	$1, %rbx
	adcq	$0, %r12
	movq	%rax, -56(%rsp)
	xorl	%r15d, %r15d
	orq	%r14, %r12
	setne	%r15b
	movq	%r15, -64(%rsp)
	movq	-64(%rsp), %rsi
	movq	%rsi, %r14
	negq	%r14
	andq	%r11, %r14
	decq	%rsi
	andq	%r10, %rsi
	orq	%r14, %rsi
	movq	%r15, -64(%rsp)
	movq	-64(%rsp), %r10
	movq	%r10, %r11
	negq	%r11
	andq	%rcx, %r11
	decq	%r10
	andq	%r9, %r10
	orq	%r11, %r10
	movq	%r15, -64(%rsp)
	movq	-64(%rsp), %rcx
	movq	%rcx, %r9
	negq	%r9
	andq	%rdx, %r9
	decq	%rcx
	andq	%r8, %rcx
	orq	%r9, %rcx
	movq	%r15, -64(%rsp)
	movq	-64(%rsp), %rdx
	movq	%rdx, %r8
	negq	%r8
	andq	%rbx, %r8
	decq	%rdx
	andq	%rax, %rdx
	orq	%r8, %rdx
	movq	$0, -64(%rsp)
	movq	$0, -8(%rsp)
	movq	$0, -16(%rsp)
	movq	$0, -24(%rsp)
	#MEMBARRIER
	movq	$0, -32(%rsp)
	movq	$0, -40(%rsp)
	movq	$0, -48(%rsp)
	movq	$0, -56(%rsp)
	#MEMBARRIER
	movq	%rsi, (%rdi)
	movq	%r10, 8(%rdi)
	movq	%rcx, 16(%rdi)
	movq	%rdx, 24(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end47:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_, .Lfunc_end47-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	.cfi_endproc

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$216, %rsp
	.cfi_def_cfa_offset 272
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	(%rdx), %r10
	movq	%rdx, %r11
	movq	%rdx, 136(%rsp)
	movq	(%rcx), %rbx
	movq	%rbx, %rax
	movq	%rbx, 128(%rsp)
	mulq	%r10
	movq	%rax, 144(%rsp)
	movq	%rdx, 80(%rsp)
	movq	8(%rcx), %r13
	movq	%r13, %rax
	movq	%r13, 120(%rsp)
	mulq	%r10
	movq	%rax, %r9
	movq	%rdx, 96(%rsp)
	movq	16(%rcx), %r15
	movq	%r15, %rax
	mulq	%r10
	movq	%rax, %r12
	movq	%rdx, %r8
	movq	24(%rcx), %r14
	movq	%r14, %rax
	movq	%r14, 104(%rsp)
	mulq	%r10
	movq	%rax, %rbp
	movq	%rdx, 112(%rsp)
	movq	8(%r11), %r10
	movq	%rbx, %rax
	mulq	%r10
	movq	%rdx, %r11
	movq	%rax, %rbx
	movq	%r13, %rax
	mulq	%r10
	addq	80(%rsp), %r9
	adcq	96(%rsp), %r12
	adcq	%r8, %rbp
	setb	%r8b
	addq	%rbx, %r9
	movq	%r9, 80(%rsp)
	adcq	%r11, %r12
	setb	%r11b
	addq	%rax, %r12
	movzbl	%r11b, %r11d
	adcq	%rdx, %r11
	movq	%r15, %rax
	mulq	%r10
	xorl	%ebx, %ebx
	addq	%rbp, %r11
	setb	%bl
	addq	%rax, %r11
	adcq	%rdx, %rbx
	addb	$255, %r8b
	adcq	112(%rsp), %rbx
	setb	%r8b
	movq	%r14, %rax
	mulq	%r10
	movq	%rax, %rbp
	movzbl	%r8b, %r8d
	addq	%rbx, %rbp
	adcq	%rdx, %r8
	movq	136(%rsp), %r9
	movq	16(%r9), %r10
	movq	128(%rsp), %rax
	mulq	%r10
	movq	%rdx, %r13
	movq	%rax, %r14
	movq	120(%rsp), %rax
	mulq	%r10
	addq	%r12, %r14
	adcq	%r11, %r13
	setb	%r11b
	movzbl	%r11b, %r12d
	addq	%rax, %r13
	adcq	%rdx, %r12
	movq	%r15, %rax
	mulq	%r10
	xorl	%r15d, %r15d
	addq	%rbp, %r12
	setb	%r15b
	addq	%rax, %r12
	adcq	%rdx, %r15
	movq	104(%rsp), %rax
	mulq	%r10
	xorl	%ebx, %ebx
	addq	%r8, %r15
	setb	%bl
	addq	%rax, %r15
	adcq	%rdx, %rbx
	movq	24(%r9), %r8
	movq	%r8, %rax
	mulq	(%rcx)
	movq	%rax, %r10
	movq	%rdx, %r11
	movq	80(%rsp), %rax
	movq	%rax, 72(%rsp)
	addq	%r13, %r10
	adcq	%r12, %r11
	setb	%bpl
	movq	%r8, %rax
	mulq	8(%rcx)
	movq	%rax, %r9
	movq	%r14, 48(%rsp)
	movq	144(%rsp), %r12
	movq	%r12, 88(%rsp)
	movzbl	%bpl, %r14d
	addq	%r11, %r9
	adcq	%rdx, %r14
	movq	%r8, %rax
	mulq	16(%rcx)
	movq	%r10, 8(%rsp)
	movq	%r9, (%rsp)
	xorl	%r9d, %r9d
	addq	%r15, %r14
	setb	%r9b
	addq	%rax, %r14
	adcq	%rdx, %r9
	movq	%r14, 32(%rsp)
	movq	%r8, %rax
	mulq	24(%rcx)
	xorl	%ecx, %ecx
	addq	%rbx, %r9
	setb	%cl
	addq	%rax, %r9
	adcq	%rdx, %rcx
	movq	%r9, 40(%rsp)
	movq	%rcx, 64(%rsp)
	movq	96(%rsi), %rbx
	movq	(%rsi), %r9
	movq	8(%rsi), %r8
	movq	16(%rsi), %r11
	movq	24(%rsi), %rcx
	movq	%rbx, %r14
	imulq	%r12, %r14
	movq	%r9, %rax
	mulq	%r14
	movq	%rdx, %rsi
	movq	%rax, %r10
	movq	%r8, %rax
	mulq	%r14
	addq	%r12, %r10
	adcq	72(%rsp), %rsi
	movq	%r10, 88(%rsp)
	setb	%r10b
	movzbl	%r10b, %r10d
	addq	%rax, %rsi
	adcq	%rdx, %r10
	movq	%r11, %rax
	mulq	%r14
	xorl	%r15d, %r15d
	addq	48(%rsp), %r10
	setb	%r15b
	addq	%rax, %r10
	adcq	%rdx, %r15
	movq	%rcx, %rax
	mulq	%r14
	xorl	%r14d, %r14d
	addq	8(%rsp), %r15
	setb	%r14b
	addq	%rax, %r15
	adcq	%rdx, %r14
	addq	%r14, (%rsp)
	movq	$0, 56(%rsp)
	adcq	$0, 32(%rsp)
	adcq	$0, 40(%rsp)
	adcq	$0, 64(%rsp)
	adcq	$0, 56(%rsp)
	movq	%rsi, 72(%rsp)
	movq	%r10, 48(%rsp)
	movq	%r15, 8(%rsp)
	setb	%al
	movzbl	%al, %eax
	movq	%rax, 16(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 24(%rsp)
	jb	.LBB48_5
	movq	72(%rsp), %r15
	movq	%rbx, %r14
	imulq	%r15, %r14
	movq	%r9, %rax
	mulq	%r14
	movq	%rdx, %rsi
	movq	%rax, %r10
	movq	%r8, %rax
	mulq	%r14
	addq	%r15, %r10
	adcq	48(%rsp), %rsi
	setb	%bpl
	movzbl	%bpl, %r15d
	addq	%rax, %rsi
	adcq	%rdx, %r15
	movq	%r11, %rax
	mulq	%r14
	movq	%r10, 72(%rsp)
	xorl	%r10d, %r10d
	addq	8(%rsp), %r15
	movq	%rsi, 48(%rsp)
	setb	%r10b
	addq	%rax, %r15
	adcq	%rdx, %r10
	movq	%r15, 8(%rsp)
	movq	%rcx, %rax
	mulq	%r14
	xorl	%esi, %esi
	addq	(%rsp), %r10
	setb	%sil
	addq	%rax, %r10
	adcq	%rdx, %rsi
	movq	%r10, (%rsp)
	addq	%rsi, 32(%rsp)
	adcq	$0, 40(%rsp)
	adcq	$0, 64(%rsp)
	adcq	$0, 56(%rsp)
	setb	%al
	movzbl	%al, %eax
	movq	%rax, 16(%rsp)
	movq	$0, 24(%rsp)
	jb	.LBB48_5
	movq	48(%rsp), %r15
	movq	%rbx, %r14
	imulq	%r15, %r14
	movq	%r9, %rax
	mulq	%r14
	movq	%rdx, %rsi
	movq	%rax, %r10
	movq	%r8, %rax
	mulq	%r14
	addq	%r15, %r10
	adcq	8(%rsp), %rsi
	setb	%bpl
	movzbl	%bpl, %r15d
	addq	%rax, %rsi
	adcq	%rdx, %r15
	movq	%r11, %rax
	mulq	%r14
	movq	%r10, 48(%rsp)
	xorl	%r10d, %r10d
	addq	(%rsp), %r15
	movq	%rsi, 8(%rsp)
	setb	%r10b
	addq	%rax, %r15
	adcq	%rdx, %r10
	movq	%r15, (%rsp)
	movq	%rcx, %rax
	mulq	%r14
	xorl	%esi, %esi
	addq	32(%rsp), %r10
	setb	%sil
	addq	%rax, %r10
	adcq	%rdx, %rsi
	movq	%r10, 32(%rsp)
	addq	%rsi, 40(%rsp)
	adcq	$0, 64(%rsp)
	adcq	$0, 56(%rsp)
	setb	%al
	movzbl	%al, %eax
	movq	%rax, 16(%rsp)
	movq	$0, 24(%rsp)
	jb	.LBB48_5
	movq	8(%rsp), %r14
	imulq	%r14, %rbx
	movq	%r9, %rax
	mulq	%rbx
	movq	%rdx, %rsi
	movq	%rax, %r10
	movq	%r8, %rax
	mulq	%rbx
	addq	%r14, %r10
	adcq	(%rsp), %rsi
	setb	%bpl
	movzbl	%bpl, %r14d
	addq	%rax, %rsi
	adcq	%rdx, %r14
	movq	%r11, %rax
	mulq	%rbx
	movq	%r10, 8(%rsp)
	xorl	%r10d, %r10d
	addq	32(%rsp), %r14
	movq	%rsi, (%rsp)
	setb	%r10b
	addq	%rax, %r14
	adcq	%rdx, %r10
	movq	%r14, 32(%rsp)
	movq	%rcx, %rax
	mulq	%rbx
	xorl	%esi, %esi
	addq	40(%rsp), %r10
	setb	%sil
	addq	%rax, %r10
	adcq	%rdx, %rsi
	movq	%r10, 40(%rsp)
	addq	%rsi, 64(%rsp)
	adcq	$0, 56(%rsp)
	setb	%al
	movzbl	%al, %eax
	movq	%rax, 16(%rsp)
	movq	$0, 24(%rsp)
	jb	.LBB48_5
	movq	(%rsp), %r10
	movq	%r10, %rbx
	subq	%r9, %rbx
	movl	$1, %edx
	sbbq	$0, %rdx
	movq	32(%rsp), %rax
	movq	%rax, %rsi
	subq	%r8, %rsi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rsi
	adcq	$0, %r8
	addq	$-1, %rsi
	adcq	$-1, %r8
	movl	$1, %r15d
	xorq	$-2, %r8
	movq	40(%rsp), %rdx
	movq	%rdx, %r9
	subq	%r11, %r9
	movl	$1, %r14d
	sbbq	$0, %r14
	addq	%r8, %r9
	adcq	$-1, %r14
	addq	$1, %r9
	adcq	$0, %r14
	xorq	$-2, %r14
	movq	64(%rsp), %r8
	movq	%r8, %r11
	subq	%rcx, %r11
	sbbq	$0, %r15
	addq	%r14, %r11
	adcq	$-1, %r15
	addq	$1, %r11
	adcq	$0, %r15
	xorl	%r14d, %r14d
	orq	56(%rsp), %r15
	setne	%r14b
	movq	%r14, 16(%rsp)
	movq	16(%rsp), %rcx
	movq	%rcx, %r15
	negq	%r15
	andq	%rbx, %r15
	decq	%rcx
	andq	%r10, %rcx
	orq	%r15, %rcx
	movq	%r14, 16(%rsp)
	movq	16(%rsp), %r10
	movq	%r10, %rbx
	negq	%rbx
	andq	%rsi, %rbx
	decq	%r10
	andq	%rax, %r10
	orq	%rbx, %r10
	movq	%r14, 16(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, %rsi
	negq	%rsi
	andq	%r9, %rsi
	decq	%rax
	andq	%rdx, %rax
	orq	%rsi, %rax
	movq	%r14, 16(%rsp)
	movq	16(%rsp), %rdx
	movq	%rdx, %rsi
	negq	%rsi
	andq	%r11, %rsi
	decq	%rdx
	andq	%r8, %rdx
	orq	%rsi, %rdx
	movq	$0, 16(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	%rcx, (%rdi)
	movq	%r10, 8(%rdi)
	movq	%rax, 16(%rdi)
	movq	%rdx, 24(%rdi)
	addq	$216, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB48_5:
	.cfi_def_cfa_offset 272
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.18(%rip), %rdx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.26(%rip), %r9
	leaq	16(%rsp), %rsi
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto@GOTPCREL(%rip)
.Lfunc_end48:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_, .Lfunc_end48-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	.cfi_endproc

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_:
.Lfunc_begin18:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception18
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$248, %rsp
	.cfi_def_cfa_offset 304
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movq	(%rsi), %rax
	cmpq	$0, 24(%rsi)
	setns	%cl
	testb	$1, %al
	je	.LBB49_1
	testb	%cl, %cl
	jne	.LBB49_7
.LBB49_3:
	movl	$2, %ecx
	movl	$2, %edx
	subq	%rax, %rdx
	movq	%rdx, %rdi
	imulq	%rax, %rdi
	movl	$2, %r8d
	subq	%rdi, %r8
	imulq	%rdx, %r8
	movq	%r8, %rdx
	imulq	%rax, %rdx
	movl	$2, %edi
	subq	%rdx, %rdi
	imulq	%r8, %rdi
	movq	%rdi, %rdx
	imulq	%rax, %rdx
	movl	$2, %r8d
	subq	%rdx, %r8
	imulq	%rdi, %r8
	movq	%r8, %rdx
	imulq	%rax, %rdx
	subq	%rdx, %rcx
	imulq	%r8, %rcx
	imulq	%rcx, %rax
	addq	$-2, %rax
	imulq	%rcx, %rax
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 208(%rsp)
	movaps	%xmm0, 224(%rsp)
	movups	(%rsi), %xmm1
	movups	16(%rsi), %xmm2
	movaps	%xmm1, 96(%rsp)
	movaps	%xmm2, 112(%rsp)
	movq	%rax, 192(%rsp)
	leaq	128(%rsp), %r14
	movaps	%xmm0, 128(%rsp)
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 176(%rsp)
	movups	%xmm0, 8(%rsp)
	movq	$0, 24(%rsp)
	movq	$1, (%rsp)
	movl	$512, %ebp
	leaq	32(%rsp), %r15
	leaq	96(%rsp), %r12
	movq	%rsp, %r13
	.p2align	4
.LBB49_4:
	movq	%r15, %rdi
	movq	%r12, %rsi
	movq	%r13, %rdx
	movq	%r13, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movups	32(%rsp), %xmm0
	movups	48(%rsp), %xmm1
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
	decq	%rbp
	jne	.LBB49_4
	movq	(%rsp), %rax
	movq	8(%rsp), %rcx
	movq	16(%rsp), %rdx
	movq	%rdx, 48(%rsp)
	movq	24(%rsp), %rdx
	movq	%rdx, 56(%rsp)
	movq	%rax, 32(%rsp)
	movq	%rcx, 40(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	48(%rsp), %rdx
	movq	%rdx, 16(%r14)
	movq	56(%rsp), %rdx
	movq	%rdx, 24(%r14)
	movq	%rax, (%r14)
	movq	%rcx, 8(%r14)
	movaps	208(%rsp), %xmm0
	movaps	224(%rsp), %xmm1
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm1, 80(%rsp)
	movq	$1, 64(%rsp)
.Ltmp285:
	leaq	32(%rsp), %rdi
	leaq	96(%rsp), %rsi
	leaq	64(%rsp), %rdx
	movq	%r14, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp286:
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movups	32(%rsp), %xmm0
	movups	48(%rsp), %xmm1
	movups	%xmm1, 48(%r14)
	movups	%xmm0, 32(%r14)
	movq	192(%rsp), %rax
	movq	%rax, 96(%rbx)
	movq	176(%rsp), %rax
	movq	%rax, 80(%rbx)
	movq	184(%rsp), %rax
	movq	%rax, 88(%rbx)
	movq	160(%rsp), %rax
	movq	%rax, 64(%rbx)
	movq	168(%rsp), %rax
	movq	%rax, 72(%rbx)
	movaps	96(%rsp), %xmm0
	movaps	112(%rsp), %xmm1
	movaps	128(%rsp), %xmm2
	movaps	144(%rsp), %xmm3
	movups	%xmm3, 48(%rbx)
	movups	%xmm2, 32(%rbx)
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	addq	$248, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB49_1:
	.cfi_def_cfa_offset 304
	movb	$1, %cl
	testb	%cl, %cl
	je	.LBB49_3
.LBB49_7:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.27(%rip), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.28(%rip), %rdx
	movl	$76, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking5panic@GOTPCREL(%rip)
.LBB49_8:
.Ltmp287:
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end49:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_, .Lfunc_end49-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table49:
.Lexception18:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end18-.Lcst_begin18
.Lcst_begin18:
	.uleb128 .Ltmp285-.Lfunc_begin18
	.uleb128 .Ltmp286-.Ltmp285
	.uleb128 .Ltmp287-.Lfunc_begin18
	.byte	0
	.uleb128 .Ltmp286-.Lfunc_begin18
	.uleb128 .Lfunc_end49-.Ltmp286
	.byte	0
	.byte	0
.Lcst_end18:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_:
.Lfunc_begin19:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception19
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$168, %rsp
	.cfi_def_cfa_offset 224
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %rbx
	movq	%rsi, %r14
	movups	(%rsi), %xmm0
	movaps	%xmm0, 96(%rsp)
	addq	$-2, 96(%rsp)
	movups	16(%rsi), %xmm0
	movl	$1, %eax
	sbbq	$0, %rax
	movaps	%xmm0, 112(%rsp)
	subq	%rax, 104(%rsp)
	movq	%rdi, 88(%rsp)
	movl	$1, %eax
	sbbq	$0, %rax
	xorq	$1, %rax
	subq	%rax, 112(%rsp)
	movl	$1, %eax
	sbbq	$0, %rax
	xorq	$1, %rax
	subq	%rax, 120(%rsp)
	movdqu	64(%rsi), %xmm0
	movdqu	80(%rsi), %xmm1
	movdqa	%xmm1, 32(%rsp)
	movdqa	%xmm0, 16(%rsp)
	movl	$255, %r15d
	leaq	48(%rsp), %r12
	leaq	16(%rsp), %r13
	leaq	128(%rsp), %rbp
	.p2align	4
.LBB50_1:
.Ltmp288:
	movq	%r12, %rdi
	movq	%r14, %rsi
	movq	%r13, %rdx
	movq	%r13, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp289:
.Ltmp291:
	movq	%rbp, %rdi
	movq	%r14, %rsi
	movq	%r12, %rdx
	movq	%rbx, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp292:
	movq	%r15, %rax
	shrq	$6, %rax
	movq	96(%rsp,%rax,8), %rax
	xorl	%ecx, %ecx
	btq	%r15, %rax
	setb	%cl
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm0
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm1
	punpcklqdq	%xmm1, %xmm0
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm1
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm2
	punpcklqdq	%xmm2, %xmm1
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	pxor	%xmm2, %xmm2
	psubq	%xmm0, %xmm2
	pcmpeqd	%xmm3, %xmm3
	paddq	%xmm3, %xmm0
	pand	48(%rsp), %xmm0
	pand	128(%rsp), %xmm2
	por	%xmm0, %xmm2
	pxor	%xmm0, %xmm0
	psubq	%xmm1, %xmm0
	paddq	%xmm3, %xmm1
	pand	64(%rsp), %xmm1
	pand	144(%rsp), %xmm0
	por	%xmm1, %xmm0
	#MEMBARRIER
	movdqa	%xmm2, 16(%rsp)
	movdqa	%xmm0, 32(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	addq	$-1, %r15
	jb	.LBB50_1
	movaps	16(%rsp), %xmm0
	movaps	32(%rsp), %xmm1
	movq	88(%rsp), %rax
	movups	%xmm1, 16(%rax)
	movups	%xmm0, (%rax)
	addq	$168, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB50_5:
	.cfi_def_cfa_offset 224
.Ltmp290:
	jmp	.LBB50_6
.LBB50_7:
.Ltmp293:
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
.LBB50_6:
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end50:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_, .Lfunc_end50-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table50:
.Lexception19:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end19-.Lcst_begin19
.Lcst_begin19:
	.uleb128 .Ltmp288-.Lfunc_begin19
	.uleb128 .Ltmp289-.Ltmp288
	.uleb128 .Ltmp290-.Lfunc_begin19
	.byte	0
	.uleb128 .Ltmp291-.Lfunc_begin19
	.uleb128 .Ltmp292-.Ltmp291
	.uleb128 .Ltmp293-.Lfunc_begin19
	.byte	0
	.uleb128 .Ltmp292-.Lfunc_begin19
	.uleb128 .Lfunc_end50-.Ltmp292
	.byte	0
	.byte	0
.Lcst_end19:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$184, %rsp
	.cfi_def_cfa_offset 240
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r15
	movq	%rdi, 120(%rsp)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movq	(%rcx), %rdi
	movq	8(%rcx), %r8
	movq	16(%rcx), %r9
	movq	24(%rcx), %r10
	movq	32(%rcx), %r11
	movq	40(%rcx), %r14
	xorl	%ebp, %ebp
	movq	40(%rsp), %r13
	.p2align	4
.LBB51_1:
	movq	(%r15,%rbp,8), %rbx
	movq	%rdi, %rax
	mulq	%rbx
	movq	%rdx, %rcx
	movq	%rax, %r12
	movq	%r8, %rax
	mulq	%rbx
	addq	%r12, (%rsp,%rbp,8)
	adcq	8(%rsp,%rbp,8), %rcx
	setb	%r12b
	movzbl	%r12b, %r12d
	addq	%rax, %rcx
	adcq	%rdx, %r12
	movq	%r9, %rax
	mulq	%rbx
	movq	%rcx, 8(%rsp,%rbp,8)
	xorl	%ecx, %ecx
	addq	16(%rsp,%rbp,8), %r12
	setb	%cl
	addq	%rax, %r12
	adcq	%rdx, %rcx
	movq	%r12, 16(%rsp,%rbp,8)
	movq	%r10, %rax
	mulq	%rbx
	xorl	%r12d, %r12d
	addq	24(%rsp,%rbp,8), %rcx
	setb	%r12b
	addq	%rax, %rcx
	adcq	%rdx, %r12
	movq	%r11, %rax
	mulq	%rbx
	movq	%rcx, 24(%rsp,%rbp,8)
	xorl	%ecx, %ecx
	addq	32(%rsp,%rbp,8), %r12
	setb	%cl
	addq	%rax, %r12
	adcq	%rdx, %rcx
	movq	%r12, 32(%rsp,%rbp,8)
	movq	%r14, %rax
	mulq	%rbx
	xorl	%ebx, %ebx
	addq	%r13, %rcx
	setb	%bl
	addq	%rax, %rcx
	adcq	%rdx, %rbx
	movq	%rcx, 40(%rsp,%rbp,8)
	movq	%rbx, 48(%rsp,%rbp,8)
	incq	%rbp
	movq	%rbx, %r13
	cmpq	$6, %rbp
	jne	.LBB51_1
	movq	144(%rsi), %r12
	movq	(%rsi), %rcx
	movq	8(%rsi), %rdi
	movq	16(%rsi), %r8
	movq	24(%rsi), %r9
	movq	32(%rsi), %r10
	movq	40(%rsi), %r11
	xorl	%ebp, %ebp
	.p2align	4
.LBB51_3:
	movq	(%rsp,%rbp), %rbx
	movq	%r12, %r13
	imulq	%rbx, %r13
	movq	%rcx, %rax
	mulq	%r13
	movq	%rdx, %r14
	movq	%rax, %r15
	movq	%rdi, %rax
	mulq	%r13
	addq	%rbx, %r15
	movq	%r15, (%rsp,%rbp)
	adcq	8(%rsp,%rbp), %r14
	setb	%bl
	movzbl	%bl, %ebx
	addq	%rax, %r14
	adcq	%rdx, %rbx
	movq	%r14, 8(%rsp,%rbp)
	movq	%r8, %rax
	mulq	%r13
	xorl	%r14d, %r14d
	addq	16(%rsp,%rbp), %rbx
	setb	%r14b
	addq	%rax, %rbx
	adcq	%rdx, %r14
	movq	%r9, %rax
	mulq	%r13
	movq	%rbx, 16(%rsp,%rbp)
	xorl	%ebx, %ebx
	addq	24(%rsp,%rbp), %r14
	setb	%bl
	addq	%rax, %r14
	adcq	%rdx, %rbx
	movq	%r14, 24(%rsp,%rbp)
	movq	%r10, %rax
	mulq	%r13
	xorl	%r14d, %r14d
	addq	32(%rsp,%rbp), %rbx
	setb	%r14b
	addq	%rax, %rbx
	adcq	%rdx, %r14
	movq	%r11, %rax
	mulq	%r13
	movq	%rbx, 32(%rsp,%rbp)
	xorl	%ebx, %ebx
	addq	40(%rsp,%rbp), %r14
	setb	%bl
	addq	%rax, %r14
	adcq	%rdx, %rbx
	movq	%r14, 40(%rsp,%rbp)
	xorl	%eax, %eax
	addq	%rbx, 48(%rsp,%rbp)
	setb	%al
	cmpq	$48, %rbp
	je	.LBB51_16
	cmpq	$56, %rbp
	je	.LBB51_16
	addq	%rax, 56(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$40, %rbp
	je	.LBB51_16
	cmpq	$48, %rbp
	je	.LBB51_16
	addq	%rax, 64(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$32, %rbp
	je	.LBB51_16
	cmpq	$40, %rbp
	je	.LBB51_16
	addq	%rax, 72(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$24, %rbp
	je	.LBB51_16
	cmpq	$32, %rbp
	je	.LBB51_16
	addq	%rax, 80(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$16, %rbp
	je	.LBB51_16
	cmpq	$24, %rbp
	je	.LBB51_16
	addq	%rax, 88(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$8, %rbp
	je	.LBB51_16
	cmpq	$16, %rbp
	je	.LBB51_16
	xorl	%edx, %edx
	addq	%rax, 96(%rsp,%rbp)
	setb	%dl
	movq	%rdx, %rax
	.p2align	4
.LBB51_16:
	movq	%rax, 128(%rsp)
	movq	$0, 136(%rsp)
	testq	%rax, %rax
	jne	.LBB51_19
	addq	$8, %rbp
	cmpq	$48, %rbp
	jne	.LBB51_3
	leaq	48(%rsp), %rdx
	movq	96(%rsp), %rcx
	leaq	128(%rsp), %rdi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	%rsp, %rax
	movq	$0, (%rax)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	movups	128(%rsp), %xmm0
	movups	144(%rsp), %xmm1
	movups	160(%rsp), %xmm2
	movq	120(%rsp), %rax
	movups	%xmm2, 32(%rax)
	movups	%xmm1, 16(%rax)
	movups	%xmm0, (%rax)
	addq	$184, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB51_19:
	.cfi_def_cfa_offset 240
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.18(%rip), %rdx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.26(%rip), %r9
	leaq	128(%rsp), %rsi
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto@GOTPCREL(%rip)
.Lfunc_end51:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_, .Lfunc_end51-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	.cfi_endproc

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_:
.Lfunc_begin20:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception20
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$296, %rsp
	.cfi_def_cfa_offset 352
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movq	(%rsi), %rax
	cmpq	$0, 40(%rsi)
	setns	%cl
	testb	$1, %al
	je	.LBB52_1
	testb	%cl, %cl
	jne	.LBB52_7
.LBB52_3:
	movl	$2, %ecx
	movl	$2, %edx
	subq	%rax, %rdx
	movq	%rdx, %rdi
	imulq	%rax, %rdi
	movl	$2, %r8d
	subq	%rdi, %r8
	imulq	%rdx, %r8
	movq	%r8, %rdx
	imulq	%rax, %rdx
	movl	$2, %edi
	subq	%rdx, %rdi
	imulq	%r8, %rdi
	movq	%rdi, %rdx
	imulq	%rax, %rdx
	movl	$2, %r8d
	subq	%rdx, %r8
	imulq	%rdi, %r8
	movq	%r8, %rdx
	imulq	%rax, %rdx
	subq	%rdx, %rcx
	imulq	%r8, %rcx
	imulq	%rcx, %rax
	addq	$-2, %rax
	imulq	%rcx, %rax
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movups	32(%rsi), %xmm2
	movaps	%xmm2, 128(%rsp)
	movaps	%xmm1, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	movq	%rax, 240(%rsp)
	leaq	144(%rsp), %r14
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 176(%rsp)
	movaps	%xmm0, 192(%rsp)
	movaps	%xmm0, 208(%rsp)
	movaps	%xmm0, 224(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$1, 88(%rsp)
	movl	$1, %edx
	movl	$768, %ebp
	xorl	%ecx, %ecx
	leaq	248(%rsp), %r15
	leaq	96(%rsp), %r12
	movq	%rsp, %r13
	xorl	%eax, %eax
	xorl	%esi, %esi
	xorl	%edi, %edi
	xorl	%r8d, %r8d
	.p2align	4
.LBB52_4:
	leaq	(%rdx,%rdx), %r9
	movq	%r9, (%rsp)
	shrdq	$63, %r8, %rdx
	shrdq	$63, %rdi, %r8
	movq	%rdx, 8(%rsp)
	movq	%r8, 16(%rsp)
	shrdq	$63, %rsi, %rdi
	movq	%rdi, 24(%rsp)
	shrdq	$63, %rax, %rsi
	movq	%rsi, 32(%rsp)
	shrdq	$63, %rcx, %rax
	movq	%rax, 40(%rsp)
	shrq	$63, %rcx
	movq	%r15, %rdi
	movq	%r12, %rsi
	movq	%r13, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	248(%rsp), %rdx
	movq	256(%rsp), %r8
	movq	264(%rsp), %rdi
	movq	272(%rsp), %rsi
	movq	280(%rsp), %rax
	movq	288(%rsp), %rcx
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	%rdx, 88(%rsp)
	movq	%r8, 80(%rsp)
	movq	%rdi, 72(%rsp)
	movq	%rsi, 64(%rsp)
	movq	%rax, 56(%rsp)
	movq	%rcx, 48(%rsp)
	decq	%rbp
	jne	.LBB52_4
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	%rdx, 144(%rsp)
	movq	%r8, 152(%rsp)
	movq	%rdi, 160(%rsp)
	movq	%rsi, 168(%rsp)
	movq	%rax, 176(%rsp)
	movq	%rcx, 184(%rsp)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 24(%rsp)
	movups	%xmm0, 8(%rsp)
	movq	$0, 40(%rsp)
	movq	$1, (%rsp)
.Ltmp294:
	leaq	248(%rsp), %rdi
	leaq	96(%rsp), %rsi
	movq	%rsp, %rdx
	movq	%r14, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp295:
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movups	248(%rsp), %xmm0
	movups	264(%rsp), %xmm1
	movups	280(%rsp), %xmm2
	movups	%xmm2, 80(%r14)
	movups	%xmm1, 64(%r14)
	movups	%xmm0, 48(%r14)
	leaq	96(%rsp), %rsi
	movl	$152, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	addq	$296, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB52_1:
	.cfi_def_cfa_offset 352
	movb	$1, %cl
	testb	%cl, %cl
	je	.LBB52_3
.LBB52_7:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.27(%rip), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.28(%rip), %rdx
	movl	$76, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking5panic@GOTPCREL(%rip)
.LBB52_8:
.Ltmp296:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end52:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_, .Lfunc_end52-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table52:
.Lexception20:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end20-.Lcst_begin20
.Lcst_begin20:
	.uleb128 .Ltmp294-.Lfunc_begin20
	.uleb128 .Ltmp295-.Ltmp294
	.uleb128 .Ltmp296-.Lfunc_begin20
	.byte	0
	.uleb128 .Ltmp295-.Lfunc_begin20
	.uleb128 .Lfunc_end52-.Ltmp295
	.byte	0
	.byte	0
.Lcst_end20:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	32(%rdx), %rax
	movq	24(%rdx), %r8
	movq	(%rdx), %r10
	movq	8(%rdx), %r9
	subq	(%rcx), %r10
	movl	$1, %r11d
	sbbq	$0, %r11
	xorq	$1, %r11
	xorl	%ebx, %ebx
	addq	8(%rcx), %r11
	setb	%bl
	subq	%r11, %r9
	movl	$1, %r14d
	sbbq	%rbx, %r14
	xorq	$1, %r14
	xorl	%ebx, %ebx
	addq	16(%rcx), %r14
	movq	16(%rdx), %r11
	setb	%bl
	subq	%r14, %r11
	movl	$1, %r14d
	sbbq	%rbx, %r14
	xorq	$1, %r14
	xorl	%ebx, %ebx
	addq	24(%rcx), %r14
	setb	%bl
	subq	%r14, %r8
	movl	$1, %r14d
	sbbq	%rbx, %r14
	xorq	$1, %r14
	xorl	%ebx, %ebx
	addq	32(%rcx), %r14
	setb	%bl
	subq	%r14, %rax
	movl	$1, %r14d
	sbbq	%rbx, %r14
	movl	$1, %ebx
	xorq	$1, %r14
	movq	40(%rdx), %rdx
	xorl	%r15d, %r15d
	addq	40(%rcx), %r14
	setb	%r15b
	subq	%r14, %rdx
	sbbq	%r15, %rbx
	xorq	$1, %rbx
	movq	%rbx, -8(%rsp)
	xorl	%ecx, %ecx
	subq	-8(%rsp), %rcx
	movq	(%rsi), %rbx
	andq	%rcx, %rbx
	addq	%r10, %rbx
	adcq	$0, %r9
	setb	%r10b
	movzbl	%r10b, %r14d
	movq	8(%rsi), %r10
	andq	%rcx, %r10
	addq	%r9, %r10
	adcq	%r11, %r14
	setb	%r9b
	movzbl	%r9b, %r11d
	movq	16(%rsi), %r9
	andq	%rcx, %r9
	addq	%r14, %r9
	adcq	%r8, %r11
	setb	%r8b
	movzbl	%r8b, %r8d
	movq	24(%rsi), %r14
	andq	%rcx, %r14
	addq	%r11, %r14
	adcq	%rax, %r8
	setb	%al
	movq	32(%rsi), %r11
	andq	%rcx, %r11
	andq	40(%rsi), %rcx
	movzbl	%al, %eax
	addq	%r8, %r11
	adcq	%rdx, %rax
	addq	%rcx, %rax
	movq	%rbx, (%rdi)
	movq	%r10, 8(%rdi)
	movq	%r9, 16(%rdi)
	movq	%r14, 24(%rdi)
	movq	%r11, 32(%rdi)
	movq	%rax, 40(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end53:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_, .Lfunc_end53-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_
	.cfi_endproc

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_:
.Lfunc_begin21:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception21
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$232, %rsp
	.cfi_def_cfa_offset 288
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rbx
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movups	32(%rsi), %xmm2
	movaps	%xmm0, 128(%rsp)
	addq	$-2, 128(%rsp)
	movaps	%xmm1, 144(%rsp)
	movl	$1, %eax
	sbbq	$0, %rax
	movaps	%xmm2, 160(%rsp)
	subq	%rax, 136(%rsp)
	movl	$1, %eax
	sbbq	$0, %rax
	xorq	$1, %rax
	subq	%rax, 144(%rsp)
	movl	$1, %eax
	sbbq	$0, %rax
	xorq	$1, %rax
	subq	%rax, 152(%rsp)
	movl	$1, %eax
	sbbq	$0, %rax
	xorq	$1, %rax
	subq	%rax, 160(%rsp)
	movq	%rdx, %r14
	movl	$1, %eax
	sbbq	$0, %rax
	xorq	$1, %rax
	subq	%rax, 168(%rsp)
	movq	%rdi, 120(%rsp)
	movdqu	96(%rsi), %xmm0
	movdqu	112(%rsi), %xmm1
	movdqu	128(%rsi), %xmm2
	movdqa	%xmm2, 48(%rsp)
	movdqa	%xmm1, 32(%rsp)
	movdqa	%xmm0, 16(%rsp)
	movl	$383, %r15d
	leaq	64(%rsp), %r12
	leaq	16(%rsp), %r13
	leaq	176(%rsp), %rbp
	.p2align	4
.LBB54_1:
.Ltmp297:
	movq	%r12, %rdi
	movq	%rbx, %rsi
	movq	%r13, %rdx
	movq	%r13, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp298:
.Ltmp300:
	movq	%rbp, %rdi
	movq	%rbx, %rsi
	movq	%r12, %rdx
	movq	%r14, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp301:
	movq	%r15, %rax
	shrq	$6, %rax
	movq	128(%rsp,%rax,8), %rax
	xorl	%ecx, %ecx
	btq	%r15, %rax
	setb	%cl
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm2
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm2
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm0
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm1
	punpcklqdq	%xmm1, %xmm0
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm1
	movq	%rcx, 8(%rsp)
	movq	8(%rsp), %xmm4
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	pxor	%xmm3, %xmm3
	psubq	%xmm2, %xmm3
	pcmpeqd	%xmm5, %xmm5
	paddq	%xmm5, %xmm2
	pand	64(%rsp), %xmm2
	punpcklqdq	%xmm4, %xmm1
	pand	176(%rsp), %xmm3
	pxor	%xmm4, %xmm4
	psubq	%xmm0, %xmm4
	paddq	%xmm5, %xmm0
	pand	80(%rsp), %xmm0
	por	%xmm2, %xmm3
	pand	192(%rsp), %xmm4
	pxor	%xmm2, %xmm2
	psubq	%xmm1, %xmm2
	paddq	%xmm5, %xmm1
	pand	96(%rsp), %xmm1
	por	%xmm0, %xmm4
	pand	208(%rsp), %xmm2
	por	%xmm1, %xmm2
	#MEMBARRIER
	movdqa	%xmm3, 16(%rsp)
	movdqa	%xmm4, 32(%rsp)
	movdqa	%xmm2, 48(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	addq	$-1, %r15
	jb	.LBB54_1
	movaps	16(%rsp), %xmm0
	movaps	32(%rsp), %xmm1
	movaps	48(%rsp), %xmm2
	movq	120(%rsp), %rax
	movups	%xmm2, 32(%rax)
	movups	%xmm1, 16(%rax)
	movups	%xmm0, (%rax)
	addq	$232, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB54_5:
	.cfi_def_cfa_offset 288
.Ltmp299:
	jmp	.LBB54_6
.LBB54_7:
.Ltmp302:
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
.LBB54_6:
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end54:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_, .Lfunc_end54-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_,"a",@progbits
	.p2align	2, 0x0
GCC_except_table54:
.Lexception21:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end21-.Lcst_begin21
.Lcst_begin21:
	.uleb128 .Ltmp297-.Lfunc_begin21
	.uleb128 .Ltmp298-.Ltmp297
	.uleb128 .Ltmp299-.Lfunc_begin21
	.byte	0
	.uleb128 .Ltmp300-.Lfunc_begin21
	.uleb128 .Ltmp301-.Ltmp300
	.uleb128 .Ltmp302-.Lfunc_begin21
	.byte	0
	.uleb128 .Ltmp301-.Lfunc_begin21
	.uleb128 .Lfunc_end54-.Ltmp301
	.byte	0
	.byte	0
.Lcst_end21:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_,"ax",@progbits
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r9
	movq	(%rdx), %rbx
	movq	%rbx, -48(%rsp)
	movq	8(%rdx), %r14
	movq	%r14, -56(%rsp)
	subq	(%rsi), %rbx
	movl	$1, %r8d
	sbbq	$0, %r8
	xorq	$1, %r8
	xorl	%r10d, %r10d
	addq	8(%rsi), %r8
	setb	%r10b
	subq	%r8, %r14
	movl	$1, %r11d
	sbbq	%r10, %r11
	xorq	$1, %r11
	movq	16(%rdx), %r8
	xorl	%r10d, %r10d
	addq	16(%rsi), %r11
	setb	%r10b
	movq	%r8, %r15
	subq	%r11, %r15
	movl	$1, %r11d
	sbbq	%r10, %r11
	xorq	$1, %r11
	movq	24(%rdx), %r10
	xorl	%r13d, %r13d
	addq	24(%rsi), %r11
	setb	%r13b
	movq	%r10, %r12
	subq	%r11, %r12
	movl	$1, %ebp
	sbbq	%r13, %rbp
	xorq	$1, %rbp
	movq	32(%rdx), %r13
	movq	%r13, -64(%rsp)
	xorl	%eax, %eax
	addq	32(%rsi), %rbp
	setb	%al
	subq	%rbp, %r13
	movl	$1, %ebp
	sbbq	%rax, %rbp
	xorq	$1, %rbp
	xorl	%edx, %edx
	addq	40(%rsi), %rbp
	movq	40(%r9), %r11
	setb	%dl
	movq	%r11, %rsi
	subq	%rbp, %rsi
	movl	$1, %eax
	sbbq	%rdx, %rax
	xorl	%ebp, %ebp
	orq	%rcx, %rax
	setne	%bpl
	movq	%rbp, -72(%rsp)
	movq	-72(%rsp), %rcx
	movq	%rcx, %rax
	negq	%rax
	andq	%rbx, %rax
	decq	%rcx
	andq	-48(%rsp), %rcx
	orq	%rax, %rcx
	movq	%rbp, -72(%rsp)
	movq	-72(%rsp), %r9
	movq	%r9, %rax
	negq	%rax
	andq	%r14, %rax
	decq	%r9
	andq	-56(%rsp), %r9
	orq	%rax, %r9
	movq	%rbp, -72(%rsp)
	movq	-72(%rsp), %rax
	movq	%rax, %rdx
	negq	%rdx
	andq	%r15, %rdx
	decq	%rax
	andq	%r8, %rax
	orq	%rdx, %rax
	movq	%rbp, -72(%rsp)
	movq	-72(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%r12, %rdx
	decq	%r8
	andq	%r10, %r8
	orq	%rdx, %r8
	movq	%rbp, -72(%rsp)
	movq	-72(%rsp), %r10
	movq	%r10, %rdx
	negq	%rdx
	andq	%r13, %rdx
	decq	%r10
	andq	-64(%rsp), %r10
	orq	%rdx, %r10
	movq	%rbp, -72(%rsp)
	movq	-72(%rsp), %rdx
	movq	%rdx, %rbx
	negq	%rbx
	andq	%rsi, %rbx
	decq	%rdx
	andq	%r11, %rdx
	orq	%rbx, %rdx
	movq	$0, -72(%rsp)
	movq	$0, -8(%rsp)
	movq	$0, -16(%rsp)
	movq	$0, -24(%rsp)
	movq	$0, -32(%rsp)
	movq	$0, -40(%rsp)
	#MEMBARRIER
	movq	%rcx, (%rdi)
	movq	%r9, 8(%rdi)
	movq	%rax, 16(%rdi)
	movq	%r8, 24(%rdi)
	movq	%r10, 32(%rdi)
	movq	%rdx, 40(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end55:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_, .Lfunc_end55-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	.cfi_endproc

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey13packet_length,"ax",@progbits
	.globl	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey13packet_length
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey13packet_length,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey13packet_length:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movl	%edx, 12(%rsp)
	addq	$32, %rdi
	movl	%esi, %eax
	bswapq	%rax
	movq	%rax, 16(%rsp)
	leaq	16(%rsp), %rsi
	leaq	12(%rsp), %rcx
	movl	$4, %r8d
	xorl	%edx, %edx
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor
	cmpb	$-1, %al
	jne	.LBB56_2
	movl	12(%rsp), %eax
	bswapl	%eax
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.LBB56_2:
	.cfi_def_cfa_offset 32
	movb	$0, 11(%rsp)
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.24(%rip), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.25(%rip), %rcx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.29(%rip), %r8
	leaq	11(%rsp), %rdx
	movl	$43, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core6result13unwrap_failed@GOTPCREL(%rip)
.Lfunc_end56:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey13packet_length, .Lfunc_end56-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey13packet_length
	.cfi_endproc

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey3new,"ax",@progbits
	.globl	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey3new
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey3new,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey3new:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3new
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end57:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey3new, .Lfunc_end57-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey3new
	.cfi_endproc

	.section	.text._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey4open,"ax",@progbits
	.globl	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey4open
	.p2align	4
	.type	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey4open,@function
_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey4open:
.Lfunc_begin22:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception22
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r14
	movq	80(%rsp), %rax
	xorq	$16, %rax
	movq	%r8, %rcx
	shrq	$32, %rcx
	orq	%rax, %rcx
	je	.LBB58_7
	xorl	%eax, %eax
	jmp	.LBB58_9
.LBB58_7:
	movq	%r9, %r13
	movq	%r8, %rbx
	movq	%rdx, %r12
	movl	%esi, %ebp
	movq	%rdi, %r15
	movq	%rsp, %rdi
	movq	%r15, %rsi
	movl	%ebp, %edx
	movq	%r12, %rcx
	movq	%r14, %r8
	movq	%rbx, %r9
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3tag
	movdqu	(%r13), %xmm0
	pcmpeqb	(%rsp), %xmm0
	pmovmskb	%xmm0, %eax
	xorl	%ecx, %ecx
	xorl	$65535, %eax
	setne	%cl
	movq	%rcx, 16(%rsp)
	cmpq	$0, 16(%rsp)
	movb	$1, %al
	jne	.LBB58_8
	movl	%ebp, %eax
	bswapq	%rax
	movq	%rax, 16(%rsp)
	leaq	32(%r15), %rdi
.Ltmp303:
	leaq	16(%rsp), %rsi
	movl	$4, %r8d
	xorl	%edx, %edx
	movq	%r12, %rcx
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor
.Ltmp304:
	cmpb	$-1, %al
	je	.LBB58_6
	xorl	%eax, %eax
	jmp	.LBB58_8
.LBB58_6:
.Ltmp305:
	leaq	16(%rsp), %rsi
	movl	$1, %edx
	movq	%r15, %rdi
	movq	%r14, %rcx
	movq	%rbx, %r8
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor
.Ltmp306:
.LBB58_8:
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	#MEMBARRIER
.LBB58_9:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB58_2:
	.cfi_def_cfa_offset 80
.Ltmp307:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end58:
	.size	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey4open, .Lfunc_end58-_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey4open
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB5_10OpeningKey4open,"a",@progbits
	.p2align	2, 0x0
GCC_except_table58:
.Lexception22:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end22-.Lcst_begin22
.Lcst_begin22:
	.uleb128 .Lfunc_begin22-.Lfunc_begin22
	.uleb128 .Ltmp303-.Lfunc_begin22
	.byte	0
	.byte	0
	.uleb128 .Ltmp303-.Lfunc_begin22
	.uleb128 .Ltmp306-.Ltmp303
	.uleb128 .Ltmp307-.Lfunc_begin22
	.byte	0
	.uleb128 .Ltmp306-.Lfunc_begin22
	.uleb128 .Lfunc_end58-.Ltmp306
	.byte	0
	.byte	0
.Lcst_end22:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes,"ax",@progbits
	.globl	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes
	.p2align	4
	.type	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes,@function
_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes:
.Lfunc_begin23:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception23
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$728, %rsp
	.cfi_def_cfa_offset 752
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rbx
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
.Ltmp308:
	leaq	40(%rsp), %rdi
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256@GOTPCREL(%rip)
.Ltmp309:
	leaq	384(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movq	%rsp, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_
	cmpb	$0, 384(%rsp)
	je	.LBB59_2
	movzbl	385(%rsp), %eax
	movb	%al, 1(%rbx)
	movb	$1, (%rbx)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	jmp	.LBB59_3
.LBB59_2:
	movups	392(%rsp), %xmm0
	movups	408(%rsp), %xmm1
	movups	%xmm1, 368(%rsp)
	movups	%xmm0, 352(%rsp)
	movaps	%xmm1, 400(%rsp)
	movaps	%xmm0, 384(%rsp)
	leaq	416(%rsp), %rdi
	leaq	40(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r14
	movl	$304, %edx
	callq	*%r14
	leaq	8(%rbx), %rdi
	leaq	384(%rsp), %rsi
	movl	$336, %edx
	callq	*%r14
	movb	$0, (%rbx)
.LBB59_3:
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$728, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB59_5:
	.cfi_def_cfa_offset 752
.Ltmp310:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end59:
	.size	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes, .Lfunc_end59-_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes,"a",@progbits
	.p2align	2, 0x0
GCC_except_table59:
.Lexception23:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end23-.Lcst_begin23
.Lcst_begin23:
	.uleb128 .Ltmp308-.Lfunc_begin23
	.uleb128 .Ltmp309-.Ltmp308
	.uleb128 .Ltmp310-.Lfunc_begin23
	.byte	0
	.uleb128 .Ltmp309-.Lfunc_begin23
	.uleb128 .Lfunc_end59-.Ltmp309
	.byte	0
	.byte	0
.Lcst_end23:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key,"ax",@progbits
	.globl	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key
	.p2align	4
	.type	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key,@function
_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key:
.Lfunc_begin24:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception24
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$728, %rsp
	.cfi_def_cfa_offset 784
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rdx
	movq	%rdi, %rbx
	leaq	32(%rsi), %r14
	movups	64(%rsi), %xmm0
	movups	80(%rsi), %xmm1
	movaps	%xmm1, 256(%rsp)
	movaps	%xmm0, 240(%rsp)
	movups	96(%rsi), %xmm0
	movups	112(%rsi), %xmm1
	movaps	%xmm0, 272(%rsp)
	movaps	%xmm1, 288(%rsp)
	movups	192(%rsi), %xmm0
	movups	208(%rsi), %xmm1
	movaps	%xmm0, 304(%rsp)
	movaps	%xmm1, 320(%rsp)
.Ltmp311:
	leaq	16(%rsp), %rdi
	leaq	240(%rsp), %rsi
	movq	%r14, %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
.Ltmp312:
	leaq	88(%rsp), %rbp
	leaq	96(%rsp), %r13
	leaq	104(%rsp), %r12
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 192(%rsp)
	movaps	%xmm0, 176(%rsp)
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 144(%rsp)
	movb	$0, 208(%rsp)
.Ltmp314:
	leaq	240(%rsp), %r15
	leaq	16(%rsp), %rsi
	movq	%r15, %rdi
	movq	%r14, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_
.Ltmp315:
	cmpb	$1, 240(%rsp)
	je	.LBB60_3
	movq	248(%rsp), %rcx
	movq	256(%rsp), %rdx
	movq	264(%rsp), %rsi
	movq	272(%rsp), %rdi
	movq	280(%rsp), %r8
	movq	288(%rsp), %r9
	movq	296(%rsp), %r10
	movq	304(%rsp), %rax
	movq	%rcx, 136(%rsp)
	movq	%rdx, 128(%rsp)
	movq	%rsi, 120(%rsp)
	movq	%rdi, 112(%rsp)
	movb	$4, 144(%rsp)
	bswapq	%rcx
	bswapq	%rdx
	movq	%rcx, 169(%rsp)
	movq	%rdx, 161(%rsp)
	bswapq	%rsi
	movq	%rsi, 153(%rsp)
	bswapq	%rdi
	movq	%rdi, 145(%rsp)
	bswapq	%r8
	bswapq	%r9
	movq	%r8, 201(%rsp)
	movq	%r9, 193(%rsp)
	bswapq	%r10
	movq	%r10, 185(%rsp)
	bswapq	%rax
	movq	%rax, 177(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
.Ltmp316:
	leaq	240(%rsp), %rdi
	leaq	144(%rsp), %rsi
	movl	$65, %edx
	callq	*_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1@GOTPCREL(%rip)
.Ltmp317:
	cmpb	$1, 240(%rsp)
	je	.LBB60_6
	leaq	248(%rsp), %rsi
	movl	$472, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$728, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB60_6:
	.cfi_def_cfa_offset 784
	movzbl	241(%rsp), %eax
	movb	%al, 8(%rsp)
	leaq	8(%rsp), %r15
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.33(%rip), %rdi
.LBB60_7:
.Ltmp318:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.25(%rip), %rcx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.32(%rip), %r8
	movl	$26, %esi
	movq	%r15, %rdx
	callq	*_RNvNtCsgxBkk5gSRhY_4core6result13unwrap_failed@GOTPCREL(%rip)
.Ltmp319:
	ud2
.LBB60_3:
	movzbl	241(%rsp), %eax
	movb	%al, 240(%rsp)
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.30(%rip), %rdi
	jmp	.LBB60_7
.LBB60_10:
.Ltmp313:
	leaq	328(%rsp), %r12
	leaq	320(%rsp), %r13
	leaq	312(%rsp), %rbp
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	$0, 304(%rsp)
	jmp	.LBB60_11
.LBB60_12:
.Ltmp320:
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
.LBB60_11:
	movq	$0, (%rbp)
	movq	$0, (%r13)
	movq	$0, (%r12)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end60:
	.size	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key, .Lfunc_end60-_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key,"a",@progbits
	.p2align	2, 0x0
GCC_except_table60:
.Lexception24:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end24-.Lcst_begin24
.Lcst_begin24:
	.uleb128 .Ltmp311-.Lfunc_begin24
	.uleb128 .Ltmp312-.Ltmp311
	.uleb128 .Ltmp313-.Lfunc_begin24
	.byte	0
	.uleb128 .Ltmp314-.Lfunc_begin24
	.uleb128 .Ltmp317-.Ltmp314
	.uleb128 .Ltmp320-.Lfunc_begin24
	.byte	0
	.uleb128 .Ltmp317-.Lfunc_begin24
	.uleb128 .Ltmp318-.Ltmp317
	.byte	0
	.byte	0
	.uleb128 .Ltmp318-.Lfunc_begin24
	.uleb128 .Ltmp319-.Ltmp318
	.uleb128 .Ltmp320-.Lfunc_begin24
	.byte	0
	.uleb128 .Ltmp319-.Lfunc_begin24
	.uleb128 .Lfunc_end60-.Ltmp319
	.byte	0
	.byte	0
.Lcst_end24:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree,"ax",@progbits
	.globl	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree
	.p2align	4
	.type	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree,@function
_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree:
.Lfunc_begin25:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception25
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$272, %rsp
	.cfi_def_cfa_offset 304
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	leaq	32(%rsi), %r15
.Ltmp321:
	leaq	88(%rsp), %rdi
	movq	%rdx, %rsi
	movq	%rbx, %rdx
	movq	%r15, %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
.Ltmp322:
.Ltmp324:
	leaq	200(%rsp), %rdi
	leaq	88(%rsp), %rsi
	movq	%r15, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_
.Ltmp325:
	cmpb	$1, 200(%rsp)
	je	.LBB61_3
	movq	208(%rsp), %rax
	movq	216(%rsp), %rcx
	movq	224(%rsp), %rdx
	movq	232(%rsp), %rsi
	movq	%rax, 32(%rsp)
	movq	%rcx, 24(%rsp)
	movq	%rdx, 16(%rsp)
	movq	%rsi, 8(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	32(%rsp), %rax
	bswapq	%rax
	movq	24(%rsp), %rcx
	bswapq	%rcx
	movq	%rax, 72(%rsp)
	movq	16(%rsp), %rax
	bswapq	%rax
	movq	%rcx, 64(%rsp)
	movq	8(%rsp), %rcx
	bswapq	%rcx
	movq	%rax, 56(%rsp)
	movq	%rcx, 48(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	#MEMBARRIER
	movq	48(%rsp), %rax
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	movq	%rdx, 17(%r14)
	movq	72(%rsp), %rdx
	movq	%rdx, 25(%r14)
	movq	%rax, 1(%r14)
	movq	%rcx, 9(%r14)
	movb	$0, (%r14)
	movq	$0, 160(%rbx)
	movq	$0, 168(%rbx)
	movq	$0, 176(%rbx)
	movq	$0, 184(%rbx)
	#MEMBARRIER
	movq	$0, 192(%rbx)
	movq	$0, 200(%rbx)
	movq	$0, 208(%rbx)
	movq	$0, 216(%rbx)
	#MEMBARRIER
	movq	$0, 264(%rbx)
	movq	$0, 272(%rbx)
	movq	$0, 280(%rbx)
	movq	$0, 288(%rbx)
	#MEMBARRIER
	movq	$0, 296(%rbx)
	movq	$0, 304(%rbx)
	movq	$0, 312(%rbx)
	movq	$0, 320(%rbx)
	#MEMBARRIER
	movq	$0, 32(%rbx)
	movq	$0, 40(%rbx)
	movq	$0, 48(%rbx)
	movq	$0, 56(%rbx)
	#MEMBARRIER
	movq	$0, 64(%rbx)
	movq	$0, 72(%rbx)
	movq	$0, 80(%rbx)
	movq	$0, 88(%rbx)
	#MEMBARRIER
	movq	$0, 96(%rbx)
	movq	$0, 104(%rbx)
	movq	$0, 112(%rbx)
	movq	$0, 120(%rbx)
	#MEMBARRIER
	movq	$0, (%rbx)
	movq	$0, 8(%rbx)
	movq	$0, 16(%rbx)
	movq	$0, 24(%rbx)
	#MEMBARRIER
	movq	%r14, %rax
	addq	$272, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB61_3:
	.cfi_def_cfa_offset 304
	movzbl	201(%rsp), %eax
	movb	%al, 40(%rsp)
.Ltmp326:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.60(%rip), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.25(%rip), %rcx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.61(%rip), %r8
	leaq	40(%rsp), %rdx
	movl	$46, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core6result13unwrap_failed@GOTPCREL(%rip)
.Ltmp327:
	ud2
.LBB61_5:
.Ltmp323:
	movq	%rax, %r14
	jmp	.LBB61_6
.LBB61_8:
.Ltmp328:
	movq	%rax, %r14
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
.LBB61_6:
	leaq	48(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%rbx, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p2569SecretKeyEBH_
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end61:
	.size	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree, .Lfunc_end61-_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree,"a",@progbits
	.p2align	2, 0x0
GCC_except_table61:
.Lexception25:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end25-.Lcst_begin25
.Lcst_begin25:
	.uleb128 .Ltmp321-.Lfunc_begin25
	.uleb128 .Ltmp322-.Ltmp321
	.uleb128 .Ltmp323-.Lfunc_begin25
	.byte	0
	.uleb128 .Ltmp324-.Lfunc_begin25
	.uleb128 .Ltmp327-.Ltmp324
	.uleb128 .Ltmp328-.Lfunc_begin25
	.byte	0
	.uleb128 .Ltmp327-.Lfunc_begin25
	.uleb128 .Lfunc_end61-.Ltmp327
	.byte	0
	.byte	0
.Lcst_end25:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes,"ax",@progbits
	.globl	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes
	.p2align	4
	.type	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes,@function
_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes:
.Lfunc_begin26:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception26
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$1056, %rsp
	.cfi_def_cfa_offset 1088
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movups	32(%rsi), %xmm2
	movaps	%xmm2, 32(%rsp)
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
.Ltmp329:
	leaq	56(%rsp), %rdi
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384@GOTPCREL(%rip)
.Ltmp330:
	leaq	560(%rsp), %rdi
	leaq	56(%rsp), %rsi
	movq	%rsp, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_
	cmpb	$0, 560(%rsp)
	je	.LBB62_2
	movzbl	561(%rsp), %eax
	movb	%al, 1(%rbx)
	movb	$1, (%rbx)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	#MEMBARRIER
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	#MEMBARRIER
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	jmp	.LBB62_3
.LBB62_2:
	movups	568(%rsp), %xmm0
	movups	584(%rsp), %xmm1
	movups	600(%rsp), %xmm2
	movups	%xmm2, 544(%rsp)
	movups	%xmm1, 528(%rsp)
	movups	%xmm0, 512(%rsp)
	movups	%xmm2, 1040(%rsp)
	movups	%xmm1, 1024(%rsp)
	movups	%xmm0, 1008(%rsp)
	leaq	560(%rsp), %r14
	leaq	56(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r15
	movl	$448, %edx
	movq	%r14, %rdi
	callq	*%r15
	leaq	8(%rbx), %rdi
	movl	$496, %edx
	movq	%r14, %rsi
	callq	*%r15
	movb	$0, (%rbx)
.LBB62_3:
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$1056, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB62_5:
	.cfi_def_cfa_offset 1088
.Ltmp331:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj30_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end62:
	.size	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes, .Lfunc_end62-_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes,"a",@progbits
	.p2align	2, 0x0
GCC_except_table62:
.Lexception26:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end26-.Lcst_begin26
.Lcst_begin26:
	.uleb128 .Ltmp329-.Lfunc_begin26
	.uleb128 .Ltmp330-.Ltmp329
	.uleb128 .Ltmp331-.Lfunc_begin26
	.byte	0
	.uleb128 .Ltmp330-.Lfunc_begin26
	.uleb128 .Lfunc_end62-.Ltmp330
	.byte	0
	.byte	0
.Lcst_end26:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key,"ax",@progbits
	.globl	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key
	.p2align	4
	.type	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key,@function
_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key:
.Lfunc_begin27:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception27
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$1040, %rsp
	.cfi_def_cfa_offset 1088
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %r15
	movq	%rdi, %rbx
	movups	48(%rsi), %xmm0
	movups	64(%rsi), %xmm1
	movups	80(%rsi), %xmm2
	movaps	%xmm2, 368(%rsp)
	movaps	%xmm1, 352(%rsp)
	movaps	%xmm0, 336(%rsp)
	movups	96(%rsi), %xmm0
	movups	112(%rsi), %xmm1
	movups	128(%rsi), %xmm2
	movaps	%xmm0, 384(%rsp)
	movaps	%xmm1, 400(%rsp)
	movaps	%xmm2, 416(%rsp)
	movups	240(%rsi), %xmm0
	movups	256(%rsi), %xmm1
	movups	272(%rsi), %xmm2
	movaps	%xmm0, 432(%rsp)
	movaps	%xmm1, 448(%rsp)
	movaps	%xmm2, 464(%rsp)
	leaq	448(%rsi), %rdx
.Ltmp332:
	leaq	160(%rsp), %rdi
	leaq	336(%rsp), %r14
	movq	%r14, %rsi
	movq	%r15, %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
.Ltmp333:
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
.Ltmp335:
	leaq	336(%rsp), %r12
	leaq	160(%rsp), %r14
	movq	%r12, %rdi
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_
.Ltmp336:
	cmpb	$1, 336(%rsp)
	je	.LBB63_3
	movq	344(%rsp), %r11
	movq	352(%rsp), %r15
	movq	360(%rsp), %r12
	movq	368(%rsp), %r13
	movq	376(%rsp), %r9
	movq	384(%rsp), %r10
	movq	392(%rsp), %r8
	movq	400(%rsp), %rdi
	movq	408(%rsp), %rdx
	movq	416(%rsp), %rsi
	movq	424(%rsp), %rcx
	movq	432(%rsp), %rax
	movq	%r11, 48(%rsp)
	movq	%r15, 40(%rsp)
	movq	%r12, 32(%rsp)
	movq	%r13, 24(%rsp)
	movq	%r9, 16(%rsp)
	movq	%r10, 8(%rsp)
	movb	$4, 63(%rsp)
	bswapq	%r11
	bswapq	%r15
	movq	%r11, 104(%rsp)
	movq	%r15, 96(%rsp)
	bswapq	%r12
	movq	%r12, 88(%rsp)
	bswapq	%r13
	movq	%r13, 80(%rsp)
	bswapq	%r9
	bswapq	%r10
	movq	%r9, 72(%rsp)
	movq	%r10, 64(%rsp)
	bswapq	%r8
	movq	%r8, 152(%rsp)
	bswapq	%rdi
	movq	%rdi, 144(%rsp)
	bswapq	%rdx
	bswapq	%rsi
	movq	%rdx, 136(%rsp)
	movq	%rsi, 128(%rsp)
	bswapq	%rcx
	movq	%rcx, 120(%rsp)
	bswapq	%rax
	movq	%rax, 112(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, (%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	#MEMBARRIER
.Ltmp337:
	leaq	336(%rsp), %rdi
	leaq	63(%rsp), %rsi
	movl	$97, %edx
	callq	*_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1@GOTPCREL(%rip)
.Ltmp338:
	cmpb	$1, 336(%rsp)
	je	.LBB63_6
	leaq	344(%rsp), %rsi
	movl	$696, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$1040, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB63_6:
	.cfi_def_cfa_offset 1088
	movzbl	337(%rsp), %eax
	movb	%al, (%rsp)
	movq	%rsp, %r12
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.33(%rip), %rdi
.LBB63_7:
.Ltmp339:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.25(%rip), %rcx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.34(%rip), %r8
	movl	$26, %esi
	movq	%r12, %rdx
	callq	*_RNvNtCsgxBkk5gSRhY_4core6result13unwrap_failed@GOTPCREL(%rip)
.Ltmp340:
	ud2
.LBB63_3:
	movzbl	337(%rsp), %eax
	movb	%al, 336(%rsp)
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.30(%rip), %rdi
	jmp	.LBB63_7
.LBB63_10:
.Ltmp334:
	jmp	.LBB63_11
.LBB63_12:
.Ltmp341:
.LBB63_11:
	movq	%rax, %rbx
	movq	%r14, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end63:
	.size	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key, .Lfunc_end63-_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key,"a",@progbits
	.p2align	2, 0x0
GCC_except_table63:
.Lexception27:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end27-.Lcst_begin27
.Lcst_begin27:
	.uleb128 .Ltmp332-.Lfunc_begin27
	.uleb128 .Ltmp333-.Ltmp332
	.uleb128 .Ltmp334-.Lfunc_begin27
	.byte	0
	.uleb128 .Ltmp335-.Lfunc_begin27
	.uleb128 .Ltmp338-.Ltmp335
	.uleb128 .Ltmp341-.Lfunc_begin27
	.byte	0
	.uleb128 .Ltmp338-.Lfunc_begin27
	.uleb128 .Ltmp339-.Ltmp338
	.byte	0
	.byte	0
	.uleb128 .Ltmp339-.Lfunc_begin27
	.uleb128 .Ltmp340-.Ltmp339
	.uleb128 .Ltmp341-.Lfunc_begin27
	.byte	0
	.uleb128 .Ltmp340-.Lfunc_begin27
	.uleb128 .Lfunc_end63-.Ltmp340
	.byte	0
	.byte	0
.Lcst_end27:
	.p2align	2, 0x0

	.section	.text._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree,"ax",@progbits
	.globl	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree
	.p2align	4
	.type	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree,@function
_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree:
.Lfunc_begin28:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception28
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$392, %rsp
	.cfi_def_cfa_offset 416
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	leaq	448(%rsi), %rax
	leaq	448(%rdx), %rsi
.Ltmp342:
	leaq	112(%rsp), %rdi
	movq	%rax, %rdx
	movq	%rbx, %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
.Ltmp343:
.Ltmp345:
	leaq	288(%rsp), %rdi
	leaq	112(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_
.Ltmp346:
	cmpb	$1, 288(%rsp)
	je	.LBB64_3
	movq	296(%rsp), %rax
	movq	304(%rsp), %rcx
	movq	312(%rsp), %rdx
	movq	320(%rsp), %rsi
	movq	328(%rsp), %rdi
	movq	336(%rsp), %r8
	movq	%rax, 48(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%rdx, 32(%rsp)
	movq	%rsi, 24(%rsp)
	movq	%rdi, 16(%rsp)
	movq	%r8, 8(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	movq	48(%rsp), %rax
	bswapq	%rax
	movq	40(%rsp), %rcx
	bswapq	%rcx
	movq	%rax, 104(%rsp)
	movq	32(%rsp), %rax
	bswapq	%rax
	movq	%rcx, 96(%rsp)
	movq	24(%rsp), %rcx
	bswapq	%rcx
	movq	%rax, 88(%rsp)
	movq	16(%rsp), %rax
	bswapq	%rax
	movq	%rcx, 80(%rsp)
	movq	8(%rsp), %rcx
	bswapq	%rcx
	movq	%rax, 72(%rsp)
	movq	%rcx, 64(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	#MEMBARRIER
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	80(%rsp), %rdx
	movq	88(%rsp), %rsi
	movaps	96(%rsp), %xmm0
	movups	%xmm0, 33(%r14)
	movq	%rdx, 17(%r14)
	movq	%rsi, 25(%r14)
	movq	%rax, 1(%r14)
	movq	%rcx, 9(%r14)
	movb	$0, (%r14)
	movq	$0, 192(%rbx)
	movq	$0, 200(%rbx)
	movq	$0, 208(%rbx)
	movq	$0, 216(%rbx)
	movq	$0, 224(%rbx)
	movq	$0, 232(%rbx)
	#MEMBARRIER
	movq	$0, 240(%rbx)
	movq	$0, 248(%rbx)
	movq	$0, 256(%rbx)
	movq	$0, 264(%rbx)
	movq	$0, 272(%rbx)
	movq	$0, 280(%rbx)
	#MEMBARRIER
	movq	$0, 344(%rbx)
	movq	$0, 352(%rbx)
	movq	$0, 360(%rbx)
	movq	$0, 368(%rbx)
	movq	$0, 376(%rbx)
	movq	$0, 384(%rbx)
	#MEMBARRIER
	movq	$0, 392(%rbx)
	movq	$0, 400(%rbx)
	movq	$0, 408(%rbx)
	movq	$0, 416(%rbx)
	movq	$0, 424(%rbx)
	movq	$0, 432(%rbx)
	#MEMBARRIER
	movq	$0, (%rbx)
	movq	$0, 8(%rbx)
	movq	$0, 16(%rbx)
	movq	$0, 24(%rbx)
	movq	$0, 32(%rbx)
	movq	$0, 40(%rbx)
	#MEMBARRIER
	movq	$0, 48(%rbx)
	movq	$0, 56(%rbx)
	movq	$0, 64(%rbx)
	movq	$0, 72(%rbx)
	movq	$0, 80(%rbx)
	movq	$0, 88(%rbx)
	#MEMBARRIER
	movq	$0, 96(%rbx)
	movq	$0, 104(%rbx)
	movq	$0, 112(%rbx)
	movq	$0, 120(%rbx)
	movq	$0, 128(%rbx)
	movq	$0, 136(%rbx)
	#MEMBARRIER
	movq	$0, 448(%rbx)
	movq	$0, 456(%rbx)
	movq	$0, 464(%rbx)
	movq	$0, 472(%rbx)
	movq	$0, 480(%rbx)
	movq	$0, 488(%rbx)
	#MEMBARRIER
	movq	%r14, %rax
	addq	$392, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB64_3:
	.cfi_def_cfa_offset 416
	movzbl	289(%rsp), %eax
	movb	%al, 56(%rsp)
.Ltmp347:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.60(%rip), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.25(%rip), %rcx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.61(%rip), %r8
	leaq	56(%rsp), %rdx
	movl	$46, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core6result13unwrap_failed@GOTPCREL(%rip)
.Ltmp348:
	ud2
.LBB64_5:
.Ltmp344:
	movq	%rax, %r14
	jmp	.LBB64_6
.LBB64_8:
.Ltmp349:
	movq	%rax, %r14
	leaq	112(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
.LBB64_6:
	leaq	64(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj30_EEBG_
	movq	%rbx, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p3849SecretKeyEBH_
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end64:
	.size	_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree, .Lfunc_end64-_RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree
	.cfi_endproc
	.section	.gcc_except_table._RNvMs0_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree,"a",@progbits
	.p2align	2, 0x0
GCC_except_table64:
.Lexception28:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end28-.Lcst_begin28
.Lcst_begin28:
	.uleb128 .Ltmp342-.Lfunc_begin28
	.uleb128 .Ltmp343-.Ltmp342
	.uleb128 .Ltmp344-.Lfunc_begin28
	.byte	0
	.uleb128 .Ltmp345-.Lfunc_begin28
	.uleb128 .Ltmp348-.Ltmp345
	.uleb128 .Ltmp349-.Lfunc_begin28
	.byte	0
	.uleb128 .Ltmp348-.Lfunc_begin28
	.uleb128 .Lfunc_end64-.Ltmp348
	.byte	0
	.byte	0
.Lcst_end28:
	.p2align	2, 0x0

	.section	.text._RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes,"ax",@progbits
	.globl	_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes
	.p2align	4
	.type	_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes,@function
_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1032, %rsp
	.cfi_def_cfa_offset 1088
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	cmpq	$1184, %rdx
	jne	.LBB65_18
	movq	%rsi, %r14
	xorl	%r13d, %r13d
	leaq	520(%rsp), %r15
	movq	memset@GOTPCREL(%rip), %rax
.LBB65_2:
	leaq	(%r14,%r13), %rbp
	addq	$384, %r13
	movl	$512, %edx
	movq	%r15, %rdi
	xorl	%esi, %esi
	movq	%rax, %r12
	callq	*%rax
	xorl	%eax, %eax
	movq	%r15, %rdx
	.p2align	4
.LBB65_3:
	movq	%rax, %rcx
	shrq	$3, %rcx
	movzbl	(%rbp,%rcx), %r9d
	movl	%eax, %ecx
	andb	$4, %cl
	movzbl	%cl, %esi
	xorl	%r8d, %r8d
	btl	%esi, %r9d
	setb	%r8b
	leal	1(%rsi), %ecx
	movl	%r9d, %r10d
	shrl	%cl, %r10d
	orw	(%rdx), %r8w
	leal	2(%rsi), %ecx
	movl	%r9d, %edi
	shrl	%cl, %edi
	addl	%r10d, %r10d
	andl	$2, %r10d
	shll	$2, %edi
	leal	3(%rsi), %ecx
	shrl	%cl, %r9d
	andl	$4, %edi
	orl	%r10d, %edi
	shll	$3, %r9d
	leaq	4(%rax), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movzbl	(%rbp,%r10), %r10d
	andb	$4, %cl
	shrl	%cl, %r10d
	andl	$8, %r9d
	orl	%edi, %r9d
	shll	$4, %r10d
	leaq	5(%rax), %rcx
	movq	%rcx, %rdi
	shrq	$3, %rdi
	movzbl	(%rbp,%rdi), %edi
	andb	$5, %cl
	shrl	%cl, %edi
	andl	$16, %r10d
	orl	%r9d, %r10d
	shll	$5, %edi
	andl	$32, %edi
	orl	%r10d, %edi
	orl	%r8d, %edi
	leaq	6(%rax), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%rbp,%r8), %r8d
	andb	$6, %cl
	shrl	%cl, %r8d
	leaq	7(%rax), %rcx
	movq	%rcx, %r9
	shrq	$3, %r9
	movzbl	(%rbp,%r9), %r9d
	andb	$7, %cl
	shrb	%cl, %r9b
	shll	$6, %r8d
	andl	$64, %r8d
	shlb	$7, %r9b
	movzbl	%r9b, %ecx
	orl	%r8d, %ecx
	leaq	8(%rax), %r8
	shrq	$3, %r8
	movzbl	(%rbp,%r8), %r8d
	xorl	%r9d, %r9d
	btl	%esi, %r8d
	setb	%r9b
	shll	$8, %r9d
	orl	%ecx, %r9d
	leaq	9(%rax), %rcx
	movq	%rcx, %rsi
	shrq	$3, %rsi
	movzbl	(%rbp,%rsi), %esi
	andl	$5, %ecx
	xorl	%r8d, %r8d
	btl	%ecx, %esi
	setb	%r8b
	shll	$9, %r8d
	orl	%r9d, %r8d
	leaq	10(%rax), %rcx
	movq	%rcx, %rsi
	shrq	$3, %rsi
	movzbl	(%rbp,%rsi), %esi
	andl	$6, %ecx
	xorl	%r9d, %r9d
	btl	%ecx, %esi
	setb	%r9b
	shll	$10, %r9d
	orl	%r8d, %r9d
	orl	%edi, %r9d
	leaq	11(%rax), %rcx
	movq	%rcx, %rsi
	shrq	$3, %rsi
	movzbl	(%rbp,%rsi), %esi
	andl	$7, %ecx
	xorl	%edi, %edi
	btl	%ecx, %esi
	setb	%dil
	shll	$11, %edi
	orl	%r9d, %edi
	movw	%di, (%rdx)
	addq	$2, %rdx
	addq	$12, %rax
	cmpq	$3072, %rax
	jne	.LBB65_3
	movl	$512, %edx
	leaq	8(%rsp), %rdi
	movq	%r15, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	xorl	%eax, %eax
	.p2align	4
.LBB65_5:
	cmpq	$512, %rax
	je	.LBB65_6
	cmpw	$3328, 8(%rsp,%rax)
	ja	.LBB65_14
	cmpw	$3328, 10(%rsp,%rax)
	ja	.LBB65_14
	cmpw	$3328, 12(%rsp,%rax)
	ja	.LBB65_14
	cmpw	$3328, 14(%rsp,%rax)
	leaq	8(%rax), %rax
	jbe	.LBB65_5
	jmp	.LBB65_14
.LBB65_6:
	xorl	%eax, %eax
	.p2align	4
.LBB65_7:
	movw	$0, 8(%rsp,%rax)
	movw	$0, 10(%rsp,%rax)
	movw	$0, 12(%rsp,%rax)
	movw	$0, 14(%rsp,%rax)
	movw	$0, 16(%rsp,%rax)
	movw	$0, 18(%rsp,%rax)
	movw	$0, 20(%rsp,%rax)
	movw	$0, 22(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB65_7
	#MEMBARRIER
	cmpq	$1152, %r13
	movq	%r12, %rax
	jne	.LBB65_2
	leaq	1(%rbx), %rdi
	movl	$1184, %edx
	movq	%r14, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movb	$0, (%rbx)
	jmp	.LBB65_17
.LBB65_18:
	movw	$1, (%rbx)
	jmp	.LBB65_17
.LBB65_14:
	movw	$513, (%rbx)
	xorl	%eax, %eax
	.p2align	4
.LBB65_15:
	movw	$0, 8(%rsp,%rax)
	movw	$0, 10(%rsp,%rax)
	movw	$0, 12(%rsp,%rax)
	movw	$0, 14(%rsp,%rax)
	movw	$0, 16(%rsp,%rax)
	movw	$0, 18(%rsp,%rax)
	movw	$0, 20(%rsp,%rax)
	movw	$0, 22(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB65_15
	#MEMBARRIER
.LBB65_17:
	movq	%rbx, %rax
	addq	$1032, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end65:
	.size	_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes, .Lfunc_end65-_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI66_0:
	.long	1290168
	.long	1290168
	.long	1290168
	.long	1290168
.LCPI66_1:
	.long	3329
	.long	3329
	.long	3329
	.long	3329
.LCPI66_2:
	.long	1664
	.long	1664
	.long	1664
	.long	1664
.LCPI66_3:
	.long	165141429
	.long	165141429
	.long	165141429
	.long	165141429
.LCPI66_4:
	.short	1023
	.short	1023
	.short	1023
	.short	1023
	.short	1023
	.short	1023
	.short	1023
	.short	1023
.LCPI66_5:
	.byte	0
	.byte	1
	.byte	2
	.byte	3
	.byte	4
	.byte	5
	.byte	6
	.byte	7
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
.LCPI66_6:
	.short	57568
	.short	57568
	.short	57568
	.short	57568
	.short	0
	.short	0
	.short	0
	.short	0
.LCPI66_7:
	.zero	16,15
.LCPI66_8:
	.zero	16,63
.LCPI66_9:
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
.LCPI66_10:
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
.LCPI66_11:
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
.LCPI66_12:
	.short	15
	.short	15
	.short	15
	.short	15
	.short	15
	.short	15
	.short	15
	.short	15
.LCPI66_13:
	.byte	0
	.byte	1
	.byte	2
	.byte	3
	.byte	4
	.byte	5
	.byte	6
	.byte	7
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.text._RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt,"ax",@progbits
	.globl	_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt
	.p2align	4
	.type	_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt,@function
_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt:
.Lfunc_begin29:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception29
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$3128, %rsp
	.cfi_def_cfa_offset 7280
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %rbp
	movq	%rdx, 24(%rsp)
	movq	%rsi, 16(%rsp)
	movq	%rdi, 32(%rsp)
	movq	_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise@GOTPCREL(%rip), %r12
	leaq	2616(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%rcx, %rsi
	xorl	%edx, %edx
	callq	*%r12
	leaq	568(%rsp), %r14
	movq	%r14, %rdi
	movq	%rbx, %rsi
	callq	*_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt@GOTPCREL(%rip)
	leaq	56(%rsp), %r13
	movq	memcpy@GOTPCREL(%rip), %r15
	movl	$512, %edx
	movq	%r13, %rdi
	movq	%r14, %rsi
	callq	*%r15
	leaq	2104(%rsp), %r14
	movl	$512, %edx
	movq	%r14, %rdi
	movq	%r13, %rsi
	callq	*%r15
	leaq	1080(%rsp), %r13
	movl	$512, %edx
	movq	%r13, %rdi
	movq	%r14, %rsi
	callq	*%r15
	leaq	4664(%rsp), %rdi
	movl	$512, %edx
	movq	%r13, %rsi
	callq	*%r15
	movb	$1, %r14b
.Ltmp350:
	movq	%rbx, %rdi
	movq	%rbp, 8(%rsp)
	movq	%rbp, %rsi
	movl	$1, %edx
	callq	*%r12
.Ltmp351:
.Ltmp352:
	leaq	568(%rsp), %rdi
	leaq	2616(%rsp), %rsi
	callq	*_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt@GOTPCREL(%rip)
.Ltmp353:
	leaq	56(%rsp), %rbx
	leaq	568(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*%r15
	leaq	2104(%rsp), %r14
	movl	$512, %edx
	movq	%r14, %rdi
	movq	%rbx, %rsi
	callq	*%r15
	leaq	1080(%rsp), %rbx
	movl	$512, %edx
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	*%r15
	leaq	5176(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	*%r15
	xorl	%r14d, %r14d
.Ltmp354:
	leaq	2616(%rsp), %rdi
	movq	8(%rsp), %rsi
	movl	$2, %edx
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise@GOTPCREL(%rip)
.Ltmp355:
	xorl	%r14d, %r14d
.Ltmp356:
	leaq	568(%rsp), %rdi
	leaq	2616(%rsp), %rsi
	callq	*_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt@GOTPCREL(%rip)
.Ltmp357:
	movq	16(%rsp), %rax
	addq	$1152, %rax
	movq	%rax, 48(%rsp)
	leaq	56(%rsp), %rbx
	leaq	568(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*%r15
	leaq	2104(%rsp), %r14
	movl	$512, %edx
	movq	%r14, %rdi
	movq	%rbx, %rsi
	callq	*%r15
	movl	$512, %edx
	leaq	1080(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	*%r15
	leaq	5688(%rsp), %rdi
	movl	$512, %edx
	movq	%rbx, %rsi
	callq	*%r15
	leaq	2616(%rsp), %rdi
	leaq	4664(%rsp), %rsi
	movl	$1536, %edx
	callq	*%r15
	leaq	4664(%rsp), %rdi
	xorl	%ebx, %ebx
	movl	$1088, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	leaq	1592(%rsp), %r15
	movl	$2642262849, %r14d
	.p2align	4
.LBB66_5:
	leaq	1(%rbx), %rax
	movq	%rax, 40(%rsp)
	movl	$512, %edx
	movq	%r15, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	xorl	%r12d, %r12d
	xorl	%r13d, %r13d
	.p2align	4
.LBB66_6:
.Ltmp359:
	leaq	568(%rsp), %rdi
	movq	48(%rsp), %rsi
	movq	%r13, %rdx
	movq	%rbx, %rcx
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem6sample@GOTPCREL(%rip)
.Ltmp360:
	leaq	(%rsp,%r12), %r15
	addq	$2616, %r15
	addq	$512, %r12
	incq	%r13
	movl	$512, %edx
	leaq	1080(%rsp), %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	xorl	%eax, %eax
	jmp	.LBB66_9
	.p2align	4
.LBB66_8:
	movzwl	568(%rsp,%rax,4), %r8d
	movzwl	(%r15,%rax,4), %edx
	movzwl	570(%rsp,%rax,4), %edi
	movzwl	2(%r15,%rax,4), %esi
	movl	%edx, %r9d
	imull	%r8d, %r9d
	imulq	$989558401, %r9, %r10
	shrq	$32, %r10
	movl	%r9d, %r11d
	subl	%r10d, %r11d
	shrl	%r11d
	addl	%r10d, %r11d
	shrl	$11, %r11d
	imull	$3329, %r11d, %r10d
	subl	%r10d, %r9d
	movl	%esi, %r10d
	imull	%edi, %r10d
	imulq	$989558401, %r10, %r11
	shrq	$32, %r11
	movl	%r10d, %ebp
	subl	%r11d, %ebp
	shrl	%ebp
	addl	%r11d, %ebp
	shrl	$11, %ebp
	imull	$3329, %ebp, %r11d
	subl	%r11d, %r10d
	movzwl	%cx, %ecx
	imull	%r10d, %ecx
	imulq	$330282857, %rcx, %r10
	shrq	$40, %r10
	imull	$3329, %r10d, %r10d
	subl	%r10d, %ecx
	addl	%r9d, %ecx
	leal	-3329(%rcx), %r9d
	cmpl	$3329, %ecx
	cmovbl	%ecx, %r9d
	movw	%r9w, 1080(%rsp,%rax,4)
	imull	%r8d, %esi
	imulq	$989558401, %rsi, %rcx
	shrq	$32, %rcx
	movl	%esi, %r8d
	subl	%ecx, %r8d
	shrl	%r8d
	addl	%ecx, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %ecx
	subl	%ecx, %esi
	imull	%edi, %edx
	imulq	$989558401, %rdx, %rcx
	shrq	$32, %rcx
	movl	%edx, %edi
	subl	%ecx, %edi
	shrl	%edi
	addl	%ecx, %edi
	shrl	$11, %edi
	imull	$3329, %edi, %ecx
	subl	%ecx, %edx
	leal	(%rsi,%rdx), %ecx
	cmpl	$3329, %ecx
	leal	-3329(%rsi,%rdx), %edx
	cmovbl	%ecx, %edx
	movw	%dx, 1082(%rsp,%rax,4)
	incq	%rax
	cmpq	$128, %rax
	je	.LBB66_13
.LBB66_9:
	movl	%eax, %ecx
	rolb	$4, %cl
	orb	$8, %cl
	movl	%ecx, %edx
	andb	$51, %dl
	shlb	$2, %dl
	shrb	$2, %cl
	andb	$51, %cl
	orb	%dl, %cl
	movl	%ecx, %edx
	andb	$85, %dl
	addb	%dl, %dl
	shrb	%cl
	andb	$85, %cl
	orb	%dl, %cl
	movzbl	%cl, %edx
	movw	$1, %cx
	movw	$17, %si
	jmp	.LBB66_11
	.p2align	4
.LBB66_10:
	imull	%esi, %esi
	movq	%rsi, %rdi
	imulq	%r14, %rdi
	shrq	$43, %rdi
	imull	$3329, %edi, %edi
	subl	%edi, %esi
	shrl	%edx
	je	.LBB66_8
.LBB66_11:
	movzwl	%si, %esi
	testb	$1, %dl
	je	.LBB66_10
	movzwl	%cx, %ecx
	imull	%esi, %ecx
	imulq	$989558401, %rcx, %rdi
	shrq	$32, %rdi
	movl	%ecx, %r8d
	subl	%edi, %r8d
	shrl	%r8d
	addl	%edi, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %edi
	subl	%edi, %ecx
	jmp	.LBB66_10
	.p2align	4
.LBB66_13:
	movl	$512, %edx
	leaq	56(%rsp), %rdi
	leaq	1080(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %rbp
	callq	*%rbp
	xorl	%eax, %eax
	leaq	1592(%rsp), %r15
	movdqa	.LCPI66_0(%rip), %xmm4
	movdqa	.LCPI66_1(%rip), %xmm5
	pxor	%xmm6, %xmm6
	.p2align	4
.LBB66_14:
	movdqu	1592(%rsp,%rax,2), %xmm2
	movdqu	56(%rsp,%rax,2), %xmm0
	movdqa	%xmm2, %xmm3
	punpckhwd	%xmm6, %xmm3
	punpcklwd	%xmm6, %xmm2
	movdqa	%xmm0, %xmm1
	punpckhwd	%xmm6, %xmm1
	paddd	%xmm3, %xmm1
	punpcklwd	%xmm6, %xmm0
	paddd	%xmm2, %xmm0
	movdqa	%xmm1, %xmm2
	pmuludq	%xmm4, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pshufd	$245, %xmm1, %xmm3
	pmuludq	%xmm4, %xmm3
	pshufd	$237, %xmm3, %xmm3
	punpckldq	%xmm3, %xmm2
	pmaddwd	%xmm5, %xmm2
	psubd	%xmm2, %xmm1
	movdqa	%xmm0, %xmm2
	pmuludq	%xmm4, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pshufd	$245, %xmm0, %xmm3
	pmuludq	%xmm4, %xmm3
	pshufd	$237, %xmm3, %xmm3
	punpckldq	%xmm3, %xmm2
	pmaddwd	%xmm5, %xmm2
	psubd	%xmm2, %xmm0
	packssdw	%xmm1, %xmm0
	movdqu	%xmm0, 1080(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB66_14
	movl	$512, %edx
	leaq	2104(%rsp), %rdi
	leaq	1080(%rsp), %rsi
	callq	*%rbp
	movl	$14, %eax
	.p2align	4
.LBB66_16:
	movw	$0, 1578(%rsp,%rax)
	movw	$0, 1580(%rsp,%rax)
	movw	$0, 1582(%rsp,%rax)
	movw	$0, 1584(%rsp,%rax)
	movw	$0, 1586(%rsp,%rax)
	movw	$0, 1588(%rsp,%rax)
	movw	$0, 1590(%rsp,%rax)
	movw	$0, 1592(%rsp,%rax)
	addq	$16, %rax
	cmpq	$526, %rax
	jne	.LBB66_16
	#MEMBARRIER
	movl	$512, %edx
	movq	%r15, %rdi
	leaq	2104(%rsp), %rsi
	callq	*%rbp
	xorl	%eax, %eax
	.p2align	4
.LBB66_18:
	movw	$0, 56(%rsp,%rax)
	movw	$0, 58(%rsp,%rax)
	movw	$0, 60(%rsp,%rax)
	movw	$0, 62(%rsp,%rax)
	movw	$0, 64(%rsp,%rax)
	movw	$0, 66(%rsp,%rax)
	movw	$0, 68(%rsp,%rax)
	movw	$0, 70(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_18
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_20:
	movw	$0, 568(%rsp,%rax)
	movw	$0, 570(%rsp,%rax)
	movw	$0, 572(%rsp,%rax)
	movw	$0, 574(%rsp,%rax)
	movw	$0, 576(%rsp,%rax)
	movw	$0, 578(%rsp,%rax)
	movw	$0, 580(%rsp,%rax)
	movw	$0, 582(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_20
	#MEMBARRIER
	cmpq	$1536, %r12
	jne	.LBB66_6
	movl	$512, %edx
	leaq	1080(%rsp), %r12
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	*%rbp
.Ltmp362:
	leaq	56(%rsp), %rdi
	movq	%r12, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse
.Ltmp363:
	leal	3(%rbx), %eax
.Ltmp365:
	movzbl	%al, %edx
	leaq	568(%rsp), %rdi
	movq	8(%rsp), %rsi
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise@GOTPCREL(%rip)
.Ltmp366:
	xorl	%eax, %eax
	movdqa	.LCPI66_0(%rip), %xmm4
	movdqa	.LCPI66_1(%rip), %xmm5
	pxor	%xmm6, %xmm6
	.p2align	4
.LBB66_25:
	movdqu	56(%rsp,%rax,2), %xmm2
	movdqu	568(%rsp,%rax,2), %xmm0
	movdqa	%xmm2, %xmm3
	punpckhwd	%xmm6, %xmm3
	punpcklwd	%xmm6, %xmm2
	movdqa	%xmm0, %xmm1
	punpckhwd	%xmm6, %xmm1
	paddd	%xmm3, %xmm1
	punpcklwd	%xmm6, %xmm0
	paddd	%xmm2, %xmm0
	movdqa	%xmm1, %xmm2
	pmuludq	%xmm4, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pshufd	$245, %xmm1, %xmm3
	pmuludq	%xmm4, %xmm3
	pshufd	$237, %xmm3, %xmm3
	punpckldq	%xmm3, %xmm2
	pmaddwd	%xmm5, %xmm2
	psubd	%xmm2, %xmm1
	movdqa	%xmm0, %xmm2
	pmuludq	%xmm4, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pshufd	$245, %xmm0, %xmm3
	pmuludq	%xmm4, %xmm3
	pshufd	$237, %xmm3, %xmm3
	punpckldq	%xmm3, %xmm2
	pmaddwd	%xmm5, %xmm2
	psubd	%xmm2, %xmm0
	packssdw	%xmm1, %xmm0
	movdqu	%xmm0, 1080(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB66_25
	movl	$512, %edx
	leaq	2104(%rsp), %rdi
	leaq	1080(%rsp), %rsi
	callq	*%rbp
	pxor	%xmm4, %xmm4
	xorl	%eax, %eax
	movdqa	.LCPI66_2(%rip), %xmm3
	movdqa	.LCPI66_3(%rip), %xmm5
	movdqa	.LCPI66_4(%rip), %xmm6
	.p2align	4
.LBB66_27:
	movdqu	2104(%rsp,%rax,2), %xmm0
	movdqa	%xmm0, %xmm1
	punpcklwd	%xmm4, %xmm1
	punpckhwd	%xmm4, %xmm0
	pslld	$10, %xmm0
	pslld	$10, %xmm1
	paddd	%xmm3, %xmm1
	paddd	%xmm3, %xmm0
	pshufd	$245, %xmm0, %xmm2
	pmuludq	%xmm5, %xmm0
	pshufd	$237, %xmm0, %xmm0
	pmuludq	%xmm5, %xmm2
	pshufd	$237, %xmm2, %xmm2
	punpckldq	%xmm2, %xmm0
	psrld	$7, %xmm0
	pshufd	$245, %xmm1, %xmm2
	pmuludq	%xmm5, %xmm1
	pshufd	$237, %xmm1, %xmm1
	pmuludq	%xmm5, %xmm2
	pshufd	$237, %xmm2, %xmm2
	punpckldq	%xmm2, %xmm1
	psrld	$7, %xmm1
	packssdw	%xmm0, %xmm1
	pand	%xmm6, %xmm1
	movdqu	%xmm1, 2104(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB66_27
	movl	$512, %edx
	leaq	1080(%rsp), %r12
	movq	%r12, %rdi
	leaq	2104(%rsp), %rsi
	callq	*%rbp
	leaq	(%rbx,%rbx,4), %rax
	shlq	$6, %rax
	leaq	(%rsp,%rax), %rbx
	addq	$4664, %rbx
	movl	$320, %edx
	movq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	xorl	%edx, %edx
	.p2align	4
.LBB66_29:
	movzwl	(%r12), %edi
	movl	%edi, %r8d
	andb	$1, %r8b
	movl	%edx, %eax
	andb	$6, %al
	movl	%eax, %ecx
	shlb	%cl, %r8b
	movq	%rdx, %r9
	shrq	$3, %r9
	orb	(%rbx,%r9), %r8b
	movl	%edi, %r10d
	shrb	%r10b
	andb	$1, %r10b
	leal	1(%rax), %ecx
	shlb	%cl, %r10b
	orb	%r8b, %r10b
	movb	%r10b, (%rbx,%r9)
	leaq	2(%rdx), %rcx
	movq	%rcx, %r8
	movl	%edi, %r9d
	shrb	$2, %r9b
	andb	$1, %r9b
	andb	$6, %cl
	shlb	%cl, %r9b
	shrq	$3, %r8
	orb	%r9b, (%rbx,%r8)
	leaq	3(%rdx), %rcx
	movq	%rcx, %r8
	movl	%edi, %r9d
	shrb	$3, %r9b
	andb	$1, %r9b
	andb	$7, %cl
	shlb	%cl, %r9b
	shrq	$3, %r8
	orb	%r9b, (%rbx,%r8)
	leaq	4(%rdx), %rcx
	movq	%rcx, %r8
	movl	%edi, %r9d
	shrb	$4, %r9b
	andb	$1, %r9b
	andb	$6, %cl
	shlb	%cl, %r9b
	shrq	$3, %r8
	orb	%r9b, (%rbx,%r8)
	leaq	5(%rdx), %rcx
	movq	%rcx, %r8
	movl	%edi, %r9d
	shrb	$5, %r9b
	andb	$1, %r9b
	andb	$7, %cl
	shlb	%cl, %r9b
	shrq	$3, %r8
	orb	%r9b, (%rbx,%r8)
	leaq	6(%rdx), %rcx
	movq	%rcx, %r8
	movl	%edi, %r9d
	shrb	$6, %r9b
	andb	$1, %r9b
	andb	$6, %cl
	shlb	%cl, %r9b
	shrq	$3, %r8
	orb	%r9b, (%rbx,%r8)
	leaq	7(%rdx), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movl	%edi, %r9d
	shrb	$7, %r9b
	andb	$7, %cl
	shlb	%cl, %r9b
	orb	%r9b, (%rbx,%r8)
	leaq	8(%rdx), %r8
	shrq	$3, %r8
	movl	%edi, %r9d
	shrl	$8, %r9d
	andb	$1, %r9b
	movl	%eax, %ecx
	shlb	%cl, %r9b
	orb	%r9b, (%rbx,%r8)
	leaq	9(%rdx), %rcx
	movq	%rcx, %rax
	shrl	$9, %edi
	andb	$1, %dil
	andb	$7, %cl
	shlb	%cl, %dil
	shrq	$3, %rax
	orb	%dil, (%rbx,%rax)
	addq	$2, %r12
	addq	$10, %rdx
	cmpq	$2560, %rdx
	jne	.LBB66_29
	xorl	%eax, %eax
	.p2align	4
.LBB66_31:
	movw	$0, 1080(%rsp,%rax)
	movw	$0, 1082(%rsp,%rax)
	movw	$0, 1084(%rsp,%rax)
	movw	$0, 1086(%rsp,%rax)
	movw	$0, 1088(%rsp,%rax)
	movw	$0, 1090(%rsp,%rax)
	movw	$0, 1092(%rsp,%rax)
	movw	$0, 1094(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_31
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_33:
	movw	$0, 568(%rsp,%rax)
	movw	$0, 570(%rsp,%rax)
	movw	$0, 572(%rsp,%rax)
	movw	$0, 574(%rsp,%rax)
	movw	$0, 576(%rsp,%rax)
	movw	$0, 578(%rsp,%rax)
	movw	$0, 580(%rsp,%rax)
	movw	$0, 582(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_33
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_35:
	movw	$0, 56(%rsp,%rax)
	movw	$0, 58(%rsp,%rax)
	movw	$0, 60(%rsp,%rax)
	movw	$0, 62(%rsp,%rax)
	movw	$0, 64(%rsp,%rax)
	movw	$0, 66(%rsp,%rax)
	movw	$0, 68(%rsp,%rax)
	movw	$0, 70(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_35
	#MEMBARRIER
	movq	40(%rsp), %rax
	movq	%rax, %rbx
	cmpq	$3, %rax
	jne	.LBB66_5
	leaq	4152(%rsp), %rdi
	xorl	%r14d, %r14d
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	leaq	1080(%rsp), %r15
	movl	$2642262849, %r13d
	xorl	%ebx, %ebx
	.p2align	4
.LBB66_38:
	leaq	(%rsp,%rbx), %rbp
	addq	$2616, %rbp
	addq	$512, %rbx
	leaq	(%r14,%r14,2), %r12
	incq	%r14
	shlq	$7, %r12
	addq	16(%rsp), %r12
	movl	$512, %edx
	movq	%r15, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	xorl	%eax, %eax
	movq	%r15, %rdx
	.p2align	4
.LBB66_39:
	movq	%rax, %rcx
	shrq	$3, %rcx
	movzbl	(%r12,%rcx), %r9d
	movl	%eax, %ecx
	andb	$4, %cl
	movzbl	%cl, %esi
	xorl	%r8d, %r8d
	btl	%esi, %r9d
	setb	%r8b
	leal	1(%rsi), %ecx
	movl	%r9d, %r10d
	shrl	%cl, %r10d
	orw	(%rdx), %r8w
	leal	2(%rsi), %ecx
	movl	%r9d, %edi
	shrl	%cl, %edi
	addl	%r10d, %r10d
	andl	$2, %r10d
	shll	$2, %edi
	leal	3(%rsi), %ecx
	shrl	%cl, %r9d
	andl	$4, %edi
	orl	%r10d, %edi
	shll	$3, %r9d
	leaq	4(%rax), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movzbl	(%r12,%r10), %r10d
	andb	$4, %cl
	shrl	%cl, %r10d
	andl	$8, %r9d
	orl	%edi, %r9d
	shll	$4, %r10d
	leaq	5(%rax), %rcx
	movq	%rcx, %rdi
	shrq	$3, %rdi
	movzbl	(%r12,%rdi), %edi
	andb	$5, %cl
	shrl	%cl, %edi
	andl	$16, %r10d
	orl	%r9d, %r10d
	shll	$5, %edi
	andl	$32, %edi
	orl	%r10d, %edi
	orl	%r8d, %edi
	leaq	6(%rax), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%r12,%r8), %r8d
	andb	$6, %cl
	shrl	%cl, %r8d
	leaq	7(%rax), %rcx
	movq	%rcx, %r9
	shrq	$3, %r9
	movzbl	(%r12,%r9), %r9d
	andb	$7, %cl
	shrb	%cl, %r9b
	shll	$6, %r8d
	andl	$64, %r8d
	shlb	$7, %r9b
	movzbl	%r9b, %ecx
	orl	%r8d, %ecx
	leaq	8(%rax), %r8
	shrq	$3, %r8
	movzbl	(%r12,%r8), %r8d
	xorl	%r9d, %r9d
	btl	%esi, %r8d
	setb	%r9b
	shll	$8, %r9d
	orl	%ecx, %r9d
	leaq	9(%rax), %rcx
	movq	%rcx, %rsi
	shrq	$3, %rsi
	movzbl	(%r12,%rsi), %esi
	andl	$5, %ecx
	xorl	%r8d, %r8d
	btl	%ecx, %esi
	setb	%r8b
	shll	$9, %r8d
	orl	%r9d, %r8d
	leaq	10(%rax), %rcx
	movq	%rcx, %rsi
	shrq	$3, %rsi
	movzbl	(%r12,%rsi), %esi
	andl	$6, %ecx
	xorl	%r9d, %r9d
	btl	%ecx, %esi
	setb	%r9b
	shll	$10, %r9d
	orl	%r8d, %r9d
	orl	%edi, %r9d
	leaq	11(%rax), %rcx
	movq	%rcx, %rsi
	shrq	$3, %rsi
	movzbl	(%r12,%rsi), %esi
	andl	$7, %ecx
	xorl	%edi, %edi
	btl	%ecx, %esi
	setb	%dil
	shll	$11, %edi
	orl	%r9d, %edi
	movw	%di, (%rdx)
	addq	$2, %rdx
	addq	$12, %rax
	cmpq	$3072, %rax
	jne	.LBB66_39
	movl	$512, %edx
	leaq	568(%rsp), %rdi
	movq	%r15, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movl	$512, %edx
	movq	%r15, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	xorl	%eax, %eax
	jmp	.LBB66_42
	.p2align	4
.LBB66_41:
	movzwl	568(%rsp,%rax,4), %r8d
	movzwl	(%rbp,%rax,4), %edx
	movzwl	570(%rsp,%rax,4), %edi
	movzwl	2(%rbp,%rax,4), %esi
	movl	%edx, %r9d
	imull	%r8d, %r9d
	imulq	$989558401, %r9, %r10
	shrq	$32, %r10
	movl	%r9d, %r11d
	subl	%r10d, %r11d
	shrl	%r11d
	addl	%r10d, %r11d
	shrl	$11, %r11d
	imull	$3329, %r11d, %r10d
	subl	%r10d, %r9d
	movl	%esi, %r10d
	imull	%edi, %r10d
	imulq	$989558401, %r10, %r11
	shrq	$32, %r11
	movl	%r10d, %r12d
	subl	%r11d, %r12d
	shrl	%r12d
	addl	%r11d, %r12d
	shrl	$11, %r12d
	imull	$3329, %r12d, %r11d
	subl	%r11d, %r10d
	movzwl	%cx, %ecx
	imull	%r10d, %ecx
	imulq	$330282857, %rcx, %r10
	shrq	$40, %r10
	imull	$3329, %r10d, %r10d
	subl	%r10d, %ecx
	addl	%r9d, %ecx
	leal	-3329(%rcx), %r9d
	cmpl	$3329, %ecx
	cmovbl	%ecx, %r9d
	movw	%r9w, 1080(%rsp,%rax,4)
	imull	%r8d, %esi
	imulq	$989558401, %rsi, %rcx
	shrq	$32, %rcx
	movl	%esi, %r8d
	subl	%ecx, %r8d
	shrl	%r8d
	addl	%ecx, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %ecx
	subl	%ecx, %esi
	imull	%edi, %edx
	imulq	$989558401, %rdx, %rcx
	shrq	$32, %rcx
	movl	%edx, %edi
	subl	%ecx, %edi
	shrl	%edi
	addl	%ecx, %edi
	shrl	$11, %edi
	imull	$3329, %edi, %ecx
	subl	%ecx, %edx
	leal	(%rsi,%rdx), %ecx
	cmpl	$3329, %ecx
	leal	-3329(%rsi,%rdx), %edx
	cmovbl	%ecx, %edx
	movw	%dx, 1082(%rsp,%rax,4)
	incq	%rax
	cmpq	$128, %rax
	je	.LBB66_47
.LBB66_42:
	movl	%eax, %ecx
	rolb	$4, %cl
	orb	$8, %cl
	movl	%ecx, %edx
	andb	$51, %dl
	shlb	$2, %dl
	shrb	$2, %cl
	andb	$51, %cl
	orb	%dl, %cl
	movl	%ecx, %edx
	andb	$85, %dl
	addb	%dl, %dl
	shrb	%cl
	andb	$85, %cl
	orb	%dl, %cl
	movzbl	%cl, %edx
	movw	$1, %cx
	movw	$17, %si
	jmp	.LBB66_45
	.p2align	4
.LBB66_43:
	movzwl	%cx, %ecx
	movzwl	%si, %esi
	imull	%esi, %ecx
	imulq	$989558401, %rcx, %rdi
	shrq	$32, %rdi
	movl	%ecx, %r8d
	subl	%edi, %r8d
	shrl	%r8d
	addl	%edi, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %edi
	subl	%edi, %ecx
.LBB66_44:
	imull	%esi, %esi
	movq	%rsi, %rdi
	imulq	%r13, %rdi
	shrq	$43, %rdi
	imull	$3329, %edi, %edi
	subl	%edi, %esi
	shrl	%edx
	je	.LBB66_41
.LBB66_45:
	testb	$1, %dl
	jne	.LBB66_43
	movzwl	%si, %esi
	jmp	.LBB66_44
	.p2align	4
.LBB66_47:
	movl	$512, %edx
	leaq	56(%rsp), %rdi
	movq	%r15, %rsi
	movq	memcpy@GOTPCREL(%rip), %r12
	callq	*%r12
	xorl	%eax, %eax
	movdqa	.LCPI66_0(%rip), %xmm4
	movdqa	.LCPI66_1(%rip), %xmm5
	pxor	%xmm6, %xmm6
	.p2align	4
.LBB66_48:
	movdqu	4152(%rsp,%rax,2), %xmm2
	movdqu	56(%rsp,%rax,2), %xmm0
	movdqa	%xmm2, %xmm3
	punpckhwd	%xmm6, %xmm3
	punpcklwd	%xmm6, %xmm2
	movdqa	%xmm0, %xmm1
	punpckhwd	%xmm6, %xmm1
	paddd	%xmm3, %xmm1
	punpcklwd	%xmm6, %xmm0
	paddd	%xmm2, %xmm0
	movdqa	%xmm1, %xmm2
	pmuludq	%xmm4, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pshufd	$245, %xmm1, %xmm3
	pmuludq	%xmm4, %xmm3
	pshufd	$237, %xmm3, %xmm3
	punpckldq	%xmm3, %xmm2
	pmaddwd	%xmm5, %xmm2
	psubd	%xmm2, %xmm1
	movdqa	%xmm0, %xmm2
	pmuludq	%xmm4, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pshufd	$245, %xmm0, %xmm3
	pmuludq	%xmm4, %xmm3
	pshufd	$237, %xmm3, %xmm3
	punpckldq	%xmm3, %xmm2
	pmaddwd	%xmm5, %xmm2
	psubd	%xmm2, %xmm0
	packssdw	%xmm1, %xmm0
	movdqu	%xmm0, 1080(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB66_48
	movl	$512, %edx
	leaq	2104(%rsp), %rbp
	movq	%rbp, %rdi
	movq	%r15, %rsi
	callq	*%r12
	movl	$14, %eax
	.p2align	4
.LBB66_50:
	movw	$0, 4138(%rsp,%rax)
	movw	$0, 4140(%rsp,%rax)
	movw	$0, 4142(%rsp,%rax)
	movw	$0, 4144(%rsp,%rax)
	movw	$0, 4146(%rsp,%rax)
	movw	$0, 4148(%rsp,%rax)
	movw	$0, 4150(%rsp,%rax)
	movw	$0, 4152(%rsp,%rax)
	addq	$16, %rax
	cmpq	$526, %rax
	jne	.LBB66_50
	#MEMBARRIER
	movl	$512, %edx
	leaq	4152(%rsp), %rdi
	movq	%rbp, %rsi
	callq	*%r12
	xorl	%eax, %eax
	.p2align	4
.LBB66_52:
	movw	$0, 56(%rsp,%rax)
	movw	$0, 58(%rsp,%rax)
	movw	$0, 60(%rsp,%rax)
	movw	$0, 62(%rsp,%rax)
	movw	$0, 64(%rsp,%rax)
	movw	$0, 66(%rsp,%rax)
	movw	$0, 68(%rsp,%rax)
	movw	$0, 70(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_52
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_54:
	movw	$0, 568(%rsp,%rax)
	movw	$0, 570(%rsp,%rax)
	movw	$0, 572(%rsp,%rax)
	movw	$0, 574(%rsp,%rax)
	movw	$0, 576(%rsp,%rax)
	movw	$0, 578(%rsp,%rax)
	movw	$0, 580(%rsp,%rax)
	movw	$0, 582(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_54
	#MEMBARRIER
	cmpq	$1536, %rbx
	jne	.LBB66_38
	leaq	1080(%rsp), %rbx
	leaq	4152(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
.Ltmp368:
	leaq	56(%rsp), %rdi
	movq	%rbx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse
.Ltmp369:
.Ltmp371:
	leaq	568(%rsp), %rdi
	movq	8(%rsp), %rsi
	movl	$6, %edx
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise@GOTPCREL(%rip)
.Ltmp372:
	movq	32(%rsp), %r14
	leaq	1592(%rsp), %r15
	movq	24(%rsp), %r12
	xorl	%eax, %eax
	pxor	%xmm0, %xmm0
	movdqa	.LCPI66_0(%rip), %xmm5
	movdqa	.LCPI66_1(%rip), %xmm6
	.p2align	4
.LBB66_59:
	movdqu	56(%rsp,%rax,2), %xmm3
	movdqu	568(%rsp,%rax,2), %xmm1
	movdqa	%xmm3, %xmm4
	punpckhwd	%xmm0, %xmm4
	punpcklwd	%xmm0, %xmm3
	movdqa	%xmm1, %xmm2
	punpckhwd	%xmm0, %xmm2
	paddd	%xmm4, %xmm2
	punpcklwd	%xmm0, %xmm1
	paddd	%xmm3, %xmm1
	movdqa	%xmm2, %xmm3
	pmuludq	%xmm5, %xmm3
	pshufd	$237, %xmm3, %xmm3
	pshufd	$245, %xmm2, %xmm4
	pmuludq	%xmm5, %xmm4
	pshufd	$237, %xmm4, %xmm4
	punpckldq	%xmm4, %xmm3
	pmaddwd	%xmm6, %xmm3
	psubd	%xmm3, %xmm2
	movdqa	%xmm1, %xmm3
	pmuludq	%xmm5, %xmm3
	pshufd	$237, %xmm3, %xmm3
	pshufd	$245, %xmm1, %xmm4
	pmuludq	%xmm5, %xmm4
	pshufd	$237, %xmm4, %xmm4
	punpckldq	%xmm4, %xmm3
	pmaddwd	%xmm6, %xmm3
	psubd	%xmm3, %xmm1
	packssdw	%xmm2, %xmm1
	movdqu	%xmm1, 1080(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB66_59
	leaq	2104(%rsp), %rdi
	leaq	1080(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	leaq	6200(%rsp), %rdi
	xorl	%ebx, %ebx
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	.LCPI66_13(%rip), %xmm0
	movq	.LCPI66_6(%rip), %xmm1
	pxor	%xmm2, %xmm2
	movdqa	.LCPI66_7(%rip), %xmm3
	movdqa	.LCPI66_8(%rip), %xmm4
	movdqa	.LCPI66_9(%rip), %xmm5
	movdqa	.LCPI66_10(%rip), %xmm6
	.p2align	4
.LBB66_61:
	movzbl	(%r12), %eax
	movd	%eax, %xmm7
	punpcklbw	%xmm7, %xmm7
	pshuflw	$0, %xmm7, %xmm7
	movdqa	%xmm0, %xmm8
	psllw	$5, %xmm8
	pand	%xmm1, %xmm8
	pxor	%xmm9, %xmm9
	pcmpgtb	%xmm8, %xmm9
	movdqa	%xmm9, %xmm10
	pandn	%xmm7, %xmm10
	psrlw	$4, %xmm7
	pand	%xmm9, %xmm7
	pand	%xmm3, %xmm7
	por	%xmm10, %xmm7
	paddb	%xmm8, %xmm8
	pxor	%xmm9, %xmm9
	pcmpgtb	%xmm8, %xmm9
	movdqa	%xmm9, %xmm10
	pandn	%xmm7, %xmm10
	psrlw	$2, %xmm7
	pand	%xmm9, %xmm7
	pand	%xmm4, %xmm7
	por	%xmm10, %xmm7
	paddb	%xmm8, %xmm8
	pxor	%xmm9, %xmm9
	pcmpgtb	%xmm8, %xmm9
	movdqa	%xmm9, %xmm8
	pandn	%xmm7, %xmm8
	psrlw	$1, %xmm7
	pand	%xmm9, %xmm7
	por	%xmm8, %xmm7
	pand	%xmm5, %xmm7
	punpcklbw	%xmm2, %xmm7
	movdqu	6200(%rsp,%rbx,2), %xmm8
	por	%xmm7, %xmm8
	movdqu	%xmm8, 6200(%rsp,%rbx,2)
	addq	$8, %rbx
	paddb	%xmm6, %xmm0
	incq	%r12
	cmpq	$256, %rbx
	jne	.LBB66_61
	xorl	%eax, %eax
	movdqa	.LCPI66_11(%rip), %xmm0
	pcmpeqd	%xmm1, %xmm1
	.p2align	4
.LBB66_63:
	movdqu	6200(%rsp,%rax,2), %xmm2
	movdqa	%xmm2, %xmm3
	pmulhuw	%xmm0, %xmm3
	pmullw	%xmm0, %xmm2
	movdqa	%xmm2, %xmm4
	punpckhwd	%xmm3, %xmm4
	punpcklwd	%xmm3, %xmm2
	psubd	%xmm1, %xmm2
	psubd	%xmm1, %xmm4
	pslld	$15, %xmm4
	psrad	$16, %xmm4
	pslld	$15, %xmm2
	psrad	$16, %xmm2
	packssdw	%xmm4, %xmm2
	movdqu	%xmm2, 6200(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB66_63
	leaq	1080(%rsp), %rdi
	leaq	6200(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	xorl	%eax, %eax
	pxor	%xmm0, %xmm0
	movdqa	.LCPI66_0(%rip), %xmm5
	movdqa	.LCPI66_1(%rip), %xmm6
	.p2align	4
.LBB66_65:
	movdqu	2104(%rsp,%rax,2), %xmm3
	movdqu	1080(%rsp,%rax,2), %xmm1
	movdqa	%xmm3, %xmm4
	punpckhwd	%xmm0, %xmm4
	punpcklwd	%xmm0, %xmm3
	movdqa	%xmm1, %xmm2
	punpckhwd	%xmm0, %xmm2
	paddd	%xmm4, %xmm2
	punpcklwd	%xmm0, %xmm1
	paddd	%xmm3, %xmm1
	movdqa	%xmm2, %xmm3
	pmuludq	%xmm5, %xmm3
	pshufd	$237, %xmm3, %xmm3
	pshufd	$245, %xmm2, %xmm4
	pmuludq	%xmm5, %xmm4
	pshufd	$237, %xmm4, %xmm4
	punpckldq	%xmm4, %xmm3
	pmaddwd	%xmm6, %xmm3
	psubd	%xmm3, %xmm2
	movdqa	%xmm1, %xmm3
	pmuludq	%xmm5, %xmm3
	pshufd	$237, %xmm3, %xmm3
	pshufd	$245, %xmm1, %xmm4
	pmuludq	%xmm5, %xmm4
	pshufd	$237, %xmm4, %xmm4
	punpckldq	%xmm4, %xmm3
	pmaddwd	%xmm6, %xmm3
	psubd	%xmm3, %xmm1
	packssdw	%xmm2, %xmm1
	movdqu	%xmm1, 6712(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB66_65
	xorl	%eax, %eax
	pxor	%xmm0, %xmm0
	movdqa	.LCPI66_12(%rip), %xmm1
	movdqa	.LCPI66_2(%rip), %xmm6
	.p2align	4
.LBB66_67:
	movdqu	6712(%rsp,%rax,2), %xmm2
	movdqa	%xmm2, %xmm3
	punpcklwd	%xmm0, %xmm3
	punpckhwd	%xmm0, %xmm2
	pslld	$4, %xmm2
	pslld	$4, %xmm3
	paddd	%xmm6, %xmm3
	paddd	%xmm6, %xmm2
	pshufd	$245, %xmm2, %xmm4
	pmuludq	%xmm5, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pmuludq	%xmm5, %xmm4
	pshufd	$237, %xmm4, %xmm4
	punpckldq	%xmm4, %xmm2
	pshufd	$245, %xmm3, %xmm4
	pmuludq	%xmm5, %xmm3
	pshufd	$237, %xmm3, %xmm3
	pmuludq	%xmm5, %xmm4
	pshufd	$237, %xmm4, %xmm4
	punpckldq	%xmm4, %xmm3
	packssdw	%xmm2, %xmm3
	pand	%xmm1, %xmm3
	movdqu	%xmm3, 6712(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB66_67
	leaq	6712(%rsp), %rsi
	movl	$512, %edx
	movq	%r15, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, 5624(%rsp)
	movdqu	%xmm0, 5640(%rsp)
	movdqu	%xmm0, 5656(%rsp)
	movdqu	%xmm0, 5672(%rsp)
	movdqu	%xmm0, 5688(%rsp)
	movdqu	%xmm0, 5704(%rsp)
	movdqu	%xmm0, 5720(%rsp)
	movdqu	%xmm0, 5736(%rsp)
	xorl	%edx, %edx
	.p2align	4
.LBB66_69:
	movzbl	(%r15), %esi
	movl	%esi, %edi
	andb	$1, %dil
	movl	%edx, %eax
	andb	$4, %al
	movl	%eax, %ecx
	shlb	%cl, %dil
	movq	%rdx, %r8
	shrq	$3, %r8
	orb	5624(%rsp,%r8), %dil
	movl	%esi, %r9d
	shrb	%r9b
	andb	$1, %r9b
	leal	1(%rax), %ecx
	shlb	%cl, %r9b
	movl	%esi, %r10d
	shrb	$2, %r10b
	andb	$1, %r10b
	leal	2(%rax), %ecx
	shlb	%cl, %r10b
	shrb	$3, %sil
	andb	$1, %sil
	orb	$3, %al
	movl	%eax, %ecx
	shlb	%cl, %sil
	orb	%r9b, %r10b
	orb	%r10b, %sil
	orb	%dil, %sil
	movb	%sil, 5624(%rsp,%r8)
	addq	$2, %r15
	addq	$4, %rdx
	cmpq	$1024, %rdx
	jne	.LBB66_69
	xorl	%eax, %eax
	.p2align	4
.LBB66_71:
	movw	$0, 1592(%rsp,%rax)
	movw	$0, 1594(%rsp,%rax)
	movw	$0, 1596(%rsp,%rax)
	movw	$0, 1598(%rsp,%rax)
	movw	$0, 1600(%rsp,%rax)
	movw	$0, 1602(%rsp,%rax)
	movw	$0, 1604(%rsp,%rax)
	movw	$0, 1606(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_71
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_73:
	movw	$0, 1080(%rsp,%rax)
	movw	$0, 1082(%rsp,%rax)
	movw	$0, 1084(%rsp,%rax)
	movw	$0, 1086(%rsp,%rax)
	movw	$0, 1088(%rsp,%rax)
	movw	$0, 1090(%rsp,%rax)
	movw	$0, 1092(%rsp,%rax)
	movw	$0, 1094(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_73
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_75:
	movw	$0, 2104(%rsp,%rax)
	movw	$0, 2106(%rsp,%rax)
	movw	$0, 2108(%rsp,%rax)
	movw	$0, 2110(%rsp,%rax)
	movw	$0, 2112(%rsp,%rax)
	movw	$0, 2114(%rsp,%rax)
	movw	$0, 2116(%rsp,%rax)
	movw	$0, 2118(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_75
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_77:
	movw	$0, 568(%rsp,%rax)
	movw	$0, 570(%rsp,%rax)
	movw	$0, 572(%rsp,%rax)
	movw	$0, 574(%rsp,%rax)
	movw	$0, 576(%rsp,%rax)
	movw	$0, 578(%rsp,%rax)
	movw	$0, 580(%rsp,%rax)
	movw	$0, 582(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_77
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_79:
	movw	$0, 56(%rsp,%rax)
	movw	$0, 58(%rsp,%rax)
	movw	$0, 60(%rsp,%rax)
	movw	$0, 62(%rsp,%rax)
	movw	$0, 64(%rsp,%rax)
	movw	$0, 66(%rsp,%rax)
	movw	$0, 68(%rsp,%rax)
	movw	$0, 70(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_79
	#MEMBARRIER
	leaq	4664(%rsp), %rsi
	movl	$1088, %edx
	movq	%r14, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	xorl	%eax, %eax
	.p2align	4
.LBB66_81:
	movw	$0, 2616(%rsp,%rax)
	movw	$0, 2618(%rsp,%rax)
	movw	$0, 2620(%rsp,%rax)
	movw	$0, 2622(%rsp,%rax)
	movw	$0, 2624(%rsp,%rax)
	movw	$0, 2626(%rsp,%rax)
	movw	$0, 2628(%rsp,%rax)
	movw	$0, 2630(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_81
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_83:
	movw	$0, 3128(%rsp,%rax)
	movw	$0, 3130(%rsp,%rax)
	movw	$0, 3132(%rsp,%rax)
	movw	$0, 3134(%rsp,%rax)
	movw	$0, 3136(%rsp,%rax)
	movw	$0, 3138(%rsp,%rax)
	movw	$0, 3140(%rsp,%rax)
	movw	$0, 3142(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_83
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_85:
	movw	$0, 3640(%rsp,%rax)
	movw	$0, 3642(%rsp,%rax)
	movw	$0, 3644(%rsp,%rax)
	movw	$0, 3646(%rsp,%rax)
	movw	$0, 3648(%rsp,%rax)
	movw	$0, 3650(%rsp,%rax)
	movw	$0, 3652(%rsp,%rax)
	movw	$0, 3654(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_85
	#MEMBARRIER
	movq	%r14, %rax
	addq	$7224, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB66_87:
	.cfi_def_cfa_offset 7280
.Ltmp373:
	movq	%rax, %rdi
	xorl	%eax, %eax
	.p2align	4
.LBB66_88:
	movw	$0, 56(%rsp,%rax)
	movw	$0, 58(%rsp,%rax)
	movw	$0, 60(%rsp,%rax)
	movw	$0, 62(%rsp,%rax)
	movw	$0, 64(%rsp,%rax)
	movw	$0, 66(%rsp,%rax)
	movw	$0, 68(%rsp,%rax)
	movw	$0, 70(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_88
	jmp	.LBB66_103
.LBB66_90:
.Ltmp370:
	jmp	.LBB66_100
.LBB66_91:
.Ltmp358:
	movq	%rax, %rdi
	xorl	%eax, %eax
	.p2align	4
.LBB66_92:
	movw	$0, 4664(%rsp,%rax)
	movw	$0, 4666(%rsp,%rax)
	movw	$0, 4668(%rsp,%rax)
	movw	$0, 4670(%rsp,%rax)
	movw	$0, 4672(%rsp,%rax)
	movw	$0, 4674(%rsp,%rax)
	movw	$0, 4676(%rsp,%rax)
	movw	$0, 4678(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_92
	#MEMBARRIER
	testb	%r14b, %r14b
	jne	.LBB66_111
	xorl	%eax, %eax
	.p2align	4
.LBB66_95:
	movw	$0, 5176(%rsp,%rax)
	movw	$0, 5178(%rsp,%rax)
	movw	$0, 5180(%rsp,%rax)
	movw	$0, 5182(%rsp,%rax)
	movw	$0, 5184(%rsp,%rax)
	movw	$0, 5186(%rsp,%rax)
	movw	$0, 5188(%rsp,%rax)
	movw	$0, 5190(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_95
	jmp	.LBB66_110
.LBB66_96:
.Ltmp367:
	movq	%rax, %rdi
	xorl	%eax, %eax
	.p2align	4
.LBB66_97:
	movw	$0, 56(%rsp,%rax)
	movw	$0, 58(%rsp,%rax)
	movw	$0, 60(%rsp,%rax)
	movw	$0, 62(%rsp,%rax)
	movw	$0, 64(%rsp,%rax)
	movw	$0, 66(%rsp,%rax)
	movw	$0, 68(%rsp,%rax)
	movw	$0, 70(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_97
	jmp	.LBB66_103
.LBB66_99:
.Ltmp364:
.LBB66_100:
	movq	%rax, %rdi
	jmp	.LBB66_104
.LBB66_101:
.Ltmp361:
	movq	%rax, %rdi
	xorl	%eax, %eax
	.p2align	4
.LBB66_102:
	movw	$0, 1592(%rsp,%rax)
	movw	$0, 1594(%rsp,%rax)
	movw	$0, 1596(%rsp,%rax)
	movw	$0, 1598(%rsp,%rax)
	movw	$0, 1600(%rsp,%rax)
	movw	$0, 1602(%rsp,%rax)
	movw	$0, 1604(%rsp,%rax)
	movw	$0, 1606(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_102
.LBB66_103:
	#MEMBARRIER
.LBB66_104:
	xorl	%eax, %eax
	.p2align	4
.LBB66_105:
	movw	$0, 2616(%rsp,%rax)
	movw	$0, 2618(%rsp,%rax)
	movw	$0, 2620(%rsp,%rax)
	movw	$0, 2622(%rsp,%rax)
	movw	$0, 2624(%rsp,%rax)
	movw	$0, 2626(%rsp,%rax)
	movw	$0, 2628(%rsp,%rax)
	movw	$0, 2630(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_105
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_107:
	movw	$0, 3128(%rsp,%rax)
	movw	$0, 3130(%rsp,%rax)
	movw	$0, 3132(%rsp,%rax)
	movw	$0, 3134(%rsp,%rax)
	movw	$0, 3136(%rsp,%rax)
	movw	$0, 3138(%rsp,%rax)
	movw	$0, 3140(%rsp,%rax)
	movw	$0, 3142(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_107
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB66_109:
	movw	$0, 3640(%rsp,%rax)
	movw	$0, 3642(%rsp,%rax)
	movw	$0, 3644(%rsp,%rax)
	movw	$0, 3646(%rsp,%rax)
	movw	$0, 3648(%rsp,%rax)
	movw	$0, 3650(%rsp,%rax)
	movw	$0, 3652(%rsp,%rax)
	movw	$0, 3654(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB66_109
.LBB66_110:
	#MEMBARRIER
.LBB66_111:
	callq	_Unwind_Resume@PLT
.Lfunc_end66:
	.size	_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt, .Lfunc_end66-_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt
	.cfi_endproc
	.section	.gcc_except_table._RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt,"a",@progbits
	.p2align	2, 0x0
GCC_except_table66:
.Lexception29:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end29-.Lcst_begin29
.Lcst_begin29:
	.uleb128 .Lfunc_begin29-.Lfunc_begin29
	.uleb128 .Ltmp350-.Lfunc_begin29
	.byte	0
	.byte	0
	.uleb128 .Ltmp350-.Lfunc_begin29
	.uleb128 .Ltmp353-.Ltmp350
	.uleb128 .Ltmp358-.Lfunc_begin29
	.byte	0
	.uleb128 .Ltmp353-.Lfunc_begin29
	.uleb128 .Ltmp354-.Ltmp353
	.byte	0
	.byte	0
	.uleb128 .Ltmp354-.Lfunc_begin29
	.uleb128 .Ltmp357-.Ltmp354
	.uleb128 .Ltmp358-.Lfunc_begin29
	.byte	0
	.uleb128 .Ltmp357-.Lfunc_begin29
	.uleb128 .Ltmp359-.Ltmp357
	.byte	0
	.byte	0
	.uleb128 .Ltmp359-.Lfunc_begin29
	.uleb128 .Ltmp360-.Ltmp359
	.uleb128 .Ltmp361-.Lfunc_begin29
	.byte	0
	.uleb128 .Ltmp360-.Lfunc_begin29
	.uleb128 .Ltmp362-.Ltmp360
	.byte	0
	.byte	0
	.uleb128 .Ltmp362-.Lfunc_begin29
	.uleb128 .Ltmp363-.Ltmp362
	.uleb128 .Ltmp364-.Lfunc_begin29
	.byte	0
	.uleb128 .Ltmp365-.Lfunc_begin29
	.uleb128 .Ltmp366-.Ltmp365
	.uleb128 .Ltmp367-.Lfunc_begin29
	.byte	0
	.uleb128 .Ltmp366-.Lfunc_begin29
	.uleb128 .Ltmp368-.Ltmp366
	.byte	0
	.byte	0
	.uleb128 .Ltmp368-.Lfunc_begin29
	.uleb128 .Ltmp369-.Ltmp368
	.uleb128 .Ltmp370-.Lfunc_begin29
	.byte	0
	.uleb128 .Ltmp371-.Lfunc_begin29
	.uleb128 .Ltmp372-.Ltmp371
	.uleb128 .Ltmp373-.Lfunc_begin29
	.byte	0
	.uleb128 .Ltmp372-.Lfunc_begin29
	.uleb128 .Lfunc_end66-.Ltmp372
	.byte	0
	.byte	0
.Lcst_end29:
	.p2align	2, 0x0

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI67_0:
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
.LCPI67_1:
	.long	512
	.long	512
	.long	512
	.long	512
.LCPI67_2:
	.long	1290168
	.long	1290168
	.long	1290168
	.long	1290168
.LCPI67_3:
	.long	3329
	.long	3329
	.long	3329
	.long	3329
.LCPI67_4:
	.long	8
	.long	8
	.long	8
	.long	8
.LCPI67_5:
	.long	989558401
	.long	989558401
	.long	989558401
	.long	989558401
.LCPI67_6:
	.long	1664
	.long	1664
	.long	1664
	.long	1664
.LCPI67_7:
	.short	1
	.short	1
	.short	1
	.short	1
	.short	1
	.short	1
	.short	1
	.short	1
	.section	.text._RNvMs2_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate,"ax",@progbits
	.globl	_RNvMs2_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate
	.p2align	4
	.type	_RNvMs2_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate,@function
_RNvMs2_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate:
.Lfunc_begin30:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception30
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$3304, %rsp
	.cfi_def_cfa_offset 3360
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rbx
	cmpq	$1088, %rcx
	jne	.LBB67_44
	movq	%rdx, 64(%rsp)
	movq	%rdi, 72(%rsp)
	leaq	2280(%rsp), %rdi
	xorl	%r14d, %r14d
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	leaq	1192(%rsp), %rbp
	movl	$2642262849, %r12d
	xorl	%eax, %eax
	.p2align	4
.LBB67_2:
	leaq	(%rbx,%r14), %r15
	addq	$512, %r14
	leaq	(%rax,%rax,4), %r13
	incq	%rax
	movq	%rax, 80(%rsp)
	shlq	$6, %r13
	addq	64(%rsp), %r13
	movl	$512, %edx
	movq	%rbp, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	xorl	%edx, %edx
	.p2align	4
.LBB67_3:
	movq	%rdx, %rax
	shrq	$3, %rax
	movzbl	(%r13,%rax), %r8d
	movl	%edx, %eax
	andb	$6, %al
	movzbl	%al, %edi
	xorl	%eax, %eax
	btl	%edi, %r8d
	setb	%al
	orw	(%rbp), %ax
	leal	1(%rdi), %ecx
	shrl	%cl, %r8d
	leaq	2(%rdx), %rcx
	movq	%rcx, %r9
	shrq	$3, %r9
	movzbl	(%r13,%r9), %r9d
	andb	$6, %cl
	shrl	%cl, %r9d
	addl	%r8d, %r8d
	andl	$2, %r8d
	shll	$2, %r9d
	leaq	3(%rdx), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movzbl	(%r13,%r10), %r10d
	andb	$7, %cl
	shrl	%cl, %r10d
	andl	$4, %r9d
	orl	%r8d, %r9d
	shll	$3, %r10d
	leaq	4(%rdx), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%r13,%r8), %r8d
	andb	$6, %cl
	shrl	%cl, %r8d
	andl	$8, %r10d
	orl	%r9d, %r10d
	shll	$4, %r8d
	andl	$16, %r8d
	orl	%r10d, %r8d
	orl	%eax, %r8d
	leaq	5(%rdx), %rcx
	movq	%rcx, %rax
	shrq	$3, %rax
	movzbl	(%r13,%rax), %r9d
	andb	$7, %cl
	shrl	%cl, %r9d
	leaq	6(%rdx), %rcx
	leaq	7(%rdx), %rax
	movq	%rax, %r10
	shrq	$3, %r10
	movzbl	(%r13,%r10), %r10d
	movq	%rcx, %r11
	shrq	$3, %r11
	movzbl	(%r13,%r11), %r11d
	andb	$6, %cl
	shrl	%cl, %r11d
	shll	$5, %r9d
	andl	$32, %r9d
	shll	$6, %r11d
	andb	$7, %al
	movl	%eax, %ecx
	shrb	%cl, %r10b
	andl	$64, %r11d
	orl	%r9d, %r11d
	shlb	$7, %r10b
	movzbl	%r10b, %eax
	orl	%r11d, %eax
	leaq	8(%rdx), %rcx
	shrq	$3, %rcx
	movzbl	(%r13,%rcx), %ecx
	xorl	%r9d, %r9d
	btl	%edi, %ecx
	setb	%r9b
	shll	$8, %r9d
	orl	%eax, %r9d
	leaq	9(%rdx), %rax
	movq	%rax, %rcx
	shrq	$3, %rcx
	movzbl	(%r13,%rcx), %ecx
	andl	$7, %eax
	xorl	%edi, %edi
	btl	%eax, %ecx
	setb	%dil
	shll	$9, %edi
	orl	%r9d, %edi
	orl	%r8d, %edi
	movw	%di, (%rbp)
	addq	$2, %rbp
	addq	$10, %rdx
	cmpq	$2560, %rdx
	jne	.LBB67_3
	movq	%r14, 88(%rsp)
	movl	$512, %edx
	leaq	96(%rsp), %rdi
	leaq	1192(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r13
	callq	*%r13
	xorl	%eax, %eax
	movdqa	.LCPI67_0(%rip), %xmm3
	movdqa	.LCPI67_1(%rip), %xmm4
	.p2align	4
.LBB67_5:
	movdqu	96(%rsp,%rax,2), %xmm0
	movdqa	%xmm0, %xmm1
	pmulhuw	%xmm3, %xmm1
	pmullw	%xmm3, %xmm0
	movdqa	%xmm0, %xmm2
	punpckhwd	%xmm1, %xmm2
	punpcklwd	%xmm1, %xmm0
	paddd	%xmm4, %xmm0
	paddd	%xmm4, %xmm2
	pslld	$6, %xmm2
	psrad	$16, %xmm2
	pslld	$6, %xmm0
	psrad	$16, %xmm0
	packssdw	%xmm2, %xmm0
	movdqu	%xmm0, 96(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB67_5
	movl	$512, %edx
	leaq	1192(%rsp), %rbp
	movq	%rbp, %rdi
	leaq	96(%rsp), %r14
	movq	%r14, %rsi
	callq	*%r13
.Ltmp374:
	movq	%r14, %rdi
	movq	%rbp, %rsi
	callq	*_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt@GOTPCREL(%rip)
.Ltmp375:
	movl	$512, %edx
	movq	%rbp, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	xorl	%eax, %eax
	movq	88(%rsp), %r14
	jmp	.LBB67_8
	.p2align	4
.LBB67_12:
	movzwl	(%r15,%rax,4), %r8d
	movzwl	96(%rsp,%rax,4), %edx
	movzwl	2(%r15,%rax,4), %edi
	movzwl	98(%rsp,%rax,4), %esi
	movl	%edx, %r9d
	imull	%r8d, %r9d
	imulq	$989558401, %r9, %r10
	shrq	$32, %r10
	movl	%r9d, %r11d
	subl	%r10d, %r11d
	shrl	%r11d
	addl	%r10d, %r11d
	shrl	$11, %r11d
	imull	$3329, %r11d, %r10d
	subl	%r10d, %r9d
	movl	%esi, %r10d
	imull	%edi, %r10d
	imulq	$989558401, %r10, %r11
	shrq	$32, %r11
	movl	%r10d, %r13d
	subl	%r11d, %r13d
	shrl	%r13d
	addl	%r11d, %r13d
	shrl	$11, %r13d
	imull	$3329, %r13d, %r11d
	subl	%r11d, %r10d
	movzwl	%cx, %ecx
	imull	%r10d, %ecx
	imulq	$330282857, %rcx, %r10
	shrq	$40, %r10
	imull	$3329, %r10d, %r10d
	subl	%r10d, %ecx
	addl	%r9d, %ecx
	leal	-3329(%rcx), %r9d
	cmpl	$3329, %ecx
	cmovbl	%ecx, %r9d
	movw	%r9w, 1192(%rsp,%rax,4)
	imull	%r8d, %esi
	imulq	$989558401, %rsi, %rcx
	shrq	$32, %rcx
	movl	%esi, %r8d
	subl	%ecx, %r8d
	shrl	%r8d
	addl	%ecx, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %ecx
	subl	%ecx, %esi
	imull	%edi, %edx
	imulq	$989558401, %rdx, %rcx
	shrq	$32, %rcx
	movl	%edx, %edi
	subl	%ecx, %edi
	shrl	%edi
	addl	%ecx, %edi
	shrl	$11, %edi
	imull	$3329, %edi, %ecx
	subl	%ecx, %edx
	leal	(%rsi,%rdx), %ecx
	cmpl	$3329, %ecx
	leal	-3329(%rsi,%rdx), %edx
	cmovbl	%ecx, %edx
	movw	%dx, 1194(%rsp,%rax,4)
	incq	%rax
	cmpq	$128, %rax
	je	.LBB67_13
.LBB67_8:
	movl	%eax, %ecx
	rolb	$4, %cl
	orb	$8, %cl
	movl	%ecx, %edx
	andb	$51, %dl
	shlb	$2, %dl
	shrb	$2, %cl
	andb	$51, %cl
	orb	%dl, %cl
	movl	%ecx, %edx
	andb	$85, %dl
	addb	%dl, %dl
	shrb	%cl
	andb	$85, %cl
	orb	%dl, %cl
	movzbl	%cl, %edx
	movw	$1, %cx
	movw	$17, %si
	jmp	.LBB67_9
	.p2align	4
.LBB67_11:
	imull	%esi, %esi
	movq	%rsi, %rdi
	imulq	%r12, %rdi
	shrq	$43, %rdi
	imull	$3329, %edi, %edi
	subl	%edi, %esi
	shrl	%edx
	je	.LBB67_12
.LBB67_9:
	movzwl	%si, %esi
	testb	$1, %dl
	je	.LBB67_11
	movzwl	%cx, %ecx
	imull	%esi, %ecx
	imulq	$989558401, %rcx, %rdi
	shrq	$32, %rdi
	movl	%ecx, %r8d
	subl	%edi, %r8d
	shrl	%r8d
	addl	%edi, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %edi
	subl	%edi, %ecx
	jmp	.LBB67_11
	.p2align	4
.LBB67_13:
	movl	$512, %edx
	leaq	672(%rsp), %rdi
	leaq	1192(%rsp), %rbp
	movq	%rbp, %rsi
	movq	memcpy@GOTPCREL(%rip), %r15
	callq	*%r15
	xorl	%eax, %eax
	movdqa	.LCPI67_2(%rip), %xmm4
	movdqa	.LCPI67_3(%rip), %xmm5
	pxor	%xmm6, %xmm6
	.p2align	4
.LBB67_14:
	movdqu	2280(%rsp,%rax,2), %xmm2
	movdqu	672(%rsp,%rax,2), %xmm0
	movdqa	%xmm2, %xmm3
	punpckhwd	%xmm6, %xmm3
	punpcklwd	%xmm6, %xmm2
	movdqa	%xmm0, %xmm1
	punpckhwd	%xmm6, %xmm1
	paddd	%xmm3, %xmm1
	punpcklwd	%xmm6, %xmm0
	paddd	%xmm2, %xmm0
	movdqa	%xmm1, %xmm2
	pmuludq	%xmm4, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pshufd	$245, %xmm1, %xmm3
	pmuludq	%xmm4, %xmm3
	pshufd	$237, %xmm3, %xmm3
	punpckldq	%xmm3, %xmm2
	pmaddwd	%xmm5, %xmm2
	psubd	%xmm2, %xmm1
	movdqa	%xmm0, %xmm2
	pmuludq	%xmm4, %xmm2
	pshufd	$237, %xmm2, %xmm2
	pshufd	$245, %xmm0, %xmm3
	pmuludq	%xmm4, %xmm3
	pshufd	$237, %xmm3, %xmm3
	punpckldq	%xmm3, %xmm2
	pmaddwd	%xmm5, %xmm2
	psubd	%xmm2, %xmm0
	packssdw	%xmm1, %xmm0
	movdqu	%xmm0, 1192(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB67_14
	movl	$512, %edx
	leaq	2792(%rsp), %r13
	movq	%r13, %rdi
	movq	%rbp, %rsi
	callq	*%r15
	movl	$14, %eax
	.p2align	4
.LBB67_16:
	movw	$0, 2266(%rsp,%rax)
	movw	$0, 2268(%rsp,%rax)
	movw	$0, 2270(%rsp,%rax)
	movw	$0, 2272(%rsp,%rax)
	movw	$0, 2274(%rsp,%rax)
	movw	$0, 2276(%rsp,%rax)
	movw	$0, 2278(%rsp,%rax)
	movw	$0, 2280(%rsp,%rax)
	addq	$16, %rax
	cmpq	$526, %rax
	jne	.LBB67_16
	#MEMBARRIER
	movl	$512, %edx
	leaq	2280(%rsp), %rdi
	movq	%r13, %rsi
	callq	*%r15
	xorl	%eax, %eax
	.p2align	4
.LBB67_18:
	movw	$0, 672(%rsp,%rax)
	movw	$0, 674(%rsp,%rax)
	movw	$0, 676(%rsp,%rax)
	movw	$0, 678(%rsp,%rax)
	movw	$0, 680(%rsp,%rax)
	movw	$0, 682(%rsp,%rax)
	movw	$0, 684(%rsp,%rax)
	movw	$0, 686(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_18
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB67_20:
	movw	$0, 96(%rsp,%rax)
	movw	$0, 98(%rsp,%rax)
	movw	$0, 100(%rsp,%rax)
	movw	$0, 102(%rsp,%rax)
	movw	$0, 104(%rsp,%rax)
	movw	$0, 106(%rsp,%rax)
	movw	$0, 108(%rsp,%rax)
	movw	$0, 110(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_20
	#MEMBARRIER
	cmpq	$1536, %r14
	movq	80(%rsp), %rax
	jne	.LBB67_2
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, 640(%rsp)
	movdqa	%xmm0, 656(%rsp)
	movdqa	%xmm0, (%rsp)
	movdqa	%xmm0, 16(%rsp)
	leaq	1192(%rsp), %rdi
	xorl	%r14d, %r14d
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	xorl	%edx, %edx
	movq	64(%rsp), %r13
	.p2align	4
.LBB67_23:
	movq	%rdx, %rax
	shrq	%rax
	movzbl	960(%r13,%rax), %esi
	movl	%r14d, %eax
	andb	$4, %al
	movzbl	%al, %eax
	xorl	%edi, %edi
	btl	%eax, %esi
	setb	%dil
	orw	1192(%rsp,%rdx,2), %di
	leal	1(%rax), %ecx
	movl	%esi, %r8d
	shrl	%cl, %r8d
	addl	%r8d, %r8d
	andl	$2, %r8d
	leal	2(%rax), %ecx
	movl	%esi, %r9d
	shrl	%cl, %r9d
	shll	$2, %r9d
	andl	$4, %r9d
	orl	%r8d, %r9d
	orb	$3, %al
	movl	%eax, %ecx
	shrl	%cl, %esi
	shll	$3, %esi
	andl	$8, %esi
	orl	%r9d, %esi
	orl	%edi, %esi
	movw	%si, 1192(%rsp,%rdx,2)
	incq	%rdx
	addb	$4, %r14b
	cmpq	$256, %rdx
	jne	.LBB67_23
	leaq	96(%rsp), %rdi
	leaq	1192(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	xorl	%eax, %eax
	movdqa	.LCPI67_4(%rip), %xmm0
	movdqa	.LCPI67_0(%rip), %xmm4
	.p2align	4
.LBB67_25:
	movdqu	96(%rsp,%rax,2), %xmm1
	movdqa	%xmm1, %xmm2
	pmulhuw	%xmm4, %xmm2
	pmullw	%xmm4, %xmm1
	movdqa	%xmm1, %xmm3
	punpckhwd	%xmm2, %xmm3
	punpcklwd	%xmm2, %xmm1
	paddd	%xmm0, %xmm1
	paddd	%xmm0, %xmm3
	pslld	$12, %xmm3
	psrad	$16, %xmm3
	pslld	$12, %xmm1
	psrad	$16, %xmm1
	packssdw	%xmm3, %xmm1
	movdqu	%xmm1, 96(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB67_25
	leaq	672(%rsp), %rdi
	leaq	96(%rsp), %rsi
	movl	$512, %edx
	movq	memcpy@GOTPCREL(%rip), %r15
	callq	*%r15
	leaq	1192(%rsp), %r14
	leaq	2280(%rsp), %rsi
	movl	$512, %edx
	movq	%r14, %rdi
	callq	*%r15
.Ltmp377:
	leaq	96(%rsp), %rdi
	movq	%r14, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse
.Ltmp378:
	xorl	%eax, %eax
	pxor	%xmm0, %xmm0
	movdqa	.LCPI67_5(%rip), %xmm1
	movdqa	.LCPI67_3(%rip), %xmm6
	.p2align	4
.LBB67_28:
	movdqu	672(%rsp,%rax,2), %xmm2
	movdqu	96(%rsp,%rax,2), %xmm4
	movdqa	%xmm2, %xmm3
	punpckhwd	%xmm0, %xmm3
	punpcklwd	%xmm0, %xmm2
	movdqa	%xmm4, %xmm5
	punpckhwd	%xmm0, %xmm5
	psubd	%xmm5, %xmm3
	punpcklwd	%xmm0, %xmm4
	psubd	%xmm4, %xmm2
	paddd	%xmm6, %xmm2
	paddd	%xmm6, %xmm3
	movdqa	%xmm3, %xmm4
	pmuludq	%xmm1, %xmm4
	pshufd	$237, %xmm4, %xmm4
	pshufd	$245, %xmm3, %xmm5
	pmuludq	%xmm1, %xmm5
	pshufd	$237, %xmm5, %xmm5
	punpckldq	%xmm5, %xmm4
	movdqa	%xmm3, %xmm5
	psubd	%xmm4, %xmm5
	psrld	$1, %xmm5
	paddd	%xmm4, %xmm5
	psrld	$11, %xmm5
	pshufd	$245, %xmm5, %xmm4
	pmuludq	%xmm6, %xmm5
	pshufd	$232, %xmm5, %xmm5
	pmuludq	%xmm6, %xmm4
	pshufd	$232, %xmm4, %xmm4
	punpckldq	%xmm4, %xmm5
	psubd	%xmm5, %xmm3
	movdqa	%xmm2, %xmm4
	pmuludq	%xmm1, %xmm4
	pshufd	$237, %xmm4, %xmm4
	pshufd	$245, %xmm2, %xmm5
	pmuludq	%xmm1, %xmm5
	pshufd	$237, %xmm5, %xmm5
	punpckldq	%xmm5, %xmm4
	movdqa	%xmm2, %xmm5
	psubd	%xmm4, %xmm5
	psrld	$1, %xmm5
	paddd	%xmm4, %xmm5
	psrld	$11, %xmm5
	pshufd	$245, %xmm5, %xmm4
	pmuludq	%xmm6, %xmm5
	pshufd	$232, %xmm5, %xmm5
	pmuludq	%xmm6, %xmm4
	pshufd	$232, %xmm4, %xmm4
	punpckldq	%xmm4, %xmm5
	psubd	%xmm5, %xmm2
	packssdw	%xmm3, %xmm2
	movdqu	%xmm2, 1192(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB67_28
	leaq	2792(%rsp), %rdi
	leaq	1192(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	xorl	%eax, %eax
	pxor	%xmm0, %xmm0
	movdqa	.LCPI67_6(%rip), %xmm1
	movdqa	.LCPI67_7(%rip), %xmm2
	movdqa	.LCPI67_2(%rip), %xmm6
	.p2align	4
.LBB67_30:
	movdqu	2792(%rsp,%rax,2), %xmm3
	movdqa	%xmm3, %xmm4
	punpcklwd	%xmm0, %xmm4
	punpckhwd	%xmm0, %xmm3
	paddd	%xmm3, %xmm3
	paddd	%xmm4, %xmm4
	paddd	%xmm1, %xmm4
	paddd	%xmm1, %xmm3
	pshufd	$245, %xmm3, %xmm5
	pmuludq	%xmm6, %xmm3
	pshufd	$237, %xmm3, %xmm3
	pmuludq	%xmm6, %xmm5
	pshufd	$237, %xmm5, %xmm5
	punpckldq	%xmm5, %xmm3
	pshufd	$245, %xmm4, %xmm5
	pmuludq	%xmm6, %xmm4
	pshufd	$237, %xmm4, %xmm4
	pmuludq	%xmm6, %xmm5
	pshufd	$237, %xmm5, %xmm5
	punpckldq	%xmm5, %xmm4
	packuswb	%xmm3, %xmm4
	pand	%xmm2, %xmm4
	movdqu	%xmm4, 2792(%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB67_30
	leaq	1192(%rsp), %rdi
	leaq	2792(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, (%rsp)
	movdqa	%xmm0, 16(%rsp)
	xorl	%edx, %edx
	xorl	%eax, %eax
	.p2align	4
.LBB67_32:
	movzbl	1192(%rsp,%rdx,2), %esi
	movzbl	1194(%rsp,%rdx,2), %edi
	andb	$1, %sil
	movl	%edx, %ecx
	andb	$6, %cl
	shlb	%cl, %sil
	movq	%rdx, %r8
	shrq	$3, %r8
	orb	(%rsp,%r8), %sil
	leal	1(%rdx), %ecx
	addq	$2, %rax
	andb	$1, %dil
	andb	$7, %cl
	shlb	%cl, %dil
	orb	%sil, %dil
	movb	%dil, (%rsp,%r8)
	movq	%rax, %rdx
	cmpq	$256, %rax
	jne	.LBB67_32
	xorl	%eax, %eax
	.p2align	4
.LBB67_34:
	movw	$0, 1192(%rsp,%rax)
	movw	$0, 1194(%rsp,%rax)
	movw	$0, 1196(%rsp,%rax)
	movw	$0, 1198(%rsp,%rax)
	movw	$0, 1200(%rsp,%rax)
	movw	$0, 1202(%rsp,%rax)
	movw	$0, 1204(%rsp,%rax)
	movw	$0, 1206(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_34
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB67_36:
	movw	$0, 96(%rsp,%rax)
	movw	$0, 98(%rsp,%rax)
	movw	$0, 100(%rsp,%rax)
	movw	$0, 102(%rsp,%rax)
	movw	$0, 104(%rsp,%rax)
	movw	$0, 106(%rsp,%rax)
	movw	$0, 108(%rsp,%rax)
	movw	$0, 110(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_36
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB67_38:
	movw	$0, 672(%rsp,%rax)
	movw	$0, 674(%rsp,%rax)
	movw	$0, 676(%rsp,%rax)
	movw	$0, 678(%rsp,%rax)
	movw	$0, 680(%rsp,%rax)
	movw	$0, 682(%rsp,%rax)
	movw	$0, 684(%rsp,%rax)
	movw	$0, 686(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_38
	#MEMBARRIER
	leaq	2720(%rbx), %rax
	movq	%rsp, %rcx
	movq	%rcx, 672(%rsp)
	movq	$32, 680(%rsp)
	movq	%rax, 688(%rsp)
	movq	$32, 696(%rsp)
.Ltmp380:
	leaq	1192(%rsp), %rdi
	leaq	672(%rsp), %rsi
	movl	$2, %edx
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1g@GOTPCREL(%rip)
.Ltmp381:
	movdqu	1192(%rsp), %xmm0
	movdqu	1208(%rsp), %xmm1
	movdqu	1224(%rsp), %xmm2
	movdqu	1240(%rsp), %xmm3
	movdqa	%xmm3, 144(%rsp)
	movdqa	%xmm2, 128(%rsp)
	movdqa	%xmm1, 112(%rsp)
	movdqa	%xmm0, 96(%rsp)
	leaq	2752(%rbx), %r15
	movq	%r15, 2792(%rsp)
	movq	$32, 2800(%rsp)
	movq	%r13, 2808(%rsp)
	movq	$1088, 2816(%rsp)
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, 688(%rsp)
	movdqa	%xmm0, 672(%rsp)
.Ltmp383:
	leaq	1192(%rsp), %rdi
	leaq	2792(%rsp), %rcx
	movl	$136, %esi
	movl	$2, %r8d
	movl	$31, %edx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new
.Ltmp384:
	movq	1400(%rsp), %rax
	xorl	%r12d, %r12d
	leaq	1192(%rsp), %r14
	jmp	.LBB67_42
	.p2align	4
.LBB67_43:
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 1400(%rsp)
	xorl	%edi, %edi
	xorl	%eax, %eax
.LBB67_57:
	leaq	(%rsp,%rdi,8), %rcx
	addq	$1192, %rcx
	movl	%eax, %edx
	andl	$7, %edx
	movzbl	(%rdx,%rcx), %ecx
	movb	%cl, 672(%rsp,%r12)
	incq	%r12
	incq	%rax
	movq	%rax, 1400(%rsp)
	cmpq	$32, %r12
	je	.LBB67_58
.LBB67_42:
	cmpq	1392(%rsp), %rax
	je	.LBB67_43
	movq	%rax, %rdi
	shrq	$3, %rdi
	cmpq	$199, %rax
	jbe	.LBB67_57
.Ltmp386:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.71(%rip), %rdx
	movl	$25, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp387:
	ud2
.LBB67_44:
	movw	$1, (%rdi)
	xorl	%eax, %eax
	.p2align	4
.LBB67_45:
	movw	$0, (%rbx,%rax)
	movw	$0, 2(%rbx,%rax)
	movw	$0, 4(%rbx,%rax)
	movw	$0, 6(%rbx,%rax)
	movw	$0, 8(%rbx,%rax)
	movw	$0, 10(%rbx,%rax)
	movw	$0, 12(%rbx,%rax)
	movw	$0, 14(%rbx,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_45
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB67_47:
	movw	$0, 512(%rbx,%rax)
	movw	$0, 514(%rbx,%rax)
	movw	$0, 516(%rbx,%rax)
	movw	$0, 518(%rbx,%rax)
	movw	$0, 520(%rbx,%rax)
	movw	$0, 522(%rbx,%rax)
	movw	$0, 524(%rbx,%rax)
	movw	$0, 526(%rbx,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_47
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB67_49:
	movw	$0, 1024(%rbx,%rax)
	movw	$0, 1026(%rbx,%rax)
	movw	$0, 1028(%rbx,%rax)
	movw	$0, 1030(%rbx,%rax)
	movw	$0, 1032(%rbx,%rax)
	movw	$0, 1034(%rbx,%rax)
	movw	$0, 1036(%rbx,%rax)
	movw	$0, 1038(%rbx,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_49
	#MEMBARRIER
	movb	$0, 2752(%rbx)
	jmp	.LBB67_51
.LBB67_58:
	movq	$0, 1192(%rsp)
	movq	$0, 1200(%rsp)
	movq	$0, 1208(%rsp)
	movq	$0, 1216(%rsp)
	movq	$0, 1224(%rsp)
	movq	$0, 1232(%rsp)
	movq	$0, 1240(%rsp)
	movq	$0, 1248(%rsp)
	movq	$0, 1256(%rsp)
	movq	$0, 1264(%rsp)
	movq	$0, 1272(%rsp)
	movq	$0, 1280(%rsp)
	movq	$0, 1288(%rsp)
	movq	$0, 1296(%rsp)
	movq	$0, 1304(%rsp)
	movq	$0, 1312(%rsp)
	movq	$0, 1320(%rsp)
	movq	$0, 1328(%rsp)
	movq	$0, 1336(%rsp)
	movq	$0, 1344(%rsp)
	movq	$0, 1352(%rsp)
	movq	$0, 1360(%rsp)
	movq	$0, 1368(%rsp)
	movq	$0, 1376(%rsp)
	movq	$0, 1384(%rsp)
	#MEMBARRIER
	movdqa	672(%rsp), %xmm0
	movdqa	688(%rsp), %xmm1
	movdqa	%xmm0, 32(%rsp)
	movdqa	%xmm1, 48(%rsp)
	leaq	128(%rsp), %rcx
.Ltmp389:
	leaq	1192(%rsp), %rdi
	movq	%rsp, %rdx
	leaq	1536(%rbx), %rsi
	callq	*_RNvMs1_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt@GOTPCREL(%rip)
.Ltmp390:
	pxor	%xmm0, %xmm0
	movl	$6, %eax
	pxor	%xmm2, %xmm2
	pxor	%xmm1, %xmm1
	.p2align	4
.LBB67_60:
	movzwl	1186(%rsp,%rax), %ecx
	movzwl	1188(%rsp,%rax), %edx
	xorw	-6(%r13,%rax), %cx
	xorw	-4(%r13,%rax), %dx
	movd	%ecx, %xmm4
	movd	%edx, %xmm3
	punpcklbw	%xmm0, %xmm4
	punpcklwd	%xmm0, %xmm4
	punpckldq	%xmm0, %xmm4
	por	%xmm2, %xmm4
	punpcklbw	%xmm0, %xmm3
	punpcklwd	%xmm0, %xmm3
	punpckldq	%xmm0, %xmm3
	por	%xmm1, %xmm3
	movzwl	1190(%rsp,%rax), %ecx
	movzwl	1192(%rsp,%rax), %edx
	xorw	-2(%r13,%rax), %cx
	xorw	(%r13,%rax), %dx
	movd	%ecx, %xmm2
	movd	%edx, %xmm1
	punpcklbw	%xmm0, %xmm2
	punpcklwd	%xmm0, %xmm2
	punpckldq	%xmm0, %xmm2
	por	%xmm4, %xmm2
	punpcklbw	%xmm0, %xmm1
	punpcklwd	%xmm0, %xmm1
	punpckldq	%xmm0, %xmm1
	por	%xmm3, %xmm1
	addq	$8, %rax
	cmpq	$1094, %rax
	jne	.LBB67_60
	por	%xmm2, %xmm1
	pshufd	$238, %xmm1, %xmm0
	por	%xmm1, %xmm0
	movq	%xmm0, %rcx
	movl	$7, %eax
	.p2align	4
.LBB67_62:
	movb	$0, 1185(%rsp,%rax)
	movb	$0, 1186(%rsp,%rax)
	movb	$0, 1187(%rsp,%rax)
	movb	$0, 1188(%rsp,%rax)
	movb	$0, 1189(%rsp,%rax)
	movb	$0, 1190(%rsp,%rax)
	movb	$0, 1191(%rsp,%rax)
	movb	$0, 1192(%rsp,%rax)
	addq	$8, %rax
	cmpq	$1095, %rax
	jne	.LBB67_62
	#MEMBARRIER
	xorl	%eax, %eax
	testq	%rcx, %rcx
	setne	%al
	movaps	640(%rsp), %xmm0
	movaps	656(%rsp), %xmm1
	movaps	%xmm1, 624(%rsp)
	movaps	%xmm0, 608(%rsp)
	movl	$1, %ecx
	.p2align	4
.LBB67_64:
	movzbl	95(%rsp,%rcx), %edx
	movzbl	31(%rsp,%rcx), %esi
	movq	%rax, 672(%rsp)
	movq	672(%rsp), %rdi
	movl	%edi, %r8d
	negl	%r8d
	andl	%esi, %r8d
	decl	%edi
	andl	%edx, %edi
	orl	%r8d, %edi
	movb	%dil, 607(%rsp,%rcx)
	movzbl	96(%rsp,%rcx), %edx
	movzbl	32(%rsp,%rcx), %esi
	movq	%rax, 672(%rsp)
	movq	672(%rsp), %rdi
	movl	%edi, %r8d
	negl	%r8d
	andl	%esi, %r8d
	decl	%edi
	andl	%edx, %edi
	orl	%r8d, %edi
	movb	%dil, 608(%rsp,%rcx)
	addq	$2, %rcx
	cmpq	$33, %rcx
	jne	.LBB67_64
	movaps	608(%rsp), %xmm0
	movaps	624(%rsp), %xmm1
	movq	72(%rsp), %rdi
	movups	%xmm1, 17(%rdi)
	movups	%xmm0, 1(%rdi)
	movb	$0, (%rdi)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	movb	$0, 96(%rsp)
	movb	$0, 97(%rsp)
	movb	$0, 98(%rsp)
	movb	$0, 99(%rsp)
	movb	$0, 100(%rsp)
	movb	$0, 101(%rsp)
	movb	$0, 102(%rsp)
	movb	$0, 103(%rsp)
	movb	$0, 104(%rsp)
	movb	$0, 105(%rsp)
	movb	$0, 106(%rsp)
	movb	$0, 107(%rsp)
	movb	$0, 108(%rsp)
	movb	$0, 109(%rsp)
	movb	$0, 110(%rsp)
	movb	$0, 111(%rsp)
	movb	$0, 112(%rsp)
	movb	$0, 113(%rsp)
	movb	$0, 114(%rsp)
	movb	$0, 115(%rsp)
	movb	$0, 116(%rsp)
	movb	$0, 117(%rsp)
	movb	$0, 118(%rsp)
	movb	$0, 119(%rsp)
	movb	$0, 120(%rsp)
	movb	$0, 121(%rsp)
	movb	$0, 122(%rsp)
	movb	$0, 123(%rsp)
	movb	$0, 124(%rsp)
	movb	$0, 125(%rsp)
	movb	$0, 126(%rsp)
	movb	$0, 127(%rsp)
	movb	$0, 128(%rsp)
	movb	$0, 129(%rsp)
	movb	$0, 130(%rsp)
	movb	$0, 131(%rsp)
	movb	$0, 132(%rsp)
	movb	$0, 133(%rsp)
	movb	$0, 134(%rsp)
	movb	$0, 135(%rsp)
	movb	$0, 136(%rsp)
	movb	$0, 137(%rsp)
	movb	$0, 138(%rsp)
	movb	$0, 139(%rsp)
	movb	$0, 140(%rsp)
	movb	$0, 141(%rsp)
	movb	$0, 142(%rsp)
	movb	$0, 143(%rsp)
	movb	$0, 144(%rsp)
	movb	$0, 145(%rsp)
	movb	$0, 146(%rsp)
	movb	$0, 147(%rsp)
	movb	$0, 148(%rsp)
	movb	$0, 149(%rsp)
	movb	$0, 150(%rsp)
	movb	$0, 151(%rsp)
	movb	$0, 152(%rsp)
	movb	$0, 153(%rsp)
	movb	$0, 154(%rsp)
	movb	$0, 155(%rsp)
	movb	$0, 156(%rsp)
	movb	$0, 157(%rsp)
	movb	$0, 158(%rsp)
	movb	$0, 159(%rsp)
	#MEMBARRIER
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB67_66:
	movw	$0, (%rbx,%rax)
	movw	$0, 2(%rbx,%rax)
	movw	$0, 4(%rbx,%rax)
	movw	$0, 6(%rbx,%rax)
	movw	$0, 8(%rbx,%rax)
	movw	$0, 10(%rbx,%rax)
	movw	$0, 12(%rbx,%rax)
	movw	$0, 14(%rbx,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_66
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB67_68:
	movw	$0, 512(%rbx,%rax)
	movw	$0, 514(%rbx,%rax)
	movw	$0, 516(%rbx,%rax)
	movw	$0, 518(%rbx,%rax)
	movw	$0, 520(%rbx,%rax)
	movw	$0, 522(%rbx,%rax)
	movw	$0, 524(%rbx,%rax)
	movw	$0, 526(%rbx,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_68
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB67_70:
	movw	$0, 1024(%rbx,%rax)
	movw	$0, 1026(%rbx,%rax)
	movw	$0, 1028(%rbx,%rax)
	movw	$0, 1030(%rbx,%rax)
	movw	$0, 1032(%rbx,%rax)
	movw	$0, 1034(%rbx,%rax)
	movw	$0, 1036(%rbx,%rax)
	movw	$0, 1038(%rbx,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_70
	#MEMBARRIER
	movb	$0, (%r15)
.LBB67_51:
	movb	$0, 2753(%rbx)
	movb	$0, 2754(%rbx)
	movb	$0, 2755(%rbx)
	movb	$0, 2756(%rbx)
	movb	$0, 2757(%rbx)
	movb	$0, 2758(%rbx)
	movb	$0, 2759(%rbx)
	movb	$0, 2760(%rbx)
	movb	$0, 2761(%rbx)
	movb	$0, 2762(%rbx)
	movb	$0, 2763(%rbx)
	movb	$0, 2764(%rbx)
	movb	$0, 2765(%rbx)
	movb	$0, 2766(%rbx)
	movb	$0, 2767(%rbx)
	movb	$0, 2768(%rbx)
	movb	$0, 2769(%rbx)
	movb	$0, 2770(%rbx)
	movb	$0, 2771(%rbx)
	movb	$0, 2772(%rbx)
	movb	$0, 2773(%rbx)
	movb	$0, 2774(%rbx)
	movb	$0, 2775(%rbx)
	movb	$0, 2776(%rbx)
	movb	$0, 2777(%rbx)
	movb	$0, 2778(%rbx)
	movb	$0, 2779(%rbx)
	movb	$0, 2780(%rbx)
	movb	$0, 2781(%rbx)
	movb	$0, 2782(%rbx)
	movb	$0, 2783(%rbx)
	#MEMBARRIER
	movq	%rdi, %rax
	addq	$3304, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB67_77:
	.cfi_def_cfa_offset 3360
.Ltmp391:
	movq	%rax, %r14
	leaq	32(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	jmp	.LBB67_75
.LBB67_76:
.Ltmp385:
	movq	%rax, %r14
	jmp	.LBB67_75
.LBB67_82:
.Ltmp382:
	movq	%rax, %r14
	jmp	.LBB67_55
.LBB67_52:
.Ltmp379:
	movq	%rax, %r14
	xorl	%eax, %eax
.LBB67_53:
	movw	$0, 672(%rsp,%rax)
	movw	$0, 674(%rsp,%rax)
	movw	$0, 676(%rsp,%rax)
	movw	$0, 678(%rsp,%rax)
	movw	$0, 680(%rsp,%rax)
	movw	$0, 682(%rsp,%rax)
	movw	$0, 684(%rsp,%rax)
	movw	$0, 686(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_53
	#MEMBARRIER
	jmp	.LBB67_55
.LBB67_74:
.Ltmp388:
	movq	%rax, %r14
	leaq	1192(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_
.LBB67_75:
	leaq	96(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_
.LBB67_55:
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%rbx, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto5mlkem16DecapsulationKeyEBF_
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.LBB67_78:
.Ltmp376:
	movq	%rax, %r14
	xorl	%eax, %eax
	.p2align	4
.LBB67_79:
	movw	$0, 2280(%rsp,%rax)
	movw	$0, 2282(%rsp,%rax)
	movw	$0, 2284(%rsp,%rax)
	movw	$0, 2286(%rsp,%rax)
	movw	$0, 2288(%rsp,%rax)
	movw	$0, 2290(%rsp,%rax)
	movw	$0, 2292(%rsp,%rax)
	movw	$0, 2294(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB67_79
	#MEMBARRIER
	movq	%rbx, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto5mlkem16DecapsulationKeyEBF_
	movq	%r14, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end67:
	.size	_RNvMs2_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate, .Lfunc_end67-_RNvMs2_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate
	.cfi_endproc
	.section	.gcc_except_table._RNvMs2_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate,"a",@progbits
	.p2align	2, 0x0
GCC_except_table67:
.Lexception30:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end30-.Lcst_begin30
.Lcst_begin30:
	.uleb128 .Lfunc_begin30-.Lfunc_begin30
	.uleb128 .Ltmp374-.Lfunc_begin30
	.byte	0
	.byte	0
	.uleb128 .Ltmp374-.Lfunc_begin30
	.uleb128 .Ltmp375-.Ltmp374
	.uleb128 .Ltmp376-.Lfunc_begin30
	.byte	0
	.uleb128 .Ltmp375-.Lfunc_begin30
	.uleb128 .Ltmp377-.Ltmp375
	.byte	0
	.byte	0
	.uleb128 .Ltmp377-.Lfunc_begin30
	.uleb128 .Ltmp378-.Ltmp377
	.uleb128 .Ltmp379-.Lfunc_begin30
	.byte	0
	.uleb128 .Ltmp378-.Lfunc_begin30
	.uleb128 .Ltmp380-.Ltmp378
	.byte	0
	.byte	0
	.uleb128 .Ltmp380-.Lfunc_begin30
	.uleb128 .Ltmp381-.Ltmp380
	.uleb128 .Ltmp382-.Lfunc_begin30
	.byte	0
	.uleb128 .Ltmp383-.Lfunc_begin30
	.uleb128 .Ltmp384-.Ltmp383
	.uleb128 .Ltmp385-.Lfunc_begin30
	.byte	0
	.uleb128 .Ltmp386-.Lfunc_begin30
	.uleb128 .Ltmp387-.Ltmp386
	.uleb128 .Ltmp388-.Lfunc_begin30
	.byte	0
	.uleb128 .Ltmp389-.Lfunc_begin30
	.uleb128 .Ltmp390-.Ltmp389
	.uleb128 .Ltmp391-.Lfunc_begin30
	.byte	0
	.uleb128 .Ltmp390-.Lfunc_begin30
	.uleb128 .Lfunc_end67-.Ltmp390
	.byte	0
	.byte	0
.Lcst_end30:
	.p2align	2, 0x0

	.section	.text._RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846digest,"ax",@progbits
	.globl	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846digest
	.p2align	4
	.type	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846digest,@function
_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846digest:
.Lfunc_begin31:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception31
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$456, %rsp
	.cfi_def_cfa_offset 480
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rbx
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movabsq	$-3766243637369397544, %rax
	movq	%rax, 128(%rsp)
	movabsq	$7105036623409894663, %rax
	movq	%rax, 136(%rsp)
	movabsq	$-7973340178411365097, %rax
	movq	%rax, 144(%rsp)
	movabsq	$1526699215303891257, %rax
	movq	%rax, 152(%rsp)
	movabsq	$7436329637833083697, %rax
	movq	%rax, 160(%rsp)
	movabsq	$-8163818279084223215, %rax
	movq	%rax, 168(%rsp)
	movabsq	$-2662702644619276377, %rax
	movq	%rax, 176(%rsp)
	movabsq	$5167115440072839076, %rax
	movq	%rax, 184(%rsp)
	movaps	%xmm0, 192(%rsp)
	movq	$0, 208(%rsp)
.Ltmp392:
	movq	%rsp, %rdi
	callq	*_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update@GOTPCREL(%rip)
.Ltmp393:
	cmpb	$-1, %al
	je	.LBB68_5
	movw	$1, (%rbx)
	xorl	%eax, %eax
	.p2align	4
.LBB68_3:
	movb	$0, (%rsp,%rax)
	movb	$0, 1(%rsp,%rax)
	movb	$0, 2(%rsp,%rax)
	movb	$0, 3(%rsp,%rax)
	movb	$0, 4(%rsp,%rax)
	movb	$0, 5(%rsp,%rax)
	movb	$0, 6(%rsp,%rax)
	movb	$0, 7(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB68_3
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	jmp	.LBB68_6
.LBB68_5:
	leaq	224(%rsp), %r14
	movq	%rsp, %rsi
	movl	$224, %edx
	movq	%r14, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	leaq	1(%rbx), %rdi
	movq	%r14, %rsi
	callq	*_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize@GOTPCREL(%rip)
	movb	$0, (%rbx)
.LBB68_6:
	movq	%rbx, %rax
	addq	$456, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB68_7:
	.cfi_def_cfa_offset 480
.Ltmp394:
	xorl	%ecx, %ecx
	.p2align	4
.LBB68_8:
	movb	$0, (%rsp,%rcx)
	movb	$0, 1(%rsp,%rcx)
	movb	$0, 2(%rsp,%rcx)
	movb	$0, 3(%rsp,%rcx)
	movb	$0, 4(%rsp,%rcx)
	movb	$0, 5(%rsp,%rcx)
	movb	$0, 6(%rsp,%rcx)
	movb	$0, 7(%rsp,%rcx)
	addq	$8, %rcx
	cmpq	$128, %rcx
	jne	.LBB68_8
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end68:
	.size	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846digest, .Lfunc_end68-_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846digest
	.cfi_endproc
	.section	.gcc_except_table._RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846digest,"a",@progbits
	.p2align	2, 0x0
GCC_except_table68:
.Lexception31:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end31-.Lcst_begin31
.Lcst_begin31:
	.uleb128 .Ltmp392-.Lfunc_begin31
	.uleb128 .Ltmp393-.Ltmp392
	.uleb128 .Ltmp394-.Lfunc_begin31
	.byte	0
	.uleb128 .Ltmp393-.Lfunc_begin31
	.uleb128 .Lfunc_end68-.Ltmp393
	.byte	0
	.byte	0
.Lcst_end31:
	.p2align	2, 0x0

	.section	.text._RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update,"ax",@progbits
	.globl	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update
	.p2align	4
	.type	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update,@function
_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	200(%rdi), %rax
	movq	192(%rdi), %rcx
	addq	%rdx, %rcx
	adcq	$0, %rax
	setb	%dl
	movq	%rax, %rsi
	shrq	$61, %rsi
	setne	%sil
	orb	%dl, %sil
	je	.LBB69_2
	xorl	%eax, %eax
	jmp	.LBB69_13
.LBB69_2:
	movq	%rdi, %r14
	movq	%rcx, 192(%rdi)
	movq	%rax, 200(%rdi)
	movq	208(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB69_6
	movl	$128, %r12d
	subq	%rdi, %r12
	cmpq	%rbx, %r12
	cmovaeq	%rbx, %r12
	leaq	(%r12,%rdi), %rsi
	cmpq	%rdi, %rsi
	jb	.LBB69_5
	cmpq	$129, %rsi
	jae	.LBB69_5
	addq	%r14, %rdi
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	208(%r14), %rax
	addq	%r12, %rax
	movq	%rax, 208(%r14)
	subq	%r12, %rbx
	addq	%r12, %r15
	cmpq	$128, %rax
	jne	.LBB69_6
	leaq	128(%r14), %rdi
	movq	%r14, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	movq	$0, 208(%r14)
.LBB69_6:
	cmpq	$128, %rbx
	jb	.LBB69_9
	leaq	128(%r14), %r12
	.p2align	4
.LBB69_8:
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	addq	$-128, %rbx
	subq	$-128, %r15
	cmpq	$127, %rbx
	ja	.LBB69_8
.LBB69_9:
	movb	$-1, %al
	testq	%rbx, %rbx
	je	.LBB69_13
	movq	208(%r14), %rdi
	leaq	(%rdi,%rbx), %rsi
	cmpq	%rdi, %rsi
	jb	.LBB69_5
	cmpq	$129, %rsi
	jae	.LBB69_5
	addq	%r14, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movb	$-1, %al
	addq	%rbx, 208(%r14)
.LBB69_13:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB69_5:
	.cfi_def_cfa_offset 48
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.35(%rip), %rcx
	movl	$128, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Lfunc_end69:
	.size	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update, .Lfunc_end69-_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update
	.cfi_endproc

	.section	.text._RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize,"ax",@progbits
	.globl	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize
	.p2align	4
	.type	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize,@function
_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize:
.Lfunc_begin32:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception32
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movq	208(%rsi), %rdi
	cmpq	$127, %rdi
	ja	.LBB70_10
	movb	$-128, (%rbx,%rdi)
	movq	208(%rbx), %rax
	leaq	1(%rax), %rdi
	movq	%rdi, 208(%rbx)
	cmpq	$128, %rdi
	ja	.LBB70_12
	movl	$127, %edx
	subq	%rax, %rdx
	addq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	cmpq	$112, 208(%rbx)
	jbe	.LBB70_4
	leaq	128(%rbx), %rdi
	movq	%rbx, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 112(%rbx)
	movaps	%xmm0, 96(%rbx)
	movaps	%xmm0, 80(%rbx)
	movaps	%xmm0, 64(%rbx)
	movaps	%xmm0, 48(%rbx)
	movaps	%xmm0, 32(%rbx)
	movaps	%xmm0, 16(%rbx)
	movaps	%xmm0, (%rbx)
.LBB70_4:
	movq	192(%rbx), %rax
	movq	200(%rbx), %rcx
	shldq	$3, %rax, %rcx
	shlq	$3, %rax
	bswapq	%rcx
	bswapq	%rax
	movq	%rax, 120(%rbx)
	movq	%rcx, 112(%rbx)
	leaq	128(%rbx), %rdi
	movq	%rbx, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	movq	128(%rbx), %rax
	movq	136(%rbx), %rcx
	bswapq	%rax
	bswapq	%rcx
	movq	144(%rbx), %rdx
	bswapq	%rdx
	movq	152(%rbx), %rsi
	bswapq	%rsi
	movq	160(%rbx), %rdi
	bswapq	%rdi
	movq	168(%rbx), %r8
	bswapq	%r8
	movq	%rax, (%r14)
	movq	%rcx, 8(%r14)
	movq	%rdx, 16(%r14)
	movq	%rsi, 24(%r14)
	movq	%rdi, 32(%r14)
	movq	%r8, 40(%r14)
	xorl	%eax, %eax
	.p2align	4
.LBB70_5:
	movb	$0, (%rbx,%rax)
	movb	$0, 1(%rbx,%rax)
	movb	$0, 2(%rbx,%rax)
	movb	$0, 3(%rbx,%rax)
	movb	$0, 4(%rbx,%rax)
	movb	$0, 5(%rbx,%rax)
	movb	$0, 6(%rbx,%rax)
	movb	$0, 7(%rbx,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB70_5
	#MEMBARRIER
	movq	$0, 128(%rbx)
	movq	$0, 136(%rbx)
	movq	$0, 144(%rbx)
	movq	$0, 152(%rbx)
	movq	$0, 160(%rbx)
	movq	$0, 168(%rbx)
	movq	$0, 176(%rbx)
	movq	$0, 184(%rbx)
	#MEMBARRIER
	movq	%r14, %rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB70_12:
	.cfi_def_cfa_offset 32
.Ltmp397:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.35(%rip), %rcx
	movl	$128, %esi
	movl	$128, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Ltmp398:
	jmp	.LBB70_11
.LBB70_10:
.Ltmp395:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.35(%rip), %rdx
	movl	$128, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp396:
.LBB70_11:
	ud2
.LBB70_7:
.Ltmp399:
	xorl	%ecx, %ecx
	.p2align	4
.LBB70_8:
	movb	$0, (%rbx,%rcx)
	movb	$0, 1(%rbx,%rcx)
	movb	$0, 2(%rbx,%rcx)
	movb	$0, 3(%rbx,%rcx)
	movb	$0, 4(%rbx,%rcx)
	movb	$0, 5(%rbx,%rcx)
	movb	$0, 6(%rbx,%rcx)
	movb	$0, 7(%rbx,%rcx)
	addq	$8, %rcx
	cmpq	$128, %rcx
	jne	.LBB70_8
	#MEMBARRIER
	movq	$0, 128(%rbx)
	movq	$0, 136(%rbx)
	movq	$0, 144(%rbx)
	movq	$0, 152(%rbx)
	movq	$0, 160(%rbx)
	movq	$0, 168(%rbx)
	movq	$0, 176(%rbx)
	movq	$0, 184(%rbx)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end70:
	.size	_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize, .Lfunc_end70-_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize
	.cfi_endproc
	.section	.gcc_except_table._RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize,"a",@progbits
	.p2align	2, 0x0
GCC_except_table70:
.Lexception32:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end32-.Lcst_begin32
.Lcst_begin32:
	.uleb128 .Lfunc_begin32-.Lfunc_begin32
	.uleb128 .Ltmp397-.Lfunc_begin32
	.byte	0
	.byte	0
	.uleb128 .Ltmp397-.Lfunc_begin32
	.uleb128 .Ltmp396-.Ltmp397
	.uleb128 .Ltmp399-.Lfunc_begin32
	.byte	0
	.uleb128 .Ltmp396-.Lfunc_begin32
	.uleb128 .Lfunc_end70-.Ltmp396
	.byte	0
	.byte	0
.Lcst_end32:
	.p2align	2, 0x0

	.section	.text._RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126digest,"ax",@progbits
	.globl	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126digest
	.p2align	4
	.type	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126digest,@function
_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126digest:
.Lfunc_begin33:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception33
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$456, %rsp
	.cfi_def_cfa_offset 480
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rbx
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movabsq	$7640891576956012808, %rax
	movq	%rax, 128(%rsp)
	movabsq	$-4942790177534073029, %rax
	movq	%rax, 136(%rsp)
	movabsq	$4354685564936845355, %rax
	movq	%rax, 144(%rsp)
	movabsq	$-6534734903238641935, %rax
	movq	%rax, 152(%rsp)
	movabsq	$5840696475078001361, %rax
	movq	%rax, 160(%rsp)
	movabsq	$-7276294671716946913, %rax
	movq	%rax, 168(%rsp)
	movabsq	$2270897969802886507, %rax
	movq	%rax, 176(%rsp)
	movabsq	$6620516959819538809, %rax
	movq	%rax, 184(%rsp)
	movaps	%xmm0, 192(%rsp)
	movq	$0, 208(%rsp)
.Ltmp400:
	movq	%rsp, %rdi
	callq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update@GOTPCREL(%rip)
.Ltmp401:
	cmpb	$-1, %al
	je	.LBB71_5
	movw	$1, (%rbx)
	xorl	%eax, %eax
	.p2align	4
.LBB71_3:
	movb	$0, (%rsp,%rax)
	movb	$0, 1(%rsp,%rax)
	movb	$0, 2(%rsp,%rax)
	movb	$0, 3(%rsp,%rax)
	movb	$0, 4(%rsp,%rax)
	movb	$0, 5(%rsp,%rax)
	movb	$0, 6(%rsp,%rax)
	movb	$0, 7(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB71_3
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	jmp	.LBB71_6
.LBB71_5:
	leaq	224(%rsp), %r14
	movq	%rsp, %rsi
	movl	$224, %edx
	movq	%r14, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	leaq	1(%rbx), %rdi
	movq	%r14, %rsi
	callq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize@GOTPCREL(%rip)
	movb	$0, (%rbx)
.LBB71_6:
	movq	%rbx, %rax
	addq	$456, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB71_7:
	.cfi_def_cfa_offset 480
.Ltmp402:
	xorl	%ecx, %ecx
	.p2align	4
.LBB71_8:
	movb	$0, (%rsp,%rcx)
	movb	$0, 1(%rsp,%rcx)
	movb	$0, 2(%rsp,%rcx)
	movb	$0, 3(%rsp,%rcx)
	movb	$0, 4(%rsp,%rcx)
	movb	$0, 5(%rsp,%rcx)
	movb	$0, 6(%rsp,%rcx)
	movb	$0, 7(%rsp,%rcx)
	addq	$8, %rcx
	cmpq	$128, %rcx
	jne	.LBB71_8
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end71:
	.size	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126digest, .Lfunc_end71-_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126digest
	.cfi_endproc
	.section	.gcc_except_table._RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126digest,"a",@progbits
	.p2align	2, 0x0
GCC_except_table71:
.Lexception33:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end33-.Lcst_begin33
.Lcst_begin33:
	.uleb128 .Ltmp400-.Lfunc_begin33
	.uleb128 .Ltmp401-.Ltmp400
	.uleb128 .Ltmp402-.Lfunc_begin33
	.byte	0
	.uleb128 .Ltmp401-.Lfunc_begin33
	.uleb128 .Lfunc_end71-.Ltmp401
	.byte	0
	.byte	0
.Lcst_end33:
	.p2align	2, 0x0

	.section	.text._RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update,"ax",@progbits
	.globl	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update
	.p2align	4
	.type	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update,@function
_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %rbx
	movq	%rsi, %r15
	movq	200(%rdi), %rax
	movq	192(%rdi), %rcx
	addq	%rdx, %rcx
	adcq	$0, %rax
	setb	%dl
	movq	%rax, %rsi
	shrq	$61, %rsi
	setne	%sil
	orb	%dl, %sil
	je	.LBB72_2
	xorl	%eax, %eax
	jmp	.LBB72_13
.LBB72_2:
	movq	%rdi, %r14
	movq	%rcx, 192(%rdi)
	movq	%rax, 200(%rdi)
	movq	208(%rdi), %rdi
	testq	%rdi, %rdi
	je	.LBB72_6
	movl	$128, %r12d
	subq	%rdi, %r12
	cmpq	%rbx, %r12
	cmovaeq	%rbx, %r12
	leaq	(%r12,%rdi), %rsi
	cmpq	%rdi, %rsi
	jb	.LBB72_5
	cmpq	$129, %rsi
	jae	.LBB72_5
	addq	%r14, %rdi
	movq	%r15, %rsi
	movq	%r12, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	208(%r14), %rax
	addq	%r12, %rax
	movq	%rax, 208(%r14)
	subq	%r12, %rbx
	addq	%r12, %r15
	cmpq	$128, %rax
	jne	.LBB72_6
	leaq	128(%r14), %rdi
	movq	%r14, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	movq	$0, 208(%r14)
.LBB72_6:
	cmpq	$128, %rbx
	jb	.LBB72_9
	leaq	128(%r14), %r12
	.p2align	4
.LBB72_8:
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	addq	$-128, %rbx
	subq	$-128, %r15
	cmpq	$127, %rbx
	ja	.LBB72_8
.LBB72_9:
	movb	$-1, %al
	testq	%rbx, %rbx
	je	.LBB72_13
	movq	208(%r14), %rdi
	leaq	(%rdi,%rbx), %rsi
	cmpq	%rdi, %rsi
	jb	.LBB72_5
	cmpq	$129, %rsi
	jae	.LBB72_5
	addq	%r14, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movb	$-1, %al
	addq	%rbx, 208(%r14)
.LBB72_13:
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB72_5:
	.cfi_def_cfa_offset 48
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.36(%rip), %rcx
	movl	$128, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Lfunc_end72:
	.size	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update, .Lfunc_end72-_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update
	.cfi_endproc

	.section	.text._RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize,"ax",@progbits
	.globl	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize
	.p2align	4
	.type	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize,@function
_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize:
.Lfunc_begin34:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception34
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %r14
	movq	208(%rsi), %rdi
	cmpq	$127, %rdi
	ja	.LBB73_10
	movb	$-128, (%rbx,%rdi)
	movq	208(%rbx), %rax
	leaq	1(%rax), %rdi
	movq	%rdi, 208(%rbx)
	cmpq	$128, %rdi
	ja	.LBB73_12
	movl	$127, %edx
	subq	%rax, %rdx
	addq	%rbx, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	cmpq	$112, 208(%rbx)
	jbe	.LBB73_4
	leaq	128(%rbx), %rdi
	movq	%rbx, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 112(%rbx)
	movaps	%xmm0, 96(%rbx)
	movaps	%xmm0, 80(%rbx)
	movaps	%xmm0, 64(%rbx)
	movaps	%xmm0, 48(%rbx)
	movaps	%xmm0, 32(%rbx)
	movaps	%xmm0, 16(%rbx)
	movaps	%xmm0, (%rbx)
.LBB73_4:
	movq	192(%rbx), %rax
	movq	200(%rbx), %rcx
	shldq	$3, %rax, %rcx
	shlq	$3, %rax
	bswapq	%rcx
	bswapq	%rax
	movq	%rax, 120(%rbx)
	movq	%rcx, 112(%rbx)
	leaq	128(%rbx), %rdi
	movq	%rbx, %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	movq	128(%rbx), %rax
	movq	136(%rbx), %rcx
	bswapq	%rax
	bswapq	%rcx
	movq	144(%rbx), %rdx
	bswapq	%rdx
	movq	152(%rbx), %rsi
	bswapq	%rsi
	movq	160(%rbx), %rdi
	bswapq	%rdi
	movq	168(%rbx), %r8
	bswapq	%r8
	movq	176(%rbx), %r9
	bswapq	%r9
	movq	184(%rbx), %r10
	bswapq	%r10
	movq	%rax, (%r14)
	movq	%rcx, 8(%r14)
	movq	%rdx, 16(%r14)
	movq	%rsi, 24(%r14)
	movq	%rdi, 32(%r14)
	movq	%r8, 40(%r14)
	movq	%r9, 48(%r14)
	movq	%r10, 56(%r14)
	xorl	%eax, %eax
	.p2align	4
.LBB73_5:
	movb	$0, (%rbx,%rax)
	movb	$0, 1(%rbx,%rax)
	movb	$0, 2(%rbx,%rax)
	movb	$0, 3(%rbx,%rax)
	movb	$0, 4(%rbx,%rax)
	movb	$0, 5(%rbx,%rax)
	movb	$0, 6(%rbx,%rax)
	movb	$0, 7(%rbx,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB73_5
	#MEMBARRIER
	movq	$0, 128(%rbx)
	movq	$0, 136(%rbx)
	movq	$0, 144(%rbx)
	movq	$0, 152(%rbx)
	movq	$0, 160(%rbx)
	movq	$0, 168(%rbx)
	movq	$0, 176(%rbx)
	movq	$0, 184(%rbx)
	#MEMBARRIER
	movq	%r14, %rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB73_12:
	.cfi_def_cfa_offset 32
.Ltmp405:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.36(%rip), %rcx
	movl	$128, %esi
	movl	$128, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Ltmp406:
	jmp	.LBB73_11
.LBB73_10:
.Ltmp403:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.36(%rip), %rdx
	movl	$128, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp404:
.LBB73_11:
	ud2
.LBB73_7:
.Ltmp407:
	xorl	%ecx, %ecx
	.p2align	4
.LBB73_8:
	movb	$0, (%rbx,%rcx)
	movb	$0, 1(%rbx,%rcx)
	movb	$0, 2(%rbx,%rcx)
	movb	$0, 3(%rbx,%rcx)
	movb	$0, 4(%rbx,%rcx)
	movb	$0, 5(%rbx,%rcx)
	movb	$0, 6(%rbx,%rcx)
	movb	$0, 7(%rbx,%rcx)
	addq	$8, %rcx
	cmpq	$128, %rcx
	jne	.LBB73_8
	#MEMBARRIER
	movq	$0, 128(%rbx)
	movq	$0, 136(%rbx)
	movq	$0, 144(%rbx)
	movq	$0, 152(%rbx)
	movq	$0, 160(%rbx)
	movq	$0, 168(%rbx)
	movq	$0, 176(%rbx)
	movq	$0, 184(%rbx)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end73:
	.size	_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize, .Lfunc_end73-_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize
	.cfi_endproc
	.section	.gcc_except_table._RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize,"a",@progbits
	.p2align	2, 0x0
GCC_except_table73:
.Lexception34:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end34-.Lcst_begin34
.Lcst_begin34:
	.uleb128 .Lfunc_begin34-.Lfunc_begin34
	.uleb128 .Ltmp405-.Lfunc_begin34
	.byte	0
	.byte	0
	.uleb128 .Ltmp405-.Lfunc_begin34
	.uleb128 .Ltmp404-.Ltmp405
	.uleb128 .Ltmp407-.Lfunc_begin34
	.byte	0
	.uleb128 .Ltmp404-.Lfunc_begin34
	.uleb128 .Lfunc_end73-.Ltmp404
	.byte	0
	.byte	0
.Lcst_end34:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$80, %rsp
	.cfi_def_cfa_offset 96
	.cfi_offset %rbx, -16
	movq	%rsi, %rbx
	movq	%rdi, %rsi
	leaq	8(%rsp), %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes
	leaq	40(%rsp), %rdi
	movq	%rbx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes
	movdqu	8(%rsp), %xmm0
	movdqu	24(%rsp), %xmm1
	movdqu	40(%rsp), %xmm2
	pcmpeqb	%xmm0, %xmm2
	movdqu	56(%rsp), %xmm0
	pcmpeqb	%xmm1, %xmm0
	pand	%xmm2, %xmm0
	pmovmskb	%xmm0, %eax
	xorl	%ecx, %ecx
	xorl	$65535, %eax
	setne	%cl
	movq	%rcx, 72(%rsp)
	xorl	%eax, %eax
	cmpq	$0, 72(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	#MEMBARRIER
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	sete	%al
	#MEMBARRIER
	addq	$80, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end74:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq, .Lfunc_end74-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F2eq
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3add,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3add,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3add:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	(%rdx), %r10
	movq	8(%rdx), %rbx
	xorl	%ecx, %ecx
	addq	(%rsi), %r10
	setb	%cl
	xorl	%r8d, %r8d
	addq	8(%rsi), %rbx
	setb	%r8b
	movq	16(%rdx), %r14
	xorl	%r9d, %r9d
	addq	16(%rsi), %r14
	setb	%r9b
	movq	24(%rdx), %r15
	xorl	%r11d, %r11d
	addq	24(%rsi), %r15
	setb	%r11b
	movq	32(%rdx), %r12
	xorl	%edx, %edx
	addq	32(%rsi), %r12
	setb	%dl
	movabsq	$2251799813685247, %rax
	shldq	$13, %r10, %rcx
	andq	%rax, %r10
	addq	%rbx, %rcx
	adcq	$0, %r8
	shldq	$13, %rcx, %r8
	andq	%rax, %rcx
	addq	%r14, %r8
	adcq	$0, %r9
	shldq	$13, %r8, %r9
	andq	%rax, %r8
	addq	%r15, %r9
	adcq	$0, %r11
	shldq	$13, %r9, %r11
	andq	%rax, %r9
	addq	%r12, %r11
	adcl	$0, %edx
	movq	%r11, %rsi
	shrq	$51, %rsi
	shll	$13, %edx
	orq	%rsi, %rdx
	andq	%rax, %r11
	leaq	(%rdx,%rdx,8), %rsi
	leaq	(%rdx,%rsi,2), %rdx
	addq	%r10, %rdx
	movq	%rdx, %rsi
	andq	%rax, %rsi
	shrq	$51, %rdx
	addq	%rcx, %rdx
	movq	%rdx, %r10
	andq	%rax, %r10
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%rax, %r8
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %r9
	andq	%rax, %r9
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%rax, %rdx
	leaq	(%rcx,%rcx,8), %r11
	leaq	(%rcx,%r11,2), %rcx
	addq	%rsi, %rcx
	movq	%rcx, %r11
	andq	%rax, %r11
	shrq	$51, %rcx
	addq	%r10, %rcx
	movq	%rcx, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	movq	%rsi, %r8
	shrq	$51, %r8
	addq	%r9, %r8
	movq	%r8, %r9
	shrq	$51, %r9
	addq	%rdx, %r9
	movq	%r9, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r10
	leaq	(%rdx,%r10,2), %rdx
	addq	%r11, %rdx
	andq	%rax, %rcx
	andq	%rax, %rsi
	andq	%rax, %r8
	andq	%rax, %r9
	movq	$0, -16(%rsp)
	movq	$0, -24(%rsp)
	movq	$0, -32(%rsp)
	movq	$0, -40(%rsp)
	movq	$0, -48(%rsp)
	movq	$0, -56(%rsp)
	movq	$0, -64(%rsp)
	movq	$0, -72(%rsp)
	movq	$0, -80(%rsp)
	movq	$0, -88(%rsp)
	#MEMBARRIER
	movq	%rdx, (%rdi)
	movq	%rcx, 8(%rdi)
	movq	%rsi, 16(%rdi)
	movq	%r8, 24(%rdi)
	movq	%r9, 32(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end75:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3add, .Lfunc_end75-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3add
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %rcx
	movq	(%rdx), %r9
	movq	(%rsi), %r8
	movq	%rsi, %r12
	movq	%r8, %rax
	mulq	%r9
	movq	%r9, -120(%rsp)
	movq	%rax, -112(%rsp)
	movq	%rdx, -104(%rsp)
	movq	8(%rcx), %rsi
	movq	%r8, %rax
	mulq	%rsi
	movq	%rax, %r11
	movq	%rdx, %r10
	movq	16(%rcx), %rbx
	movq	%r8, %rax
	mulq	%rbx
	movq	%rbx, -64(%rsp)
	movq	%rax, %rbp
	movq	%rdx, %r14
	movq	24(%rcx), %r15
	movq	%r8, %rax
	mulq	%r15
	movq	%r15, -80(%rsp)
	movq	%rax, %r13
	movq	%rdx, -32(%rsp)
	movq	32(%rcx), %rcx
	movq	%r8, %rax
	mulq	%rcx
	movq	%rcx, -72(%rsp)
	movq	%rax, -40(%rsp)
	movq	%rdx, -24(%rsp)
	movq	%r12, %r8
	movq	%r12, -56(%rsp)
	movq	8(%r12), %r12
	movq	%r12, %rax
	mulq	%r9
	addq	%r11, %rax
	movq	%rax, -88(%rsp)
	adcq	%r10, %rdx
	movq	%rdx, -96(%rsp)
	movq	%r12, %rax
	mulq	%rsi
	movq	%rsi, %r10
	movq	%rsi, -48(%rsp)
	movq	%rdx, %r11
	movq	%rax, %rsi
	addq	%rbp, %rsi
	adcq	%r14, %r11
	movq	%r12, %rax
	mulq	%rbx
	movq	%rdx, %r14
	movq	%rax, %rbp
	addq	%r13, %rbp
	adcq	-32(%rsp), %r14
	movq	%r12, %rax
	mulq	%r15
	movq	%rdx, %r15
	movq	%rax, %r9
	addq	-40(%rsp), %r9
	adcq	-24(%rsp), %r15
	movq	%r12, %rax
	mulq	%rcx
	movq	%rdx, %rcx
	movl	$19, %edx
	mulq	%rdx
	movq	%rax, %r13
	movq	%rdx, %r12
	leaq	(%rcx,%rcx,8), %rax
	leaq	(%rcx,%rax,2), %rax
	addq	%rax, %r12
	addq	-112(%rsp), %r13
	adcq	-104(%rsp), %r12
	movq	16(%r8), %rcx
	movq	%rcx, %rax
	mulq	-120(%rsp)
	addq	%rsi, %rax
	movq	%rax, -104(%rsp)
	adcq	%r11, %rdx
	movq	%rdx, -112(%rsp)
	movq	%rcx, %rax
	mulq	%r10
	movq	%rdx, %rbx
	movq	%rax, %rsi
	addq	%rbp, %rsi
	adcq	%r14, %rbx
	movq	%rcx, %rax
	mulq	-64(%rsp)
	movq	%rdx, %r14
	movq	%rax, %r10
	addq	%r9, %r10
	adcq	%r15, %r14
	movq	%rcx, %rax
	movl	$19, %ecx
	mulq	%rcx
	movq	%rax, %rcx
	movq	%rdx, %r8
	movq	%rdx, %r9
	movq	-80(%rsp), %rdx
	imulq	%rdx, %r9
	mulq	%rdx
	movq	%rax, %rbp
	movq	%rdx, %r11
	addq	%r9, %r11
	addq	%r13, %rbp
	adcq	%r12, %r11
	movq	%rcx, %rax
	movq	-72(%rsp), %rcx
	mulq	%rcx
	movq	%rax, %r9
	movq	%rdx, %r15
	imulq	%rcx, %r8
	addq	%r8, %r15
	addq	-88(%rsp), %r9
	adcq	-96(%rsp), %r15
	movq	-56(%rsp), %rax
	movq	24(%rax), %rcx
	movq	%rcx, %rax
	mulq	-120(%rsp)
	addq	%rsi, %rax
	movq	%rax, -88(%rsp)
	adcq	%rbx, %rdx
	movq	%rdx, -96(%rsp)
	movq	%rcx, %rax
	mulq	-48(%rsp)
	movq	%rdx, %r12
	movq	%rax, %r8
	addq	%r10, %r8
	adcq	%r14, %r12
	movq	%rcx, %rax
	movl	$19, %ecx
	mulq	%rcx
	movq	%rax, %rcx
	movq	%rdx, %rsi
	movq	%rdx, %r10
	movq	-64(%rsp), %rdx
	imulq	%rdx, %r10
	mulq	%rdx
	movq	%rax, %r13
	movq	%rdx, %rbx
	addq	%r10, %rbx
	addq	%rbp, %r13
	adcq	%r11, %rbx
	movq	%rsi, %r10
	movq	-80(%rsp), %rdx
	imulq	%rdx, %r10
	movq	%rcx, %rax
	mulq	%rdx
	movq	%rax, %rbp
	movq	%rdx, %r14
	addq	%r10, %r14
	addq	%r9, %rbp
	adcq	%r15, %r14
	movq	%rcx, %rax
	movq	-72(%rsp), %r9
	mulq	%r9
	movq	%rax, %rcx
	movq	%rdx, %r15
	imulq	%r9, %rsi
	addq	%rsi, %r15
	addq	-104(%rsp), %rcx
	adcq	-112(%rsp), %r15
	movq	-56(%rsp), %rax
	movq	32(%rax), %rsi
	movq	%rsi, %rax
	mulq	-120(%rsp)
	movq	%rax, %r11
	addq	%r8, %r11
	adcq	%r12, %rdx
	movq	%rdx, -120(%rsp)
	movq	%rsi, %rax
	movl	$19, %edx
	mulq	%rdx
	movq	%rax, %r12
	movq	%rdx, %r9
	movq	%rdx, %r8
	movq	-48(%rsp), %rdx
	imulq	%rdx, %r8
	mulq	%rdx
	movq	%rax, %r10
	movq	%rdx, %rsi
	addq	%r8, %rsi
	addq	%r13, %r10
	adcq	%rbx, %rsi
	movq	%r9, %r8
	movq	-64(%rsp), %rdx
	imulq	%rdx, %r8
	movq	%r12, %rax
	mulq	%rdx
	movq	%rax, %r13
	movq	%rdx, %rbx
	addq	%r8, %rbx
	addq	%rbp, %r13
	adcq	%r14, %rbx
	movq	%r9, %r8
	movq	-80(%rsp), %rdx
	imulq	%rdx, %r8
	movq	%r12, %rax
	mulq	%rdx
	movq	%rax, %rbp
	movq	%rdx, %r14
	addq	%r8, %r14
	addq	%rcx, %rbp
	adcq	%r15, %r14
	movq	%r12, %rax
	movq	-72(%rsp), %rcx
	mulq	%rcx
	imulq	%rcx, %r9
	addq	%r9, %rdx
	addq	-88(%rsp), %rax
	adcq	-96(%rsp), %rdx
	movabsq	$2251799813685247, %rcx
	movq	%rsi, %r8
	shrq	$51, %r8
	shldq	$13, %r10, %rsi
	andq	%rcx, %r10
	addq	%r13, %rsi
	adcq	%rbx, %r8
	movq	%r8, %rbx
	shrq	$51, %rbx
	shldq	$13, %rsi, %r8
	andq	%rcx, %rsi
	addq	%rbp, %r8
	adcq	%r14, %rbx
	movq	%rbx, %r14
	shrq	$51, %r14
	shldq	$13, %r8, %rbx
	andq	%rcx, %r8
	addq	%rax, %rbx
	adcq	%rdx, %r14
	movq	%r14, %rdx
	shrq	$51, %rdx
	shldq	$13, %rbx, %r14
	andq	%rcx, %rbx
	addq	%r11, %r14
	adcq	-120(%rsp), %rdx
	movq	%rdx, %rax
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r9
	leaq	(%rdx,%r9,2), %r9
	shldq	$13, %r14, %rax
	andq	%rcx, %r14
	movl	$19, %edx
	mulq	%rdx
	addq	%r10, %rax
	adcq	%r9, %rdx
	shldq	$13, %rax, %rdx
	andq	%rcx, %rax
	addq	%rsi, %rdx
	movq	%rdx, %r9
	andq	%rcx, %r9
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%rcx, %r8
	shrq	$51, %rdx
	addq	%rbx, %rdx
	movq	%rdx, %r10
	andq	%rcx, %r10
	shrq	$51, %rdx
	addq	%r14, %rdx
	movq	%rdx, %rsi
	shrq	$51, %rsi
	andq	%rcx, %rdx
	leaq	(%rsi,%rsi,8), %r11
	leaq	(%rsi,%r11,2), %rsi
	addq	%rax, %rsi
	movq	%rsi, %r11
	shrq	$51, %rsi
	addq	%r9, %rsi
	movq	%rsi, %rax
	shrq	$51, %rax
	addq	%r8, %rax
	movq	%rax, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	movq	%r8, %r9
	shrq	$51, %r9
	addq	%rdx, %r9
	movq	%r9, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r10
	leaq	(%rdx,%r10,2), %rdx
	andq	%rcx, %r11
	addq	%r11, %rdx
	andq	%rcx, %rsi
	andq	%rcx, %rax
	andq	%rcx, %r8
	andq	%rcx, %r9
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, -8(%rsp)
	movq	$0, -16(%rsp)
	#MEMBARRIER
	movq	%rdx, (%rdi)
	movq	%rsi, 8(%rdi)
	movq	%rax, 16(%rdi)
	movq	%r8, 24(%rdi)
	movq	%r9, 32(%rdi)
	addq	$72, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end76:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul, .Lfunc_end76-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3pow,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3pow,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3pow:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r14
	movq	%rdx, %r15
	movq	%rsi, %r12
	movq	%rdi, 56(%rsp)
	movq	$1, 16(%rsp)
	pxor	%xmm0, %xmm0
	movdqu	%xmm0, 24(%rsp)
	movdqu	%xmm0, 40(%rsp)
	decq	%r14
	leaq	64(%rsp), %r13
	leaq	16(%rsp), %rbp
	leaq	112(%rsp), %rbx
	.p2align	4
.LBB77_1:
	movq	%r13, %rdi
	movq	%rbp, %rsi
	movq	%rbp, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	%rbx, %rdi
	movq	%r13, %rsi
	movq	%r12, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r14, %rax
	shrq	$3, %rax
	movzbl	(%r15,%rax), %eax
	movl	%r14d, %ecx
	andl	$7, %ecx
	xorl	%edx, %edx
	btl	%ecx, %eax
	setb	%dl
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %xmm1
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %xmm0
	punpcklqdq	%xmm0, %xmm1
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %xmm0
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %xmm2
	punpcklqdq	%xmm2, %xmm0
	movq	96(%rsp), %rsi
	movq	144(%rsp), %rdi
	movq	%rdx, 8(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, %rcx
	negq	%rcx
	andq	%rdi, %rcx
	decq	%rax
	andq	%rsi, %rax
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	pxor	%xmm2, %xmm2
	psubq	%xmm1, %xmm2
	pcmpeqd	%xmm3, %xmm3
	paddq	%xmm3, %xmm1
	pand	64(%rsp), %xmm1
	pand	112(%rsp), %xmm2
	por	%xmm1, %xmm2
	pxor	%xmm1, %xmm1
	psubq	%xmm0, %xmm1
	paddq	%xmm3, %xmm0
	pand	80(%rsp), %xmm0
	pand	128(%rsp), %xmm1
	orq	%rcx, %rax
	por	%xmm0, %xmm1
	#MEMBARRIER
	movdqa	%xmm2, 16(%rsp)
	movdqa	%xmm1, 32(%rsp)
	movq	%rax, 48(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	addq	$-1, %r14
	jb	.LBB77_1
	movq	48(%rsp), %rax
	movq	56(%rsp), %rcx
	movq	%rax, 32(%rcx)
	movaps	16(%rsp), %xmm0
	movaps	32(%rsp), %xmm1
	movups	%xmm1, 16(%rcx)
	movups	%xmm0, (%rcx)
	addq	$152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end77:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3pow, .Lfunc_end77-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3pow
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3sub,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3sub,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3sub:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	xorl	%eax, %eax
	movq	(%rsi), %r8
	movq	8(%rsi), %r10
	subq	(%rdx), %r8
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	movabsq	$4503599627370458, %r9
	addq	%r8, %r9
	adcq	$0, %rcx
	subq	8(%rdx), %r10
	movl	$0, %r11d
	sbbq	%r11, %r11
	movq	%rcx, %r8
	shldq	$13, %r9, %rcx
	shrq	$51, %r8
	addq	%r10, %rcx
	adcq	%r11, %r8
	movq	16(%rsi), %r11
	subq	16(%rdx), %r11
	movl	$0, %r14d
	sbbq	%r14, %r14
	movabsq	$4503599627370494, %rbx
	addq	%rbx, %rcx
	adcq	$0, %r8
	movq	%r8, %r10
	shldq	$13, %rcx, %r8
	shrq	$51, %r10
	addq	%r11, %r8
	adcq	%r14, %r10
	movq	24(%rsi), %r14
	subq	24(%rdx), %r14
	movl	$0, %r15d
	sbbq	%r15, %r15
	addq	%rbx, %r8
	adcq	$0, %r10
	movq	%r10, %r11
	shrq	$51, %r11
	shldq	$13, %r8, %r10
	addq	%r14, %r10
	adcq	%r15, %r11
	movq	32(%rsi), %rsi
	subq	32(%rdx), %rsi
	sbbq	%rax, %rax
	addq	%rbx, %r10
	adcq	$0, %r11
	movq	%r11, %rdx
	shldq	$13, %r10, %r11
	shrq	$51, %rdx
	addq	%rsi, %r11
	adcq	%rax, %rdx
	movabsq	$2251799813685247, %rsi
	andq	%rsi, %r9
	andq	%rsi, %rcx
	andq	%rsi, %r8
	andq	%rsi, %r10
	addq	%rbx, %r11
	adcq	$0, %rdx
	movq	%rdx, %rax
	shldq	$13, %r11, %rax
	shrq	$51, %rdx
	andq	%rsi, %r11
	leaq	(%rdx,%rdx,8), %rbx
	leaq	(%rdx,%rbx,2), %rbx
	movl	$19, %edx
	mulq	%rdx
	addq	%r9, %rax
	adcq	%rbx, %rdx
	shldq	$13, %rax, %rdx
	andq	%rsi, %rax
	addq	%rcx, %rdx
	movq	%rdx, %r9
	andq	%rsi, %r9
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%rsi, %r8
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%rsi, %r10
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%rsi, %rdx
	leaq	(%rcx,%rcx,8), %r11
	leaq	(%rcx,%r11,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %r11
	andq	%rsi, %r11
	shrq	$51, %rcx
	addq	%r9, %rcx
	movq	%rcx, %rax
	shrq	$51, %rax
	addq	%r8, %rax
	movq	%rax, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	movq	%r8, %r9
	shrq	$51, %r9
	addq	%rdx, %r9
	movq	%r9, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r10
	leaq	(%rdx,%r10,2), %rdx
	addq	%r11, %rdx
	andq	%rsi, %rcx
	andq	%rsi, %rax
	andq	%rsi, %r8
	andq	%rsi, %r9
	movq	$0, -8(%rsp)
	movq	$0, -16(%rsp)
	movq	$0, -24(%rsp)
	movq	$0, -32(%rsp)
	movq	$0, -40(%rsp)
	movq	$0, -48(%rsp)
	movq	$0, -56(%rsp)
	movq	$0, -64(%rsp)
	movq	$0, -72(%rsp)
	movq	$0, -80(%rsp)
	#MEMBARRIER
	movq	%rdx, (%rdi)
	movq	%rcx, 8(%rdi)
	movq	%rax, 16(%rdi)
	movq	%r8, 24(%rdi)
	movq	%r9, 32(%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end78:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3sub, .Lfunc_end78-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3sub
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	(%rsi), %rcx
	movabsq	$2251799813685247, %rax
	movq	%rcx, %r9
	andq	%rax, %r9
	shrq	$51, %rcx
	xorl	%edx, %edx
	addq	8(%rsi), %rcx
	setb	%dl
	shldq	$13, %rcx, %rdx
	andq	%rax, %rcx
	xorl	%r8d, %r8d
	addq	16(%rsi), %rdx
	setb	%r8b
	shldq	$13, %rdx, %r8
	andq	%rax, %rdx
	xorl	%r10d, %r10d
	addq	24(%rsi), %r8
	setb	%r10b
	shldq	$13, %r8, %r10
	andq	%rax, %r8
	xorl	%r11d, %r11d
	addq	32(%rsi), %r10
	setb	%r11b
	movq	%r10, %rsi
	shrq	$51, %rsi
	shll	$13, %r11d
	orq	%rsi, %r11
	andq	%rax, %r10
	leaq	(%r11,%r11,8), %rsi
	leaq	(%r11,%rsi,2), %r11
	addq	%r9, %r11
	movq	%r11, %rsi
	andq	%rax, %rsi
	shrq	$51, %r11
	addq	%rcx, %r11
	movq	%r11, %rbx
	andq	%rax, %rbx
	shrq	$51, %r11
	addq	%rdx, %r11
	movq	%r11, %rdx
	andq	%rax, %rdx
	shrq	$51, %r11
	addq	%r8, %r11
	movq	%r11, %r14
	andq	%rax, %r14
	shrq	$51, %r11
	addq	%r10, %r11
	movq	%r11, %rcx
	shrq	$51, %rcx
	andq	%rax, %r11
	leaq	(%rcx,%rcx,8), %r8
	leaq	(%rcx,%r8,2), %r9
	addq	%rsi, %r9
	movq	%r9, %rcx
	andq	%rax, %rcx
	shrq	$51, %r9
	addq	%rbx, %r9
	movq	%r9, %r8
	shrq	$51, %r8
	addq	%rdx, %r8
	movq	%r8, %rsi
	shrq	$51, %rsi
	addq	%r14, %rsi
	movq	%rsi, %rdx
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %r10
	shrq	$51, %r10
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r11
	leaq	(%r11,%rcx), %r10
	movq	$0, -120(%rsp)
	movq	$0, -128(%rsp)
	movq	$0, -24(%rsp)
	movq	$0, -32(%rsp)
	movq	$0, -40(%rsp)
	movq	$0, -48(%rsp)
	movq	$0, -56(%rsp)
	movq	$0, -64(%rsp)
	movq	$0, -72(%rsp)
	andq	%rax, %r9
	andq	%rax, %r8
	andq	%rax, %rsi
	andq	%rax, %rdx
	leaq	(%rcx,%r11), %rbx
	addq	$19, %rbx
	movq	%rbx, %rcx
	shrq	$51, %rcx
	negq	%rcx
	leaq	(%rax,%rcx), %r14
	incq	%r14
	xorl	%ecx, %ecx
	movq	%r9, %r11
	subq	%r14, %r11
	movl	$0, %r14d
	sbbq	%r14, %r14
	movq	$0, -80(%rsp)
	#MEMBARRIER
	movabsq	$2251799813685248, %r13
	movq	%r11, %r15
	addq	%r13, %r15
	adcq	$0, %r14
	shldq	$13, %r15, %r14
	movq	%r10, 24(%rsp)
	negq	%r14
	leaq	(%rax,%r14), %r15
	incq	%r15
	movq	%r8, %r14
	subq	%r15, %r14
	movl	$0, %r15d
	sbbq	%r15, %r15
	movq	%r14, %r12
	addq	%r13, %r12
	adcq	$0, %r15
	movq	%r9, 16(%rsp)
	shldq	$13, %r12, %r15
	negq	%r15
	leaq	(%rax,%r15), %r12
	incq	%r12
	movq	%rsi, %r15
	subq	%r12, %r15
	movl	$0, %r12d
	sbbq	%r12, %r12
	movq	%r15, %rbp
	addq	%r13, %rbp
	adcq	$0, %r12
	shldq	$13, %rbp, %r12
	movq	%r8, 8(%rsp)
	andq	%rax, %r15
	andq	%rax, %r14
	andq	%rax, %r11
	andq	%rax, %rbx
	negq	%r12
	leaq	(%rax,%r12), %rbp
	incq	%rbp
	movq	%rdx, %r12
	subq	%rbp, %r12
	movl	$0, %ebp
	sbbq	%rbp, %rbp
	movq	%rsi, (%rsp)
	addq	%r12, %r13
	adcq	$0, %rbp
	movq	%rdx, -8(%rsp)
	andq	%rax, %r12
	shldq	$13, %r13, %rbp
	movl	$1, %r13d
	subq	%rbp, %r13
	movq	%rbx, -32(%rsp)
	movq	%r11, -48(%rsp)
	movq	%r14, -64(%rsp)
	movq	%r15, -80(%rsp)
	movq	%r12, 32(%rsp)
	movq	%r13, -128(%rsp)
	movq	-128(%rsp), %rbp
	movq	%rbp, %rax
	negq	%rax
	decq	%rbp
	andq	%rbx, %rbp
	andq	%r10, %rax
	orq	%rbp, %rax
	movq	%r13, -128(%rsp)
	movq	-128(%rsp), %rbx
	movq	%rbx, %r10
	negq	%r10
	decq	%rbx
	andq	%r11, %rbx
	andq	%r9, %r10
	orq	%rbx, %r10
	movq	%r13, -128(%rsp)
	movq	-128(%rsp), %r11
	movq	%r11, %r9
	negq	%r9
	decq	%r11
	andq	%r14, %r11
	andq	%r8, %r9
	orq	%r11, %r9
	movq	%r13, -128(%rsp)
	movq	-128(%rsp), %r8
	movq	%r8, %r11
	negq	%r11
	decq	%r8
	andq	%r15, %r8
	andq	%rsi, %r11
	orq	%r8, %r11
	movq	%r13, -128(%rsp)
	movq	-128(%rsp), %rsi
	movq	%rsi, %r8
	negq	%r8
	decq	%rsi
	andq	%r12, %rsi
	andq	%rdx, %r8
	orq	%rsi, %r8
	movq	%rax, -128(%rsp)
	movq	%r10, -120(%rsp)
	movq	%r9, -112(%rsp)
	movq	%r11, -104(%rsp)
	movq	%r8, -96(%rsp)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rdi)
	movups	%xmm0, (%rdi)
	movabsq	$-6872316419617283935, %rsi
	.p2align	4
.LBB79_1:
	leaq	1(%rcx), %r8
	movq	%rcx, %rax
	mulq	%rsi
	shrl	$5, %edx
	imull	$-51, %edx, %eax
	movq	%rcx, %rdx
	shrq	$3, %rdx
	movzbl	%cl, %r9d
	imull	$161, %r9d, %r9d
	shrl	$13, %r9d
	movq	-128(%rsp,%r9,8), %r9
	addl	%ecx, %eax
	btq	%rax, %r9
	setb	%al
	andb	$7, %cl
	shlb	%cl, %al
	orb	%al, (%rdi,%rdx)
	movq	%r8, %rcx
	cmpq	$255, %r8
	jne	.LBB79_1
	movq	$0, -128(%rsp)
	movq	$0, -120(%rsp)
	movq	$0, -112(%rsp)
	movq	$0, -104(%rsp)
	movq	$0, -96(%rsp)
	#MEMBARRIER
	movq	$0, -32(%rsp)
	movq	$0, -48(%rsp)
	movq	$0, -64(%rsp)
	movq	$0, -80(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, -8(%rsp)
	#MEMBARRIER
	addq	$40, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end79:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes, .Lfunc_end79-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB4_1S6reduce,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB4_1S6reduce,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB4_1S6reduce:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, -64(%rsp)
	movq	$0, -72(%rsp)
	movq	$0, -80(%rsp)
	movq	$0, -88(%rsp)
	movq	$0, -96(%rsp)
	movl	$511, %eax
	movabsq	$-1503914060200516823, %rdx
	movabsq	$-1152921504606846977, %r8
	.p2align	4
.LBB80_1:
	movq	%rax, %rcx
	shrq	$3, %rcx
	movzbl	(%rsi,%rcx), %ecx
	movl	%eax, %r9d
	andl	$7, %r9d
	xorl	%r10d, %r10d
	btl	%r9d, %ecx
	setb	%r10b
	movq	-72(%rsp), %r11
	leaq	(%r10,%r11,2), %rcx
	movq	%rcx, -32(%rsp)
	movq	-80(%rsp), %r10
	shrdq	$63, %r10, %r11
	movq	%r11, -40(%rsp)
	movq	-88(%rsp), %rbx
	shrdq	$63, %rbx, %r10
	movq	%r10, -48(%rsp)
	movq	-96(%rsp), %r9
	shldq	$1, %rbx, %r9
	movq	%r9, -56(%rsp)
	movq	%rcx, %r15
	movabsq	$-6346243789798364141, %rdi
	addq	%rdi, %r15
	movq	%r11, %rbp
	adcq	$0, %rbp
	movl	$0, %ebx
	adcq	$1, %rbx
	addq	%rdx, %rbp
	adcq	$-1, %rbx
	xorq	$1, %rbx
	movq	%r10, %r13
	subq	%rbx, %r13
	movl	$1, %ebx
	sbbq	$0, %rbx
	xorl	%r12d, %r12d
	addq	%r9, %rbx
	setb	%r12b
	addq	%r8, %rbx
	adcq	$0, %r12
	xorq	$1, %r12
	movq	%r12, -104(%rsp)
	movq	-104(%rsp), %r14
	movq	%r14, %rdi
	decq	%r14
	andq	%r15, %r14
	negq	%rdi
	andq	%rcx, %rdi
	orq	%r14, %rdi
	movq	%r12, -104(%rsp)
	movq	-104(%rsp), %rcx
	movq	%rcx, %r15
	decq	%rcx
	andq	%rbp, %rcx
	negq	%r15
	andq	%r11, %r15
	orq	%rcx, %r15
	movq	%r12, -104(%rsp)
	movq	-104(%rsp), %r11
	movq	%r11, %rcx
	decq	%r11
	andq	%r13, %r11
	negq	%rcx
	andq	%r10, %rcx
	orq	%r11, %rcx
	movq	%r12, -104(%rsp)
	movq	-104(%rsp), %r10
	movq	%r10, %r11
	decq	%r10
	andq	%rbx, %r10
	negq	%r11
	andq	%r9, %r11
	orq	%r10, %r11
	movq	$0, -104(%rsp)
	movq	$0, -8(%rsp)
	movq	$0, -16(%rsp)
	movq	$0, -24(%rsp)
	#MEMBARRIER
	movq	$0, -72(%rsp)
	movq	$0, -80(%rsp)
	movq	$0, -88(%rsp)
	movq	$0, -96(%rsp)
	#MEMBARRIER
	movq	%rdi, -72(%rsp)
	movq	%r15, -80(%rsp)
	movq	%rcx, -88(%rsp)
	movq	%r11, -96(%rsp)
	movq	$0, -32(%rsp)
	movq	$0, -40(%rsp)
	movq	$0, -48(%rsp)
	movq	$0, -56(%rsp)
	#MEMBARRIER
	addq	$-1, %rax
	jb	.LBB80_1
	movq	-72(%rsp), %rax
	movq	-64(%rsp), %rcx
	movq	%rax, (%rcx)
	movq	-80(%rsp), %rax
	movq	%rax, 8(%rcx)
	movq	-88(%rsp), %rax
	movq	%rax, 16(%rcx)
	movq	-96(%rsp), %rax
	movq	%rax, 24(%rcx)
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end80:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB4_1S6reduce, .Lfunc_end80-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB4_1S6reduce
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1400, %rsp
	.cfi_def_cfa_offset 1456
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r15
	movq	%rdx, %r13
	movl	%esi, %ebp
	movq	%rdi, %r12
	leaq	375(%rsp), %rdi
	movq	%r12, %rsi
	movq	%r8, %rdx
	movq	%r9, %rcx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey14representative
	movzbl	376(%rsp), %r14d
	cmpb	$1, 375(%rsp)
	je	.LBB81_10
	leaq	377(%rsp), %rsi
	leaq	889(%rsp), %rdi
	movl	$511, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movb	%r14b, 888(%rsp)
	movq	1544(%r12), %rdx
	leaq	-1(%rdx), %rax
	movq	%rax, %r12
	shrq	$3, %r12
	movl	%eax, %ecx
	andl	$7, %ecx
	cmpq	$1, %rcx
	sbbq	$-1, %r12
	movq	%rdx, %rsi
	shrq	$3, %rsi
	andl	$7, %edx
	xorl	%ecx, %ecx
	negq	%rdx
	sbbq	%rcx, %rcx
	subq	%rsi, %rcx
	leaq	512(%rcx), %rdi
	movl	$512, %esi
	subq	%r12, %rsi
	cmpq	%rdi, %rsi
	jb	.LBB81_38
	cmpq	$513, %rsi
	jae	.LBB81_38
	addq	%rsp, %rsi
	addq	$888, %rsi
	movq	%r12, %rdx
	negq	%rdx
	.p2align	4
.LBB81_4:
	cmpq	%rcx, %rdx
	je	.LBB81_7
	cmpb	$0, 1400(%rsp,%rcx)
	leaq	1(%rcx), %rcx
	je	.LBB81_4
.LBB81_6:
	movb	$5, %r14b
	jmp	.LBB81_10
.LBB81_7:
	movl	%ebp, %ecx
	shlb	$4, %cl
	addb	$32, %cl
	movzbl	%cl, %ebx
	leaq	2(,%rbx,2), %rcx
	movb	$5, %r14b
	cmpq	%rcx, %r12
	jb	.LBB81_10
	cmpb	$-68, 1399(%rsp)
	jne	.LBB81_10
	leaq	(,%r12,8), %rdx
	subq	%rax, %rdx
	movb	$8, %cl
	subb	%dl, %cl
	andb	$15, %cl
	movl	$255, %eax
	shll	%cl, %eax
	testb	%al, (%rsi)
	je	.LBB81_11
.LBB81_10:
	movl	%r14d, %eax
	addq	$1400, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB81_11:
	.cfi_def_cfa_offset 1456
	movq	%rdx, 120(%rsp)
	movq	%rsi, 8(%rsp)
	movq	%rbx, %r14
	notq	%r14
	addq	%r12, %r14
	leaq	-1(%r12), %rsi
	cmpq	%r14, %rsi
	jb	.LBB81_39
	movq	%r13, 112(%rsp)
	leaq	375(%rsp), %rdi
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	cmpq	$513, %r14
	jae	.LBB81_40
	movl	%ebp, 4(%rsp)
	movq	%rbx, 24(%rsp)
	cmpq	%r12, %r14
	ja	.LBB81_42
	movq	%r15, 104(%rsp)
	leaq	375(%rsp), %r12
	movq	%r12, %rdi
	movq	8(%rsp), %rbx
	movq	%rbx, %rsi
	movq	%r14, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, 16(%rsp)
	testq	%r14, %r14
	je	.LBB81_25
	movq	%rbx, %rsi
	movq	16(%rsp), %rbp
	addq	%rbp, %rsi
	xorl	%ebx, %ebx
	movzbl	4(%rsp), %eax
	movl	%eax, 8(%rsp)
	.p2align	4
.LBB81_16:
	movq	24(%rsp), %rcx
	cmpq	%rbp, %rcx
	movq	%rbp, %r15
	cmovbq	%rcx, %r15
	movl	%ebx, %eax
	bswapl	%eax
	movl	%eax, 244(%rsp)
	movq	%rsi, %r13
	movq	%rsi, 128(%rsp)
	movq	%rcx, 136(%rsp)
	leaq	244(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	$4, 152(%rsp)
	movl	$2, %ecx
	leaq	32(%rsp), %rdi
	movl	8(%rsp), %esi
	leaq	128(%rsp), %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest
	movzbl	33(%rsp), %r14d
	cmpb	$0, 32(%rsp)
	jne	.LBB81_10
	leaq	34(%rsp), %rax
	movdqu	(%rax), %xmm0
	movdqu	16(%rax), %xmm1
	movdqu	32(%rax), %xmm2
	movdqu	47(%rax), %xmm3
	leaq	312(%rsp), %rax
	movdqu	%xmm3, 47(%rax)
	movdqu	%xmm2, 32(%rax)
	movdqu	%xmm1, 16(%rax)
	movdqu	%xmm0, (%rax)
	movb	%r14b, 311(%rsp)
	cmpq	$33, %r15
	jae	.LBB81_19
	xorl	%eax, %eax
	movq	%r12, %rcx
	movq	%r13, %rsi
	jmp	.LBB81_21
	.p2align	4
.LBB81_19:
	leaq	-1(%r15), %rax
	cmpq	$64, %rax
	movl	$64, %ecx
	cmovaeq	%rcx, %rax
	incq	%rax
	movl	%eax, %ecx
	andl	$31, %ecx
	movl	$32, %edx
	cmoveq	%rdx, %rcx
	subq	%rcx, %rax
	leaq	(%r12,%rax), %rcx
	xorl	%edx, %edx
	movq	%r13, %rsi
	.p2align	4
.LBB81_20:
	movdqu	311(%rsp,%rdx), %xmm0
	movdqu	327(%rsp,%rdx), %xmm1
	movdqu	(%r12,%rdx), %xmm2
	pxor	%xmm0, %xmm2
	movdqu	16(%r12,%rdx), %xmm0
	pxor	%xmm1, %xmm0
	movdqu	%xmm2, (%r12,%rdx)
	movdqu	%xmm0, 16(%r12,%rdx)
	addq	$32, %rdx
	cmpq	%rdx, %rax
	jne	.LBB81_20
.LBB81_21:
	addq	%r15, %r12
	subq	%r15, %rbp
	incl	%ebx
	.p2align	4
.LBB81_22:
	cmpq	$64, %rax
	je	.LBB81_43
	movzbl	311(%rsp,%rax), %edx
	xorb	%dl, (%rcx)
	incq	%rax
	incq	%rcx
	cmpq	%r12, %rcx
	jne	.LBB81_22
	testq	%rbp, %rbp
	jne	.LBB81_16
.LBB81_25:
	movq	120(%rsp), %rcx
	andb	$7, %cl
	movzbl	375(%rsp), %eax
	shlb	%cl, %al
	shrb	%cl, %al
	movb	%al, 375(%rsp)
	movq	16(%rsp), %r13
	movq	%r13, %r12
	movq	24(%rsp), %r15
	subq	%r15, %r12
	leaq	-1(%r12), %rsi
	cmpq	$513, %rsi
	jae	.LBB81_41
	xorl	%eax, %eax
	movl	4(%rsp), %ecx
	movq	112(%rsp), %rdx
	.p2align	4
.LBB81_27:
	cmpq	%rax, %rsi
	je	.LBB81_30
	cmpb	$0, 375(%rsp,%rax)
	leaq	1(%rax), %rax
	je	.LBB81_27
	jmp	.LBB81_6
.LBB81_30:
	movb	$5, %r14b
	cmpb	$1, 375(%rsp,%rsi)
	jne	.LBB81_10
	movq	%rdx, 128(%rsp)
	movq	104(%rsp), %rax
	movq	%rax, 136(%rsp)
	movzbl	%cl, %ebx
	leaq	32(%rsp), %rdi
	leaq	128(%rsp), %rdx
	movl	$1, %ecx
	movl	%ebx, %esi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest
	movzbl	33(%rsp), %r14d
	cmpb	$1, 32(%rsp)
	je	.LBB81_10
	movdqu	34(%rsp), %xmm0
	movups	50(%rsp), %xmm1
	movdqu	66(%rsp), %xmm2
	movdqu	81(%rsp), %xmm3
	movdqu	%xmm3, 292(%rsp)
	movdqu	%xmm2, 277(%rsp)
	movups	%xmm1, 261(%rsp)
	movdqu	%xmm0, 245(%rsp)
	movb	%r14b, 244(%rsp)
	cmpq	%r15, %r13
	jb	.LBB81_44
	leaq	(%rsp,%r12), %rax
	addq	$375, %rax
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.38(%rip), %rcx
	movq	%rcx, 192(%rsp)
	movq	$8, 200(%rsp)
	leaq	244(%rsp), %rcx
	movq	%rcx, 208(%rsp)
	movq	%r15, 216(%rsp)
	movq	%rax, 224(%rsp)
	movq	%r15, 232(%rsp)
	leaq	32(%rsp), %rdi
	leaq	192(%rsp), %rdx
	movl	$3, %ecx
	movl	%ebx, %esi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest
	movzbl	33(%rsp), %r14d
	cmpb	$0, 32(%rsp)
	jne	.LBB81_10
	movdqu	34(%rsp), %xmm0
	movdqu	50(%rsp), %xmm1
	movdqu	66(%rsp), %xmm2
	movdqu	81(%rsp), %xmm3
	movdqu	%xmm3, 176(%rsp)
	movdqu	%xmm2, 161(%rsp)
	movdqu	%xmm1, 145(%rsp)
	movdqu	%xmm0, 129(%rsp)
	movb	%r14b, 128(%rsp)
	shll	$4, %ebx
	leaq	888(%rsp), %rax
	subq	%rbx, %rax
	addq	$481, %rax
	pxor	%xmm1, %xmm1
	xorl	%ecx, %ecx
	pxor	%xmm2, %xmm2
	pxor	%xmm0, %xmm0
.LBB81_35:
	movzwl	128(%rsp,%rcx), %edx
	movzwl	130(%rsp,%rcx), %esi
	xorw	-2(%rax,%rcx), %dx
	xorw	(%rax,%rcx), %si
	movd	%edx, %xmm3
	movd	%esi, %xmm4
	punpcklbw	%xmm1, %xmm3
	punpcklwd	%xmm1, %xmm3
	punpckldq	%xmm1, %xmm3
	por	%xmm3, %xmm2
	punpcklbw	%xmm1, %xmm4
	punpcklwd	%xmm1, %xmm4
	punpckldq	%xmm1, %xmm4
	por	%xmm4, %xmm0
	addq	$4, %rcx
	cmpq	%rcx, %r15
	jne	.LBB81_35
	por	%xmm2, %xmm0
	pxor	%xmm1, %xmm1
	pcmpeqd	%xmm0, %xmm1
	movmskps	%xmm1, %eax
	xorl	%ecx, %ecx
	xorl	$15, %eax
	setne	%cl
	movq	%rcx, 32(%rsp)
	cmpq	$0, 32(%rsp)
	movb	$5, %r14b
	jne	.LBB81_10
	movb	$-1, %r14b
	jmp	.LBB81_10
.LBB81_38:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.44(%rip), %rcx
	movl	$512, %edx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB81_39:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.43(%rip), %rcx
	movq	%r14, %rdi
	movq	%r12, %rdx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB81_40:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.42(%rip), %rcx
	movl	$512, %edx
	xorl	%edi, %edi
	movq	%r14, %rsi
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB81_41:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.40(%rip), %rcx
	movl	$512, %edx
	xorl	%edi, %edi
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB81_42:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.37(%rip), %rcx
	xorl	%edi, %edi
	movq	%r14, %rsi
	movq	%r12, %rdx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB81_43:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.41(%rip), %rdx
	movl	$64, %edi
	movl	$64, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB81_44:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.39(%rip), %rcx
	movl	$512, %edx
	movq	%r12, %rdi
	movq	%r13, %rsi
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Lfunc_end81:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss, .Lfunc_end81-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey14representative,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey14representative,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey14representative:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$3592, %rsp
	.cfi_def_cfa_offset 3648
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r15
	movq	%rdi, %rbx
	movq	1544(%rsi), %rax
	movq	%rax, %rcx
	shrq	$3, %rcx
	andl	$7, %eax
	cmpq	$1, %rax
	sbbq	$-1, %rcx
	cmpq	%rcx, %r15
	jne	.LBB82_23
	movq	%rdx, %r12
	movq	%rsi, %r14
	leaq	8(%rsp), %rdi
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	testq	%r15, %r15
	je	.LBB82_6
	decq	%r12
	leaq	-1(%r15), %rax
	xorl	%edx, %edx
	xorl	%esi, %esi
	.p2align	4
.LBB82_3:
	movq	%rsi, %rdi
	shrq	$3, %rdi
	cmpq	$512, %rsi
	je	.LBB82_21
	movzbl	(%r12,%r15), %r8d
	movl	%edx, %ecx
	andb	$48, %cl
	shlq	%cl, %r8
	orq	%r8, 8(%rsp,%rdi,8)
	cmpq	%rsi, %rax
	je	.LBB82_6
	leaq	2(%rsi), %rdi
	movzbl	-1(%r12,%r15), %r8d
	movl	%edx, %ecx
	andb	$48, %cl
	orb	$8, %cl
	shlq	%cl, %r8
	andq	$-8, %rsi
	orq	%r8, 8(%rsp,%rsi)
	addq	$16, %rdx
	addq	$-2, %r12
	movq	%rdi, %rsi
	cmpq	%rdi, %r15
	jne	.LBB82_3
.LBB82_6:
	leaq	520(%rsp), %rdi
	leaq	8(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	leaq	1032(%rsp), %rdi
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	1536(%r14), %rax
	testq	%rax, %rax
	je	.LBB82_12
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	xorl	%esi, %esi
	.p2align	4
.LBB82_8:
	cmpq	$64, %rsi
	je	.LBB82_22
	addq	(%r14,%rsi,8), %rcx
	adcq	$0, %rdx
	movq	520(%rsp,%rsi,8), %rdi
	subq	%rcx, %rdi
	movq	%rdi, 1032(%rsp,%rsi,8)
	leaq	1(%rsi), %rsi
	movl	$1, %edi
	sbbq	%rdx, %rdi
	movq	%rdi, %rcx
	xorq	$1, %rcx
	movl	$0, %edx
	cmpq	%rsi, %rax
	jne	.LBB82_8
	testq	%rdi, %rdi
	jne	.LBB82_12
	leaq	1032(%rsp), %rdi
	leaq	8(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
.LBB82_12:
	leaq	8(%rsp), %rdi
	leaq	1032(%rsp), %rsi
	movl	$512, %edx
	callq	*bcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB82_13
	movw	$1281, (%rbx)
	jmp	.LBB82_20
.LBB82_23:
	movw	$1, (%rbx)
	jmp	.LBB82_20
.LBB82_13:
	movq	%rbx, (%rsp)
	leaq	512(%r14), %rcx
	leaq	2568(%rsp), %rdi
	leaq	8(%rsp), %rdx
	movq	%r14, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul
	leaq	1024(%r14), %rsi
	leaq	3080(%rsp), %r12
	movl	$512, %edx
	movq	%r12, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movl	1560(%r14), %ebp
	movl	$33, %ebx
	leaq	520(%rsp), %r13
	movq	memcpy@GOTPCREL(%rip), %r15
	jmp	.LBB82_14
	.p2align	4
.LBB82_16:
	decl	%ebx
	cmpl	$1, %ebx
	jbe	.LBB82_17
.LBB82_14:
	movq	%r13, %rdi
	movq	%r14, %rsi
	movq	%r12, %rdx
	movq	%r12, %rcx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul
	movl	$512, %edx
	movq	%r12, %rdi
	movq	%r13, %rsi
	callq	*%r15
	leal	-2(%rbx), %eax
	movzbl	%al, %eax
	btl	%eax, %ebp
	jae	.LBB82_16
	movq	%r13, %rdi
	movq	%r14, %rsi
	movq	%r12, %rdx
	leaq	2568(%rsp), %rcx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul
	movl	$512, %edx
	movq	%r12, %rdi
	movq	%r13, %rsi
	callq	*%r15
	jmp	.LBB82_16
.LBB82_17:
	leaq	2064(%rsp), %rdi
	movq	memset@GOTPCREL(%rip), %rbx
	movl	$504, %edx
	xorl	%esi, %esi
	callq	*%rbx
	movq	$1, 2056(%rsp)
	leaq	520(%rsp), %rdi
	leaq	3080(%rsp), %rdx
	leaq	2056(%rsp), %rcx
	movq	%r14, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul
	leaq	1544(%rsp), %rdi
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*%rbx
	movl	$60, %eax
	leaq	536(%rsp), %rcx
	pxor	%xmm0, %xmm0
	.p2align	4
.LBB82_18:
	movdqu	-16(%rcx), %xmm1
	movdqu	(%rcx), %xmm2
	movdqa	%xmm1, %xmm3
	punpcklbw	%xmm0, %xmm3
	pshufd	$78, %xmm3, %xmm3
	pshuflw	$27, %xmm3, %xmm3
	pshufhw	$27, %xmm3, %xmm3
	punpckhbw	%xmm0, %xmm1
	pshufd	$78, %xmm1, %xmm1
	pshuflw	$27, %xmm1, %xmm1
	pshufhw	$27, %xmm1, %xmm1
	packuswb	%xmm3, %xmm1
	movdqa	%xmm2, %xmm3
	punpcklbw	%xmm0, %xmm3
	pshufd	$78, %xmm3, %xmm3
	pshuflw	$27, %xmm3, %xmm3
	pshufhw	$27, %xmm3, %xmm3
	punpckhbw	%xmm0, %xmm2
	pshufd	$78, %xmm2, %xmm2
	pshuflw	$27, %xmm2, %xmm2
	pshufhw	$27, %xmm2, %xmm2
	packuswb	%xmm3, %xmm2
	movdqu	%xmm1, 1560(%rsp,%rax,8)
	movdqu	%xmm2, 1544(%rsp,%rax,8)
	addq	$-4, %rax
	addq	$32, %rcx
	cmpq	$-4, %rax
	jne	.LBB82_18
	movq	(%rsp), %rbx
	leaq	1(%rbx), %rdi
	leaq	1544(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movb	$0, (%rbx)
.LBB82_20:
	addq	$3592, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB82_22:
	.cfi_def_cfa_offset 3648
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.59(%rip), %rdx
	movl	$64, %edi
	movl	$64, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB82_21:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.73(%rip), %rdx
	movl	$64, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end82:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey14representative, .Lfunc_end82-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey14representative
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey15from_components,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey15from_components
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey15from_components,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey15from_components:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	subq	$40, %rsp
	.cfi_def_cfa_offset 4192
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	leaq	-256(%rdx), %rax
	cmpq	$257, %rax
	jae	.LBB83_5
	movzbl	(%rsi), %eax
	testb	%al, %al
	sete	%r9b
	leaq	-5(%r8), %r10
	cmpq	$-4, %r10
	setb	%r10b
	orb	%r9b, %r10b
	jne	.LBB83_5
	cmpb	$0, (%rcx)
	je	.LBB83_5
	movzbl	(%rcx), %r9d
	cmpq	$1, %r8
	jne	.LBB83_7
	movl	%r9d, %ebx
	jmp	.LBB83_11
.LBB83_7:
	movzbl	1(%rcx), %r10d
	shll	$8, %r9d
	movl	%r9d, %ebx
	orl	%r10d, %ebx
	cmpq	$2, %r8
	jne	.LBB83_9
	movl	%r10d, %r9d
	jmp	.LBB83_11
.LBB83_9:
	movzbl	2(%rcx), %r9d
	shll	$8, %ebx
	orl	%r9d, %ebx
	cmpq	$3, %r8
	je	.LBB83_11
	movzbl	3(%rcx), %r9d
	shll	$8, %ebx
	orl	%r9d, %ebx
.LBB83_11:
	testb	$1, %r9b
	je	.LBB83_5
	movzbl	%al, %eax
	movl	$15, %ecx
	bsrl	%eax, %ecx
	xorl	$7, %ecx
	leaq	(,%rdx,8), %r14
	subq	%rcx, %r14
	cmpq	$2048, %r14
	jb	.LBB83_5
	cmpl	$2, %ebx
	jbe	.LBB83_5
	testb	$1, -1(%rsi,%rdx)
	jne	.LBB83_16
.LBB83_5:
	movw	$513, (%rdi)
.LBB83_6:
	movq	%rdi, %rax
	addq	$4136, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB83_16:
	.cfi_def_cfa_offset 4192
	movq	%rdi, (%rsp)
	addq	%rdx, %rsi
	movq	%rsi, %r12
	leaq	7(%rdx), %rbp
	shrq	$3, %rbp
	leaq	8(%rsp), %rdi
	xorl	%r15d, %r15d
	movq	%rdx, %r13
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	cmpq	$1, %r13
	jne	.LBB83_18
	movq	%r12, %rdx
	jmp	.LBB83_21
.LBB83_18:
	movq	%r13, %rax
	movl	%eax, %esi
	andl	$1022, %esi
	xorl	%r15d, %r15d
	movq	%r12, %rdx
	.p2align	4
.LBB83_19:
	movzbl	-1(%rdx), %edi
	leal	(,%r15,8), %ecx
	andb	$48, %cl
	shlq	%cl, %rdi
	movq	%r15, %r8
	andq	$-8, %r8
	orq	8(%rsp,%r8), %rdi
	movq	%rdi, 8(%rsp,%r8)
	addq	$2, %r15
	movzbl	-2(%rdx), %r9d
	orb	$8, %cl
	shlq	%cl, %r9
	addq	$-2, %rdx
	orq	%rdi, %r9
	movq	%r9, 8(%rsp,%r8)
	cmpq	%rsi, %r15
	jne	.LBB83_19
	testb	$1, %al
	je	.LBB83_22
.LBB83_21:
	movzbl	-1(%rdx), %eax
	leal	(,%r15,8), %ecx
	shlq	%cl, %rax
	andq	$-8, %r15
	orq	%rax, 8(%rsp,%r15)
.LBB83_22:
	movq	8(%rsp), %r15
	movl	$2, %eax
	movl	$2, %ecx
	subq	%r15, %rcx
	movq	%r15, %rdx
	imulq	%rcx, %rdx
	movl	$2, %esi
	subq	%rdx, %rsi
	imulq	%rcx, %rsi
	movq	%r15, %rcx
	imulq	%rsi, %rcx
	movl	$2, %edx
	subq	%rcx, %rdx
	imulq	%rsi, %rdx
	movq	%r15, %rcx
	imulq	%rdx, %rcx
	movl	$2, %esi
	subq	%rcx, %rsi
	imulq	%rdx, %rsi
	movq	%r15, %rcx
	imulq	%rsi, %rcx
	subq	%rcx, %rax
	imulq	%rsi, %rax
	imulq	%rax, %r15
	addq	$-2, %r15
	imulq	%rax, %r15
	leaq	1544(%rsp), %rdi
	leaq	8(%rsp), %rsi
	movl	$512, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbp, 3080(%rsp)
	movq	%r14, 3088(%rsp)
	movl	%ebx, 3104(%rsp)
	movq	%r15, 3096(%rsp)
	leaq	2056(%rsp), %rdi
	xorl	%r13d, %r13d
	movq	memset@GOTPCREL(%rip), %r14
	movl	$1024, %edx
	xorl	%esi, %esi
	callq	*%r14
	leaq	528(%rsp), %rdi
	movl	$504, %edx
	xorl	%esi, %esi
	callq	*%r14
	movq	$1, 520(%rsp)
	movq	%rbp, %rbx
	shlq	$7, %rbx
	leaq	520(%rsp), %r12
	jmp	.LBB83_24
	.p2align	4
.LBB83_23:
	cmpq	%rbx, %r13
	je	.LBB83_33
.LBB83_24:
	incq	%r13
	movl	$512, %edx
	leaq	1032(%rsp), %rdi
	xorl	%esi, %esi
	callq	*%r14
	movl	$1, %eax
	xorl	%r15d, %r15d
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB83_25:
	cmpq	$65, %rax
	je	.LBB83_34
	movq	%rcx, %rdi
	orq	$1, %rdi
	movq	512(%rsp,%rax,8), %r8
	movq	%r8, %rsi
	shrq	$63, %rsi
	addq	%r8, %r8
	addq	%r15, %r8
	adcq	%rdx, %rsi
	movq	%r8, 1024(%rsp,%rax,8)
	cmpq	%rbp, %rdi
	je	.LBB83_28
	addq	$2, %rcx
	movq	520(%rsp,%rax,8), %rdx
	movq	%rdx, %r15
	shrq	$63, %r15
	addq	%rdx, %rdx
	addq	%rsi, %rdx
	adcq	$0, %r15
	movq	%rdx, 1032(%rsp,%rax,8)
	addq	$2, %rax
	movl	$0, %edx
	cmpq	%rbp, %rcx
	jne	.LBB83_25
	jmp	.LBB83_29
	.p2align	4
.LBB83_28:
	movq	%rsi, %r15
.LBB83_29:
	movl	$512, %edx
	movq	%r12, %rdi
	xorl	%esi, %esi
	callq	*%r14
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	xorl	%edx, %edx
	.p2align	4
.LBB83_30:
	addq	1544(%rsp,%rdx,8), %rcx
	adcq	$0, %rax
	movq	1032(%rsp,%rdx,8), %rsi
	subq	%rcx, %rsi
	movq	%rsi, 520(%rsp,%rdx,8)
	leaq	1(%rdx), %rdx
	movl	$1, %esi
	sbbq	%rax, %rsi
	movq	%rsi, %rcx
	xorq	$1, %rcx
	movl	$0, %eax
	cmpq	%rdx, %rbp
	jne	.LBB83_30
	orq	%rsi, %r15
	jne	.LBB83_23
	movl	$512, %edx
	movq	%r12, %rdi
	leaq	1032(%rsp), %rsi
	callq	*memcpy@GOTPCREL(%rip)
	jmp	.LBB83_23
.LBB83_33:
	leaq	520(%rsp), %rsi
	movl	$512, %edx
	leaq	2056(%rsp), %rbx
	movq	%rbx, %rdi
	movq	memcpy@GOTPCREL(%rip), %r14
	callq	*%r14
	leaq	3120(%rsp), %rdi
	movl	$504, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	$1, 3112(%rsp)
	leaq	3624(%rsp), %r15
	leaq	1544(%rsp), %r12
	leaq	3112(%rsp), %rdx
	movq	%r15, %rdi
	movq	%r12, %rsi
	movq	%rbx, %rcx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul
	movl	$512, %edx
	leaq	2568(%rsp), %rdi
	movq	%r15, %rsi
	callq	*%r14
	movq	(%rsp), %rbx
	leaq	8(%rbx), %rdi
	movl	$1568, %edx
	movq	%r12, %rsi
	callq	*%r14
	movq	%rbx, %rdi
	movb	$0, (%rbx)
	jmp	.LBB83_6
.LBB83_34:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.45(%rip), %rdx
	movl	$64, %edi
	movl	$64, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end83:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey15from_components, .Lfunc_end83-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey15from_components
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1112, %rsp
	.cfi_def_cfa_offset 1168
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r15
	movq	%rdx, %r12
	movl	%esi, %ebp
	movq	%rdi, %rbx
	leaq	87(%rsp), %rdi
	movq	%rbx, %rsi
	movq	%r8, %rdx
	movq	%r9, %rcx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey14representative
	movzbl	88(%rsp), %r13d
	cmpb	$1, 87(%rsp)
	je	.LBB84_31
	leaq	89(%rsp), %rsi
	leaq	601(%rsp), %rdi
	movl	$511, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movb	%r13b, 600(%rsp)
	movq	1544(%rbx), %rax
	movq	%rax, %rbx
	shrq	$3, %rbx
	andl	$7, %eax
	cmpq	$1, %rax
	sbbq	$-1, %rbx
	movl	$512, %r14d
	subq	%rbx, %r14
	jb	.LBB84_32
	movq	%r12, (%rsp)
	movq	%r15, 8(%rsp)
	movzbl	%bpl, %r15d
	leaq	87(%rsp), %rdi
	movq	%rsp, %rdx
	movl	$1, %ecx
	movl	%r15d, %esi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3rsaNtB2_4Hash6digest
	movzbl	88(%rsp), %r13d
	cmpb	$0, 87(%rsp)
	jne	.LBB84_31
	movdqu	89(%rsp), %xmm0
	movdqu	105(%rsp), %xmm1
	movdqu	121(%rsp), %xmm2
	movdqu	136(%rsp), %xmm3
	movdqu	%xmm3, 71(%rsp)
	movdqu	%xmm2, 56(%rsp)
	movdqu	%xmm1, 40(%rsp)
	movdqu	%xmm0, 24(%rsp)
	movb	%r13b, 23(%rsp)
	movb	$48, 87(%rsp)
	movabsq	$92471539387469104, %rax
	movq	%rax, 89(%rsp)
	movl	$33817445, 97(%rsp)
	testb	%bpl, %bpl
	je	.LBB84_4
	cmpl	$1, %r15d
	jne	.LBB84_7
	movb	$0, 101(%rsp)
	movb	$2, %cl
	movl	$48, %eax
	movb	$65, %dl
	jmp	.LBB84_8
.LBB84_4:
	movb	$1, %cl
	movl	$32, %eax
	movb	$49, %dl
	jmp	.LBB84_8
.LBB84_7:
	movb	$3, %cl
	movl	$64, %eax
	movb	$81, %dl
.LBB84_8:
	movw	$5, 102(%rsp)
	movb	$4, 104(%rsp)
	movb	%dl, 88(%rsp)
	movb	%cl, 101(%rsp)
	movb	%al, 105(%rsp)
	movq	%rbx, %rdi
	subq	%rax, %rdi
	leaq	-22(%rdi), %rcx
	cmpq	$8, %rcx
	jb	.LBB84_16
	cmpq	$1, %rbx
	jbe	.LBB84_33
	leaq	(%rsp,%r14), %rcx
	addq	$600, %rcx
	cmpw	$256, (%rcx)
	jne	.LBB84_16
	addq	$-19, %rdi
	leaq	-1(%rdi), %rsi
	cmpq	$2, %rsi
	jb	.LBB84_34
	cmpq	%rbx, %rsi
	ja	.LBB84_34
	movq	%rbx, %rdx
	negq	%rdx
	.p2align	4
.LBB84_14:
	leaq	(%rax,%rdx), %r8
	cmpq	$-22, %r8
	je	.LBB84_17
	cmpb	$-1, 1114(%rsp,%rdx)
	leaq	1(%rdx), %rdx
	je	.LBB84_14
	jmp	.LBB84_16
.LBB84_17:
	cmpq	%rbx, %rsi
	jae	.LBB84_35
	cmpb	$0, (%rcx,%rsi)
	jne	.LBB84_16
	leaq	19(%rdi), %rsi
	movq	%rbx, %rdx
	subq	%rsi, %rdx
	setb	%r8b
	cmpq	$-20, %rdi
	ja	.LBB84_20
	testb	%r8b, %r8b
	jne	.LBB84_36
.LBB84_22:
	movdqu	(%rcx,%rdi), %xmm0
	movdqu	3(%rcx,%rdi), %xmm1
	movdqu	87(%rsp), %xmm2
	pcmpeqb	%xmm0, %xmm2
	movdqu	90(%rsp), %xmm0
	pcmpeqb	%xmm1, %xmm0
	pand	%xmm2, %xmm0
	pmovmskb	%xmm0, %ecx
	cmpl	$65535, %ecx
	jne	.LBB84_16
	cmpq	%rax, %rdx
	jne	.LBB84_16
	cmpq	%rsi, %rbx
	jne	.LBB84_26
	xorl	%eax, %eax
	jmp	.LBB84_29
.LBB84_26:
	movq	%rax, %rcx
	negq	%rcx
	addq	%rsp, %rcx
	addq	$1114, %rcx
	pxor	%xmm1, %xmm1
	xorl	%edx, %edx
	pxor	%xmm2, %xmm2
	pxor	%xmm0, %xmm0
.LBB84_27:
	movzwl	23(%rsp,%rdx), %esi
	movzwl	25(%rsp,%rdx), %edi
	xorw	-2(%rcx,%rdx), %si
	xorw	(%rcx,%rdx), %di
	movd	%esi, %xmm3
	movd	%edi, %xmm4
	punpcklbw	%xmm1, %xmm3
	punpcklwd	%xmm1, %xmm3
	punpckldq	%xmm1, %xmm3
	por	%xmm3, %xmm2
	punpcklbw	%xmm1, %xmm4
	punpcklwd	%xmm1, %xmm4
	punpckldq	%xmm1, %xmm4
	por	%xmm4, %xmm0
	addq	$4, %rdx
	cmpq	%rdx, %rax
	jne	.LBB84_27
	por	%xmm2, %xmm0
	pxor	%xmm1, %xmm1
	pcmpeqd	%xmm0, %xmm1
	movmskps	%xmm1, %ecx
	xorl	%eax, %eax
	xorl	$15, %ecx
	setne	%al
.LBB84_29:
	movq	%rax, (%rsp)
	cmpq	$0, (%rsp)
	je	.LBB84_30
.LBB84_16:
	movb	$5, %r13b
.LBB84_31:
	movl	%r13d, %eax
	addq	$1112, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB84_30:
	.cfi_def_cfa_offset 1168
	movb	$-1, %r13b
	jmp	.LBB84_31
.LBB84_32:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.50(%rip), %rcx
	movl	$512, %esi
	movl	$512, %edx
	movq	%r14, %rdi
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB84_33:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.46(%rip), %rcx
	movl	$2, %esi
	xorl	%edi, %edi
	movq	%rbx, %rdx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB84_34:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.49(%rip), %rcx
	movl	$2, %edi
	movq	%rbx, %rdx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB84_20:
	movb	$1, %r8b
	testb	%r8b, %r8b
	je	.LBB84_22
.LBB84_36:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.48(%rip), %rcx
	movq	%rbx, %rdx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB84_35:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.47(%rip), %rdx
	movq	%rsi, %rdi
	movq	%rbx, %rsi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end84:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5, .Lfunc_end84-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$2088, %rsp
	.cfi_def_cfa_offset 2144
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r12
	movq	%rdx, %r13
	movq	%rsi, %r15
	movq	%rdi, (%rsp)
	movq	1536(%rsi), %r14
	leaq	1048(%rsp), %rbp
	movl	$1040, %edx
	movq	%rbp, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	testq	%r14, %r14
	je	.LBB85_6
	xorl	%edi, %edi
	.p2align	4
.LBB85_2:
	cmpq	$64, %rdi
	je	.LBB85_33
	leaq	1(%rdi), %rsi
	movq	(%r13,%rdi,8), %rcx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB85_4:
	cmpq	$64, %r10
	je	.LBB85_5
	movq	%rcx, %rax
	mulq	(%r12,%r10,8)
	addq	(%rbp,%r10,8), %r8
	adcq	$0, %r9
	addq	%rax, %r8
	movq	%r8, (%rbp,%r10,8)
	movq	%r9, %r8
	adcq	%rdx, %r8
	incq	%r10
	movl	$0, %r9d
	cmpq	%r10, %r14
	jne	.LBB85_4
	addq	%r14, %rdi
	cmpq	$130, %rdi
	jae	.LBB85_32
	movq	%r8, 1048(%rsp,%rdi,8)
	addq	$8, %rbp
	movq	%rsi, %rdi
	cmpq	%r14, %rsi
	jne	.LBB85_2
	movq	1552(%r15), %rax
	movq	%rax, 8(%rsp)
	leaq	1048(%rsp), %r10
	movl	$1032, %r11d
	xorl	%esi, %esi
	xorl	%r13d, %r13d
	xorl	%ebp, %ebp
	.p2align	4
.LBB85_27:
	cmpq	$130, %rbp
	je	.LBB85_14
	leaq	1(%rbp), %rbx
	movq	1048(%rsp,%rbp,8), %rcx
	imulq	8(%rsp), %rcx
	leaq	130(%r13), %r9
	movq	%rsi, %rdi
	movq	%rsi, %r12
	movq	%rsi, %r8
	.p2align	4
.LBB85_29:
	cmpq	$64, %rdi
	je	.LBB85_18
	cmpq	%rdi, %r9
	je	.LBB85_25
	movq	%rcx, %rax
	mulq	(%r15,%rdi,8)
	addq	(%r10,%rdi,8), %r12
	adcq	$0, %r8
	addq	%rax, %r12
	movq	%r12, (%r10,%rdi,8)
	movq	%r8, %r12
	adcq	%rdx, %r12
	incq	%rdi
	movl	$0, %r8d
	cmpq	%rdi, %r14
	jne	.LBB85_29
	leaq	(%r14,%rbp), %rax
	leaq	(%r14,%r14), %rcx
	cmpq	%rax, %rcx
	setb	%cl
	cmpq	$130, %rax
	setae	%al
	orb	%cl, %al
	movq	%r14, %rax
	leaq	(,%r14,8), %rcx
	jne	.LBB85_23
	.p2align	4
.LBB85_21:
	addq	%r12, (%r10,%rcx)
	movq	%rsi, %r12
	adcq	$0, %r12
	cmpq	%rax, %rbp
	je	.LBB85_23
	decq	%rax
	cmpq	%rcx, %r11
	leaq	8(%rcx), %rcx
	jne	.LBB85_21
.LBB85_23:
	movq	%r12, 16(%rsp)
	movq	$0, 24(%rsp)
	testq	%r12, %r12
	jne	.LBB85_17
	decq	%r13
	addq	$8, %r10
	addq	$-8, %r11
	movq	%rbx, %rbp
	cmpq	%r14, %rbx
	jne	.LBB85_27
	leaq	536(%rsp), %rdi
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	cmpq	$65, %r14
	jb	.LBB85_7
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.51(%rip), %rcx
	movl	$64, %edx
	xorl	%edi, %edi
	movq	%r14, %rsi
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB85_6:
	leaq	536(%rsp), %rdi
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
.LBB85_7:
	leaq	(%rsp,%r14,8), %rsi
	addq	$1048, %rsi
	leaq	(,%r14,8), %rdx
	leaq	536(%rsp), %r12
	movq	memcpy@GOTPCREL(%rip), %rbx
	movq	%r12, %rdi
	callq	*%rbx
	leaq	16(%rsp), %rdi
	movl	$512, %edx
	movq	%r12, %rsi
	callq	*%rbx
	movq	%r14, %rax
	shlq	$4, %rax
	movq	1048(%rsp,%rax), %rbx
	movl	$512, %edx
	movq	(%rsp), %r12
	movq	%r12, %rdi
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	testq	%r14, %r14
	je	.LBB85_13
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	.p2align	4
.LBB85_9:
	addq	(%r15,%rdx,8), %rax
	adcq	$0, %rcx
	movq	16(%rsp,%rdx,8), %rsi
	subq	%rax, %rsi
	movq	%rsi, (%r12,%rdx,8)
	leaq	1(%rdx), %rdx
	movl	$1, %esi
	sbbq	%rcx, %rsi
	movq	%rsi, %rax
	xorq	$1, %rax
	movl	$0, %ecx
	cmpq	%rdx, %r14
	jne	.LBB85_9
	testq	%rbx, %rbx
	jne	.LBB85_13
	testq	%rsi, %rsi
	jne	.LBB85_13
	leaq	536(%rsp), %rsi
	movl	$512, %edx
	movq	%r12, %rdi
	callq	*memcpy@GOTPCREL(%rip)
.LBB85_13:
	addq	$2088, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB85_17:
	.cfi_def_cfa_offset 2144
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.18(%rip), %rdx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.53(%rip), %r9
	leaq	16(%rsp), %rsi
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedooECs1muTxUaRwMI_12toyos_crypto@GOTPCREL(%rip)
.LBB85_5:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.58(%rip), %rdx
	movl	$64, %edi
	movl	$64, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB85_25:
	subq	%r13, %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.55(%rip), %rdx
	movl	$130, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB85_18:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.54(%rip), %rdx
	movl	$64, %edi
	movl	$64, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB85_33:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.57(%rip), %rdx
	movl	$64, %edi
	movl	$64, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB85_32:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.56(%rip), %rdx
	movl	$130, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB85_14:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.52(%rip), %rdx
	movl	$130, %edi
	movl	$130, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end85:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul, .Lfunc_end85-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3rsaNtB4_9PublicKey3mul
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey3new,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey3new
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey3new,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey3new:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movl	%edx, %ebx
	movq	%rdi, %r14
	addq	$8, %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3new
	movl	$1, (%r14)
	movl	%ebx, 4(%r14)
	movq	%r14, %rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end86:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey3new, .Lfunc_end86-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey3new
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey4seal,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey4seal
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey4seal,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey4seal:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r14
	movq	%rdi, %rax
	movq	%r8, %rdx
	shrq	$32, %rdx
	je	.LBB87_1
	movw	$1, (%rax)
	jmp	.LBB87_6
.LBB87_1:
	cmpb	$0, (%rsi)
	je	.LBB87_8
	movq	%rcx, %r12
	movq	%r8, %r15
	movq	%rax, %rbp
	movl	4(%rsi), %ebx
	movq	%rbx, %rax
	bswapq	%rax
	movq	%rax, 8(%rsp)
	movq	%rsi, %r13
	leaq	40(%rsi), %rdi
	leaq	8(%rsp), %rsi
	movl	$4, %r8d
	xorl	%edx, %edx
	movq	%r14, %rcx
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor
	cmpb	$-1, %al
	jne	.LBB87_4
	leaq	8(%r13), %rdi
	leaq	8(%rsp), %rsi
	movl	$1, %edx
	movq	%r12, %rcx
	movq	%r15, %r8
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor
	cmpb	$-1, %al
	je	.LBB87_5
.LBB87_4:
	movq	%rbp, %rax
	movw	$1, (%rbp)
	jmp	.LBB87_6
.LBB87_8:
	movw	$1537, (%rax)
.LBB87_6:
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB87_5:
	.cfi_def_cfa_offset 80
	leaq	8(%rsp), %rdi
	leaq	8(%r13), %rsi
	movl	%ebx, %edx
	movq	%r14, %rcx
	movq	%r12, %r8
	movq	%r15, %r9
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3sshNtB2_4Keys3tag
	xorl	%eax, %eax
	movl	%ebx, %ecx
	incl	%ecx
	setne	%al
	movl	%eax, (%r13)
	movl	%ecx, 4(%r13)
	movups	8(%rsp), %xmm0
	movq	%rbp, %rax
	movups	%xmm0, 8(%rbp)
	movl	%ebx, 4(%rbp)
	movb	$0, (%rbp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	#MEMBARRIER
	jmp	.LBB87_6
.Lfunc_end87:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey4seal, .Lfunc_end87-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto3sshNtB4_10SealingKey4seal
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm:
.Lfunc_begin35:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception35
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$560, %rsp
	.cfi_def_cfa_offset 592
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movups	(%rsi), %xmm0
	movaps	%xmm0, (%rsp)
.Ltmp408:
	leaq	32(%rsp), %rdi
	movl	$16, %edx
	movl	$10, %ecx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand
.Ltmp409:
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 16(%rsp)
.Ltmp411:
	leaq	32(%rsp), %rdi
	leaq	16(%rsp), %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt
.Ltmp412:
	leaq	304(%rsp), %rdi
	leaq	32(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r14
	movl	$256, %edx
	callq	*%r14
	movaps	16(%rsp), %xmm0
	movaps	%xmm0, 288(%rsp)
	xorl	%ecx, %ecx
	movl	$1, %eax
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	movl	%ecx, %ebp
	shrb	%bpl
	andb	$1, %bpl
	leaq	288(%rsp), %rsi
	movl	$272, %edx
	movq	%rbx, %rdi
	callq	*%r14
	movb	%bpl, 272(%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$560, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB88_3:
	.cfi_def_cfa_offset 592
.Ltmp413:
	movq	%rax, %rbx
	leaq	16(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movl	$7, %eax
	.p2align	4
.LBB88_4:
	movb	$0, 25(%rsp,%rax)
	movb	$0, 26(%rsp,%rax)
	movb	$0, 27(%rsp,%rax)
	movb	$0, 28(%rsp,%rax)
	movb	$0, 29(%rsp,%rax)
	movb	$0, 30(%rsp,%rax)
	movb	$0, 31(%rsp,%rax)
	movb	$0, 32(%rsp,%rax)
	addq	$8, %rax
	cmpq	$247, %rax
	jne	.LBB88_4
	#MEMBARRIER
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB88_6:
.Ltmp410:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end88:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm, .Lfunc_end88-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm,"a",@progbits
	.p2align	2, 0x0
GCC_except_table88:
.Lexception35:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end35-.Lcst_begin35
.Lcst_begin35:
	.uleb128 .Ltmp408-.Lfunc_begin35
	.uleb128 .Ltmp409-.Ltmp408
	.uleb128 .Ltmp410-.Lfunc_begin35
	.byte	0
	.uleb128 .Ltmp411-.Lfunc_begin35
	.uleb128 .Ltmp412-.Ltmp411
	.uleb128 .Ltmp413-.Lfunc_begin35
	.byte	0
	.uleb128 .Ltmp412-.Lfunc_begin35
	.uleb128 .Lfunc_end88-.Ltmp412
	.byte	0
	.byte	0
.Lcst_end35:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm:
.Lfunc_begin36:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception36
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$576, %rsp
	.cfi_def_cfa_offset 608
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movaps	%xmm1, 16(%rsp)
	movaps	%xmm0, (%rsp)
.Ltmp414:
	leaq	48(%rsp), %rdi
	movl	$32, %edx
	movl	$14, %ecx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes6expand
.Ltmp415:
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 32(%rsp)
.Ltmp417:
	leaq	48(%rsp), %rdi
	leaq	32(%rsp), %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3aesNtB2_3Aes7encrypt
.Ltmp418:
	leaq	320(%rsp), %rdi
	leaq	48(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r14
	movl	$256, %edx
	callq	*%r14
	movaps	32(%rsp), %xmm0
	movaps	%xmm0, 304(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	movl	%ecx, %ebp
	shrb	%bpl
	andb	$1, %bpl
	leaq	304(%rsp), %rsi
	movl	$272, %edx
	movq	%rbx, %rdi
	callq	*%r14
	movb	%bpl, 272(%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$576, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB89_3:
	.cfi_def_cfa_offset 608
.Ltmp419:
	movq	%rax, %rbx
	leaq	32(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movl	$7, %eax
	.p2align	4
.LBB89_4:
	movb	$0, 41(%rsp,%rax)
	movb	$0, 42(%rsp,%rax)
	movb	$0, 43(%rsp,%rax)
	movb	$0, 44(%rsp,%rax)
	movb	$0, 45(%rsp,%rax)
	movb	$0, 46(%rsp,%rax)
	movb	$0, 47(%rsp,%rax)
	movb	$0, 48(%rsp,%rax)
	addq	$8, %rax
	cmpq	$247, %rax
	jne	.LBB89_4
	#MEMBARRIER
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB89_6:
.Ltmp416:
	movq	%rax, %rbx
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end89:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm, .Lfunc_end89-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm,"a",@progbits
	.p2align	2, 0x0
GCC_except_table89:
.Lexception36:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end36-.Lcst_begin36
.Lcst_begin36:
	.uleb128 .Ltmp414-.Lfunc_begin36
	.uleb128 .Ltmp415-.Ltmp414
	.uleb128 .Ltmp416-.Lfunc_begin36
	.byte	0
	.uleb128 .Ltmp417-.Lfunc_begin36
	.uleb128 .Ltmp418-.Ltmp417
	.uleb128 .Ltmp419-.Lfunc_begin36
	.byte	0
	.uleb128 .Ltmp418-.Lfunc_begin36
	.uleb128 .Lfunc_end89-.Ltmp418
	.byte	0
	.byte	0
.Lcst_end36:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey4open,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey4open
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey4open,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey4open:
.Lfunc_begin37:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception37
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpq	$16, 104(%rsp)
	jne	.LBB90_4
	movq	%r8, %rbx
	movq	%rcx, %r8
	movq	%rdx, %rcx
	movq	%rsi, %r15
	movq	%rdi, %r12
	movq	96(%rsp), %rbp
	cmpb	$2, 272(%rdi)
	jne	.LBB90_5
	movabsq	$274877906880, %rax
	cmpq	%rax, %r9
	ja	.LBB90_4
	movq	%r9, %r13
	movq	%r9, (%rsp)
	leaq	16(%rsp), %r14
	movq	%r14, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	movq	%rbx, %r9
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto4aead10chacha_tag
	movdqu	(%rbp), %xmm0
	pcmpeqb	16(%rsp), %xmm0
	pmovmskb	%xmm0, %eax
	xorl	%ecx, %ecx
	xorl	$65535, %eax
	setne	%cl
	movq	%rcx, 32(%rsp)
	cmpq	$0, 32(%rsp)
	movb	$1, %al
	jne	.LBB90_11
.Ltmp423:
	movq	%r12, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	movq	%r13, %rcx
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha3xor
.Ltmp424:
	jmp	.LBB90_11
.LBB90_5:
	movabsq	$68719476704, %rax
	cmpq	%rax, %r9
	seta	%al
	movq	%r8, %rdx
	shrq	$61, %rdx
	setne	%dl
	orb	%al, %dl
	je	.LBB90_9
.LBB90_4:
	xorl	%eax, %eax
	jmp	.LBB90_12
.LBB90_9:
	movq	%r9, %r13
	movq	%r9, (%rsp)
	leaq	16(%rsp), %r14
	movq	%r14, %rdi
	movq	%r12, %rsi
	movq	%r15, %rdx
	movq	%rbx, %r9
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3tag
	movdqu	(%rbp), %xmm0
	pcmpeqb	16(%rsp), %xmm0
	pmovmskb	%xmm0, %eax
	xorl	%ecx, %ecx
	xorl	$65535, %eax
	setne	%cl
	movq	%rcx, 32(%rsp)
	cmpq	$0, 32(%rsp)
	movb	$1, %al
	jne	.LBB90_11
.Ltmp420:
	movq	%r12, %rdi
	movq	%r15, %rsi
	movq	%rbx, %rdx
	movq	%r13, %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto3gcmNtB2_3Gcm3xor
	movb	$-1, %al
.Ltmp421:
.LBB90_11:
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
.LBB90_12:
	addq	$40, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB90_13:
	.cfi_def_cfa_offset 96
.Ltmp422:
	jmp	.LBB90_15
.LBB90_14:
.Ltmp425:
.LBB90_15:
	movq	%rax, %rbx
	movq	%r14, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj10_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end90:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey4open, .Lfunc_end90-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey4open
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4aeadNtB4_10OpeningKey4open,"a",@progbits
	.p2align	2, 0x0
GCC_except_table90:
.Lexception37:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end37-.Lcst_begin37
.Lcst_begin37:
	.uleb128 .Lfunc_begin37-.Lfunc_begin37
	.uleb128 .Ltmp423-.Lfunc_begin37
	.byte	0
	.byte	0
	.uleb128 .Ltmp423-.Lfunc_begin37
	.uleb128 .Ltmp424-.Ltmp423
	.uleb128 .Ltmp425-.Lfunc_begin37
	.byte	0
	.uleb128 .Ltmp424-.Lfunc_begin37
	.uleb128 .Ltmp420-.Ltmp424
	.byte	0
	.byte	0
	.uleb128 .Ltmp420-.Lfunc_begin37
	.uleb128 .Ltmp421-.Ltmp420
	.uleb128 .Ltmp422-.Lfunc_begin37
	.byte	0
	.uleb128 .Ltmp421-.Lfunc_begin37
	.uleb128 .Lfunc_end90-.Ltmp421
	.byte	0
	.byte	0
.Lcst_end37:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	24(%rdx), %rcx
	movq	%rcx, %r8
	bswapq	%r8
	movq	16(%rdx), %rax
	movq	%rax, %rbx
	bswapq	%rbx
	movq	8(%rdx), %r9
	movq	%r9, %r11
	bswapq	%r11
	movq	(%rdx), %rdx
	movq	%rdx, %r10
	bswapq	%r10
	movq	%rbx, -48(%rsp)
	cmpq	200(%rsi), %r8
	movl	$1, %r14d
	sbbq	$0, %r14
	subq	208(%rsi), %rbx
	movl	$1, %r15d
	sbbq	$0, %r15
	addq	%r14, %rbx
	adcq	$0, %r15
	addq	$-1, %rbx
	adcq	$-1, %r15
	movq	%r11, -56(%rsp)
	xorq	$-2, %r15
	subq	216(%rsi), %r11
	movq	%r10, -64(%rsp)
	movl	$1, %r14d
	sbbq	$0, %r14
	movl	$1, %ebx
	addq	%r15, %r11
	adcq	$-1, %r14
	addq	$1, %r11
	adcq	$0, %r14
	xorq	$-2, %r14
	subq	224(%rsi), %r10
	sbbq	$0, %rbx
	addq	%r14, %r10
	adcq	$-1, %rbx
	addq	$1, %r10
	adcq	$0, %rbx
	movq	%r8, -40(%rsp)
	orq	%rcx, %rax
	orq	%r9, %rax
	orq	%rdx, %rax
	movq	$0, -8(%rsp)
	movq	$0, -16(%rsp)
	movq	$0, -24(%rsp)
	movq	$0, -32(%rsp)
	#MEMBARRIER
	je	.LBB91_4
	testq	%rbx, %rbx
	jne	.LBB91_4
	movq	-40(%rsp), %rax
	movq	-48(%rsp), %rcx
	movq	-56(%rsp), %rdx
	movq	-64(%rsp), %rsi
	movq	%rax, 8(%rdi)
	movq	%rcx, 16(%rdi)
	movq	%rdx, 24(%rdi)
	movq	%rsi, 32(%rdi)
	movb	$0, (%rdi)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB91_4:
	.cfi_def_cfa_offset 32
	movw	$513, (%rdi)
	movq	$0, -40(%rsp)
	movq	$0, -48(%rsp)
	movq	$0, -56(%rsp)
	movq	$0, -64(%rsp)
	#MEMBARRIER
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end91:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_, .Lfunc_end91-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	40(%rdx), %r9
	movq	%r9, %rax
	bswapq	%rax
	movq	32(%rdx), %r8
	movq	%r8, %r11
	bswapq	%r11
	movq	24(%rdx), %rcx
	movq	%rcx, %rbx
	bswapq	%rbx
	cmpq	296(%rsi), %rax
	movq	16(%rdx), %r10
	movl	$1, %r14d
	sbbq	$0, %r14
	movq	%r11, -64(%rsp)
	subq	304(%rsi), %r11
	movl	$1, %r15d
	sbbq	$0, %r15
	addq	%r14, %r11
	movq	%r10, %r14
	bswapq	%r14
	adcq	$0, %r15
	addq	$-1, %r11
	adcq	$-1, %r15
	movq	%rbx, -72(%rsp)
	xorq	$-2, %r15
	subq	312(%rsi), %rbx
	movl	$1, %r12d
	sbbq	$0, %r12
	addq	%r15, %rbx
	movq	8(%rdx), %r11
	adcq	$-1, %r12
	movq	%r14, -80(%rsp)
	addq	$1, %rbx
	adcq	$0, %r12
	xorq	$-2, %r12
	subq	320(%rsi), %r14
	movl	$1, %ebx
	sbbq	$0, %rbx
	addq	%r12, %r14
	movq	%r11, %r15
	bswapq	%r15
	adcq	$-1, %rbx
	movq	%r15, -88(%rsp)
	addq	$1, %r14
	adcq	$0, %rbx
	xorq	$-2, %rbx
	subq	328(%rsi), %r15
	movl	$1, %r14d
	sbbq	$0, %r14
	addq	%rbx, %r15
	movq	(%rdx), %rdx
	adcq	$-1, %r14
	addq	$1, %r15
	movq	%rdx, %rbx
	bswapq	%rbx
	adcq	$0, %r14
	movq	%rbx, -96(%rsp)
	xorq	$-2, %r14
	subq	336(%rsi), %rbx
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%r14, %rbx
	adcq	$-1, %rsi
	addq	$1, %rbx
	adcq	$0, %rsi
	orq	%r9, %r8
	orq	%r10, %rcx
	orq	%r8, %rcx
	orq	%r11, %rcx
	orq	%rdx, %rcx
	movq	%rax, -56(%rsp)
	movq	$0, -8(%rsp)
	movq	$0, -16(%rsp)
	movq	$0, -24(%rsp)
	movq	$0, -32(%rsp)
	movq	$0, -40(%rsp)
	movq	$0, -48(%rsp)
	#MEMBARRIER
	je	.LBB92_4
	testq	%rsi, %rsi
	jne	.LBB92_4
	movq	-56(%rsp), %rax
	movq	-64(%rsp), %rcx
	movq	-72(%rsp), %rdx
	movq	-80(%rsp), %rsi
	movq	-88(%rsp), %r8
	movq	-96(%rsp), %r9
	movq	%rax, 8(%rdi)
	movq	%rcx, 16(%rdi)
	movq	%rdx, 24(%rdi)
	movq	%rsi, 32(%rdi)
	movq	%r8, 40(%rdi)
	movq	%r9, 48(%rdi)
	movb	$0, (%rdi)
	jmp	.LBB92_3
.LBB92_4:
	movw	$513, (%rdi)
	movq	$0, -56(%rsp)
	movq	$0, -64(%rsp)
	movq	$0, -72(%rsp)
	movq	$0, -80(%rsp)
	movq	$0, -88(%rsp)
	movq	$0, -96(%rsp)
	#MEMBARRIER
.LBB92_3:
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end92:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_, .Lfunc_end92-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI93_0:
	.long	989558401
	.long	989558401
	.long	989558401
	.long	989558401
.LCPI93_1:
	.long	3329
	.long	3329
	.long	3329
	.long	3329
.LCPI93_2:
	.long	1290168
	.long	1290168
	.long	1290168
	.long	1290168
	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt:
.Lfunc_begin38:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception38
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$72, %rsp
	.cfi_def_cfa_offset 128
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rbx
	movq	%rdi, 32(%rsp)
	movl	$128, %r14d
	movb	$1, %r10b
	movdqa	.LCPI93_0(%rip), %xmm0
	movdqa	.LCPI93_1(%rip), %xmm1
	pxor	%xmm2, %xmm2
	movdqa	.LCPI93_2(%rip), %xmm3
	movl	$2642262849, %r8d
	jmp	.LBB93_1
	.p2align	4
.LBB93_11:
	movq	%r14, %rax
	shrq	%rax
	cmpq	$3, %r14
	movq	%rax, %r14
	jbe	.LBB93_12
.LBB93_1:
	leaq	(%r14,%r14), %r9
	rep		bsfq	%r9, %rcx
	movl	$256, %edx
	shrq	%cl, %rdx
	leal	-1(%r9), %eax
	btl	$8, %eax
	movq	%rdx, %r12
	adcq	$0, %r12
	je	.LBB93_11
	addb	%r10b, %dl
	movq	%rdx, 40(%rsp)
	movq	%r9, %rax
	negq	%rax
	movq	%rax, 48(%rsp)
	leaq	(%rbx,%r9), %r13
	movq	%r14, %rdx
	negq	%rdx
	movq	%rbx, 16(%rsp)
	xorl	%r11d, %r11d
	movq	%r14, %rax
	xorl	%ebp, %ebp
	.p2align	4
.LBB93_3:
	movq	%r12, 64(%rsp)
	cmpq	$257, %rax
	movl	$256, %esi
	cmovaeq	%rax, %rsi
	movq	%rdx, 56(%rsp)
	leaq	(%rsi,%rdx), %rdi
	leaq	-1(%r14), %rdx
	cmpq	%rdx, %rdi
	cmovaeq	%rdx, %rdi
	movq	48(%rsp), %rcx
	movq	%r11, 24(%rsp)
	imulq	%r11, %rcx
	subq	%r14, %rcx
	addq	%rsi, %rcx
	cmpq	%rdx, %rcx
	movq	%rdx, %rsi
	cmovbq	%rcx, %rsi
	cmovaeq	%rdx, %rcx
	movb	%r10b, 15(%rsp)
	movl	%r10d, %r11d
	rolb	$4, %r11b
	movl	%r11d, %r15d
	andb	$51, %r15b
	shlb	$2, %r15b
	shrb	$2, %r11b
	andb	$51, %r11b
	orb	%r15b, %r11b
	movl	%r11d, %r15d
	andb	$85, %r15b
	addb	%r15b, %r15b
	shrb	%r11b
	andb	$84, %r11b
	orb	%r15b, %r11b
	shrb	%r11b
	je	.LBB93_4
	movzbl	%r11b, %r11d
	movw	$17, %r12w
	movw	$1, %r15w
	movq	%rbp, %r10
	jmp	.LBB93_24
	.p2align	4
.LBB93_26:
	movzwl	%r15w, %r15d
	movzwl	%r12w, %r12d
	imull	%r12d, %r15d
	imulq	$989558401, %r15, %rdx
	shrq	$32, %rdx
	movl	%r15d, %r10d
	subl	%edx, %r10d
	shrl	%r10d
	addl	%edx, %r10d
	shrl	$11, %r10d
	imull	$3329, %r10d, %edx
	movq	%rbp, %r10
	subl	%edx, %r15d
.LBB93_27:
	imull	%r12d, %r12d
	movq	%r12, %rdx
	imulq	%r8, %rdx
	shrq	$43, %rdx
	imull	$3329, %edx, %edx
	subl	%edx, %r12d
	shrl	%r11d
	je	.LBB93_13
.LBB93_24:
	testb	$1, %r11b
	jne	.LBB93_26
	movzwl	%r12w, %r12d
	jmp	.LBB93_27
	.p2align	4
.LBB93_13:
	movzwl	%r15w, %r15d
	movq	%r10, %r11
	cmpq	$7, %rsi
	ja	.LBB93_19
	jmp	.LBB93_15
	.p2align	4
.LBB93_4:
	movl	$1, %r15d
	movq	%rbp, %r10
	movq	%r10, %r11
	cmpq	$7, %rsi
	jbe	.LBB93_15
.LBB93_19:
	leaq	(,%r14,4), %r11
	imulq	24(%rsp), %r11
	leaq	(%r11,%r13), %rdx
	leaq	(%rbx,%r11), %r12
	leaq	(%r12,%rcx,2), %r10
	addq	$2, %r10
	cmpq	%r10, %rdx
	movq	%rbp, %r10
	jae	.LBB93_21
	leaq	(%rbx,%r9), %rdx
	addq	$2, %rdx
	addq	%rdx, %r11
	leaq	(%r11,%rcx,2), %rcx
	movq	%r10, %r11
	cmpq	%rcx, %r12
	jb	.LBB93_15
.LBB93_21:
	incq	%rsi
	movl	%esi, %ecx
	andl	$7, %ecx
	movl	$8, %edx
	cmoveq	%rdx, %rcx
	subq	%rcx, %rsi
	movq	%rsi, %r11
	addq	%r10, %r11
	movd	%r15d, %xmm4
	pshufd	$0, %xmm4, %xmm4
	subq	%rcx, %rdi
	incq	%rdi
	pslld	$16, %xmm4
	psrad	$16, %xmm4
	packssdw	%xmm4, %xmm4
	movq	16(%rsp), %rsi
	.p2align	4
.LBB93_22:
	movdqu	(%rsi,%r9), %xmm5
	movdqa	%xmm4, %xmm7
	pmulhuw	%xmm5, %xmm7
	pmullw	%xmm4, %xmm5
	movdqa	%xmm5, %xmm6
	punpcklwd	%xmm7, %xmm6
	punpckhwd	%xmm7, %xmm5
	movdqa	%xmm5, %xmm7
	pmuludq	%xmm0, %xmm7
	pshufd	$237, %xmm7, %xmm7
	pshufd	$245, %xmm5, %xmm8
	pmuludq	%xmm0, %xmm8
	pshufd	$237, %xmm8, %xmm8
	punpckldq	%xmm8, %xmm7
	movdqa	%xmm5, %xmm8
	psubd	%xmm7, %xmm8
	psrld	$1, %xmm8
	paddd	%xmm7, %xmm8
	psrld	$11, %xmm8
	pshufd	$245, %xmm8, %xmm7
	pmuludq	%xmm1, %xmm8
	pshufd	$232, %xmm8, %xmm8
	pmuludq	%xmm1, %xmm7
	pshufd	$232, %xmm7, %xmm7
	punpckldq	%xmm7, %xmm8
	psubd	%xmm8, %xmm5
	movdqa	%xmm6, %xmm7
	pmuludq	%xmm0, %xmm7
	pshufd	$237, %xmm7, %xmm7
	pshufd	$245, %xmm6, %xmm8
	pmuludq	%xmm0, %xmm8
	pshufd	$237, %xmm8, %xmm8
	punpckldq	%xmm8, %xmm7
	movdqa	%xmm6, %xmm8
	psubd	%xmm7, %xmm8
	psrld	$1, %xmm8
	paddd	%xmm7, %xmm8
	psrld	$11, %xmm8
	pshufd	$245, %xmm8, %xmm7
	pmuludq	%xmm1, %xmm8
	pshufd	$232, %xmm8, %xmm8
	pmuludq	%xmm1, %xmm7
	pshufd	$232, %xmm7, %xmm7
	punpckldq	%xmm7, %xmm8
	psubd	%xmm8, %xmm6
	movdqu	(%rsi), %xmm7
	movdqa	%xmm7, %xmm8
	punpckhwd	%xmm2, %xmm8
	punpcklwd	%xmm2, %xmm7
	movdqa	%xmm7, %xmm9
	psubd	%xmm6, %xmm9
	paddd	%xmm1, %xmm9
	movdqa	%xmm8, %xmm10
	psubd	%xmm5, %xmm10
	paddd	%xmm1, %xmm10
	movdqa	%xmm10, %xmm11
	pmuludq	%xmm0, %xmm11
	pshufd	$237, %xmm11, %xmm11
	pshufd	$245, %xmm10, %xmm12
	pmuludq	%xmm0, %xmm12
	pshufd	$237, %xmm12, %xmm12
	punpckldq	%xmm12, %xmm11
	movdqa	%xmm10, %xmm12
	psubd	%xmm11, %xmm12
	psrld	$1, %xmm12
	paddd	%xmm11, %xmm12
	psrld	$11, %xmm12
	pshufd	$245, %xmm12, %xmm11
	pmuludq	%xmm1, %xmm12
	pshufd	$232, %xmm12, %xmm12
	pmuludq	%xmm1, %xmm11
	pshufd	$232, %xmm11, %xmm11
	punpckldq	%xmm11, %xmm12
	psubd	%xmm12, %xmm10
	movdqa	%xmm9, %xmm11
	pmuludq	%xmm0, %xmm11
	pshufd	$237, %xmm11, %xmm11
	pshufd	$245, %xmm9, %xmm12
	pmuludq	%xmm0, %xmm12
	pshufd	$237, %xmm12, %xmm12
	punpckldq	%xmm12, %xmm11
	movdqa	%xmm9, %xmm12
	psubd	%xmm11, %xmm12
	psrld	$1, %xmm12
	paddd	%xmm11, %xmm12
	psrld	$11, %xmm12
	pshufd	$245, %xmm12, %xmm11
	pmuludq	%xmm1, %xmm12
	pshufd	$232, %xmm12, %xmm12
	pmuludq	%xmm1, %xmm11
	pshufd	$232, %xmm11, %xmm11
	punpckldq	%xmm11, %xmm12
	psubd	%xmm12, %xmm9
	packssdw	%xmm10, %xmm9
	movdqu	%xmm9, (%rsi,%r9)
	paddd	%xmm6, %xmm7
	paddd	%xmm5, %xmm8
	movdqa	%xmm8, %xmm5
	pmuludq	%xmm3, %xmm5
	pshufd	$237, %xmm5, %xmm5
	pshufd	$245, %xmm8, %xmm6
	pmuludq	%xmm3, %xmm6
	pshufd	$237, %xmm6, %xmm6
	punpckldq	%xmm6, %xmm5
	pmaddwd	%xmm1, %xmm5
	psubd	%xmm5, %xmm8
	movdqa	%xmm7, %xmm5
	pmuludq	%xmm3, %xmm5
	pshufd	$237, %xmm5, %xmm5
	pshufd	$245, %xmm7, %xmm6
	pmuludq	%xmm3, %xmm6
	pshufd	$237, %xmm6, %xmm6
	punpckldq	%xmm6, %xmm5
	pmaddwd	%xmm1, %xmm5
	psubd	%xmm5, %xmm7
	packssdw	%xmm8, %xmm7
	movdqu	%xmm7, (%rsi)
	addq	$16, %rsi
	addq	$-8, %rdi
	jne	.LBB93_22
.LBB93_15:
	addq	%r9, %r10
	movq	%r10, %rbp
	movq	64(%rsp), %r12
	decq	%r12
	movzbl	15(%rsp), %r10d
	incb	%r10b
	.p2align	4
.LBB93_16:
	leaq	(%r14,%r11), %rdi
	cmpq	$256, %rdi
	jae	.LBB93_17
	movzwl	(%r13,%r11,2), %ecx
	imull	%r15d, %ecx
	imulq	$989558401, %rcx, %rdx
	shrq	$32, %rdx
	movl	%ecx, %esi
	subl	%edx, %esi
	shrl	%esi
	addl	%edx, %esi
	shrl	$11, %esi
	imull	$3329, %esi, %edx
	subl	%edx, %ecx
	movzwl	(%rbx,%r11,2), %edx
	movl	%edx, %esi
	subl	%ecx, %esi
	addl	$3329, %esi
	imulq	$1290168, %rsi, %rdi
	shrq	$32, %rdi
	imull	$3329, %edi, %edi
	subl	%edi, %esi
	movw	%si, (%r13,%r11,2)
	addl	%edx, %ecx
	imulq	$1290168, %rcx, %rdx
	shrq	$32, %rdx
	imull	$3329, %edx, %edx
	subl	%edx, %ecx
	movw	%cx, (%rbx,%r11,2)
	incq	%r11
	cmpq	%r11, %rax
	jne	.LBB93_16
	addq	%r9, %rax
	movq	24(%rsp), %r11
	incq	%r11
	movq	56(%rsp), %rdx
	subq	%r9, %rdx
	leaq	(,%r14,4), %rcx
	addq	%rcx, 16(%rsp)
	testq	%r12, %r12
	jne	.LBB93_3
	movq	40(%rsp), %rax
	movl	%eax, %r10d
	jmp	.LBB93_11
.LBB93_12:
	movl	$512, %edx
	movq	32(%rsp), %r14
	movq	%r14, %rdi
	movq	%rbx, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%r14, %rax
	addq	$72, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB93_17:
	.cfi_def_cfa_offset 128
.Ltmp426:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.62(%rip), %rdx
	movl	$256, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp427:
	ud2
.LBB93_5:
.Ltmp428:
	xorl	%ecx, %ecx
	.p2align	4
.LBB93_6:
	movw	$0, (%rbx,%rcx)
	movw	$0, 2(%rbx,%rcx)
	movw	$0, 4(%rbx,%rcx)
	movw	$0, 6(%rbx,%rcx)
	movw	$0, 8(%rbx,%rcx)
	movw	$0, 10(%rbx,%rcx)
	movw	$0, 12(%rbx,%rcx)
	movw	$0, 14(%rbx,%rcx)
	addq	$16, %rcx
	cmpq	$512, %rcx
	jne	.LBB93_6
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end93:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt, .Lfunc_end93-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly3ntt,"a",@progbits
	.p2align	2, 0x0
GCC_except_table93:
.Lexception38:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end38-.Lcst_begin38
.Lcst_begin38:
	.uleb128 .Lfunc_begin38-.Lfunc_begin38
	.uleb128 .Ltmp426-.Lfunc_begin38
	.byte	0
	.byte	0
	.uleb128 .Ltmp426-.Lfunc_begin38
	.uleb128 .Ltmp427-.Ltmp426
	.uleb128 .Ltmp428-.Lfunc_begin38
	.byte	0
	.uleb128 .Ltmp427-.Lfunc_begin38
	.uleb128 .Lfunc_end93-.Ltmp427
	.byte	0
	.byte	0
.Lcst_end38:
	.p2align	2, 0x0

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI94_0:
	.long	1290168
	.long	1290168
	.long	1290168
	.long	1290168
.LCPI94_1:
	.long	3329
	.long	3329
	.long	3329
	.long	3329
	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly4plus,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly4plus
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly4plus,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly4plus:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$512, %rsp
	.cfi_def_cfa_offset 528
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	xorl	%eax, %eax
	pxor	%xmm0, %xmm0
	movdqa	.LCPI94_0(%rip), %xmm1
	movdqa	.LCPI94_1(%rip), %xmm2
	.p2align	4
.LBB94_1:
	movdqu	(%rsi,%rax,2), %xmm5
	movdqu	(%rdx,%rax,2), %xmm3
	movdqa	%xmm5, %xmm6
	punpckhwd	%xmm0, %xmm6
	punpcklwd	%xmm0, %xmm5
	movdqa	%xmm3, %xmm4
	punpckhwd	%xmm0, %xmm4
	paddd	%xmm6, %xmm4
	punpcklwd	%xmm0, %xmm3
	paddd	%xmm5, %xmm3
	movdqa	%xmm4, %xmm5
	pmuludq	%xmm1, %xmm5
	pshufd	$237, %xmm5, %xmm5
	pshufd	$245, %xmm4, %xmm6
	pmuludq	%xmm1, %xmm6
	pshufd	$237, %xmm6, %xmm6
	punpckldq	%xmm6, %xmm5
	pmaddwd	%xmm2, %xmm5
	psubd	%xmm5, %xmm4
	movdqa	%xmm3, %xmm5
	pmuludq	%xmm1, %xmm5
	pshufd	$237, %xmm5, %xmm5
	pshufd	$245, %xmm3, %xmm6
	pmuludq	%xmm1, %xmm6
	pshufd	$237, %xmm6, %xmm6
	punpckldq	%xmm6, %xmm5
	pmaddwd	%xmm2, %xmm5
	psubd	%xmm5, %xmm3
	packssdw	%xmm4, %xmm3
	movdqu	%xmm3, (%rsp,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB94_1
	movq	%rsp, %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, %rax
	addq	$512, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end94:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly4plus, .Lfunc_end94-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly4plus
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly6encode,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly6encode
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly6encode,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly6encode:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$24, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rcx, 8(%rsp)
	movq	%rsi, %rax
	shlq	$5, %rax
	movq	%rax, 16(%rsp)
	cmpq	%rax, %rcx
	jne	.LBB95_9
	movq	%rcx, %rbx
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %r12
	movq	%rdx, %rdi
	xorl	%esi, %esi
	movq	%rcx, %rdx
	callq	*memset@GOTPCREL(%rip)
	testq	%r15, %r15
	je	.LBB95_7
	xorl	%edx, %edx
	xorl	%eax, %eax
	.p2align	4
.LBB95_3:
	leaq	1(%rdx), %rsi
	xorl	%ecx, %ecx
	.p2align	4
.LBB95_4:
	leaq	(%rax,%rcx), %rdi
	shrq	$3, %rdi
	cmpq	%rbx, %rdi
	jae	.LBB95_8
	leaq	1(%rcx), %r8
	movzwl	(%r12,%rdx,2), %r9d
	movl	%ecx, %r10d
	andl	$15, %r10d
	btl	%r10d, %r9d
	setb	%r9b
	addl	%eax, %ecx
	andb	$7, %cl
	shlb	%cl, %r9b
	orb	%r9b, (%r14,%rdi)
	movq	%r8, %rcx
	cmpq	%r8, %r15
	jne	.LBB95_4
	addq	%r15, %rax
	movq	%rsi, %rdx
	cmpq	$256, %rsi
	jne	.LBB95_3
.LBB95_7:
	addq	$24, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB95_8:
	.cfi_def_cfa_offset 64
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.64(%rip), %rdx
	movq	%rbx, %rsi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB95_9:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.63(%rip), %r9
	leaq	8(%rsp), %rsi
	leaq	16(%rsp), %rdx
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCsgxBkk5gSRhY_4core9panicking13assert_failedjjEB4_@GOTPCREL(%rip)
.Lfunc_end95:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly6encode, .Lfunc_end95-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly6encode
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI96_0:
	.long	1290168
	.long	1290168
	.long	1290168
	.long	1290168
.LCPI96_1:
	.long	3329
	.long	3329
	.long	3329
	.long	3329
.LCPI96_2:
	.long	989558401
	.long	989558401
	.long	989558401
	.long	989558401
.LCPI96_3:
	.short	3303
	.short	3303
	.short	3303
	.short	3303
	.short	3303
	.short	3303
	.short	3303
	.short	3303
.LCPI96_4:
	.long	330282857
	.long	330282857
	.long	330282857
	.long	330282857
	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse:
.Lfunc_begin39:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception39
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$88, %rsp
	.cfi_def_cfa_offset 144
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %rbx
	movq	%rdi, 40(%rsp)
	movl	$2, %edx
	movb	$127, 15(%rsp)
	pxor	%xmm1, %xmm1
	movdqa	.LCPI96_0(%rip), %xmm2
	movdqa	.LCPI96_1(%rip), %xmm0
	movdqa	.LCPI96_2(%rip), %xmm3
	movl	$2642262849, %r10d
	jmp	.LBB96_1
	.p2align	4
.LBB96_2:
	cmpq	$65, %r11
	jae	.LBB96_3
.LBB96_1:
	movq	%rdx, %r11
	addq	%rdx, %rdx
	rep		bsfl	%edx, %ecx
	movl	$256, %esi
	shrl	%cl, %esi
	leal	-1(%rdx), %eax
	btl	$8, %eax
	adcq	$0, %rsi
	movq	%rsi, 16(%rsp)
	je	.LBB96_2
	movq	%rdx, %rax
	negq	%rax
	movq	%rax, 56(%rsp)
	leaq	(%rbx,%rdx), %r13
	leaq	(%rbx,%rdx), %rax
	addq	$2, %rax
	movq	%rax, 48(%rsp)
	leaq	(%rbx,%r11,2), %r9
	movq	%r11, %r8
	negq	%r8
	movq	%rbx, %rdi
	xorl	%eax, %eax
	xorl	%r15d, %r15d
	movq	%r11, %r14
	xorl	%ecx, %ecx
	.p2align	4
.LBB96_11:
	cmpq	$257, %r14
	movl	$256, %esi
	movq	%r14, 64(%rsp)
	cmovaeq	%r14, %rsi
	movq	%r8, 80(%rsp)
	addq	%rsi, %r8
	cmpq	$257, %rcx
	movl	$256, %r12d
	movq	%rcx, 24(%rsp)
	cmovaeq	%rcx, %r12
	movq	%rax, 72(%rsp)
	addq	%r12, %rax
	cmpq	%rax, %r8
	cmovbq	%r8, %rax
	leaq	-1(%r11), %rdx
	cmpq	%rdx, %rax
	cmovaeq	%rdx, %rax
	movq	56(%rsp), %r14
	movq	%r15, 32(%rsp)
	imulq	%r15, %r14
	addq	%r14, %r12
	subq	%r11, %r14
	addq	%rsi, %r14
	cmpq	%r12, %r14
	movq	%r12, %r8
	cmovbq	%r14, %r8
	cmpq	%rdx, %r8
	cmovaeq	%rdx, %r8
	cmpq	%r12, %r14
	cmovaeq	%r12, %r14
	cmpq	%rdx, %r14
	cmovaeq	%rdx, %r14
	movzbl	15(%rsp), %esi
	rolb	$4, %sil
	movl	%esi, %ebp
	andb	$51, %bpl
	shlb	$2, %bpl
	shrb	$2, %sil
	andb	$51, %sil
	orb	%bpl, %sil
	movl	%esi, %ebp
	andb	$85, %bpl
	addb	%bpl, %bpl
	shrb	%sil
	andb	$84, %sil
	orb	%bpl, %sil
	shrb	%sil
	je	.LBB96_12
	movzbl	%sil, %esi
	movw	$17, %bp
	movw	$1, %r12w
	jmp	.LBB96_24
	.p2align	4
.LBB96_31:
	movzwl	%r12w, %r12d
	movzwl	%bp, %ebp
	imull	%ebp, %r12d
	imulq	$989558401, %r12, %rdx
	shrq	$32, %rdx
	movl	%r12d, %r15d
	subl	%edx, %r15d
	shrl	%r15d
	addl	%edx, %r15d
	shrl	$11, %r15d
	imull	$3329, %r15d, %edx
	subl	%edx, %r12d
.LBB96_32:
	imull	%ebp, %ebp
	movq	%rbp, %rdx
	imulq	%r10, %rdx
	shrq	$43, %rdx
	imull	$3329, %edx, %edx
	subl	%edx, %ebp
	shrl	%esi
	je	.LBB96_13
.LBB96_24:
	testb	$1, %sil
	jne	.LBB96_31
	movzwl	%bp, %ebp
	jmp	.LBB96_32
	.p2align	4
.LBB96_13:
	movzwl	%r12w, %r12d
	movq	24(%rsp), %rcx
	movq	%rcx, %rsi
	cmpq	$7, %r8
	ja	.LBB96_18
	jmp	.LBB96_15
	.p2align	4
.LBB96_12:
	movl	$1, %r12d
	movq	24(%rsp), %rcx
	movq	%rcx, %rsi
	cmpq	$7, %r8
	jbe	.LBB96_15
.LBB96_18:
	leaq	(,%r11,4), %rbp
	imulq	32(%rsp), %rbp
	leaq	(%rbx,%rbp), %rsi
	movq	48(%rsp), %rdx
	addq	%rbp, %rdx
	leaq	(%rdx,%r14,2), %rdx
	cmpq	%rdx, %rsi
	jae	.LBB96_20
	leaq	(%rsi,%r14,2), %rdx
	addq	$2, %rdx
	addq	%r13, %rbp
	movq	%rcx, %rsi
	cmpq	%rdx, %rbp
	jb	.LBB96_15
.LBB96_20:
	incq	%r8
	movl	%r8d, %edx
	andl	$7, %edx
	movl	$8, %esi
	cmoveq	%rsi, %rdx
	subq	%rdx, %r8
	movq	%r8, %rsi
	addq	%rcx, %rsi
	movd	%r12d, %xmm4
	pshufd	$0, %xmm4, %xmm4
	subq	%rdx, %rax
	incq	%rax
	pslld	$16, %xmm4
	psrad	$16, %xmm4
	packssdw	%xmm4, %xmm4
	xorl	%r8d, %r8d
	.p2align	4
.LBB96_21:
	movdqu	(%rdi,%r8,2), %xmm7
	movdqa	%xmm7, %xmm8
	punpckhwd	%xmm1, %xmm8
	punpcklwd	%xmm1, %xmm7
	movdqu	(%r9,%r8,2), %xmm5
	movdqa	%xmm5, %xmm6
	punpckhwd	%xmm1, %xmm6
	punpcklwd	%xmm1, %xmm5
	movdqa	%xmm5, %xmm9
	paddd	%xmm7, %xmm9
	movdqa	%xmm6, %xmm10
	paddd	%xmm8, %xmm10
	movdqa	%xmm10, %xmm11
	pmuludq	%xmm2, %xmm11
	pshufd	$237, %xmm11, %xmm11
	pshufd	$245, %xmm10, %xmm12
	pmuludq	%xmm2, %xmm12
	pshufd	$237, %xmm12, %xmm12
	punpckldq	%xmm12, %xmm11
	pmaddwd	%xmm0, %xmm11
	psubd	%xmm11, %xmm10
	movdqa	%xmm9, %xmm11
	pmuludq	%xmm2, %xmm11
	pshufd	$237, %xmm11, %xmm11
	pshufd	$245, %xmm9, %xmm12
	pmuludq	%xmm2, %xmm12
	pshufd	$237, %xmm12, %xmm12
	punpckldq	%xmm12, %xmm11
	pmaddwd	%xmm0, %xmm11
	psubd	%xmm11, %xmm9
	packssdw	%xmm10, %xmm9
	movdqu	%xmm9, (%rdi,%r8,2)
	psubd	%xmm8, %xmm6
	psubd	%xmm7, %xmm5
	paddd	%xmm0, %xmm5
	paddd	%xmm0, %xmm6
	movdqa	%xmm6, %xmm7
	pmuludq	%xmm3, %xmm7
	pshufd	$237, %xmm7, %xmm7
	pshufd	$245, %xmm6, %xmm8
	pmuludq	%xmm3, %xmm8
	pshufd	$237, %xmm8, %xmm8
	punpckldq	%xmm8, %xmm7
	movdqa	%xmm6, %xmm8
	psubd	%xmm7, %xmm8
	psrld	$1, %xmm8
	paddd	%xmm7, %xmm8
	psrld	$11, %xmm8
	pshufd	$245, %xmm8, %xmm7
	pmuludq	%xmm0, %xmm8
	pshufd	$232, %xmm8, %xmm8
	pmuludq	%xmm0, %xmm7
	pshufd	$232, %xmm7, %xmm7
	punpckldq	%xmm7, %xmm8
	psubd	%xmm8, %xmm6
	movdqa	%xmm5, %xmm7
	pmuludq	%xmm3, %xmm7
	pshufd	$237, %xmm7, %xmm7
	pshufd	$245, %xmm5, %xmm8
	pmuludq	%xmm3, %xmm8
	pshufd	$237, %xmm8, %xmm8
	punpckldq	%xmm8, %xmm7
	movdqa	%xmm5, %xmm8
	psubd	%xmm7, %xmm8
	psrld	$1, %xmm8
	paddd	%xmm7, %xmm8
	psrld	$11, %xmm8
	pshufd	$245, %xmm8, %xmm7
	pmuludq	%xmm0, %xmm8
	pshufd	$232, %xmm8, %xmm8
	pmuludq	%xmm0, %xmm7
	pshufd	$232, %xmm7, %xmm7
	punpckldq	%xmm7, %xmm8
	psubd	%xmm8, %xmm5
	packssdw	%xmm6, %xmm5
	movdqa	%xmm5, %xmm7
	pmulhuw	%xmm4, %xmm7
	pmullw	%xmm4, %xmm5
	movdqa	%xmm5, %xmm6
	punpcklwd	%xmm7, %xmm6
	punpckhwd	%xmm7, %xmm5
	movdqa	%xmm5, %xmm7
	pmuludq	%xmm3, %xmm7
	pshufd	$237, %xmm7, %xmm7
	pshufd	$245, %xmm5, %xmm8
	pmuludq	%xmm3, %xmm8
	pshufd	$237, %xmm8, %xmm8
	punpckldq	%xmm8, %xmm7
	movdqa	%xmm5, %xmm8
	psubd	%xmm7, %xmm8
	psrld	$1, %xmm8
	paddd	%xmm7, %xmm8
	psrld	$11, %xmm8
	pshufd	$245, %xmm8, %xmm7
	pmuludq	%xmm0, %xmm8
	pshufd	$232, %xmm8, %xmm8
	pmuludq	%xmm0, %xmm7
	pshufd	$232, %xmm7, %xmm7
	punpckldq	%xmm7, %xmm8
	psubd	%xmm8, %xmm5
	movdqa	%xmm6, %xmm7
	pmuludq	%xmm3, %xmm7
	pshufd	$237, %xmm7, %xmm7
	pshufd	$245, %xmm6, %xmm8
	pmuludq	%xmm3, %xmm8
	pshufd	$237, %xmm8, %xmm8
	punpckldq	%xmm8, %xmm7
	movdqa	%xmm6, %xmm8
	psubd	%xmm7, %xmm8
	psrld	$1, %xmm8
	paddd	%xmm7, %xmm8
	psrld	$11, %xmm8
	pshufd	$245, %xmm8, %xmm7
	pmuludq	%xmm0, %xmm8
	pshufd	$232, %xmm8, %xmm8
	pmuludq	%xmm0, %xmm7
	pshufd	$232, %xmm7, %xmm7
	punpckldq	%xmm7, %xmm8
	psubd	%xmm8, %xmm6
	packssdw	%xmm5, %xmm6
	movdqu	%xmm6, (%r9,%r8,2)
	addq	$8, %r8
	cmpq	%r8, %rax
	jne	.LBB96_21
	movq	24(%rsp), %rcx
.LBB96_15:
	decq	16(%rsp)
	decb	15(%rsp)
	leaq	(%r11,%rcx), %r8
	addq	%r11, %rcx
	addq	%r11, %rcx
	.p2align	4
.LBB96_16:
	cmpq	$255, %rsi
	ja	.LBB96_17
	leaq	(%r11,%rsi), %rax
	cmpq	$255, %rax
	ja	.LBB96_28
	movzwl	(%rbx,%rsi,2), %edx
	movzwl	(%r13,%rsi,2), %eax
	leal	(%rax,%rdx), %r14d
	imulq	$1290168, %r14, %rbp
	shrq	$32, %rbp
	imull	$3329, %ebp, %ebp
	subl	%ebp, %r14d
	movw	%r14w, (%rbx,%rsi,2)
	subl	%edx, %eax
	addl	$3329, %eax
	imulq	$989558401, %rax, %rdx
	shrq	$32, %rdx
	movl	%eax, %ebp
	subl	%edx, %ebp
	shrl	%ebp
	addl	%edx, %ebp
	shrl	$11, %ebp
	imull	$3329, %ebp, %edx
	subl	%edx, %eax
	imull	%r12d, %eax
	imulq	$330282857, %rax, %rdx
	shrq	$40, %rdx
	imull	$3329, %edx, %edx
	subl	%edx, %eax
	movw	%ax, (%r13,%rsi,2)
	incq	%rsi
	cmpq	%rsi, %r8
	jne	.LBB96_16
	leaq	(%r11,%r11), %rdx
	movq	64(%rsp), %r14
	addq	%rdx, %r14
	movq	32(%rsp), %r15
	incq	%r15
	movq	80(%rsp), %r8
	subq	%rdx, %r8
	movq	72(%rsp), %rsi
	subq	%rdx, %rsi
	leaq	(,%r11,4), %rax
	addq	%rax, %r9
	addq	%rax, %rdi
	movq	%rsi, %rax
	cmpq	$0, 16(%rsp)
	jne	.LBB96_11
	jmp	.LBB96_2
.LBB96_3:
	xorl	%eax, %eax
	movdqa	.LCPI96_3(%rip), %xmm1
	movdqa	.LCPI96_4(%rip), %xmm2
	.p2align	4
.LBB96_4:
	movdqu	(%rbx,%rax,2), %xmm3
	movdqa	%xmm3, %xmm5
	pmulhuw	%xmm1, %xmm5
	pmullw	%xmm1, %xmm3
	movdqa	%xmm3, %xmm4
	punpcklwd	%xmm5, %xmm4
	punpckhwd	%xmm5, %xmm3
	pshufd	$245, %xmm3, %xmm5
	pmuludq	%xmm2, %xmm5
	psrlq	$40, %xmm5
	pmuludq	%xmm0, %xmm5
	pshufd	$232, %xmm5, %xmm5
	movdqa	%xmm3, %xmm6
	pmuludq	%xmm2, %xmm6
	pshufd	$245, %xmm6, %xmm6
	psrld	$8, %xmm6
	pmuludq	%xmm0, %xmm6
	pshufd	$232, %xmm6, %xmm6
	punpckldq	%xmm5, %xmm6
	psubd	%xmm6, %xmm3
	pshufd	$245, %xmm4, %xmm5
	pmuludq	%xmm2, %xmm5
	psrlq	$40, %xmm5
	pmuludq	%xmm0, %xmm5
	pshufd	$232, %xmm5, %xmm5
	movdqa	%xmm4, %xmm6
	pmuludq	%xmm2, %xmm6
	pshufd	$245, %xmm6, %xmm6
	psrld	$8, %xmm6
	pmuludq	%xmm0, %xmm6
	pshufd	$232, %xmm6, %xmm6
	punpckldq	%xmm5, %xmm6
	psubd	%xmm6, %xmm4
	packssdw	%xmm3, %xmm4
	movdqu	%xmm4, (%rbx,%rax,2)
	addq	$8, %rax
	cmpq	$256, %rax
	jne	.LBB96_4
	movl	$512, %edx
	movq	40(%rsp), %rdi
	movq	%rbx, %rsi
	addq	$88, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	jmpq	*memcpy@GOTPCREL(%rip)
.LBB96_17:
	.cfi_def_cfa_offset 144
	movq	%rsi, %rax
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.65(%rip), %rdx
	jmp	.LBB96_29
.LBB96_28:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.66(%rip), %rdx
.LBB96_29:
.Ltmp429:
	movl	$256, %esi
	movq	%rax, %rdi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp430:
	ud2
.LBB96_6:
.Ltmp431:
	xorl	%ecx, %ecx
	.p2align	4
.LBB96_7:
	movw	$0, (%rbx,%rcx)
	movw	$0, 2(%rbx,%rcx)
	movw	$0, 4(%rbx,%rcx)
	movw	$0, 6(%rbx,%rcx)
	movw	$0, 8(%rbx,%rcx)
	movw	$0, 10(%rbx,%rcx)
	movw	$0, 12(%rbx,%rcx)
	movw	$0, 14(%rbx,%rcx)
	addq	$16, %rcx
	cmpq	$512, %rcx
	jne	.LBB96_7
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end96:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse, .Lfunc_end96-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7inverse,"a",@progbits
	.p2align	2, 0x0
GCC_except_table96:
.Lexception39:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end39-.Lcst_begin39
.Lcst_begin39:
	.uleb128 .Lfunc_begin39-.Lfunc_begin39
	.uleb128 .Ltmp429-.Lfunc_begin39
	.byte	0
	.byte	0
	.uleb128 .Ltmp429-.Lfunc_begin39
	.uleb128 .Ltmp430-.Ltmp429
	.uleb128 .Ltmp431-.Lfunc_begin39
	.byte	0
	.uleb128 .Ltmp430-.Lfunc_begin39
	.uleb128 .Lfunc_end96-.Ltmp430
	.byte	0
	.byte	0
.Lcst_end39:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7product,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7product
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7product,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7product:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$512, %rsp
	.cfi_def_cfa_offset 560
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, %rbx
	movq	%rsp, %rdi
	xorl	%r12d, %r12d
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movl	$2642262849, %eax
	jmp	.LBB97_1
	.p2align	4
.LBB97_5:
	movzwl	(%r15,%r12,4), %r8d
	movzwl	(%r14,%r12,4), %edx
	movzwl	2(%r15,%r12,4), %edi
	movzwl	2(%r14,%r12,4), %esi
	movl	%edx, %r9d
	imull	%r8d, %r9d
	imulq	$989558401, %r9, %r10
	shrq	$32, %r10
	movl	%r9d, %r11d
	subl	%r10d, %r11d
	shrl	%r11d
	addl	%r10d, %r11d
	shrl	$11, %r11d
	imull	$3329, %r11d, %r10d
	subl	%r10d, %r9d
	movl	%esi, %r10d
	imull	%edi, %r10d
	imulq	$989558401, %r10, %r11
	shrq	$32, %r11
	movl	%r10d, %ebp
	subl	%r11d, %ebp
	shrl	%ebp
	addl	%r11d, %ebp
	shrl	$11, %ebp
	imull	$3329, %ebp, %r11d
	subl	%r11d, %r10d
	movzwl	%cx, %ecx
	imull	%r10d, %ecx
	imulq	$330282857, %rcx, %r10
	shrq	$40, %r10
	imull	$3329, %r10d, %r10d
	subl	%r10d, %ecx
	addl	%r9d, %ecx
	leal	-3329(%rcx), %r9d
	cmpl	$3329, %ecx
	cmovbl	%ecx, %r9d
	movw	%r9w, (%rsp,%r12,4)
	imull	%r8d, %esi
	imulq	$989558401, %rsi, %rcx
	shrq	$32, %rcx
	movl	%esi, %r8d
	subl	%ecx, %r8d
	shrl	%r8d
	addl	%ecx, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %ecx
	subl	%ecx, %esi
	imull	%edi, %edx
	imulq	$989558401, %rdx, %rcx
	shrq	$32, %rcx
	movl	%edx, %edi
	subl	%ecx, %edi
	shrl	%edi
	addl	%ecx, %edi
	shrl	$11, %edi
	imull	$3329, %edi, %ecx
	subl	%ecx, %edx
	leal	(%rsi,%rdx), %ecx
	cmpl	$3329, %ecx
	leal	-3329(%rsi,%rdx), %edx
	cmovbl	%ecx, %edx
	movw	%dx, 2(%rsp,%r12,4)
	incq	%r12
	cmpq	$128, %r12
	je	.LBB97_6
.LBB97_1:
	movl	%r12d, %ecx
	rolb	$4, %cl
	orb	$8, %cl
	movl	%ecx, %edx
	andb	$51, %dl
	shlb	$2, %dl
	shrb	$2, %cl
	andb	$51, %cl
	orb	%dl, %cl
	movl	%ecx, %edx
	andb	$85, %dl
	addb	%dl, %dl
	shrb	%cl
	andb	$85, %cl
	orb	%dl, %cl
	movzbl	%cl, %edx
	movw	$1, %cx
	movw	$17, %si
	jmp	.LBB97_2
	.p2align	4
.LBB97_4:
	imull	%esi, %esi
	movq	%rsi, %rdi
	imulq	%rax, %rdi
	shrq	$43, %rdi
	imull	$3329, %edi, %edi
	subl	%edi, %esi
	shrl	%edx
	je	.LBB97_5
.LBB97_2:
	movzwl	%si, %esi
	testb	$1, %dl
	je	.LBB97_4
	movzwl	%cx, %ecx
	imull	%esi, %ecx
	imulq	$989558401, %rcx, %rdi
	shrq	$32, %rdi
	movl	%ecx, %r8d
	subl	%edi, %r8d
	shrl	%r8d
	addl	%edi, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %edi
	subl	%edi, %ecx
	jmp	.LBB97_4
.LBB97_6:
	movq	%rsp, %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbx, %rax
	addq	$512, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end97:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7product, .Lfunc_end97-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB4_4Poly7product
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new:
.Lfunc_begin40:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception40
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$248, %rsp
	.cfi_def_cfa_offset 304
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rcx, %r12
	movq	%rsi, %r14
	movq	%rdi, %rbx
	cmpq	$72, %rsi
	je	.LBB98_3
	cmpl	$136, %r14d
	je	.LBB98_3
	cmpl	$168, %r14d
	jne	.LBB98_20
.LBB98_3:
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 208(%rsp)
	movaps	%xmm0, 192(%rsp)
	movaps	%xmm0, 176(%rsp)
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm0, 128(%rsp)
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movq	$0, 224(%rsp)
	movq	%r14, 232(%rsp)
	movq	$0, 240(%rsp)
	testq	%r8, %r8
	je	.LBB98_4
	movl	%edx, 4(%rsp)
	movq	%rbx, 16(%rsp)
	shlq	$4, %r8
	addq	%r12, %r8
	xorl	%ecx, %ecx
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.69(%rip), %rax
	movq	%rax, 8(%rsp)
	leaq	32(%rsp), %r13
	movq	%r8, 24(%rsp)
	jmp	.LBB98_8
	.p2align	4
.LBB98_7:
	addq	$16, %r12
	movq	24(%rsp), %r8
	cmpq	%r8, %r12
	je	.LBB98_14
.LBB98_8:
	movq	8(%r12), %rbx
	testq	%rbx, %rbx
	je	.LBB98_7
	movq	(%r12), %rbp
	xorl	%r15d, %r15d
	jmp	.LBB98_10
	.p2align	4
.LBB98_13:
	incq	%r15
	cmpq	%r15, %rbx
	je	.LBB98_7
.LBB98_10:
	movq	%rcx, %rdi
	shrq	$3, %rdi
	cmpq	$199, %rcx
	ja	.LBB98_18
	movzbl	(%rbp,%r15), %eax
	shll	$3, %ecx
	shlq	%cl, %rax
	xorq	%rax, 32(%rsp,%rdi,8)
	movq	240(%rsp), %rcx
	incq	%rcx
	movq	%rcx, 240(%rsp)
	cmpq	%r14, %rcx
	jne	.LBB98_13
	movq	%r13, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 240(%rsp)
	xorl	%ecx, %ecx
	jmp	.LBB98_13
.LBB98_14:
	movq	%rcx, %rdi
	shrq	$3, %rdi
	cmpq	$200, %rcx
	jae	.LBB98_17
	movq	16(%rsp), %rbx
	movl	4(%rsp), %edx
	jmp	.LBB98_5
.LBB98_4:
	xorl	%edi, %edi
	xorl	%ecx, %ecx
.LBB98_5:
	movzbl	%dl, %eax
	shll	$3, %ecx
	shlq	%cl, %rax
	xorq	%rax, 32(%rsp,%rdi,8)
	decq	%r14
	leal	(,%r14,8), %ecx
	movl	$128, %eax
	shlq	%cl, %rax
	andq	$-8, %r14
	xorq	%rax, 32(%rsp,%r14)
	leaq	32(%rsp), %r14
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 240(%rsp)
	movl	$216, %edx
	movq	%rbx, %rdi
	movq	%r14, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	addq	$248, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB98_17:
	.cfi_def_cfa_offset 304
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.70(%rip), %rax
	movq	%rax, 8(%rsp)
.LBB98_18:
.Ltmp432:
	movl	$25, %esi
	movq	8(%rsp), %rdx
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp433:
	ud2
.LBB98_20:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.67(%rip), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.68(%rip), %rdx
	movl	$48, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking5panic@GOTPCREL(%rip)
.LBB98_16:
.Ltmp434:
	movq	%rax, %rbx
	leaq	32(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end98:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new, .Lfunc_end98-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new,"a",@progbits
	.p2align	2, 0x0
GCC_except_table98:
.Lexception40:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end40-.Lcst_begin40
.Lcst_begin40:
	.uleb128 .Lfunc_begin40-.Lfunc_begin40
	.uleb128 .Ltmp432-.Lfunc_begin40
	.byte	0
	.byte	0
	.uleb128 .Ltmp432-.Lfunc_begin40
	.uleb128 .Ltmp433-.Ltmp432
	.uleb128 .Ltmp434-.Lfunc_begin40
	.byte	0
	.uleb128 .Ltmp433-.Lfunc_begin40
	.uleb128 .Lfunc_end98-.Ltmp433
	.byte	0
	.byte	0
.Lcst_end40:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute,"ax",@progbits
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$920, %rsp
	.cfi_def_cfa_offset 976
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbp
	movq	$0, 288(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 712(%rsp)
	movq	$24, 720(%rsp)
	leaq	728(%rsp), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.72(%rip), %rsi
	movl	$192, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movq	120(%rbp), %rbx
	movq	(%rbp), %rax
	movq	%rax, 128(%rsp)
	movq	8(%rbp), %rax
	movq	%rax, 168(%rsp)
	movq	160(%rbp), %rdi
	movq	128(%rbp), %rdx
	movq	168(%rbp), %rax
	movq	%rax, 112(%rsp)
	movq	136(%rbp), %rax
	movq	%rax, 104(%rsp)
	movq	176(%rbp), %rax
	movq	%rax, 96(%rsp)
	movq	144(%rbp), %rax
	movq	%rax, 88(%rsp)
	movq	104(%rbp), %rax
	movq	%rax, 80(%rsp)
	movq	184(%rbp), %rcx
	movq	152(%rbp), %rsi
	movq	112(%rbp), %rax
	movq	%rax, 72(%rsp)
	movq	192(%rbp), %rax
	movq	%rax, 64(%rsp)
	movq	80(%rbp), %rax
	movq	%rax, 32(%rsp)
	movq	40(%rbp), %rax
	movq	%rax, 120(%rsp)
	movq	%rdx, %rax
	movq	%rsi, %rdx
	movq	88(%rbp), %r8
	movq	48(%rbp), %rsi
	movq	%rsi, 40(%rsp)
	movq	96(%rbp), %rsi
	movq	56(%rbp), %r9
	movq	%r9, 56(%rsp)
	movq	16(%rbp), %r9
	movq	%r9, 152(%rsp)
	movq	64(%rbp), %r9
	movq	%r9, 48(%rsp)
	movq	24(%rbp), %r15
	movq	72(%rbp), %r13
	movq	%rbp, 424(%rsp)
	movq	32(%rbp), %r9
	movq	%r9, 160(%rsp)
	movl	$2, %r12d
	.p2align	4
.LBB99_1:
	movq	%rdx, 136(%rsp)
	movq	%rbx, 24(%rsp)
	movq	%rax, 16(%rsp)
	movq	%rdi, 8(%rsp)
	movq	%rcx, 144(%rsp)
	movq	%r12, 592(%rsp)
	movq	32(%rsp), %rbp
	xorq	%rbx, %rbp
	movq	%rdi, %r10
	xorq	120(%rsp), %r10
	xorq	%rbp, %r10
	movq	112(%rsp), %rbp
	xorq	%rax, %rbp
	movq	%r8, %rax
	xorq	40(%rsp), %rax
	xorq	%rbp, %rax
	movq	96(%rsp), %rbp
	xorq	104(%rsp), %rbp
	movq	%rsi, %rbx
	xorq	56(%rsp), %rbx
	xorq	%rbp, %rbx
	movq	80(%rsp), %rbp
	xorq	88(%rsp), %rbp
	movq	%rcx, %rdi
	xorq	48(%rsp), %rdi
	xorq	%rbp, %rdi
	movq	72(%rsp), %rbp
	xorq	%rdx, %rbp
	movq	64(%rsp), %rcx
	xorq	%r13, %rcx
	xorq	%rbp, %rcx
	xorq	128(%rsp), %r10
	movq	168(%rsp), %rdx
	xorq	%rdx, %rax
	movq	152(%rsp), %r14
	xorq	%r14, %rbx
	xorq	%r15, %rdi
	movq	%rax, %r9
	rolq	%r9
	movq	160(%rsp), %r12
	xorq	%r12, %rcx
	movq	%r15, %r11
	movq	%r14, %r15
	movq	%rbx, %rbp
	rolq	%rbp
	xorq	%rcx, %r9
	movq	%rdi, %r14
	rolq	%r14
	xorq	%r10, %rbp
	movq	%rcx, 552(%rsp)
	rolq	%rcx
	movq	%rax, 568(%rsp)
	xorq	%rax, %r14
	movq	%r10, 576(%rsp)
	rolq	%r10
	movq	%rbx, 544(%rsp)
	xorq	%rbx, %rcx
	movq	%rdi, 560(%rsp)
	xorq	%rdi, %r10
	movq	128(%rsp), %rax
	xorq	%r9, %rax
	movq	%rax, 248(%rsp)
	xorq	%rbp, %rdx
	rolq	%rdx
	movq	%rdx, 232(%rsp)
	xorq	%r14, %r15
	rolq	$62, %r15
	movq	%r15, 584(%rsp)
	xorq	%rcx, %r11
	rolq	$28, %r11
	movq	%r11, 240(%rsp)
	xorq	%r10, %r12
	rolq	$27, %r12
	movq	%r12, 216(%rsp)
	movq	120(%rsp), %rax
	xorq	%r9, %rax
	rolq	$36, %rax
	movq	%rax, 176(%rsp)
	movq	40(%rsp), %rbx
	xorq	%rbp, %rbx
	rolq	$44, %rbx
	movq	56(%rsp), %rax
	xorq	%r14, %rax
	rolq	$6, %rax
	movq	%rax, 224(%rsp)
	movq	48(%rsp), %rax
	xorq	%rcx, %rax
	rolq	$55, %rax
	movq	%rax, 184(%rsp)
	xorq	%r10, %r13
	movq	%r13, %rdi
	rolq	$20, %rdi
	movq	32(%rsp), %r13
	xorq	%r9, %r13
	rolq	$3, %r13
	xorq	%rbp, %r8
	rolq	$10, %r8
	movq	%r8, 208(%rsp)
	xorq	%r14, %rsi
	rolq	$43, %rsi
	movq	80(%rsp), %rax
	xorq	%rcx, %rax
	rolq	$25, %rax
	movq	%rax, 200(%rsp)
	movq	72(%rsp), %rax
	xorq	%r10, %rax
	rolq	$39, %rax
	movq	%rax, 192(%rsp)
	movq	24(%rsp), %rax
	xorq	%r9, %rax
	rolq	$41, %rax
	movq	%rax, 24(%rsp)
	movq	16(%rsp), %r8
	xorq	%rbp, %r8
	rolq	$45, %r8
	movq	104(%rsp), %rax
	xorq	%r14, %rax
	rolq	$15, %rax
	movq	%rax, 16(%rsp)
	movq	88(%rsp), %r11
	xorq	%rcx, %r11
	rolq	$21, %r11
	movq	136(%rsp), %rdx
	xorq	%r10, %rdx
	rolq	$8, %rdx
	movq	%r9, 136(%rsp)
	movq	8(%rsp), %rax
	xorq	%r9, %rax
	movq	%rax, %r9
	rolq	$18, %r9
	movq	%rbp, 536(%rsp)
	movq	112(%rsp), %rax
	xorq	%rbp, %rax
	rolq	$2, %rax
	movq	%rax, 8(%rsp)
	movq	%r14, 528(%rsp)
	movq	96(%rsp), %rax
	xorq	%r14, %rax
	movq	%rax, %r14
	rolq	$61, %r14
	movq	%rcx, 520(%rsp)
	movq	144(%rsp), %rax
	xorq	%rcx, %rax
	movq	%rax, %rcx
	rolq	$56, %rcx
	movq	%r10, 144(%rsp)
	movq	64(%rsp), %rax
	xorq	%r10, %rax
	movq	%rax, %r10
	rolq	$14, %r10
	movq	%rbx, %r12
	notq	%r12
	andq	%rsi, %r12
	movq	%rsi, %rax
	notq	%rax
	andq	%r11, %rax
	xorq	%rbx, %rax
	movq	%rax, 168(%rsp)
	movq	%r11, %rax
	notq	%rax
	andq	%r10, %rax
	movq	%rsi, 488(%rsp)
	xorq	%rsi, %rax
	movq	%rax, 152(%rsp)
	movq	%r10, %r15
	notq	%r15
	movq	248(%rsp), %rax
	andq	%rax, %r15
	movq	%r11, 472(%rsp)
	xorq	%r11, %r15
	notq	%rax
	movq	%rbx, 512(%rsp)
	andq	%rbx, %rax
	movq	%r10, 440(%rsp)
	xorq	%r10, %rax
	movq	%rax, 160(%rsp)
	movq	%rdi, %rax
	notq	%rax
	andq	%r13, %rax
	movq	240(%rsp), %rsi
	xorq	%rsi, %rax
	movq	%rax, 120(%rsp)
	movq	%r13, %rax
	notq	%rax
	andq	%r8, %rax
	xorq	%rdi, %rax
	movq	%rax, 40(%rsp)
	movq	%r8, %rax
	notq	%rax
	andq	%r14, %rax
	movq	%r13, 496(%rsp)
	xorq	%r13, %rax
	movq	%rax, 56(%rsp)
	movq	%r14, %rax
	notq	%rax
	andq	%rsi, %rax
	movq	%r8, 480(%rsp)
	xorq	%r8, %rax
	movq	%rax, 48(%rsp)
	movq	%rsi, %r13
	notq	%r13
	movq	%rdi, 504(%rsp)
	andq	%rdi, %r13
	movq	%r14, 448(%rsp)
	xorq	%r14, %r13
	movq	%rcx, %rdi
	movq	224(%rsp), %rsi
	movq	%rsi, %rax
	notq	%rax
	movq	200(%rsp), %r10
	andq	%r10, %rax
	movq	232(%rsp), %rcx
	xorq	%rcx, %rax
	movq	%rax, 32(%rsp)
	movq	%r10, %r8
	movq	%r10, %rax
	notq	%r8
	andq	%rdx, %r8
	xorq	%rsi, %r8
	movq	%rsi, %r10
	movq	%rdx, %rsi
	notq	%rsi
	andq	%r9, %rsi
	xorq	%rax, %rsi
	movq	%r9, %rax
	notq	%rax
	andq	%rcx, %rax
	movq	%rdx, 464(%rsp)
	xorq	%rdx, %rax
	movq	%rax, 80(%rsp)
	movq	%rcx, %rax
	notq	%rax
	andq	%r10, %rax
	movq	%r9, 456(%rsp)
	xorq	%r9, %rax
	movq	%rax, 72(%rsp)
	movq	176(%rsp), %rcx
	movq	%rcx, %rbx
	notq	%rbx
	movq	208(%rsp), %r9
	andq	%r9, %rbx
	movq	216(%rsp), %rdx
	xorq	%rdx, %rbx
	movq	%r9, %rax
	notq	%rax
	movq	16(%rsp), %r11
	andq	%r11, %rax
	xorq	%rcx, %rax
	movq	%rcx, %r10
	movq	%r11, %rcx
	notq	%rcx
	andq	%rdi, %rcx
	xorq	%r9, %rcx
	movq	%rcx, 104(%rsp)
	movq	%rdi, %rcx
	notq	%rcx
	andq	%rdx, %rcx
	xorq	%r11, %rcx
	movq	%rcx, 88(%rsp)
	notq	%rdx
	andq	%r10, %rdx
	movq	%rdi, 432(%rsp)
	xorq	%rdi, %rdx
	movq	184(%rsp), %r11
	movq	%r11, %rdi
	notq	%rdi
	movq	192(%rsp), %r14
	andq	%r14, %rdi
	movq	584(%rsp), %r9
	xorq	%r9, %rdi
	movq	%r14, %rcx
	notq	%rcx
	movq	24(%rsp), %r10
	andq	%r10, %rcx
	xorq	%r11, %rcx
	movq	%r11, %rbp
	movq	%rcx, 112(%rsp)
	movq	%r10, %rcx
	notq	%rcx
	movq	8(%rsp), %r11
	andq	%r11, %rcx
	xorq	%r14, %rcx
	movq	%rcx, 96(%rsp)
	movq	%r11, %rcx
	movq	%r11, %r14
	notq	%rcx
	andq	%r9, %rcx
	xorq	%r10, %rcx
	movq	%r9, %r11
	notq	%r9
	andq	%rbp, %r9
	movq	592(%rsp), %rbp
	xorq	712(%rsp,%rbp,8), %r12
	xorq	%r14, %r9
	movq	%r9, 64(%rsp)
	movq	248(%rsp), %r9
	xorq	%r9, %r12
	movq	%r12, 128(%rsp)
	incq	%rbp
	movq	%rbp, %r12
	cmpq	$26, %rbp
	jne	.LBB99_1
	movq	424(%rsp), %rbp
	movq	%r8, 88(%rbp)
	movq	40(%rsp), %r8
	movq	%r8, 48(%rbp)
	movq	%rdx, %r8
	movq	%rcx, %rdx
	movq	168(%rsp), %rcx
	movq	%rcx, 8(%rbp)
	movq	%rsi, 96(%rbp)
	movq	56(%rsp), %rcx
	movq	%rcx, 56(%rbp)
	movq	152(%rsp), %rcx
	movq	%rcx, 16(%rbp)
	movq	48(%rsp), %rcx
	movq	%rcx, 64(%rbp)
	movq	%r15, 24(%rbp)
	movq	%r13, 72(%rbp)
	movq	160(%rsp), %rcx
	movq	%rcx, 32(%rbp)
	movq	32(%rsp), %rcx
	movq	%rcx, 80(%rbp)
	movq	80(%rsp), %rcx
	movq	%rcx, 104(%rbp)
	movq	72(%rsp), %rcx
	movq	%rcx, 112(%rbp)
	movq	%rbx, 120(%rbp)
	movq	%rax, 128(%rbp)
	movq	104(%rsp), %rax
	movq	%rax, 136(%rbp)
	movq	88(%rsp), %rax
	movq	%rax, 144(%rbp)
	movq	%r8, 152(%rbp)
	movq	%rdi, 160(%rbp)
	movq	112(%rsp), %rax
	movq	%rax, 168(%rbp)
	movq	96(%rsp), %rax
	movq	%rax, 176(%rbp)
	movq	%rdx, 184(%rbp)
	movq	64(%rsp), %rax
	movq	%rax, 192(%rbp)
	movq	128(%rsp), %rax
	movq	%rax, (%rbp)
	movq	120(%rsp), %rax
	movq	%rax, 40(%rbp)
	movq	576(%rsp), %rax
	movq	%rax, 288(%rsp)
	movq	568(%rsp), %rax
	movq	%rax, 280(%rsp)
	movq	544(%rsp), %rax
	movq	%rax, 272(%rsp)
	movq	560(%rsp), %rax
	movq	%rax, 264(%rsp)
	movq	552(%rsp), %rax
	movq	%rax, 256(%rsp)
	movq	136(%rsp), %rax
	movq	%rax, 328(%rsp)
	movq	536(%rsp), %rax
	movq	%rax, 320(%rsp)
	movq	528(%rsp), %rax
	movq	%rax, 312(%rsp)
	movq	520(%rsp), %rax
	movq	%rax, 304(%rsp)
	movq	144(%rsp), %rax
	movq	%rax, 296(%rsp)
	movq	%r9, 416(%rsp)
	movq	232(%rsp), %rax
	movq	%rax, 344(%rsp)
	movq	%r11, 632(%rsp)
	movq	240(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	216(%rsp), %rax
	movq	%rax, 672(%rsp)
	movq	176(%rsp), %rax
	movq	%rax, 664(%rsp)
	movq	512(%rsp), %rax
	movq	%rax, 408(%rsp)
	movq	224(%rsp), %rax
	movq	%rax, 336(%rsp)
	movq	184(%rsp), %rax
	movq	%rax, 624(%rsp)
	movq	504(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	496(%rsp), %rax
	movq	%rax, 360(%rsp)
	movq	208(%rsp), %rax
	movq	%rax, 656(%rsp)
	movq	488(%rsp), %rax
	movq	%rax, 400(%rsp)
	movq	200(%rsp), %rax
	movq	%rax, 696(%rsp)
	movq	192(%rsp), %rax
	movq	%rax, 616(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 608(%rsp)
	movq	480(%rsp), %rax
	movq	%rax, 352(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 648(%rsp)
	movq	472(%rsp), %rax
	movq	%rax, 392(%rsp)
	movq	464(%rsp), %rax
	movq	%rax, 688(%rsp)
	movq	456(%rsp), %rax
	movq	%rax, 680(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, 600(%rsp)
	movq	448(%rsp), %rax
	movq	%rax, 704(%rsp)
	movq	432(%rsp), %rax
	movq	%rax, 640(%rsp)
	movq	440(%rsp), %rax
	movq	%rax, 384(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 600(%rsp)
	#MEMBARRIER
	addq	$920, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end99:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute, .Lfunc_end99-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey10public_key,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey10public_key
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey10public_key,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey10public_key:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$64, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	xorps	%xmm0, %xmm0
	movups	%xmm0, 48(%rsp)
	movups	%xmm0, 33(%rsp)
	movb	$9, 32(%rsp)
	movq	%rsp, %rdi
	leaq	32(%rsp), %rdx
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6x255198multiply
	movups	(%rsp), %xmm0
	movups	16(%rsp), %xmm1
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$64, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end100:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey10public_key, .Lfunc_end100-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey10public_key
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey5agree,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey5agree
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey5agree,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey5agree:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$40, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movq	%rsp, %rdi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6x255198multiply
	movdqu	(%rsp), %xmm0
	movdqu	16(%rsp), %xmm1
	por	%xmm0, %xmm1
	pxor	%xmm0, %xmm0
	pcmpeqb	%xmm1, %xmm0
	pmovmskb	%xmm0, %eax
	xorl	%ecx, %ecx
	xorl	$65535, %eax
	setne	%cl
	movq	%rcx, 32(%rsp)
	cmpq	$0, 32(%rsp)
	je	.LBB101_2
	leaq	1(%rbx), %rax
	movdqu	(%rsp), %xmm0
	movdqu	16(%rsp), %xmm1
	movdqu	%xmm1, 16(%rax)
	movdqu	%xmm0, (%rax)
	movb	$0, (%rbx)
	jmp	.LBB101_3
.LBB101_2:
	movw	$769, (%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
.LBB101_3:
	movb	$0, (%r14)
	movb	$0, 1(%r14)
	movb	$0, 2(%r14)
	movb	$0, 3(%r14)
	movb	$0, 4(%r14)
	movb	$0, 5(%r14)
	movb	$0, 6(%r14)
	movb	$0, 7(%r14)
	movb	$0, 8(%r14)
	movb	$0, 9(%r14)
	movb	$0, 10(%r14)
	movb	$0, 11(%r14)
	movb	$0, 12(%r14)
	movb	$0, 13(%r14)
	movb	$0, 14(%r14)
	movb	$0, 15(%r14)
	movb	$0, 16(%r14)
	movb	$0, 17(%r14)
	movb	$0, 18(%r14)
	movb	$0, 19(%r14)
	movb	$0, 20(%r14)
	movb	$0, 21(%r14)
	movb	$0, 22(%r14)
	movb	$0, 23(%r14)
	movb	$0, 24(%r14)
	movb	$0, 25(%r14)
	movb	$0, 26(%r14)
	movb	$0, 27(%r14)
	movb	$0, 28(%r14)
	movb	$0, 29(%r14)
	movb	$0, 30(%r14)
	movb	$0, 31(%r14)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$40, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end101:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey5agree, .Lfunc_end101-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6x25519NtB4_9SecretKey5agree
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$528, %rsp
	.cfi_def_cfa_offset 576
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %r14
	movq	%rdi, %rbx
	leaq	160(%rsp), %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point6decode
	cmpb	$1, 160(%rsp)
	jne	.LBB102_2
	movzbl	161(%rsp), %eax
	movb	%al, 1(%rbx)
	movb	$1, (%rbx)
	jmp	.LBB102_5
.LBB102_2:
	leaq	168(%rsp), %rsi
	leaq	368(%rsp), %r15
	movq	memcpy@GOTPCREL(%rip), %r13
	movl	$160, %edx
	movq	%r15, %rdi
	callq	*%r13
	movq	%rsp, %r12
	movl	$160, %edx
	movq	%r12, %rdi
	movq	%r15, %rsi
	callq	*%r13
	movq	%r12, %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point11small_order
	testb	%al, %al
	je	.LBB102_3
	movw	$513, (%rbx)
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	jmp	.LBB102_5
.LBB102_3:
	leaq	192(%rsp), %rdi
	movq	%rsp, %rsi
	movl	$160, %edx
	callq	*%r13
	movups	(%r14), %xmm0
	movups	16(%r14), %xmm1
	movaps	%xmm0, 160(%rsp)
	movaps	%xmm1, 176(%rsp)
	leaq	8(%rbx), %rdi
	leaq	160(%rsp), %rsi
	movl	$192, %edx
	callq	*%r13
	movb	$0, (%rbx)
.LBB102_5:
	movq	%rbx, %rax
	addq	$528, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end102:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes, .Lfunc_end102-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes
	.cfi_endproc

	.section	.text._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey6verify,"ax",@progbits
	.globl	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey6verify
	.p2align	4
	.type	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey6verify,@function
_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey6verify:
.Lfunc_begin41:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception41
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1336, %rsp
	.cfi_def_cfa_offset 1392
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	cmpq	$64, %r8
	jne	.LBB103_3
	movq	%rdx, %r14
	movq	%rsi, %r15
	movq	%rdi, 72(%rsp)
	leaq	624(%rsp), %rdi
	movq	%rcx, %rbp
	movq	%rcx, %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point6decode
	cmpb	$1, 624(%rsp)
	jne	.LBB103_4
	movzbl	625(%rsp), %eax
	jmp	.LBB103_17
.LBB103_3:
	xorl	%eax, %eax
	jmp	.LBB103_17
.LBB103_4:
	leaq	632(%rsp), %rsi
	leaq	86(%rsp), %r12
	movq	memcpy@GOTPCREL(%rip), %rbx
	movl	$160, %edx
	movq	%r12, %rdi
	callq	*%rbx
	leaq	400(%rsp), %r13
	movl	$160, %edx
	movq	%r13, %rdi
	movq	%r12, %rsi
	callq	*%rbx
	movq	%r13, %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point11small_order
	movl	%eax, %ecx
	movb	$5, %al
	testb	%cl, %cl
	jne	.LBB103_16
	movq	%rbp, %rsi
	movq	32(%rbp), %r8
	movq	40(%rbp), %rdi
	movq	48(%rbp), %rdx
	movq	56(%rbp), %rcx
	movq	%r8, 40(%rsp)
	movq	%rdi, 360(%rsp)
	xorl	%r9d, %r9d
	movabsq	$-6346243789798364141, %rbp
	addq	%r8, %rbp
	movq	%rdi, %r10
	adcq	$0, %r10
	adcq	$1, %r9
	movabsq	$-1503914060200516823, %r13
	addq	%r10, %r13
	adcq	$-1, %r9
	xorq	$1, %r9
	movq	%rdx, %r10
	subq	%r9, %r10
	movl	$1, %r9d
	sbbq	$0, %r9
	movq	%rdx, 352(%rsp)
	xorl	%r12d, %r12d
	addq	%rcx, %r9
	setb	%r12b
	movabsq	$-1152921504606846977, %r11
	addq	%r9, %r11
	adcq	$0, %r12
	movq	%rcx, 344(%rsp)
	xorq	$1, %r12
	movq	%r12, 624(%rsp)
	movq	624(%rsp), %rbx
	movq	%rbx, %r9
	decq	%rbx
	andq	%rbp, %rbx
	negq	%r9
	andq	%r8, %r9
	orq	%rbx, %r9
	movq	%r12, 624(%rsp)
	movq	624(%rsp), %rbx
	movq	%rbx, %r8
	decq	%rbx
	andq	%r13, %rbx
	negq	%r8
	andq	%rdi, %r8
	orq	%rbx, %r8
	movq	%r12, 624(%rsp)
	movq	624(%rsp), %rbx
	movq	%rbx, %rdi
	decq	%rbx
	andq	%r10, %rbx
	negq	%rdi
	andq	%rdx, %rdi
	orq	%rbx, %rdi
	movq	%r12, 624(%rsp)
	movq	624(%rsp), %rdx
	movq	%rdx, %r10
	decq	%rdx
	andq	%r11, %rdx
	negq	%r10
	andq	%rcx, %r10
	orq	%rdx, %r10
	movq	$0, 624(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 1176(%rsp)
	movq	$0, 1016(%rsp)
	#MEMBARRIER
	movq	%r9, 856(%rsp)
	movq	%r8, 560(%rsp)
	movq	%rdi, 368(%rsp)
	movq	%r10, 312(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 344(%rsp)
	#MEMBARRIER
	movq	856(%rsp), %rcx
	movq	560(%rsp), %rdx
	movq	368(%rsp), %rdi
	movq	312(%rsp), %r8
	movdqu	32(%rsi), %xmm1
	movdqu	48(%rsi), %xmm0
	movq	%r8, %r9
	shrq	$56, %r9
	movq	%rdx, %r10
	shrq	$56, %r10
	movd	%r10d, %xmm3
	movq	%rdx, %r10
	shrq	$48, %r10
	movd	%r10d, %xmm4
	movq	%rdx, %r10
	shrq	$40, %r10
	movd	%r10d, %xmm5
	movq	%rdx, %r10
	shrq	$32, %r10
	movd	%r10d, %xmm2
	movq	%rcx, %r10
	shrq	$56, %r10
	movd	%r10d, %xmm7
	movq	%rcx, %r10
	shrq	$48, %r10
	punpcklbw	%xmm3, %xmm4
	punpcklbw	%xmm5, %xmm2
	punpcklwd	%xmm4, %xmm2
	movd	%edx, %xmm3
	movdqa	%xmm3, %xmm4
	psrld	$24, %xmm4
	movdqa	%xmm3, %xmm5
	psrld	$16, %xmm5
	punpcklbw	%xmm4, %xmm5
	movdqa	%xmm3, %xmm4
	psrld	$8, %xmm4
	punpcklbw	%xmm4, %xmm3
	movd	%r10d, %xmm4
	movq	%rcx, %r10
	shrq	$40, %r10
	punpcklwd	%xmm5, %xmm3
	movd	%r10d, %xmm5
	movq	%rcx, %r10
	shrq	$32, %r10
	punpckldq	%xmm2, %xmm3
	movd	%r10d, %xmm6
	movq	%r8, %r10
	shrq	$48, %r10
	punpcklbw	%xmm7, %xmm4
	punpcklbw	%xmm5, %xmm6
	punpcklwd	%xmm4, %xmm6
	movd	%ecx, %xmm2
	movdqa	%xmm2, %xmm4
	psrld	$24, %xmm4
	movdqa	%xmm2, %xmm5
	psrld	$16, %xmm5
	punpcklbw	%xmm4, %xmm5
	movdqa	%xmm2, %xmm4
	psrld	$8, %xmm4
	punpcklbw	%xmm4, %xmm2
	movd	%r9d, %xmm4
	movq	%r8, %r9
	shrq	$40, %r9
	punpcklwd	%xmm5, %xmm2
	movd	%r10d, %xmm5
	movq	%r8, %r10
	shrq	$32, %r10
	punpckldq	%xmm6, %xmm2
	movd	%r9d, %xmm6
	movq	%rdi, %r11
	shrq	$56, %r11
	punpcklqdq	%xmm3, %xmm2
	movd	%r10d, %xmm3
	movq	%rdi, %r9
	shrq	$48, %r9
	pcmpeqb	%xmm1, %xmm2
	movd	%r11d, %xmm7
	movq	%rdi, %r10
	shrq	$40, %r10
	punpcklbw	%xmm4, %xmm5
	punpcklbw	%xmm6, %xmm3
	punpcklwd	%xmm5, %xmm3
	movd	%r8d, %xmm1
	movdqa	%xmm1, %xmm4
	psrld	$24, %xmm4
	movdqa	%xmm1, %xmm5
	psrld	$16, %xmm5
	punpcklbw	%xmm4, %xmm5
	movdqa	%xmm1, %xmm4
	psrld	$8, %xmm4
	punpcklbw	%xmm4, %xmm1
	movd	%r9d, %xmm4
	movq	%rdi, %r9
	shrq	$32, %r9
	punpcklwd	%xmm5, %xmm1
	punpckldq	%xmm3, %xmm1
	punpcklbw	%xmm7, %xmm4
	movd	%r10d, %xmm3
	movd	%r9d, %xmm5
	punpcklbw	%xmm3, %xmm5
	punpcklwd	%xmm4, %xmm5
	movd	%edi, %xmm3
	movdqa	%xmm3, %xmm4
	psrld	$24, %xmm4
	movdqa	%xmm3, %xmm6
	psrld	$16, %xmm6
	punpcklbw	%xmm4, %xmm6
	movdqa	%xmm3, %xmm4
	psrld	$8, %xmm4
	punpcklbw	%xmm4, %xmm3
	punpcklwd	%xmm6, %xmm3
	punpckldq	%xmm5, %xmm3
	punpcklqdq	%xmm1, %xmm3
	pcmpeqb	%xmm0, %xmm3
	pand	%xmm2, %xmm3
	pmovmskb	%xmm3, %r9d
	xorl	%r10d, %r10d
	xorl	$65535, %r9d
	setne	%r10b
	movq	%r10, 624(%rsp)
	cmpq	$0, 624(%rsp)
	je	.LBB103_7
	movq	$0, 856(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	jmp	.LBB103_16
.LBB103_7:
	movq	%rcx, 32(%rsp)
	movq	%rdx, 24(%rsp)
	movq	%rdi, 16(%rsp)
	movq	%r8, 8(%rsp)
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, 192(%rsp)
	movdqa	%xmm0, 176(%rsp)
	movdqa	%xmm0, 160(%rsp)
	movdqa	%xmm0, 144(%rsp)
	movdqa	%xmm0, 128(%rsp)
	movdqa	%xmm0, 112(%rsp)
	movdqa	%xmm0, 96(%rsp)
	movdqa	%xmm0, 80(%rsp)
	movabsq	$7640891576956012808, %rax
	movq	%rax, 208(%rsp)
	movabsq	$-4942790177534073029, %rax
	movq	%rax, 216(%rsp)
	movabsq	$4354685564936845355, %rax
	movq	%rax, 224(%rsp)
	movabsq	$-6534734903238641935, %rax
	movq	%rax, 232(%rsp)
	movabsq	$5840696475078001361, %rax
	movq	%rax, 240(%rsp)
	movabsq	$-7276294671716946913, %rax
	movq	%rax, 248(%rsp)
	movabsq	$2270897969802886507, %rax
	movq	%rax, 256(%rsp)
	movabsq	$6620516959819538809, %rax
	movq	%rax, 264(%rsp)
	movdqa	%xmm0, 272(%rsp)
	movq	$0, 288(%rsp)
.Ltmp435:
	leaq	80(%rsp), %rdi
	movl	$32, %edx
	callq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update@GOTPCREL(%rip)
.Ltmp436:
	cmpb	$-1, %al
	jne	.LBB103_13
.Ltmp437:
	leaq	80(%rsp), %rdi
	movl	$32, %edx
	movq	72(%rsp), %rsi
	callq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update@GOTPCREL(%rip)
.Ltmp438:
	cmpb	$-1, %al
	jne	.LBB103_13
.Ltmp439:
	leaq	80(%rsp), %rdi
	movq	%r15, %rsi
	movq	%r14, %rdx
	callq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update@GOTPCREL(%rip)
.Ltmp440:
	cmpb	$-1, %al
	je	.LBB103_18
.LBB103_13:
	xorl	%eax, %eax
	.p2align	4
.LBB103_14:
	movb	$0, 80(%rsp,%rax)
	movb	$0, 81(%rsp,%rax)
	movb	$0, 82(%rsp,%rax)
	movb	$0, 83(%rsp,%rax)
	movb	$0, 84(%rsp,%rax)
	movb	$0, 85(%rsp,%rax)
	movb	$0, 86(%rsp,%rax)
	movb	$0, 87(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB103_14
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	#MEMBARRIER
	xorl	%eax, %eax
.LBB103_16:
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	#MEMBARRIER
.LBB103_17:
	addq	$1336, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB103_18:
	.cfi_def_cfa_offset 1392
	leaq	624(%rsp), %r14
	leaq	80(%rsp), %rsi
	movl	$224, %edx
	movq	%r14, %rdi
	callq	*memcpy@GOTPCREL(%rip)
.Ltmp442:
	leaq	560(%rsp), %rdi
	movq	%r14, %rsi
	callq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize@GOTPCREL(%rip)
.Ltmp443:
	leaq	40(%rsp), %rdi
	leaq	560(%rsp), %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB4_1S6reduce
.Ltmp445:
	leaq	1016(%rsp), %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point4base
.Ltmp446:
	movq	32(%rsp), %rax
	movq	%rax, 312(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 320(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 328(%rsp)
	movq	8(%rsp), %rax
	movq	%rax, 336(%rsp)
	leaq	856(%rsp), %r15
	leaq	1016(%rsp), %r14
	leaq	312(%rsp), %rdx
	movq	%r15, %rdi
	movq	%r14, %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3mul
	movdqu	40(%rsp), %xmm0
	movdqu	56(%rsp), %xmm1
	movdqa	%xmm1, 384(%rsp)
	movdqa	%xmm0, 368(%rsp)
	movq	72(%rsp), %rsi
	addq	$32, %rsi
	leaq	624(%rsp), %r13
	leaq	368(%rsp), %rdx
	movq	%r13, %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3mul
	leaq	1176(%rsp), %rbp
	leaq	400(%rsp), %rbx
	movq	%rbp, %rdi
	movq	%rbx, %rsi
	movq	%r13, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point3add
	movq	%r15, %rdi
	movq	%rbp, %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB2_5Point2eq
	movq	%rax, %r12
	movq	%rbp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_
	movq	%r13, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_
	movq	%r15, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_
	movq	%r14, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_
	negb	%r12b
	orb	$5, %r12b
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	#MEMBARRIER
	movq	%rbx, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_
	movq	%r12, %rax
	jmp	.LBB103_17
.LBB103_21:
.Ltmp447:
	movq	%rax, %rbx
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	jmp	.LBB103_26
.LBB103_22:
.Ltmp444:
	movq	%rax, %rbx
	jmp	.LBB103_27
.LBB103_23:
.Ltmp441:
	movq	%rax, %rbx
	xorl	%eax, %eax
.LBB103_24:
	movb	$0, 80(%rsp,%rax)
	movb	$0, 81(%rsp,%rax)
	movb	$0, 82(%rsp,%rax)
	movb	$0, 83(%rsp,%rax)
	movb	$0, 84(%rsp,%rax)
	movb	$0, 85(%rsp,%rax)
	movb	$0, 86(%rsp,%rax)
	movb	$0, 87(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB103_24
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
.LBB103_26:
	#MEMBARRIER
.LBB103_27:
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	#MEMBARRIER
	leaq	400(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto7ed255195PointEBF_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end103:
	.size	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey6verify, .Lfunc_end103-_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey6verify
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtCs1muTxUaRwMI_12toyos_crypto7ed25519NtB4_9PublicKey6verify,"a",@progbits
	.p2align	2, 0x0
GCC_except_table103:
.Lexception41:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end41-.Lcst_begin41
.Lcst_begin41:
	.uleb128 .Lfunc_begin41-.Lfunc_begin41
	.uleb128 .Ltmp435-.Lfunc_begin41
	.byte	0
	.byte	0
	.uleb128 .Ltmp435-.Lfunc_begin41
	.uleb128 .Ltmp440-.Ltmp435
	.uleb128 .Ltmp441-.Lfunc_begin41
	.byte	0
	.uleb128 .Ltmp440-.Lfunc_begin41
	.uleb128 .Ltmp442-.Ltmp440
	.byte	0
	.byte	0
	.uleb128 .Ltmp442-.Lfunc_begin41
	.uleb128 .Ltmp443-.Ltmp442
	.uleb128 .Ltmp444-.Lfunc_begin41
	.byte	0
	.uleb128 .Ltmp445-.Lfunc_begin41
	.uleb128 .Ltmp446-.Ltmp445
	.uleb128 .Ltmp447-.Lfunc_begin41
	.byte	0
	.uleb128 .Ltmp446-.Lfunc_begin41
	.uleb128 .Lfunc_end103-.Ltmp446
	.byte	0
	.byte	0
.Lcst_end41:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest,"ax",@progbits
	.globl	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest
	.p2align	4
	.type	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest,@function
_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest:
.Lfunc_begin42:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception42
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$904, %rsp
	.cfi_def_cfa_offset 960
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movb	$4, %al
	cmpq	$6, %rcx
	jb	.LBB104_43
	cmpb	$48, (%rdx)
	jne	.LBB104_43
	movzbl	1(%rdx), %r8d
	leaq	-2(%rcx), %r9
	cmpq	%r8, %r9
	jne	.LBB104_43
	cmpb	$2, 2(%rdx)
	jne	.LBB104_43
	movzbl	3(%rdx), %r14d
	leaq	4(%r14), %r12
	cmpq	%rcx, %r12
	ja	.LBB104_43
	testq	%r14, %r14
	je	.LBB104_43
	leaq	96(%rdi), %r10
	leaq	4(%rdx), %r8
	cmpb	$0, (%r8)
	js	.LBB104_43
	movq	%r14, %r9
	jne	.LBB104_11
	cmpl	$1, %r14d
	je	.LBB104_10
	cmpb	$0, 5(%rdx)
	jns	.LBB104_43
.LBB104_10:
	leaq	-1(%r14), %r9
	leaq	5(%rdx), %r8
.LBB104_11:
	movb	$5, %al
	cmpl	$33, %r9d
	jae	.LBB104_43
	movq	%r10, 104(%rsp)
	movq	%rdx, %rbx
	movq	%rsi, 648(%rsp)
	movq	%rdi, 376(%rsp)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movq	%rsp, %r15
	movq	%r15, %rdi
	subq	%r9, %rdi
	addq	$32, %rdi
	movq	%r8, %rsi
	movq	%r9, %rdx
	movq	%rcx, %r13
	callq	*memcpy@GOTPCREL(%rip)
	movzbl	(%rsp), %ebp
	movups	1(%rsp), %xmm0
	movaps	%xmm0, 208(%rsp)
	movups	17(%rsp), %xmm0
	movaps	%xmm0, 224(%rsp)
	movups	32(%rsp), %xmm0
	movups	%xmm0, 239(%rsp)
	movb	$4, %al
	cmpq	%r13, %r12
	jae	.LBB104_43
	cmpb	$2, (%rbx,%r12)
	jne	.LBB104_43
	movq	%r13, %rcx
	leaq	5(%r14), %rdx
	cmpq	%r13, %rdx
	jae	.LBB104_43
	movq	%rbx, %rsi
	movzbl	5(%rbx,%r14), %edx
	leaq	(%r14,%rdx), %rbx
	addq	$6, %rbx
	cmpq	%rcx, %rbx
	ja	.LBB104_43
	testq	%rdx, %rdx
	je	.LBB104_43
	addq	$6, %r14
	addq	%r14, %rsi
	cmpb	$0, (%rsi)
	js	.LBB104_43
	jne	.LBB104_22
	cmpl	$1, %edx
	je	.LBB104_21
	cmpb	$0, 1(%rsi)
	jns	.LBB104_43
.LBB104_21:
	decq	%rdx
	incq	%rsi
.LBB104_22:
	movb	$5, %al
	cmpl	$33, %edx
	jae	.LBB104_43
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	subq	%rdx, %r15
	addq	$32, %r15
	movq	%r15, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movzbl	(%rsp), %ecx
	movups	1(%rsp), %xmm0
	movaps	%xmm0, 112(%rsp)
	movups	17(%rsp), %xmm0
	movaps	%xmm0, 128(%rsp)
	movups	32(%rsp), %xmm0
	movups	%xmm0, 143(%rsp)
	movb	$4, %al
	cmpq	%r13, %rbx
	jne	.LBB104_43
	movups	239(%rsp), %xmm0
	movups	%xmm0, 760(%rsp)
	movaps	208(%rsp), %xmm0
	movaps	224(%rsp), %xmm1
	movups	%xmm1, 745(%rsp)
	movups	%xmm0, 729(%rsp)
	movups	143(%rsp), %xmm0
	movups	%xmm0, 808(%rsp)
	movaps	112(%rsp), %xmm0
	movaps	128(%rsp), %xmm1
	movups	%xmm1, 793(%rsp)
	movups	%xmm0, 777(%rsp)
	movb	%bpl, 728(%rsp)
	movb	%cl, 776(%rsp)
	leaq	824(%rsp), %rdi
	leaq	728(%rsp), %rdx
	movq	104(%rsp), %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_
	cmpb	$0, 824(%rsp)
	jne	.LBB104_42
	movups	832(%rsp), %xmm0
	movups	848(%rsp), %xmm1
	movaps	%xmm1, 320(%rsp)
	movaps	%xmm0, 304(%rsp)
	leaq	680(%rsp), %rdi
	leaq	776(%rsp), %rdx
	movq	104(%rsp), %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_
	cmpb	$1, 680(%rsp)
	jne	.LBB104_27
	movw	$1281, 680(%rsp)
	jmp	.LBB104_41
.LBB104_27:
	movups	688(%rsp), %xmm0
	movups	704(%rsp), %xmm1
	movaps	%xmm1, 400(%rsp)
	movq	648(%rsp), %rax
	movq	24(%rax), %rcx
	bswapq	%rcx
	movaps	%xmm0, 384(%rsp)
	movq	16(%rax), %rdx
	bswapq	%rdx
	movq	(%rax), %rsi
	movq	8(%rax), %rax
	bswapq	%rax
	bswapq	%rsi
	movq	%rcx, 344(%rsp)
	movq	%rdx, 352(%rsp)
	movq	%rax, 360(%rsp)
	movq	%rsi, 368(%rsp)
	movq	376(%rsp), %rbx
	leaq	296(%rbx), %r15
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 864(%rsp)
	movaps	%xmm0, 880(%rsp)
	movaps	%xmm0, (%rsp)
	movaps	%xmm0, 16(%rsp)
	leaq	456(%rsp), %rdi
	movq	%rsp, %rdx
	leaq	344(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	leaq	328(%rbx), %r12
.Ltmp448:
	movq	%rsp, %rdi
	leaq	384(%rsp), %rdx
	movq	%r15, %rsi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp449:
.Ltmp451:
	leaq	424(%rsp), %rdi
	movq	%rsp, %rdx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_
.Ltmp452:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
.Ltmp454:
	leaq	112(%rsp), %rdi
	leaq	456(%rsp), %rdx
	movq	%r15, %rsi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp455:
.Ltmp457:
	leaq	208(%rsp), %rdi
	leaq	112(%rsp), %rdx
	leaq	424(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp458:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 8(%rsp)
	movq	$0, 24(%rsp)
	movq	$1, (%rsp)
.Ltmp460:
	leaq	488(%rsp), %rdi
	leaq	208(%rsp), %rdx
	movq	%rsp, %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp461:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
.Ltmp463:
	leaq	112(%rsp), %rdi
	leaq	304(%rsp), %rdx
	movq	%r15, %rsi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp464:
.Ltmp466:
	leaq	208(%rsp), %rdi
	leaq	112(%rsp), %rdx
	leaq	424(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp467:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 8(%rsp)
	movq	$0, 24(%rsp)
	movq	$1, (%rsp)
.Ltmp469:
	leaq	520(%rsp), %rdi
	leaq	208(%rsp), %rdx
	movq	%rsp, %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp470:
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	376(%rsp), %rax
	movups	128(%rax), %xmm0
	movups	144(%rax), %xmm1
	movaps	%xmm1, 128(%rsp)
	movaps	%xmm0, 112(%rsp)
	movups	160(%rax), %xmm0
	movups	176(%rax), %xmm1
	movaps	%xmm0, 144(%rsp)
	movaps	%xmm1, 160(%rsp)
	movups	256(%rax), %xmm0
	movups	272(%rax), %xmm1
	movaps	%xmm0, 176(%rsp)
	movaps	%xmm1, 192(%rsp)
.Ltmp472:
	leaq	208(%rsp), %rdi
	leaq	112(%rsp), %rsi
	leaq	488(%rsp), %rdx
	movq	104(%rsp), %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
.Ltmp473:
.Ltmp475:
	movq	%rsp, %rdi
	leaq	520(%rsp), %rdx
	movq	376(%rsp), %rsi
	movq	104(%rsp), %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
.Ltmp476:
.Ltmp478:
	leaq	552(%rsp), %rdi
	leaq	208(%rsp), %rsi
	movq	%rsp, %rdx
	movq	104(%rsp), %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_
.Ltmp479:
	leaq	624(%rsp), %r14
	leaq	632(%rsp), %r12
	leaq	640(%rsp), %r13
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
.Ltmp481:
	movq	%rsp, %rdi
	leaq	552(%rsp), %rsi
	movq	104(%rsp), %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_
.Ltmp482:
	cmpb	$0, (%rsp)
	je	.LBB104_44
	movw	$1281, (%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	#MEMBARRIER
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	#MEMBARRIER
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
.LBB104_41:
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
.LBB104_42:
	movb	$5, %al
.LBB104_43:
	addq	$904, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB104_44:
	.cfi_def_cfa_offset 960
	movups	8(%rsp), %xmm0
	movups	24(%rsp), %xmm1
	movaps	%xmm1, 224(%rsp)
	movaps	%xmm0, 208(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	#MEMBARRIER
	leaq	112(%rsp), %rdi
	leaq	864(%rsp), %rdx
	leaq	208(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 720(%rsp)
	#MEMBARRIER
	movq	304(%rsp), %rax
	movq	312(%rsp), %rcx
	movq	320(%rsp), %rdx
	movq	328(%rsp), %rsi
	xorq	120(%rsp), %rcx
	xorq	112(%rsp), %rax
	xorq	128(%rsp), %rdx
	orq	%rcx, %rax
	orq	%rax, %rdx
	xorq	136(%rsp), %rsi
	orq	%rdx, %rsi
	sete	%al
	negb	%al
	orb	$5, %al
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	#MEMBARRIER
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	#MEMBARRIER
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	jmp	.LBB104_43
.LBB104_45:
.Ltmp483:
	movq	%rax, %rdi
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	movq	$0, 616(%rsp)
	jmp	.LBB104_51
.LBB104_46:
.Ltmp480:
	movq	%rax, %rdi
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	jmp	.LBB104_48
.LBB104_47:
.Ltmp477:
	movq	%rax, %rdi
.LBB104_48:
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	jmp	.LBB104_50
.LBB104_49:
.Ltmp474:
	movq	%rax, %rdi
.LBB104_50:
	leaq	184(%rsp), %r14
	leaq	192(%rsp), %r12
	leaq	200(%rsp), %r13
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
.LBB104_51:
	movq	$0, (%r14)
	movq	$0, (%r12)
	movq	$0, (%r13)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	jmp	.LBB104_56
.LBB104_52:
.Ltmp471:
	movq	%rax, %rdi
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	jmp	.LBB104_54
.LBB104_53:
.Ltmp468:
	movq	%rax, %rdi
.LBB104_54:
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	jmp	.LBB104_56
.LBB104_55:
.Ltmp465:
	movq	%rax, %rdi
.LBB104_56:
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	jmp	.LBB104_61
.LBB104_57:
.Ltmp462:
	movq	%rax, %rdi
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	jmp	.LBB104_59
.LBB104_58:
.Ltmp459:
	movq	%rax, %rdi
.LBB104_59:
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	jmp	.LBB104_61
.LBB104_60:
.Ltmp456:
	movq	%rax, %rdi
.LBB104_61:
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
.LBB104_62:
	#MEMBARRIER
.LBB104_63:
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	#MEMBARRIER
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	callq	_Unwind_Resume@PLT
.LBB104_64:
.Ltmp453:
	movq	%rax, %rdi
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	jmp	.LBB104_62
.LBB104_65:
.Ltmp450:
	movq	%rax, %rdi
	jmp	.LBB104_63
.Lfunc_end104:
	.size	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest, .Lfunc_end104-_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest,"a",@progbits
	.p2align	2, 0x0
GCC_except_table104:
.Lexception42:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end42-.Lcst_begin42
.Lcst_begin42:
	.uleb128 .Lfunc_begin42-.Lfunc_begin42
	.uleb128 .Ltmp448-.Lfunc_begin42
	.byte	0
	.byte	0
	.uleb128 .Ltmp448-.Lfunc_begin42
	.uleb128 .Ltmp449-.Ltmp448
	.uleb128 .Ltmp450-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp451-.Lfunc_begin42
	.uleb128 .Ltmp452-.Ltmp451
	.uleb128 .Ltmp453-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp454-.Lfunc_begin42
	.uleb128 .Ltmp455-.Ltmp454
	.uleb128 .Ltmp456-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp457-.Lfunc_begin42
	.uleb128 .Ltmp458-.Ltmp457
	.uleb128 .Ltmp459-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp460-.Lfunc_begin42
	.uleb128 .Ltmp461-.Ltmp460
	.uleb128 .Ltmp462-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp463-.Lfunc_begin42
	.uleb128 .Ltmp464-.Ltmp463
	.uleb128 .Ltmp465-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp466-.Lfunc_begin42
	.uleb128 .Ltmp467-.Ltmp466
	.uleb128 .Ltmp468-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp469-.Lfunc_begin42
	.uleb128 .Ltmp470-.Ltmp469
	.uleb128 .Ltmp471-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp472-.Lfunc_begin42
	.uleb128 .Ltmp473-.Ltmp472
	.uleb128 .Ltmp474-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp475-.Lfunc_begin42
	.uleb128 .Ltmp476-.Ltmp475
	.uleb128 .Ltmp477-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp478-.Lfunc_begin42
	.uleb128 .Ltmp479-.Ltmp478
	.uleb128 .Ltmp480-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp481-.Lfunc_begin42
	.uleb128 .Ltmp482-.Ltmp481
	.uleb128 .Ltmp483-.Lfunc_begin42
	.byte	0
	.uleb128 .Ltmp482-.Lfunc_begin42
	.uleb128 .Lfunc_end104-.Ltmp482
	.byte	0
	.byte	0
.Lcst_end42:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify,"ax",@progbits
	.globl	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify
	.p2align	4
	.type	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify,@function
_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$80, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%r8, %rbx
	movq	%rcx, %r14
	movq	%rdi, %r15
	leaq	15(%rsp), %rdi
	callq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566digest@GOTPCREL(%rip)
	movzbl	16(%rsp), %eax
	cmpb	$1, 15(%rsp)
	je	.LBB105_2
	movups	17(%rsp), %xmm0
	movups	32(%rsp), %xmm1
	movups	%xmm1, 64(%rsp)
	movups	%xmm0, 49(%rsp)
	movb	%al, 48(%rsp)
	leaq	48(%rsp), %rsi
	movq	%r15, %rdi
	movq	%r14, %rdx
	movq	%rbx, %rcx
	callq	*_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest@GOTPCREL(%rip)
.LBB105_2:
	addq	$80, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end105:
	.size	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify, .Lfunc_end105-_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify
	.cfi_endproc

	.section	.text._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1,"ax",@progbits
	.globl	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1
	.p2align	4
	.type	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1,@function
_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1:
.Lfunc_begin43:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception43
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$728, %rsp
	.cfi_def_cfa_offset 784
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r15
	movq	%rsi, %r14
	movq	%rdi, %rbx
	leaq	336(%rsp), %rdi
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256@GOTPCREL(%rip)
	cmpq	$65, %r15
	jne	.LBB106_1
	movb	$4, %al
	cmpb	$4, (%r14)
	jne	.LBB106_30
	movq	25(%r14), %rcx
	bswapq	%rcx
	movq	17(%r14), %r10
	bswapq	%r10
	movq	1(%r14), %rdi
	movq	9(%r14), %r9
	bswapq	%r9
	bswapq	%rdi
	movq	%rcx, 32(%rsp)
	movq	%r10, 40(%rsp)
	movq	%r9, 48(%rsp)
	movq	%rdi, 56(%rsp)
	movq	57(%r14), %r8
	bswapq	%r8
	movq	49(%r14), %rsi
	bswapq	%rsi
	movq	33(%r14), %rax
	movq	41(%r14), %rdx
	bswapq	%rdx
	bswapq	%rax
	movq	%r8, 64(%rsp)
	movq	432(%rsp), %r13
	movq	440(%rsp), %rbp
	cmpq	%r13, %rcx
	movl	$1, %r11d
	sbbq	$0, %r11
	xorl	%ecx, %ecx
	subq	%rbp, %r10
	movl	$0, %r12d
	sbbq	%r12, %r12
	addq	%r11, %r10
	adcq	$0, %r12
	addq	$-1, %r10
	adcq	$0, %r12
	xorq	$-2, %r12
	movq	448(%rsp), %r15
	subq	%r15, %r9
	movl	$0, %r10d
	sbbq	%r10, %r10
	addq	%r12, %r9
	adcq	$-1, %r10
	addq	$1, %r9
	adcq	$1, %r10
	xorq	$-2, %r10
	movq	456(%rsp), %r11
	subq	%r11, %rdi
	movl	$0, %r9d
	sbbq	%r9, %r9
	movq	%rsi, 72(%rsp)
	addq	%r10, %rdi
	adcq	$-1, %r9
	movl	$1, %r10d
	addq	$1, %rdi
	adcq	$1, %r9
	xorq	$1, %r9
	cmpq	%r13, %r8
	sbbq	$0, %r10
	subq	%rbp, %rsi
	movl	$0, %edi
	sbbq	%rdi, %rdi
	movq	%rdx, 80(%rsp)
	addq	%r10, %rsi
	adcq	$0, %rdi
	addq	$-1, %rsi
	adcq	$0, %rdi
	xorq	$-2, %rdi
	subq	%r15, %rdx
	movl	$0, %esi
	sbbq	%rsi, %rsi
	addq	%rdi, %rdx
	adcq	$-1, %rsi
	movq	%rax, 88(%rsp)
	addq	$1, %rdx
	adcq	$1, %rsi
	xorq	$-2, %rsi
	subq	%r11, %rax
	sbbq	%rcx, %rcx
	addq	%rsi, %rax
	adcq	$-1, %rcx
	addq	$1, %rax
	adcq	$1, %rcx
	xorq	$1, %rcx
	testq	%rcx, %r9
	je	.LBB106_17
	movq	%r11, 320(%rsp)
	leaq	432(%rsp), %rsi
	leaq	464(%rsp), %r12
.Ltmp484:
	leaq	128(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp485:
.Ltmp487:
	leaq	192(%rsp), %rdi
	leaq	64(%rsp), %rdx
	leaq	432(%rsp), %rsi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp488:
.Ltmp490:
	leaq	256(%rsp), %rdi
	leaq	128(%rsp), %rcx
	leaq	432(%rsp), %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp491:
.Ltmp493:
	leaq	160(%rsp), %rdi
	leaq	256(%rsp), %rdx
	leaq	128(%rsp), %rcx
	leaq	432(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp494:
	leaq	16(%rsp), %r12
	xorps	%xmm0, %xmm0
	movups	%xmm0, 8(%rsp)
	movq	$0, 24(%rsp)
	movq	$3, (%rsp)
.Ltmp496:
	leaq	288(%rsp), %rdi
	movq	%rsp, %rdx
	leaq	432(%rsp), %rsi
	leaq	464(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp497:
	leaq	304(%rsp), %r12
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
.Ltmp499:
	movq	%rsp, %rdi
	leaq	288(%rsp), %rdx
	leaq	128(%rsp), %rcx
	leaq	432(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp500:
	movq	160(%rsp), %rax
	subq	(%rsp), %rax
	movl	$1, %esi
	sbbq	$0, %rsi
	movq	168(%rsp), %rcx
	xorl	%edx, %edx
	subq	8(%rsp), %rcx
	movl	$0, %edi
	sbbq	%rdi, %rdi
	addq	%rsi, %rcx
	adcq	$0, %rdi
	addq	$-1, %rcx
	adcq	$0, %rdi
	movq	176(%rsp), %rsi
	xorq	$-2, %rdi
	subq	16(%rsp), %rsi
	movl	$0, %r8d
	sbbq	%r8, %r8
	addq	%rdi, %rsi
	adcq	$-1, %r8
	addq	$1, %rsi
	adcq	$1, %r8
	xorq	$-2, %r8
	movq	184(%rsp), %rdi
	subq	24(%rsp), %rdi
	movl	$0, %r9d
	sbbq	%r9, %r9
	addq	%r8, %rdi
	adcq	$-1, %r9
	movq	%rdi, %r8
	addq	$1, %r8
	adcq	$1, %r9
	xorq	$1, %r9
	movq	%r9, 224(%rsp)
	subq	224(%rsp), %rdx
	andq	%rdx, %r13
	andq	%rdx, %rbp
	andq	%rdx, %r15
	movq	320(%rsp), %r8
	andq	%rdx, %r8
	addq	%rax, %r13
	adcq	%rcx, %rbp
	adcq	%rsi, %r15
	adcq	$1, %rdi
	addq	%r8, %rdi
	movq	%r13, 224(%rsp)
	movq	%rbp, 232(%rsp)
	movq	%r15, 240(%rsp)
	movq	%rdi, 248(%rsp)
	leaq	96(%rsp), %rdi
	leaq	224(%rsp), %rdx
	leaq	336(%rsp), %rcx
	leaq	432(%rsp), %r15
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
.Ltmp502:
	movq	%rsp, %rdi
	leaq	192(%rsp), %rcx
	movq	%r15, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp503:
	movq	96(%rsp), %r9
	movq	104(%rsp), %rdi
	movq	8(%rsp), %r8
	movq	16(%rsp), %rdx
	movq	112(%rsp), %rsi
	movq	24(%rsp), %rax
	movq	120(%rsp), %rcx
	cmpq	(%rsp), %r9
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	#MEMBARRIER
	jne	.LBB106_16
	cmpq	%r8, %rdi
	jne	.LBB106_16
	cmpq	%rdx, %rsi
	jne	.LBB106_16
	cmpq	%rax, %rcx
	jne	.LBB106_16
	leaq	1(%r14), %rax
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	leaq	104(%rbx), %rdi
	movaps	128(%rsp), %xmm0
	movaps	%xmm0, 320(%rsp)
	movaps	144(%rsp), %xmm0
	movaps	%xmm0, 704(%rsp)
	movaps	192(%rsp), %xmm0
	movaps	%xmm0, 688(%rsp)
	movaps	208(%rsp), %xmm0
	movaps	%xmm0, 672(%rsp)
	movups	496(%rsp), %xmm0
	movaps	%xmm0, 656(%rsp)
	movups	512(%rsp), %xmm0
	movaps	%xmm0, 640(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movzbl	(%r14), %ebp
	movups	(%rax), %xmm0
	movups	16(%rax), %xmm1
	movups	32(%rax), %xmm2
	movups	48(%rax), %xmm3
	movups	%xmm3, 457(%rbx)
	movups	%xmm2, 441(%rbx)
	movups	%xmm1, 425(%rbx)
	movups	%xmm0, 409(%rbx)
	leaq	336(%rsp), %rsi
	movl	$304, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movaps	320(%rsp), %xmm0
	movups	%xmm0, 8(%rbx)
	movaps	704(%rsp), %xmm0
	movups	%xmm0, 24(%rbx)
	movaps	688(%rsp), %xmm0
	movups	%xmm0, 40(%rbx)
	movaps	672(%rsp), %xmm0
	movups	%xmm0, 56(%rbx)
	movaps	656(%rsp), %xmm0
	movups	%xmm0, 72(%rbx)
	movaps	640(%rsp), %xmm0
	movups	%xmm0, 88(%rbx)
	movb	%bpl, 408(%rbx)
	movb	$0, (%rbx)
	jmp	.LBB106_28
.LBB106_1:
	xorl	%eax, %eax
	jmp	.LBB106_30
.LBB106_16:
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
.LBB106_17:
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movb	$3, %al
.LBB106_30:
	movb	%al, 1(%rbx)
	movb	$1, (%rbx)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	#MEMBARRIER
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	#MEMBARRIER
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	#MEMBARRIER
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	#MEMBARRIER
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
.LBB106_28:
	movq	%rbx, %rax
	addq	$728, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB106_23:
	.cfi_def_cfa_offset 784
.Ltmp504:
	movq	%rax, %rbx
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	jmp	.LBB106_25
.LBB106_22:
.Ltmp501:
	leaq	312(%rsp), %rcx
	movq	%rax, %rbx
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	jmp	.LBB106_21
.LBB106_20:
.Ltmp498:
	leaq	24(%rsp), %rcx
	movq	%rax, %rbx
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
.LBB106_21:
	movq	$0, (%r12)
	movq	$0, (%rcx)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	jmp	.LBB106_19
.LBB106_18:
.Ltmp495:
	movq	%rax, %rbx
.LBB106_19:
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	jmp	.LBB106_25
.LBB106_24:
.Ltmp492:
	movq	%rax, %rbx
.LBB106_25:
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
.LBB106_26:
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
.LBB106_3:
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	336(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj4_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB106_31:
.Ltmp489:
	movq	%rax, %rbx
	jmp	.LBB106_26
.LBB106_2:
.Ltmp486:
	movq	%rax, %rbx
	jmp	.LBB106_3
.Lfunc_end106:
	.size	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1, .Lfunc_end106-_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1,"a",@progbits
	.p2align	2, 0x0
GCC_except_table106:
.Lexception43:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end43-.Lcst_begin43
.Lcst_begin43:
	.uleb128 .Lfunc_begin43-.Lfunc_begin43
	.uleb128 .Ltmp484-.Lfunc_begin43
	.byte	0
	.byte	0
	.uleb128 .Ltmp484-.Lfunc_begin43
	.uleb128 .Ltmp485-.Ltmp484
	.uleb128 .Ltmp486-.Lfunc_begin43
	.byte	0
	.uleb128 .Ltmp487-.Lfunc_begin43
	.uleb128 .Ltmp488-.Ltmp487
	.uleb128 .Ltmp489-.Lfunc_begin43
	.byte	0
	.uleb128 .Ltmp490-.Lfunc_begin43
	.uleb128 .Ltmp491-.Ltmp490
	.uleb128 .Ltmp492-.Lfunc_begin43
	.byte	0
	.uleb128 .Ltmp493-.Lfunc_begin43
	.uleb128 .Ltmp494-.Ltmp493
	.uleb128 .Ltmp495-.Lfunc_begin43
	.byte	0
	.uleb128 .Ltmp496-.Lfunc_begin43
	.uleb128 .Ltmp497-.Ltmp496
	.uleb128 .Ltmp498-.Lfunc_begin43
	.byte	0
	.uleb128 .Ltmp499-.Lfunc_begin43
	.uleb128 .Ltmp500-.Ltmp499
	.uleb128 .Ltmp501-.Lfunc_begin43
	.byte	0
	.uleb128 .Ltmp502-.Lfunc_begin43
	.uleb128 .Ltmp503-.Ltmp502
	.uleb128 .Ltmp504-.Lfunc_begin43
	.byte	0
	.uleb128 .Ltmp503-.Lfunc_begin43
	.uleb128 .Lfunc_end106-.Ltmp503
	.byte	0
	.byte	0
.Lcst_end43:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest,"ax",@progbits
	.globl	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest
	.p2align	4
	.type	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest,@function
_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest:
.Lfunc_begin44:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception44
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1304, %rsp
	.cfi_def_cfa_offset 1360
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movb	$4, %al
	cmpq	$6, %rcx
	jb	.LBB107_43
	cmpb	$48, (%rdx)
	jne	.LBB107_43
	movzbl	1(%rdx), %r8d
	leaq	-2(%rcx), %r9
	cmpq	%r8, %r9
	jne	.LBB107_43
	cmpb	$2, 2(%rdx)
	jne	.LBB107_43
	movzbl	3(%rdx), %ebx
	leaq	4(%rbx), %r14
	cmpq	%rcx, %r14
	ja	.LBB107_43
	testq	%rbx, %rbx
	je	.LBB107_43
	leaq	448(%rdi), %r10
	leaq	4(%rdx), %r8
	cmpb	$0, (%r8)
	js	.LBB107_43
	movq	%rbx, %r9
	jne	.LBB107_11
	cmpl	$1, %ebx
	je	.LBB107_10
	cmpb	$0, 5(%rdx)
	jns	.LBB107_43
.LBB107_10:
	leaq	-1(%rbx), %r9
	leaq	5(%rdx), %r8
.LBB107_11:
	movb	$5, %al
	cmpl	$49, %r9d
	jae	.LBB107_43
	movq	%r10, 1064(%rsp)
	movq	%rdx, %r12
	movq	%rsi, 1072(%rsp)
	movq	%rdi, 8(%rsp)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	leaq	16(%rsp), %r15
	movq	%r15, %rdi
	subq	%r9, %rdi
	addq	$48, %rdi
	movq	%r8, %rsi
	movq	%r9, %rdx
	movq	%rcx, %r13
	callq	*memcpy@GOTPCREL(%rip)
	movzbl	16(%rsp), %ebp
	movups	17(%rsp), %xmm0
	movaps	%xmm0, 416(%rsp)
	movups	33(%rsp), %xmm0
	movaps	%xmm0, 432(%rsp)
	movups	48(%rsp), %xmm0
	movups	%xmm0, 447(%rsp)
	movb	$4, %al
	cmpq	%r13, %r14
	jae	.LBB107_43
	cmpb	$2, (%r12,%r14)
	jne	.LBB107_43
	movq	%r13, %rcx
	leaq	5(%rbx), %rdx
	cmpq	%r13, %rdx
	jae	.LBB107_43
	movzbl	5(%r12,%rbx), %edx
	leaq	(%rbx,%rdx), %r14
	addq	$6, %r14
	cmpq	%rcx, %r14
	ja	.LBB107_43
	testq	%rdx, %rdx
	je	.LBB107_43
	addq	$6, %rbx
	addq	%rbx, %r12
	cmpb	$0, (%r12)
	js	.LBB107_43
	jne	.LBB107_22
	cmpl	$1, %edx
	je	.LBB107_21
	cmpb	$0, 1(%r12)
	jns	.LBB107_43
.LBB107_21:
	decq	%rdx
	incq	%r12
.LBB107_22:
	movb	$5, %al
	cmpl	$49, %edx
	jae	.LBB107_43
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	subq	%rdx, %r15
	addq	$48, %r15
	movq	%r15, %rdi
	movq	%r12, %rsi
	callq	*memcpy@GOTPCREL(%rip)
	movzbl	16(%rsp), %ecx
	movups	17(%rsp), %xmm0
	movaps	%xmm0, 224(%rsp)
	movups	33(%rsp), %xmm0
	movaps	%xmm0, 240(%rsp)
	movups	48(%rsp), %xmm0
	movups	%xmm0, 255(%rsp)
	movb	$4, %al
	cmpq	%r13, %r14
	movq	8(%rsp), %rsi
	jne	.LBB107_43
	movups	447(%rsp), %xmm0
	movups	%xmm0, 1184(%rsp)
	movaps	416(%rsp), %xmm0
	movaps	432(%rsp), %xmm1
	movups	%xmm1, 1169(%rsp)
	movups	%xmm0, 1153(%rsp)
	movups	255(%rsp), %xmm0
	movups	%xmm0, 1232(%rsp)
	movaps	224(%rsp), %xmm0
	movaps	240(%rsp), %xmm1
	movups	%xmm1, 1217(%rsp)
	movups	%xmm0, 1201(%rsp)
	movb	%bpl, 1152(%rsp)
	movb	%cl, 1200(%rsp)
	leaq	1248(%rsp), %rdi
	leaq	1152(%rsp), %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_
	cmpb	$0, 1248(%rsp)
	jne	.LBB107_42
	movups	1256(%rsp), %xmm0
	movups	1272(%rsp), %xmm1
	movups	1288(%rsp), %xmm2
	movaps	%xmm2, 208(%rsp)
	movaps	%xmm1, 192(%rsp)
	movaps	%xmm0, 176(%rsp)
	leaq	1096(%rsp), %rdi
	leaq	1200(%rsp), %rdx
	movq	8(%rsp), %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_
	cmpb	$1, 1096(%rsp)
	jne	.LBB107_27
	movw	$1281, 1096(%rsp)
	jmp	.LBB107_41
.LBB107_27:
	movups	1104(%rsp), %xmm0
	movups	1120(%rsp), %xmm1
	movups	1136(%rsp), %xmm2
	movaps	%xmm2, 640(%rsp)
	movq	1072(%rsp), %rcx
	movq	40(%rcx), %rax
	bswapq	%rax
	movaps	%xmm1, 624(%rsp)
	movq	32(%rcx), %rdx
	bswapq	%rdx
	movq	24(%rcx), %rsi
	bswapq	%rsi
	movq	16(%rcx), %rdi
	bswapq	%rdi
	movq	(%rcx), %r8
	movq	8(%rcx), %rcx
	bswapq	%rcx
	bswapq	%r8
	movaps	%xmm0, 608(%rsp)
	movq	%rax, 408(%rsp)
	movq	%rdx, 400(%rsp)
	movq	%rsi, 392(%rsp)
	movq	%rdi, 384(%rsp)
	movq	%rcx, 376(%rsp)
	movq	%r8, 368(%rsp)
	movq	8(%rsp), %rbx
	leaq	296(%rbx), %r15
	movq	$0, 416(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 168(%rsp)
	movq	%rax, 224(%rsp)
	movq	%rdx, 232(%rsp)
	movq	%rsi, 240(%rsp)
	movq	%rdi, 248(%rsp)
	movq	%rcx, 256(%rsp)
	movq	%r8, 264(%rsp)
	leaq	16(%rsp), %rdi
	leaq	224(%rsp), %rdx
	movq	%r15, %rsi
	xorl	%ecx, %ecx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movups	16(%rsp), %xmm0
	movups	32(%rsp), %xmm1
	movups	48(%rsp), %xmm2
	movaps	%xmm2, 688(%rsp)
	movaps	%xmm1, 672(%rsp)
	movaps	%xmm0, 656(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	leaq	344(%rbx), %r12
.Ltmp505:
	leaq	16(%rsp), %rdi
	leaq	608(%rsp), %rdx
	movq	%r15, %rsi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp506:
.Ltmp508:
	leaq	560(%rsp), %rdi
	leaq	16(%rsp), %rdx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_
.Ltmp509:
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
.Ltmp511:
	leaq	224(%rsp), %rdi
	leaq	656(%rsp), %rdx
	movq	%r15, %rsi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp512:
.Ltmp514:
	leaq	416(%rsp), %rdi
	leaq	224(%rsp), %rdx
	leaq	560(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp515:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 40(%rsp)
	movups	%xmm0, 24(%rsp)
	movq	$0, 56(%rsp)
	movq	$1, 16(%rsp)
.Ltmp517:
	leaq	704(%rsp), %rdi
	leaq	416(%rsp), %rdx
	leaq	16(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp518:
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
.Ltmp520:
	leaq	224(%rsp), %rdi
	leaq	176(%rsp), %rdx
	movq	%r15, %rsi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp521:
.Ltmp523:
	leaq	416(%rsp), %rdi
	leaq	224(%rsp), %rdx
	leaq	560(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp524:
	xorps	%xmm0, %xmm0
	movups	%xmm0, 40(%rsp)
	movups	%xmm0, 24(%rsp)
	movq	$0, 56(%rsp)
	movq	$1, 16(%rsp)
.Ltmp526:
	leaq	752(%rsp), %rdi
	leaq	416(%rsp), %rdx
	leaq	16(%rsp), %rcx
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp527:
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	8(%rsp), %rcx
	movups	48(%rcx), %xmm0
	movups	64(%rcx), %xmm1
	movups	80(%rcx), %xmm2
	movaps	%xmm2, 256(%rsp)
	movaps	%xmm1, 240(%rsp)
	movaps	%xmm0, 224(%rsp)
	movups	96(%rcx), %xmm0
	movups	112(%rcx), %xmm1
	movups	128(%rcx), %xmm2
	movaps	%xmm0, 272(%rsp)
	movaps	%xmm1, 288(%rsp)
	movaps	%xmm2, 304(%rsp)
	movups	240(%rcx), %xmm0
	movups	256(%rcx), %xmm1
	movups	272(%rcx), %xmm2
	movaps	%xmm0, 320(%rsp)
	movaps	%xmm1, 336(%rsp)
	movaps	%xmm2, 352(%rsp)
.Ltmp529:
	leaq	416(%rsp), %rdi
	leaq	224(%rsp), %r12
	leaq	704(%rsp), %rdx
	movq	%r12, %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
.Ltmp530:
.Ltmp532:
	leaq	16(%rsp), %rdi
	leaq	752(%rsp), %rdx
	movq	1064(%rsp), %rsi
	movq	8(%rsp), %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
.Ltmp533:
.Ltmp535:
	leaq	920(%rsp), %rdi
	leaq	416(%rsp), %rsi
	leaq	16(%rsp), %rdx
	movq	8(%rsp), %rcx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_
.Ltmp536:
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	#MEMBARRIER
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
.Ltmp538:
	leaq	16(%rsp), %rdi
	leaq	920(%rsp), %r12
	movq	%r12, %rsi
	movq	8(%rsp), %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_
.Ltmp539:
	cmpb	$0, 16(%rsp)
	je	.LBB107_44
	movw	$1281, 16(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 960(%rsp)
	#MEMBARRIER
	movq	$0, 968(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 1008(%rsp)
	#MEMBARRIER
	movq	$0, 1016(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	movq	$0, 1056(%rsp)
	#MEMBARRIER
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	#MEMBARRIER
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	#MEMBARRIER
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	#MEMBARRIER
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	#MEMBARRIER
.LBB107_41:
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
.LBB107_42:
	movb	$5, %al
.LBB107_43:
	addq	$1304, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB107_44:
	.cfi_def_cfa_offset 1360
	movq	24(%rsp), %rax
	movq	32(%rsp), %rcx
	movq	40(%rsp), %rdx
	movq	48(%rsp), %rsi
	movq	56(%rsp), %rdi
	movq	64(%rsp), %r8
	movq	%rax, 840(%rsp)
	movq	%rcx, 832(%rsp)
	movq	%rdx, 824(%rsp)
	movq	%rsi, 816(%rsp)
	movq	%rdi, 808(%rsp)
	movq	%r8, 800(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 896(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1080(%rsp)
	movq	840(%rsp), %rax
	movq	%rax, 416(%rsp)
	movq	832(%rsp), %rax
	movq	%rax, 424(%rsp)
	movq	824(%rsp), %rax
	movq	%rax, 432(%rsp)
	movq	816(%rsp), %rax
	movq	%rax, 440(%rsp)
	movq	808(%rsp), %rax
	movq	%rax, 448(%rsp)
	movq	800(%rsp), %rax
	movq	%rax, 456(%rsp)
	leaq	224(%rsp), %rdi
	leaq	416(%rsp), %rdx
	movq	%r15, %rsi
	xorl	%ecx, %ecx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	224(%rsp), %rax
	movq	232(%rsp), %rcx
	movq	%rax, 888(%rsp)
	movq	%rcx, 880(%rsp)
	movq	240(%rsp), %rax
	movq	%rax, 872(%rsp)
	movq	248(%rsp), %rax
	movq	%rax, 864(%rsp)
	movq	256(%rsp), %rax
	movq	%rax, 856(%rsp)
	movq	264(%rsp), %rax
	movq	%rax, 848(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1080(%rsp)
	#MEMBARRIER
	movq	176(%rsp), %rax
	movq	184(%rsp), %rcx
	movq	192(%rsp), %rdx
	movq	200(%rsp), %rsi
	movq	208(%rsp), %rdi
	movq	216(%rsp), %r8
	xorq	880(%rsp), %rcx
	xorq	888(%rsp), %rax
	xorq	872(%rsp), %rdx
	xorq	864(%rsp), %rsi
	orq	%rcx, %rax
	orq	%rdx, %rsi
	xorq	856(%rsp), %rdi
	orq	%rax, %rsi
	orq	%rsi, %rdi
	xorq	848(%rsp), %r8
	orq	%rdi, %r8
	sete	%al
	negb	%al
	orb	$5, %al
	movq	$0, 888(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 872(%rsp)
	movq	$0, 864(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 848(%rsp)
	#MEMBARRIER
	movq	$0, 840(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 800(%rsp)
	#MEMBARRIER
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 960(%rsp)
	#MEMBARRIER
	movq	$0, 968(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 1008(%rsp)
	#MEMBARRIER
	movq	$0, 1016(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	movq	$0, 1056(%rsp)
	#MEMBARRIER
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	#MEMBARRIER
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	#MEMBARRIER
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	#MEMBARRIER
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	jmp	.LBB107_43
.LBB107_45:
.Ltmp540:
	jmp	.LBB107_50
.LBB107_46:
.Ltmp537:
	movq	%rax, %rbx
	leaq	16(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	jmp	.LBB107_48
.LBB107_47:
.Ltmp534:
	movq	%rax, %rbx
.LBB107_48:
	leaq	416(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	jmp	.LBB107_51
.LBB107_49:
.Ltmp531:
.LBB107_50:
	movq	%rax, %rbx
.LBB107_51:
	movq	%r12, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5PointKj6_EEBG_
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	#MEMBARRIER
	jmp	.LBB107_56
.LBB107_52:
.Ltmp528:
	movq	%rax, %rbx
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	jmp	.LBB107_54
.LBB107_53:
.Ltmp525:
	movq	%rax, %rbx
.LBB107_54:
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	jmp	.LBB107_56
.LBB107_55:
.Ltmp522:
	movq	%rax, %rbx
.LBB107_56:
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	#MEMBARRIER
	jmp	.LBB107_61
.LBB107_57:
.Ltmp519:
	movq	%rax, %rbx
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	jmp	.LBB107_59
.LBB107_58:
.Ltmp516:
	movq	%rax, %rbx
.LBB107_59:
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	jmp	.LBB107_61
.LBB107_60:
.Ltmp513:
	movq	%rax, %rbx
.LBB107_61:
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
.LBB107_62:
	#MEMBARRIER
.LBB107_63:
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB107_64:
.Ltmp510:
	movq	%rax, %rbx
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	jmp	.LBB107_62
.LBB107_65:
.Ltmp507:
	movq	%rax, %rbx
	jmp	.LBB107_63
.Lfunc_end107:
	.size	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest, .Lfunc_end107-_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest,"a",@progbits
	.p2align	2, 0x0
GCC_except_table107:
.Lexception44:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end44-.Lcst_begin44
.Lcst_begin44:
	.uleb128 .Lfunc_begin44-.Lfunc_begin44
	.uleb128 .Ltmp505-.Lfunc_begin44
	.byte	0
	.byte	0
	.uleb128 .Ltmp505-.Lfunc_begin44
	.uleb128 .Ltmp506-.Ltmp505
	.uleb128 .Ltmp507-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp508-.Lfunc_begin44
	.uleb128 .Ltmp509-.Ltmp508
	.uleb128 .Ltmp510-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp511-.Lfunc_begin44
	.uleb128 .Ltmp512-.Ltmp511
	.uleb128 .Ltmp513-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp514-.Lfunc_begin44
	.uleb128 .Ltmp515-.Ltmp514
	.uleb128 .Ltmp516-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp517-.Lfunc_begin44
	.uleb128 .Ltmp518-.Ltmp517
	.uleb128 .Ltmp519-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp520-.Lfunc_begin44
	.uleb128 .Ltmp521-.Ltmp520
	.uleb128 .Ltmp522-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp523-.Lfunc_begin44
	.uleb128 .Ltmp524-.Ltmp523
	.uleb128 .Ltmp525-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp526-.Lfunc_begin44
	.uleb128 .Ltmp527-.Ltmp526
	.uleb128 .Ltmp528-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp529-.Lfunc_begin44
	.uleb128 .Ltmp530-.Ltmp529
	.uleb128 .Ltmp531-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp532-.Lfunc_begin44
	.uleb128 .Ltmp533-.Ltmp532
	.uleb128 .Ltmp534-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp535-.Lfunc_begin44
	.uleb128 .Ltmp536-.Ltmp535
	.uleb128 .Ltmp537-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp538-.Lfunc_begin44
	.uleb128 .Ltmp539-.Ltmp538
	.uleb128 .Ltmp540-.Lfunc_begin44
	.byte	0
	.uleb128 .Ltmp539-.Lfunc_begin44
	.uleb128 .Lfunc_end107-.Ltmp539
	.byte	0
	.byte	0
.Lcst_end44:
	.p2align	2, 0x0

	.section	.text._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify,"ax",@progbits
	.globl	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify
	.p2align	4
	.type	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify,@function
_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$112, %rsp
	.cfi_def_cfa_offset 144
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%r8, %rbx
	movq	%rcx, %r14
	movq	%rdi, %r15
	leaq	15(%rsp), %rdi
	callq	*_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846digest@GOTPCREL(%rip)
	movzbl	16(%rsp), %eax
	cmpb	$1, 15(%rsp)
	je	.LBB108_2
	movups	17(%rsp), %xmm0
	movups	33(%rsp), %xmm1
	movups	48(%rsp), %xmm2
	movups	%xmm2, 96(%rsp)
	movups	%xmm1, 81(%rsp)
	movups	%xmm0, 65(%rsp)
	movb	%al, 64(%rsp)
	leaq	64(%rsp), %rsi
	movq	%r15, %rdi
	movq	%r14, %rdx
	movq	%rbx, %rcx
	callq	*_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest@GOTPCREL(%rip)
.LBB108_2:
	addq	$112, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end108:
	.size	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify, .Lfunc_end108-_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify
	.cfi_endproc

	.section	.text._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1,"ax",@progbits
	.globl	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1
	.p2align	4
	.type	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1,@function
_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1:
.Lfunc_begin45:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception45
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$1176, %rsp
	.cfi_def_cfa_offset 1232
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r15
	movq	%rsi, %r14
	movq	%rdi, %rbx
	leaq	624(%rsp), %rdi
	callq	*_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384@GOTPCREL(%rip)
	cmpq	$97, %r15
	jne	.LBB109_1
	movb	$4, %al
	cmpb	$4, (%r14)
	jne	.LBB109_32
	movq	41(%r14), %rax
	bswapq	%rax
	movq	33(%r14), %r9
	bswapq	%r9
	movq	25(%r14), %r8
	bswapq	%r8
	movq	17(%r14), %rdi
	bswapq	%rdi
	movq	1(%r14), %rcx
	movq	9(%r14), %rsi
	bswapq	%rsi
	bswapq	%rcx
	movq	%rax, 96(%rsp)
	movq	%r9, 104(%rsp)
	movq	%r8, 112(%rsp)
	movq	%rdi, 120(%rsp)
	movq	89(%r14), %rdx
	bswapq	%rdx
	movq	%rsi, 128(%rsp)
	movq	768(%rsp), %r15
	movq	776(%rsp), %r13
	cmpq	%r15, %rax
	movl	$1, %r10d
	sbbq	$0, %r10
	xorl	%eax, %eax
	subq	%r13, %r9
	movl	$0, %r11d
	sbbq	%r11, %r11
	addq	%r10, %r9
	adcq	$0, %r11
	addq	$-1, %r9
	adcq	$0, %r11
	xorq	$-2, %r11
	movq	784(%rsp), %r10
	subq	%r10, %r8
	movl	$0, %r9d
	sbbq	%r9, %r9
	addq	%r11, %r8
	adcq	$-1, %r9
	addq	$1, %r8
	adcq	$1, %r9
	xorq	$-2, %r9
	movq	792(%rsp), %r11
	subq	%r11, %rdi
	movl	$0, %r8d
	sbbq	%r8, %r8
	addq	%r9, %rdi
	adcq	$-1, %r8
	addq	$1, %rdi
	adcq	$1, %r8
	xorq	$-2, %r8
	movq	800(%rsp), %rbp
	subq	%rbp, %rsi
	movl	$0, %edi
	sbbq	%rdi, %rdi
	addq	%r8, %rsi
	adcq	$-1, %rdi
	movq	%rcx, 136(%rsp)
	addq	$1, %rsi
	adcq	$1, %rdi
	xorq	$-2, %rdi
	movq	808(%rsp), %r8
	subq	%r8, %rcx
	movl	$0, %esi
	sbbq	%rsi, %rsi
	addq	%rdi, %rcx
	movq	81(%r14), %rdi
	bswapq	%rdi
	movq	%rdx, 144(%rsp)
	movq	%rdi, 152(%rsp)
	adcq	$-1, %rsi
	addq	$1, %rcx
	movl	$1, %ecx
	adcq	$1, %rsi
	xorq	$1, %rsi
	movq	%r15, 560(%rsp)
	cmpq	%r15, %rdx
	sbbq	$0, %rcx
	subq	%r13, %rdi
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rcx, %rdi
	movq	73(%r14), %rcx
	bswapq	%rcx
	adcq	$0, %rdx
	addq	$-1, %rdi
	adcq	$0, %rdx
	movq	%rcx, 160(%rsp)
	xorq	$-2, %rdx
	subq	%r10, %rcx
	movl	$0, %edi
	sbbq	%rdi, %rdi
	addq	%rdx, %rcx
	movq	65(%r14), %rdx
	bswapq	%rdx
	adcq	$-1, %rdi
	addq	$1, %rcx
	adcq	$1, %rdi
	movq	%rdx, 168(%rsp)
	xorq	$-2, %rdi
	subq	%r11, %rdx
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%rdi, %rdx
	movq	57(%r14), %rdi
	bswapq	%rdi
	adcq	$-1, %rcx
	addq	$1, %rdx
	adcq	$1, %rcx
	movq	%rdi, 176(%rsp)
	xorq	$-2, %rcx
	subq	%rbp, %rdi
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rcx, %rdi
	movq	49(%r14), %rcx
	bswapq	%rcx
	adcq	$-1, %rdx
	addq	$1, %rdi
	movq	%rcx, 184(%rsp)
	adcq	$1, %rdx
	xorq	$-2, %rdx
	subq	%r8, %rcx
	sbbq	%rax, %rax
	addq	%rdx, %rcx
	adcq	$-1, %rax
	addq	$1, %rcx
	adcq	$1, %rax
	xorq	$1, %rax
	testq	%rax, %rsi
	je	.LBB109_19
	movq	%r10, %r15
	movq	%r11, 528(%rsp)
	movq	%r8, 544(%rsp)
	leaq	768(%rsp), %rsi
	leaq	816(%rsp), %r12
.Ltmp541:
	leaq	192(%rsp), %rdi
	leaq	96(%rsp), %rdx
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp542:
.Ltmp544:
	leaq	288(%rsp), %rdi
	leaq	144(%rsp), %rdx
	leaq	768(%rsp), %rsi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp545:
.Ltmp547:
	leaq	336(%rsp), %rdi
	leaq	192(%rsp), %rcx
	leaq	768(%rsp), %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp548:
.Ltmp550:
	leaq	240(%rsp), %rdi
	leaq	336(%rsp), %rdx
	leaq	192(%rsp), %rcx
	leaq	768(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp551:
	leaq	16(%rsp), %r12
	xorps	%xmm0, %xmm0
	movups	%xmm0, 24(%rsp)
	movups	%xmm0, 8(%rsp)
	movq	$0, 40(%rsp)
	movq	$3, (%rsp)
.Ltmp553:
	leaq	384(%rsp), %rdi
	movq	%rsp, %rdx
	leaq	768(%rsp), %rsi
	leaq	816(%rsp), %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp554:
	leaq	400(%rsp), %r12
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
.Ltmp556:
	leaq	432(%rsp), %rdi
	leaq	384(%rsp), %rdx
	leaq	192(%rsp), %rcx
	leaq	768(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp557:
	movq	240(%rsp), %rcx
	subq	432(%rsp), %rcx
	movl	$1, %eax
	sbbq	$0, %rax
	movq	248(%rsp), %rdx
	xorl	%esi, %esi
	subq	440(%rsp), %rdx
	movl	$0, %r8d
	sbbq	%r8, %r8
	addq	%rax, %rdx
	adcq	$0, %r8
	addq	$-1, %rdx
	adcq	$0, %r8
	movq	256(%rsp), %rdi
	xorq	$-2, %r8
	subq	448(%rsp), %rdi
	movl	$0, %eax
	sbbq	%rax, %rax
	addq	%r8, %rdi
	adcq	$-1, %rax
	addq	$1, %rdi
	adcq	$1, %rax
	movq	264(%rsp), %r8
	xorq	$-2, %rax
	subq	456(%rsp), %r8
	movl	$0, %r10d
	sbbq	%r10, %r10
	addq	%rax, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$1, %r10
	movq	272(%rsp), %r9
	xorq	$-2, %r10
	subq	464(%rsp), %r9
	movl	$0, %r11d
	sbbq	%r11, %r11
	addq	%r10, %r9
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$1, %r11
	xorq	$-2, %r11
	movq	280(%rsp), %rax
	subq	472(%rsp), %rax
	movl	$0, %r10d
	sbbq	%r10, %r10
	addq	%r11, %rax
	adcq	$-1, %r10
	movq	%rax, %r11
	addq	$1, %r11
	adcq	$1, %r10
	xorq	$1, %r10
	movq	%r10, (%rsp)
	subq	(%rsp), %rsi
	movq	560(%rsp), %r10
	andq	%rsi, %r10
	andq	%rsi, %r13
	andq	%rsi, %r15
	movq	528(%rsp), %r12
	andq	%rsi, %r12
	andq	%rsi, %rbp
	movq	544(%rsp), %r11
	andq	%rsi, %r11
	addq	%rcx, %r10
	adcq	%rdx, %r13
	adcq	%rdi, %r15
	adcq	%r8, %r12
	adcq	%r9, %rbp
	adcq	$1, %rax
	addq	%r11, %rax
	movq	%r10, 616(%rsp)
	movq	%r13, 608(%rsp)
	movq	%r15, 600(%rsp)
	movq	%r12, 592(%rsp)
	movq	%rbp, 584(%rsp)
	movq	%rax, 576(%rsp)
	addq	624(%rsp), %r10
	movq	%r10, 480(%rsp)
	adcq	$0, %r13
	setb	%cl
	movq	632(%rsp), %rdx
	leaq	(%rdx,%r13), %rsi
	xorl	%edi, %edi
	addq	640(%rsp), %r15
	movq	%rsi, 488(%rsp)
	setb	%dil
	addq	%rdx, %r13
	movzbl	%cl, %ecx
	adcq	%r15, %rcx
	setb	%sil
	movq	%rcx, 496(%rsp)
	xorl	%edx, %edx
	addq	648(%rsp), %r12
	setb	%dl
	addb	$255, %sil
	adcq	%r12, %rdi
	setb	%cl
	movq	%rdi, 504(%rsp)
	xorl	%esi, %esi
	addq	656(%rsp), %rbp
	setb	%sil
	addb	$255, %cl
	adcq	%rbp, %rdx
	setb	%dil
	xorl	%ecx, %ecx
	addq	664(%rsp), %rax
	setb	%cl
	addb	$255, %dil
	adcq	%rax, %rsi
	movq	%rdx, 512(%rsp)
	adcq	$0, %rcx
	movq	%rsi, 520(%rsp)
	movq	%rsp, %rdi
	leaq	480(%rsp), %rdx
	leaq	768(%rsp), %r15
	movq	%r15, %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	#MEMBARRIER
	movq	(%rsp), %rax
	movq	8(%rsp), %rcx
	movq	%rax, 88(%rsp)
	movq	%rcx, 80(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
.Ltmp559:
	movq	%rsp, %rdi
	leaq	288(%rsp), %rcx
	movq	%r15, %rsi
	movq	%rcx, %rdx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp560:
	movq	88(%rsp), %r12
	movq	80(%rsp), %r11
	movq	8(%rsp), %r15
	movq	16(%rsp), %r9
	movq	72(%rsp), %r10
	movq	24(%rsp), %rdi
	movq	64(%rsp), %r8
	movq	32(%rsp), %rdx
	movq	56(%rsp), %rsi
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	cmpq	(%rsp), %r12
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	jne	.LBB109_18
	cmpq	%r15, %r11
	jne	.LBB109_18
	cmpq	%r9, %r10
	jne	.LBB109_18
	cmpq	%rdi, %r8
	jne	.LBB109_18
	cmpq	%rdx, %rsi
	jne	.LBB109_18
	cmpq	%rax, %rcx
	jne	.LBB109_18
	leaq	1(%r14), %rax
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	leaq	8(%rbx), %rdi
	movaps	192(%rsp), %xmm0
	movaps	%xmm0, 560(%rsp)
	movaps	208(%rsp), %xmm0
	movaps	%xmm0, 544(%rsp)
	movaps	224(%rsp), %xmm0
	movaps	%xmm0, 528(%rsp)
	movaps	288(%rsp), %xmm0
	movaps	%xmm0, 1152(%rsp)
	movaps	304(%rsp), %xmm0
	movaps	%xmm0, 1136(%rsp)
	movaps	320(%rsp), %xmm0
	movaps	%xmm0, 1120(%rsp)
	movups	864(%rsp), %xmm0
	movaps	%xmm0, 1104(%rsp)
	movups	880(%rsp), %xmm0
	movaps	%xmm0, 1088(%rsp)
	movups	896(%rsp), %xmm0
	movaps	%xmm0, 1072(%rsp)
	#MEMBARRIER
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movzbl	(%r14), %ebp
	movups	80(%rax), %xmm0
	movups	%xmm0, 681(%rbx)
	movups	64(%rax), %xmm0
	movups	%xmm0, 665(%rbx)
	movups	(%rax), %xmm0
	movups	16(%rax), %xmm1
	movups	32(%rax), %xmm2
	movups	48(%rax), %xmm3
	movups	%xmm3, 649(%rbx)
	movups	%xmm2, 633(%rbx)
	movups	%xmm1, 617(%rbx)
	movups	%xmm0, 601(%rbx)
	leaq	624(%rsp), %rsi
	movl	$448, %edx
	callq	*memcpy@GOTPCREL(%rip)
	movaps	560(%rsp), %xmm0
	movups	%xmm0, 456(%rbx)
	movaps	544(%rsp), %xmm0
	movups	%xmm0, 472(%rbx)
	movaps	528(%rsp), %xmm0
	movups	%xmm0, 488(%rbx)
	movaps	1152(%rsp), %xmm0
	movups	%xmm0, 504(%rbx)
	movaps	1136(%rsp), %xmm0
	movups	%xmm0, 520(%rbx)
	movaps	1120(%rsp), %xmm0
	movups	%xmm0, 536(%rbx)
	movaps	1104(%rsp), %xmm0
	movups	%xmm0, 552(%rbx)
	movaps	1088(%rsp), %xmm0
	movups	%xmm0, 568(%rbx)
	movaps	1072(%rsp), %xmm0
	movups	%xmm0, 584(%rbx)
	movb	%bpl, 600(%rbx)
	movb	$0, (%rbx)
	jmp	.LBB109_30
.LBB109_1:
	xorl	%eax, %eax
	jmp	.LBB109_32
.LBB109_18:
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
.LBB109_19:
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movb	$3, %al
.LBB109_32:
	movb	%al, 1(%rbx)
	movb	$1, (%rbx)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	movq	$0, 856(%rsp)
	#MEMBARRIER
	movq	$0, 864(%rsp)
	movq	$0, 872(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 904(%rsp)
	#MEMBARRIER
	movq	$0, 968(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 1008(%rsp)
	#MEMBARRIER
	movq	$0, 1016(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	movq	$0, 1056(%rsp)
	#MEMBARRIER
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	#MEMBARRIER
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	#MEMBARRIER
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	#MEMBARRIER
.LBB109_30:
	movq	%rbx, %rax
	addq	$1176, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB109_25:
	.cfi_def_cfa_offset 1232
.Ltmp561:
	movq	%rax, %rbx
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	jmp	.LBB109_27
.LBB109_24:
.Ltmp558:
	leaq	424(%rsp), %rdi
	leaq	416(%rsp), %rsi
	leaq	408(%rsp), %rdx
	movq	%r12, %rcx
	movq	%rax, %rbx
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	jmp	.LBB109_23
.LBB109_22:
.Ltmp555:
	leaq	40(%rsp), %rdi
	leaq	32(%rsp), %rsi
	leaq	24(%rsp), %rdx
	movq	%r12, %rcx
	movq	%rax, %rbx
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
.LBB109_23:
	movq	$0, (%rcx)
	movq	$0, (%rdx)
	movq	$0, (%rsi)
	movq	$0, (%rdi)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	jmp	.LBB109_21
.LBB109_20:
.Ltmp552:
	movq	%rax, %rbx
.LBB109_21:
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
	jmp	.LBB109_27
.LBB109_26:
.Ltmp549:
	movq	%rax, %rbx
.LBB109_27:
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
.LBB109_28:
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
.LBB109_3:
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	leaq	624(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto4nist5CurveKj6_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB109_33:
.Ltmp546:
	movq	%rax, %rbx
	jmp	.LBB109_28
.LBB109_2:
.Ltmp543:
	movq	%rax, %rbx
	jmp	.LBB109_3
.Lfunc_end109:
	.size	_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1, .Lfunc_end109-_RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1
	.cfi_endproc
	.section	.gcc_except_table._RNvMs_NtNtCs1muTxUaRwMI_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1,"a",@progbits
	.p2align	2, 0x0
GCC_except_table109:
.Lexception45:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end45-.Lcst_begin45
.Lcst_begin45:
	.uleb128 .Lfunc_begin45-.Lfunc_begin45
	.uleb128 .Ltmp541-.Lfunc_begin45
	.byte	0
	.byte	0
	.uleb128 .Ltmp541-.Lfunc_begin45
	.uleb128 .Ltmp542-.Ltmp541
	.uleb128 .Ltmp543-.Lfunc_begin45
	.byte	0
	.uleb128 .Ltmp544-.Lfunc_begin45
	.uleb128 .Ltmp545-.Ltmp544
	.uleb128 .Ltmp546-.Lfunc_begin45
	.byte	0
	.uleb128 .Ltmp547-.Lfunc_begin45
	.uleb128 .Ltmp548-.Ltmp547
	.uleb128 .Ltmp549-.Lfunc_begin45
	.byte	0
	.uleb128 .Ltmp550-.Lfunc_begin45
	.uleb128 .Ltmp551-.Ltmp550
	.uleb128 .Ltmp552-.Lfunc_begin45
	.byte	0
	.uleb128 .Ltmp553-.Lfunc_begin45
	.uleb128 .Ltmp554-.Ltmp553
	.uleb128 .Ltmp555-.Lfunc_begin45
	.byte	0
	.uleb128 .Ltmp556-.Lfunc_begin45
	.uleb128 .Ltmp557-.Ltmp556
	.uleb128 .Ltmp558-.Lfunc_begin45
	.byte	0
	.uleb128 .Ltmp559-.Lfunc_begin45
	.uleb128 .Ltmp560-.Ltmp559
	.uleb128 .Ltmp561-.Lfunc_begin45
	.byte	0
	.uleb128 .Ltmp560-.Lfunc_begin45
	.uleb128 .Lfunc_end109-.Ltmp560
	.byte	0
	.byte	0
.Lcst_end45:
	.p2align	2, 0x0

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto2ct5equal,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto2ct5equal
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto2ct5equal,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto2ct5equal:
	.cfi_startproc
	cmpq	%rcx, %rsi
	jne	.LBB110_4
	testq	%rsi, %rsi
	je	.LBB110_5
	cmpq	$4, %rsi
	jae	.LBB110_7
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	jmp	.LBB110_10
.LBB110_4:
	xorl	%eax, %eax
	retq
.LBB110_5:
	xorl	%eax, %eax
	movq	%rax, -8(%rsp)
	cmpq	$0, -8(%rsp)
	sete	%al
	retq
.LBB110_7:
	movabsq	$9223372036854775804, %rax
	andq	%rsi, %rax
	pxor	%xmm1, %xmm1
	xorl	%ecx, %ecx
	pxor	%xmm2, %xmm2
	pxor	%xmm0, %xmm0
	.p2align	4
.LBB110_8:
	movzwl	(%rdx,%rcx), %r8d
	movzwl	2(%rdx,%rcx), %r9d
	xorw	(%rdi,%rcx), %r8w
	xorw	2(%rdi,%rcx), %r9w
	movd	%r8d, %xmm3
	movd	%r9d, %xmm4
	punpcklbw	%xmm1, %xmm3
	punpcklwd	%xmm1, %xmm3
	punpckldq	%xmm1, %xmm3
	por	%xmm3, %xmm2
	punpcklbw	%xmm1, %xmm4
	punpcklwd	%xmm1, %xmm4
	punpckldq	%xmm1, %xmm4
	por	%xmm4, %xmm0
	addq	$4, %rcx
	cmpq	%rcx, %rax
	jne	.LBB110_8
	por	%xmm2, %xmm0
	pshufd	$238, %xmm0, %xmm1
	por	%xmm0, %xmm1
	movq	%xmm1, %rcx
	jmp	.LBB110_11
.LBB110_10:
	movzbl	(%rdx,%rax), %r8d
	xorb	(%rdi,%rax), %r8b
	incq	%rax
	movzbl	%r8b, %r8d
	orq	%r8, %rcx
.LBB110_11:
	cmpq	%rax, %rsi
	jne	.LBB110_10
	xorl	%eax, %eax
	testq	%rcx, %rcx
	setne	%al
	movq	%rax, -8(%rsp)
	cmpq	$0, -8(%rsp)
	sete	%al
	retq
.Lfunc_end110:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto2ct5equal, .Lfunc_end110-_RNvNtCs1muTxUaRwMI_12toyos_crypto2ct5equal
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul:
	.cfi_startproc
	movl	%esi, %eax
	andl	$1, %eax
	movq	%rax, -8(%rsp)
	movq	-8(%rsp), %rcx
	negb	%cl
	andb	%dil, %cl
	leal	(%rdi,%rdi), %r8d
	shrb	$7, %dil
	movzbl	%dil, %eax
	movq	%rax, -8(%rsp)
	movq	-8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movl	%esi, %edx
	shrb	%dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, -8(%rsp)
	movq	-8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	addb	%al, %al
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%esi, %edi
	shrb	$2, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, -8(%rsp)
	movq	-8(%rsp), %rdi
	negb	%dil
	andb	%cl, %dil
	xorb	%dl, %dil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, -8(%rsp)
	movq	-8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%esi, %edx
	shrb	$3, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, -8(%rsp)
	movq	-8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%dil, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%esi, %edi
	shrb	$4, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, -8(%rsp)
	movq	-8(%rsp), %rdi
	negb	%dil
	andb	%cl, %dil
	xorb	%dl, %dil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, -8(%rsp)
	movq	-8(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%esi, %edx
	shrb	$5, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, -8(%rsp)
	movq	-8(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%dil, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%esi, %edi
	shrb	$6, %dil
	andb	$1, %dil
	movzbl	%dil, %edi
	movq	%rdi, -8(%rsp)
	movq	-8(%rsp), %rdi
	negb	%dil
	andb	%cl, %dil
	xorb	%dl, %dil
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, -8(%rsp)
	movq	-8(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$7, %sil
	movzbl	%sil, %eax
	movq	%rax, -8(%rsp)
	movq	-8(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%dil, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, -8(%rsp)
	movq	-8(%rsp), %rcx
	retq
.Lfunc_end111:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul, .Lfunc_end111-_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	pushq	%rax
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movl	%edi, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %ebx
	movl	%ebx, %edi
	movl	%ebx, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %r14d
	movl	%r14d, %edi
	movl	%r14d, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %r15d
	movl	%r15d, %edi
	movl	%r15d, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %r12d
	movl	%r12d, %edi
	movl	%r12d, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %r13d
	movl	%r13d, %edi
	movl	%r13d, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %ebp
	movl	%ebp, %edi
	movl	%ebp, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movb	%al, 7(%rsp)
	movl	%ebx, %edi
	movl	%r14d, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %edi
	movl	%r15d, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %edi
	movl	%r12d, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %edi
	movl	%r13d, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %edi
	movl	%ebp, %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movzbl	%al, %edi
	movzbl	7(%rsp), %esi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes3mul
	movl	%eax, %ecx
	rolb	%cl
	movl	%eax, %edx
	rolb	$2, %dl
	xorb	%cl, %dl
	movl	%eax, %ecx
	rolb	$3, %cl
	movl	%eax, %esi
	rolb	$4, %sil
	xorb	%cl, %sil
	xorb	%dl, %sil
	xorb	%sil, %al
	xorb	$99, %al
	addq	$8, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end112:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox, .Lfunc_end112-_RNvNtCs1muTxUaRwMI_12toyos_crypto3aes4sbox
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI113_0:
	.quad	67108863
	.quad	67108863
	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto4aead10chacha_tag,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto4aead10chacha_tag,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto4aead10chacha_tag:
.Lfunc_begin46:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception46
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$360, %rsp
	.cfi_def_cfa_offset 416
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r9, 208(%rsp)
	movq	%r8, %r12
	movq	%rcx, 216(%rsp)
	movq	%rdi, 200(%rsp)
	movups	.Lanon.65f595193a40e4134698b8f1074b12b6.79(%rip), %xmm0
	movaps	%xmm0, 80(%rsp)
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm1, 112(%rsp)
	movl	$0, 128(%rsp)
	movq	(%rdx), %rax
	movq	%rax, 132(%rsp)
	movl	8(%rdx), %eax
	movl	%eax, 140(%rsp)
	leaq	2(%rsp), %rdi
	leaq	80(%rsp), %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds
	movl	$0, 80(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 92(%rsp)
	movl	$0, 96(%rsp)
	movl	$0, 100(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	#MEMBARRIER
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 240(%rsp)
	movzwl	2(%rsp), %r9d
	movzbl	4(%rsp), %eax
	movzbl	6(%rsp), %r8d
	movzbl	7(%rsp), %edi
	movzbl	8(%rsp), %esi
	movzbl	5(%rsp), %r11d
	movzbl	9(%rsp), %ebp
	movzbl	10(%rsp), %edx
	movzwl	11(%rsp), %r13d
	shll	$8, %r13d
	movzbl	13(%rsp), %r10d
	movzbl	14(%rsp), %ebx
	movzbl	15(%rsp), %ecx
	movzbl	16(%rsp), %r15d
	movzbl	17(%rsp), %r14d
	andb	$15, %r11b
	andb	$15, %bpl
	andb	$15, %r10b
	andb	$15, %r14b
	movzbl	%r14b, %r14d
	shlq	$56, %r14
	shlq	$48, %r15
	orq	%r14, %r15
	shlq	$40, %rcx
	orq	%r15, %rcx
	andl	$-4, %ebx
	shlq	$32, %rbx
	movzbl	%r10b, %r10d
	shll	$24, %r10d
	orq	%rbx, %r10
	orq	%r13, %r10
	andl	$-4, %edx
	movzbl	%bpl, %ebx
	shlq	$56, %rbx
	shlq	$48, %rsi
	orq	%rbx, %rsi
	movq	%r12, %rbx
	shlq	$40, %rdi
	andl	$-4, %r8d
	shlq	$32, %r8
	movzbl	%r11b, %r11d
	shll	$24, %r11d
	shll	$16, %eax
	orq	%r9, %rax
	orq	%r11, %rax
	orq	%r8, %rax
	orq	%rdi, %rax
	movups	18(%rsp), %xmm1
	movaps	%xmm1, 224(%rsp)
	movups	%xmm0, 312(%rsp)
	movups	%xmm0, 296(%rsp)
	movq	$0, 328(%rsp)
	orq	%rcx, %r10
	shrq	$40, %rcx
	orq	%r10, %rdx
	orq	%rsi, %rax
	movl	%eax, %edi
	andl	$67108863, %edi
	shrq	$26, %rax
	shldq	$12, %rsi, %rdx
	andl	$67108863, %eax
	movq	%r10, %xmm0
	psrlq	$14, %xmm0
	movq	%rdx, %xmm1
	punpcklqdq	%xmm0, %xmm1
	pand	.LCPI113_0(%rip), %xmm1
	movq	%rdi, 256(%rsp)
	movq	%rax, 264(%rsp)
	movdqa	%xmm1, 272(%rsp)
	movq	%rcx, 288(%rsp)
	movq	$0, 336(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 344(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 66(%rsp)
	#MEMBARRIER
.Ltmp562:
	leaq	224(%rsp), %rdi
	movq	216(%rsp), %rsi
	movq	%r12, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
.Ltmp563:
	movq	336(%rsp), %rax
	testq	%rax, %rax
	je	.LBB113_6
	movl	$16, %edx
	subq	%rax, %rdx
	cmpq	$17, %rdx
	jae	.LBB113_3
.Ltmp564:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.18(%rip), %rsi
	leaq	224(%rsp), %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
.Ltmp565:
.LBB113_6:
.Ltmp566:
	movq	416(%rsp), %r12
	leaq	224(%rsp), %rdi
	movq	208(%rsp), %rsi
	movq	%r12, %rdx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
.Ltmp567:
	movq	336(%rsp), %rax
	testq	%rax, %rax
	je	.LBB113_10
	movl	$16, %edx
	subq	%rax, %rdx
	cmpq	$16, %rdx
	ja	.LBB113_3
.Ltmp570:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.18(%rip), %rsi
	leaq	224(%rsp), %rdi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
.Ltmp571:
.LBB113_10:
	movq	%rbx, 80(%rsp)
.Ltmp572:
	leaq	224(%rsp), %rdi
	leaq	80(%rsp), %rsi
	movl	$8, %edx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
.Ltmp573:
	movq	%r12, 80(%rsp)
.Ltmp574:
	leaq	224(%rsp), %rdi
	leaq	80(%rsp), %rsi
	movl	$8, %edx
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056update
.Ltmp575:
	movq	336(%rsp), %rax
	movq	%rax, 192(%rsp)
	movaps	320(%rsp), %xmm0
	movaps	%xmm0, 176(%rsp)
	movaps	304(%rsp), %xmm0
	movaps	%xmm0, 160(%rsp)
	movaps	288(%rsp), %xmm0
	movaps	%xmm0, 144(%rsp)
	movaps	224(%rsp), %xmm0
	movaps	240(%rsp), %xmm1
	movaps	256(%rsp), %xmm2
	movaps	272(%rsp), %xmm3
	movaps	%xmm3, 128(%rsp)
	movaps	%xmm2, 112(%rsp)
	movaps	%xmm1, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
.Ltmp577:
	leaq	344(%rsp), %rdi
	leaq	80(%rsp), %rsi
	callq	_RNvMNtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB2_8Poly13056finish
.Ltmp578:
	movups	344(%rsp), %xmm0
	movq	200(%rsp), %rax
	movups	%xmm0, (%rax)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	#MEMBARRIER
	addq	$360, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB113_3:
	.cfi_def_cfa_offset 416
	movq	%rdx, %rsi
.Ltmp568:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.19(%rip), %rcx
	movl	$16, %edx
	xorl	%edi, %edi
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Ltmp569:
	ud2
.LBB113_16:
.Ltmp579:
	movq	%rax, %rbx
	leaq	2(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.LBB113_14:
.Ltmp576:
	movq	%rax, %rbx
	leaq	224(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto8poly13058Poly1305EBF_
	leaq	2(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj40_EEBG_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end113:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto4aead10chacha_tag, .Lfunc_end113-_RNvNtCs1muTxUaRwMI_12toyos_crypto4aead10chacha_tag
	.cfi_endproc
	.section	.gcc_except_table._RNvNtCs1muTxUaRwMI_12toyos_crypto4aead10chacha_tag,"a",@progbits
	.p2align	2, 0x0
GCC_except_table113:
.Lexception46:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end46-.Lcst_begin46
.Lcst_begin46:
	.uleb128 .Ltmp562-.Lfunc_begin46
	.uleb128 .Ltmp575-.Ltmp562
	.uleb128 .Ltmp576-.Lfunc_begin46
	.byte	0
	.uleb128 .Ltmp577-.Lfunc_begin46
	.uleb128 .Ltmp578-.Ltmp577
	.uleb128 .Ltmp579-.Lfunc_begin46
	.byte	0
	.uleb128 .Ltmp568-.Lfunc_begin46
	.uleb128 .Ltmp569-.Ltmp568
	.uleb128 .Ltmp576-.Lfunc_begin46
	.byte	0
	.uleb128 .Ltmp569-.Lfunc_begin46
	.uleb128 .Lfunc_end113-.Ltmp569
	.byte	0
	.byte	0
.Lcst_end46:
	.p2align	2, 0x0

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$200, %rsp
	.cfi_def_cfa_offset 256
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	pxor	%xmm0, %xmm0
	movdqa	%xmm0, 176(%rsp)
	movdqa	%xmm0, 160(%rsp)
	movdqa	%xmm0, 144(%rsp)
	movdqa	%xmm0, 128(%rsp)
	movdqa	%xmm0, 112(%rsp)
	movdqa	%xmm0, 96(%rsp)
	movdqa	%xmm0, 80(%rsp)
	movdqa	%xmm0, 64(%rsp)
	movdqa	%xmm0, 48(%rsp)
	movdqa	%xmm0, 32(%rsp)
	movdqa	%xmm0, 16(%rsp)
	movdqa	%xmm0, (%rsp)
	movdqu	(%rsi), %xmm1
	movdqa	%xmm1, %xmm2
	punpckhbw	%xmm0, %xmm2
	pshuflw	$27, %xmm2, %xmm2
	pshufhw	$27, %xmm2, %xmm2
	punpcklbw	%xmm0, %xmm1
	pshuflw	$27, %xmm1, %xmm1
	pshufhw	$27, %xmm1, %xmm1
	packuswb	%xmm2, %xmm1
	movdqa	%xmm1, -64(%rsp)
	movdqu	16(%rsi), %xmm2
	movdqa	%xmm2, %xmm3
	punpckhbw	%xmm0, %xmm3
	pshuflw	$27, %xmm3, %xmm3
	pshufhw	$27, %xmm3, %xmm3
	punpcklbw	%xmm0, %xmm2
	pshuflw	$27, %xmm2, %xmm2
	pshufhw	$27, %xmm2, %xmm2
	packuswb	%xmm3, %xmm2
	movdqa	%xmm2, -48(%rsp)
	movdqu	32(%rsi), %xmm2
	movdqa	%xmm2, %xmm3
	punpckhbw	%xmm0, %xmm3
	pshuflw	$27, %xmm3, %xmm3
	pshufhw	$27, %xmm3, %xmm3
	punpcklbw	%xmm0, %xmm2
	pshuflw	$27, %xmm2, %xmm2
	pshufhw	$27, %xmm2, %xmm2
	packuswb	%xmm3, %xmm2
	movdqa	%xmm2, -32(%rsp)
	movdqu	48(%rsi), %xmm2
	movdqa	%xmm2, %xmm3
	punpckhbw	%xmm0, %xmm3
	pshuflw	$27, %xmm3, %xmm3
	pshufhw	$27, %xmm3, %xmm3
	punpcklbw	%xmm0, %xmm2
	pshuflw	$27, %xmm2, %xmm0
	pshufhw	$27, %xmm0, %xmm0
	packuswb	%xmm3, %xmm0
	movdqa	%xmm0, -16(%rsp)
	movd	%xmm1, %eax
	movl	$16, %ecx
	.p2align	4
.LBB114_1:
	movl	-124(%rsp,%rcx,4), %edx
	movl	%edx, %esi
	roll	$25, %esi
	movl	%edx, %r8d
	roll	$14, %r8d
	movl	-72(%rsp,%rcx,4), %r9d
	movl	%r9d, %r10d
	roll	$15, %r10d
	movl	%r9d, %r11d
	roll	$13, %r11d
	xorl	%esi, %r8d
	xorl	%r10d, %r11d
	movl	%edx, %esi
	shrl	$3, %esi
	xorl	%r8d, %esi
	shrl	$10, %r9d
	addl	-92(%rsp,%rcx,4), %eax
	xorl	%r11d, %r9d
	addl	%r9d, %eax
	addl	%esi, %eax
	movl	%eax, -64(%rsp,%rcx,4)
	incq	%rcx
	movl	%edx, %eax
	cmpq	$64, %rcx
	jne	.LBB114_1
	movl	(%rdi), %r13d
	movl	4(%rdi), %r15d
	movl	8(%rdi), %ebp
	movl	12(%rdi), %eax
	movl	16(%rdi), %edx
	movl	20(%rdi), %r10d
	movl	24(%rdi), %r12d
	movl	28(%rdi), %r14d
	xorl	%esi, %esi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.74(%rip), %rbx
	movl	%r13d, %r8d
	movl	%r15d, -124(%rsp)
	movl	%ebp, -120(%rsp)
	movl	%eax, -116(%rsp)
	movl	%edx, -112(%rsp)
	movl	%r10d, -108(%rsp)
	movl	%r12d, -104(%rsp)
	movl	%r14d, -100(%rsp)
	.p2align	4
.LBB114_3:
	movl	%r14d, %r11d
	movl	%r12d, %r14d
	movl	%r10d, %r12d
	movl	%edx, %r10d
	movl	%eax, %ecx
	movl	%ebp, %eax
	movl	%edx, %r9d
	roll	$26, %r9d
	movl	%r15d, %ebp
	movl	%edx, %r15d
	roll	$21, %r15d
	xorl	%r9d, %r15d
	movl	%edx, %r9d
	roll	$7, %r9d
	xorl	%r15d, %r9d
	movl	%r12d, %r15d
	andl	%edx, %r15d
	addl	%r11d, %r15d
	notl	%edx
	andl	%r14d, %edx
	addl	%r15d, %edx
	addl	%r9d, %edx
	addl	(%rsi,%rbx), %edx
	addl	-64(%rsp,%rsi), %edx
	movl	%r8d, %r15d
	roll	$30, %r8d
	movl	%r15d, %r9d
	roll	$19, %r9d
	xorl	%r8d, %r9d
	movl	%r15d, %r11d
	roll	$10, %r11d
	xorl	%r9d, %r11d
	movl	%eax, %r9d
	xorl	%ebp, %r9d
	andl	%r15d, %r9d
	movl	%eax, %r8d
	andl	%ebp, %r8d
	xorl	%r9d, %r8d
	addl	%r11d, %r8d
	addl	%edx, %r8d
	addl	%ecx, %edx
	addq	$4, %rsi
	cmpq	$256, %rsi
	jne	.LBB114_3
	addl	%r8d, %r13d
	movl	%r13d, (%rdi)
	movl	-124(%rsp), %ecx
	addl	%r15d, %ecx
	movl	%ecx, 4(%rdi)
	movl	-120(%rsp), %ecx
	addl	%ebp, %ecx
	movl	%ecx, 8(%rdi)
	movl	-116(%rsp), %ecx
	addl	%eax, %ecx
	movl	%ecx, 12(%rdi)
	movl	-112(%rsp), %ecx
	addl	%edx, %ecx
	movl	%ecx, 16(%rdi)
	movl	-108(%rsp), %ecx
	addl	%r10d, %ecx
	movl	%ecx, 20(%rdi)
	movl	-104(%rsp), %ecx
	addl	%r12d, %ecx
	movl	%ecx, 24(%rdi)
	movl	-100(%rsp), %ecx
	addl	%r14d, %ecx
	movl	%ecx, 28(%rdi)
	movl	%r8d, -68(%rsp)
	movl	%r15d, -72(%rsp)
	movl	%ebp, -76(%rsp)
	movl	%eax, -80(%rsp)
	movl	%edx, -84(%rsp)
	movl	%r10d, -88(%rsp)
	movl	%r12d, -92(%rsp)
	movl	%r14d, -96(%rsp)
	movl	$0, -64(%rsp)
	movl	$0, -60(%rsp)
	movl	$0, -56(%rsp)
	movl	$0, -52(%rsp)
	movl	$0, -48(%rsp)
	movl	$0, -44(%rsp)
	movl	$0, -40(%rsp)
	movl	$0, -36(%rsp)
	movl	$0, -32(%rsp)
	movl	$0, -28(%rsp)
	movl	$0, -24(%rsp)
	movl	$0, -20(%rsp)
	movl	$0, -16(%rsp)
	movl	$0, -12(%rsp)
	movl	$0, -8(%rsp)
	movl	$0, -4(%rsp)
	movl	$0, (%rsp)
	movl	$0, 4(%rsp)
	movl	$0, 8(%rsp)
	movl	$0, 12(%rsp)
	movl	$0, 16(%rsp)
	movl	$0, 20(%rsp)
	movl	$0, 24(%rsp)
	movl	$0, 28(%rsp)
	movl	$0, 32(%rsp)
	movl	$0, 36(%rsp)
	movl	$0, 40(%rsp)
	movl	$0, 44(%rsp)
	movl	$0, 48(%rsp)
	movl	$0, 52(%rsp)
	movl	$0, 56(%rsp)
	movl	$0, 60(%rsp)
	movl	$0, 64(%rsp)
	movl	$0, 68(%rsp)
	movl	$0, 72(%rsp)
	movl	$0, 76(%rsp)
	movl	$0, 80(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 92(%rsp)
	movl	$0, 96(%rsp)
	movl	$0, 100(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	movl	$0, 144(%rsp)
	movl	$0, 148(%rsp)
	movl	$0, 152(%rsp)
	movl	$0, 156(%rsp)
	movl	$0, 160(%rsp)
	movl	$0, 164(%rsp)
	movl	$0, 168(%rsp)
	movl	$0, 172(%rsp)
	movl	$0, 176(%rsp)
	movl	$0, 180(%rsp)
	movl	$0, 184(%rsp)
	movl	$0, 188(%rsp)
	#MEMBARRIER
	movl	$0, -68(%rsp)
	movl	$0, -72(%rsp)
	movl	$0, -76(%rsp)
	movl	$0, -80(%rsp)
	movl	$0, -84(%rsp)
	movl	$0, -88(%rsp)
	movl	$0, -92(%rsp)
	movl	$0, -96(%rsp)
	#MEMBARRIER
	addq	$200, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end114:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256, .Lfunc_end114-_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress256
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$760, %rsp
	.cfi_def_cfa_offset 816
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %r14
	movq	%rdi, %rbx
	leaq	248(%rsp), %rdi
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	(%r14), %rax
	bswapq	%rax
	movq	%rax, 120(%rsp)
	movq	8(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 128(%rsp)
	movq	16(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 136(%rsp)
	movq	24(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 144(%rsp)
	movq	32(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 152(%rsp)
	movq	40(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 160(%rsp)
	movq	48(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 168(%rsp)
	movq	56(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 176(%rsp)
	movq	64(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 184(%rsp)
	movq	72(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 192(%rsp)
	movq	80(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 200(%rsp)
	movq	88(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 208(%rsp)
	movq	96(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 216(%rsp)
	movq	104(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 224(%rsp)
	movq	112(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 232(%rsp)
	movq	120(%r14), %rcx
	bswapq	%rcx
	movq	%rcx, 240(%rsp)
	movl	$16, %ecx
	.p2align	4
.LBB115_1:
	movq	(%rsp,%rcx,8), %rdx
	movq	%rdx, %rsi
	rorq	%rsi
	movq	%rdx, %rdi
	rolq	$56, %rdi
	movq	104(%rsp,%rcx,8), %r8
	movq	%r8, %r9
	rolq	$45, %r9
	movq	%r8, %r10
	rolq	$3, %r10
	xorq	%rsi, %rdi
	xorq	%r9, %r10
	movq	%rdx, %rsi
	shrq	$7, %rsi
	xorq	%rdi, %rsi
	shrq	$6, %r8
	addq	64(%rsp,%rcx,8), %rax
	xorq	%r10, %r8
	addq	%r8, %rax
	addq	%rsi, %rax
	movq	%rax, 120(%rsp,%rcx,8)
	incq	%rcx
	movq	%rdx, %rax
	cmpq	$80, %rcx
	jne	.LBB115_1
	movq	(%rbx), %rbp
	movq	8(%rbx), %r12
	movq	16(%rbx), %r14
	movq	24(%rbx), %rax
	movq	32(%rbx), %rdx
	movq	40(%rbx), %r9
	movq	48(%rbx), %r13
	movq	56(%rbx), %r15
	xorl	%esi, %esi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.75(%rip), %r11
	movq	%rbp, %rdi
	movq	%r12, (%rsp)
	movq	%r14, 8(%rsp)
	movq	%rax, 16(%rsp)
	movq	%rdx, 24(%rsp)
	movq	%r9, 32(%rsp)
	movq	%r13, 40(%rsp)
	movq	%r15, 48(%rsp)
	.p2align	4
.LBB115_3:
	movq	%r15, %r10
	movq	%r13, %r15
	movq	%r9, %r13
	movq	%rdx, %r9
	movq	%rax, %rcx
	movq	%r14, %rax
	movq	%rdx, %r8
	rolq	$50, %r8
	movq	%r12, %r14
	movq	%rdx, %r12
	rolq	$46, %r12
	xorq	%r8, %r12
	movq	%rdx, %r8
	rolq	$23, %r8
	xorq	%r12, %r8
	movq	%r13, %r12
	andq	%rdx, %r12
	addq	%r10, %r12
	notq	%rdx
	andq	%r15, %rdx
	addq	%r12, %rdx
	addq	%r8, %rdx
	addq	(%rsi,%r11), %rdx
	addq	120(%rsp,%rsi), %rdx
	movq	%rdi, %r12
	rolq	$36, %rdi
	movq	%r12, %r8
	rolq	$30, %r8
	xorq	%rdi, %r8
	movq	%r12, %r10
	rolq	$25, %r10
	xorq	%r8, %r10
	movq	%rax, %r8
	xorq	%r14, %r8
	andq	%r12, %r8
	movq	%rax, %rdi
	andq	%r14, %rdi
	xorq	%r8, %rdi
	addq	%r10, %rdi
	addq	%rdx, %rdi
	addq	%rcx, %rdx
	addq	$8, %rsi
	cmpq	$640, %rsi
	jne	.LBB115_3
	addq	%rdi, %rbp
	movq	%rbp, (%rbx)
	movq	(%rsp), %rcx
	addq	%r12, %rcx
	movq	%rcx, 8(%rbx)
	movq	8(%rsp), %rcx
	addq	%r14, %rcx
	movq	%rcx, 16(%rbx)
	movq	16(%rsp), %rcx
	addq	%rax, %rcx
	movq	%rcx, 24(%rbx)
	movq	24(%rsp), %rcx
	addq	%rdx, %rcx
	movq	%rcx, 32(%rbx)
	movq	32(%rsp), %rcx
	addq	%r9, %rcx
	movq	%rcx, 40(%rbx)
	movq	40(%rsp), %rcx
	addq	%r13, %rcx
	movq	%rcx, 48(%rbx)
	movq	48(%rsp), %rcx
	addq	%r15, %rcx
	movq	%rcx, 56(%rbx)
	movq	%rdi, 112(%rsp)
	movq	%r12, 104(%rsp)
	movq	%r14, 96(%rsp)
	movq	%rax, 88(%rsp)
	movq	%rdx, 80(%rsp)
	movq	%r9, 72(%rsp)
	movq	%r13, 64(%rsp)
	movq	%r15, 56(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	addq	$760, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end115:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512, .Lfunc_end115-_RNvNtCs1muTxUaRwMI_12toyos_crypto4hash11compress512
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256:
.Lfunc_begin47:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception47
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$504, %rsp
	.cfi_def_cfa_offset 560
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movabsq	$-523289583788211982, %rdx
	movabsq	$-819310685055303018, %rsi
	movabsq	$-5482079946633869636, %r12
	movabsq	$8575836109218198432, %r14
	movabsq	$7716867327612699207, %rdi
	movabsq	$7285987128567378166, %r13
	movabsq	$6540974713487397863, %r15
	movabsq	$4309448131093880907, %rbp
	movq	$-1, 240(%rsp)
	movl	$4294967295, %eax
	movq	%rax, 248(%rsp)
	movq	$0, 256(%rsp)
	movabsq	$-4294967296, %rax
	leaq	1(%rax), %rcx
	movq	%rcx, 264(%rsp)
	movabsq	$-884452912994769583, %rcx
	movq	%rcx, 272(%rsp)
	movabsq	$-4834901526196019580, %rcx
	movq	%rcx, 280(%rsp)
	movq	$-1, 288(%rsp)
	movq	%rax, 296(%rsp)
	movq	%rbp, 304(%rsp)
	movq	%r13, 312(%rsp)
	movq	%r12, 320(%rsp)
	movq	%r15, 328(%rsp)
	movq	%rsi, 336(%rsp)
	movq	%r14, 344(%rsp)
	movq	%rdx, 352(%rsp)
	movq	%rdi, 360(%rsp)
	movabsq	$-3767753221892779531, %rax
	movq	%rax, 368(%rsp)
	movabsq	$3156516839386865358, %rax
	movq	%rax, 376(%rsp)
	movabsq	$-8149286295562117610, %rax
	movq	%rax, 384(%rsp)
	movabsq	$5756518291402817435, %rax
	movq	%rax, 392(%rsp)
	leaq	104(%rsp), %rdi
	leaq	240(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_
.Ltmp580:
	leaq	400(%rsp), %rdi
	leaq	272(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_
.Ltmp581:
	movq	%rbp, 64(%rsp)
	movq	%r13, 32(%rsp)
	movq	%r12, 8(%rsp)
	movq	%r15, (%rsp)
	leaq	136(%rsp), %r12
.Ltmp583:
	leaq	208(%rsp), %rdi
	leaq	104(%rsp), %rsi
	leaq	304(%rsp), %rdx
	movq	%rdi, 24(%rsp)
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp584:
	movq	$0, 64(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	#MEMBARRIER
	movabsq	$-819310685055303018, %rax
	movq	%rax, 64(%rsp)
	movq	%r14, 8(%rsp)
	movabsq	$-523289583788211982, %rax
	movq	%rax, (%rsp)
	movabsq	$7716867327612699207, %rax
	movq	%rax, 16(%rsp)
.Ltmp586:
	leaq	32(%rsp), %r15
	leaq	104(%rsp), %rsi
	leaq	336(%rsp), %rdx
	movq	%r15, %rdi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp587:
	leaq	40(%rsp), %rbp
	leaq	48(%rsp), %r13
	leaq	56(%rsp), %r14
	movq	$0, 64(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 16(%rsp)
	#MEMBARRIER
.Ltmp589:
	leaq	64(%rsp), %rdi
	leaq	104(%rsp), %rsi
	leaq	368(%rsp), %rdx
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
.Ltmp590:
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	200(%rsp), %rax
	movq	%rax, 192(%rbx)
	movups	184(%rsp), %xmm0
	movups	%xmm0, 176(%rbx)
	movups	168(%rsp), %xmm0
	movups	%xmm0, 160(%rbx)
	movups	104(%rsp), %xmm0
	movups	120(%rsp), %xmm1
	movups	136(%rsp), %xmm2
	movups	152(%rsp), %xmm3
	movups	%xmm3, 144(%rbx)
	movups	%xmm2, 128(%rbx)
	movups	%xmm1, 112(%rbx)
	movups	%xmm0, 96(%rbx)
	movups	400(%rsp), %xmm0
	movups	416(%rsp), %xmm1
	movups	432(%rsp), %xmm2
	movups	448(%rsp), %xmm3
	movups	%xmm0, 200(%rbx)
	movups	%xmm1, 216(%rbx)
	movups	%xmm2, 232(%rbx)
	movups	%xmm3, 248(%rbx)
	movups	464(%rsp), %xmm0
	movups	%xmm0, 264(%rbx)
	movups	480(%rsp), %xmm0
	movups	%xmm0, 280(%rbx)
	movq	496(%rsp), %rax
	movq	%rax, 296(%rbx)
	movups	208(%rsp), %xmm0
	movups	224(%rsp), %xmm1
	movups	%xmm0, (%rbx)
	movups	%xmm1, 16(%rbx)
	movups	32(%rsp), %xmm0
	movups	48(%rsp), %xmm1
	movups	%xmm0, 32(%rbx)
	movups	%xmm1, 48(%rbx)
	movups	64(%rsp), %xmm0
	movups	80(%rsp), %xmm1
	movups	%xmm0, 64(%rbx)
	movups	%xmm1, 80(%rbx)
	movq	%rbx, %rax
	addq	$504, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB116_7:
	.cfi_def_cfa_offset 560
.Ltmp591:
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	jmp	.LBB116_6
.LBB116_5:
.Ltmp588:
	leaq	64(%rsp), %r15
	leaq	16(%rsp), %r14
	movq	%rsp, %r13
	leaq	8(%rsp), %rbp
.LBB116_6:
	leaq	216(%rsp), %rsi
	leaq	224(%rsp), %rdx
	leaq	232(%rsp), %rcx
	movq	$0, (%r15)
	movq	$0, (%rbp)
	movq	$0, (%r13)
	movq	$0, (%r14)
	#MEMBARRIER
	jmp	.LBB116_9
.LBB116_8:
.Ltmp585:
	leaq	64(%rsp), %rcx
	movq	%rcx, 24(%rsp)
	movq	%rsp, %rcx
	leaq	8(%rsp), %rdx
	leaq	32(%rsp), %rsi
.LBB116_9:
	movq	24(%rsp), %rdi
	movq	$0, (%rdi)
	movq	$0, (%rsi)
	movq	$0, (%rdx)
	movq	$0, (%rcx)
	#MEMBARRIER
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	#MEMBARRIER
	jmp	.LBB116_10
.LBB116_11:
.Ltmp582:
.LBB116_10:
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end116:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256, .Lfunc_end116-_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256
	.cfi_endproc
	.section	.gcc_except_table._RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p256,"a",@progbits
	.p2align	2, 0x0
GCC_except_table116:
.Lexception47:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end47-.Lcst_begin47
.Lcst_begin47:
	.uleb128 .Lfunc_begin47-.Lfunc_begin47
	.uleb128 .Ltmp580-.Lfunc_begin47
	.byte	0
	.byte	0
	.uleb128 .Ltmp580-.Lfunc_begin47
	.uleb128 .Ltmp581-.Ltmp580
	.uleb128 .Ltmp582-.Lfunc_begin47
	.byte	0
	.uleb128 .Ltmp583-.Lfunc_begin47
	.uleb128 .Ltmp584-.Ltmp583
	.uleb128 .Ltmp585-.Lfunc_begin47
	.byte	0
	.uleb128 .Ltmp586-.Lfunc_begin47
	.uleb128 .Ltmp587-.Ltmp586
	.uleb128 .Ltmp588-.Lfunc_begin47
	.byte	0
	.uleb128 .Ltmp589-.Lfunc_begin47
	.uleb128 .Ltmp590-.Ltmp589
	.uleb128 .Ltmp591-.Lfunc_begin47
	.byte	0
	.uleb128 .Ltmp590-.Lfunc_begin47
	.uleb128 .Lfunc_end116-.Ltmp590
	.byte	0
	.byte	0
.Lcst_end47:
	.p2align	2, 0x0

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384:
.Lfunc_begin48:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception48
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$744, %rsp
	.cfi_def_cfa_offset 800
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movabsq	$-4155070326131207779, %rbp
	movabsq	$-5534590068959811612, %r10
	movabsq	$-6158731714831383241, %rcx
	movabsq	$-7454014372307260135, %r14
	movabsq	$-8164525713704047244, %rdx
	movabsq	$7934563412932533144, %rsi
	movabsq	$6482722621138151992, %rdi
	movabsq	$6125724927633205612, %r8
	movabsq	$4203087948775033527, %r9
	movabsq	$3064076045283764975, %r13
	movabsq	$1737717031765098770, %r15
	movabsq	$221811693264799578, %r12
	movl	$4294967295, %eax
	movq	%rax, 344(%rsp)
	movabsq	$-4294967296, %rax
	movq	%rax, 352(%rsp)
	movq	$-2, 360(%rsp)
	pcmpeqd	%xmm0, %xmm0
	movdqu	%xmm0, 368(%rsp)
	movq	$-1, 384(%rsp)
	movabsq	$-1374695839762142861, %rax
	movq	%rax, 392(%rsp)
	movabsq	$6348401684107011962, %rax
	movq	%rax, 400(%rsp)
	movabsq	$-4079331616924160545, %rax
	movq	%rax, 408(%rsp)
	movdqu	%xmm0, 416(%rsp)
	movq	$-1, 432(%rsp)
	movq	%r13, 200(%rsp)
	movq	%rbp, 208(%rsp)
	movq	%r12, 216(%rsp)
	movq	%r15, 224(%rsp)
	movq	%r14, 232(%rsp)
	movq	%r10, 240(%rsp)
	movq	%r9, 248(%rsp)
	movq	%r8, 256(%rsp)
	movq	%rdi, 264(%rsp)
	movq	%rsi, 272(%rsp)
	movq	%rdx, 280(%rsp)
	movq	%rcx, 288(%rsp)
	movabsq	$8809917716911230559, %rax
	movq	%rax, 296(%rsp)
	movabsq	$747793036959711645, %rax
	movq	%rax, 304(%rsp)
	movabsq	$-1595909157222827840, %rax
	movq	%rax, 312(%rsp)
	movabsq	$-507748159718812548, %rax
	movq	%rax, 320(%rsp)
	movabsq	$6745997240412855337, %rax
	movq	%rax, 328(%rsp)
	movabsq	$3897828414440483951, %rax
	movq	%rax, 336(%rsp)
	leaq	440(%rsp), %rdi
	leaq	344(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_
.Ltmp592:
	leaq	592(%rsp), %rdi
	leaq	392(%rsp), %rsi
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_
.Ltmp593:
	movq	%r13, 104(%rsp)
	movq	%rbp, 48(%rsp)
	movq	%r12, 24(%rsp)
	movq	%r15, 16(%rsp)
	movq	%r14, 8(%rsp)
	movabsq	$-5534590068959811612, %rax
	movq	%rax, (%rsp)
	leaq	488(%rsp), %r12
.Ltmp595:
	leaq	152(%rsp), %rdi
	leaq	440(%rsp), %rsi
	leaq	200(%rsp), %rdx
	movq	%rdi, 40(%rsp)
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp596:
	movq	$0, 104(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	#MEMBARRIER
	movabsq	$4203087948775033527, %rax
	movq	%rax, 104(%rsp)
	movabsq	$6125724927633205612, %rax
	movq	%rax, 24(%rsp)
	movabsq	$6482722621138151992, %rax
	movq	%rax, 16(%rsp)
	movabsq	$7934563412932533144, %rax
	movq	%rax, 8(%rsp)
	movabsq	$-8164525713704047244, %rax
	movq	%rax, (%rsp)
	movabsq	$-6158731714831383241, %rax
	movq	%rax, 32(%rsp)
.Ltmp598:
	leaq	48(%rsp), %r15
	leaq	440(%rsp), %rsi
	leaq	248(%rsp), %rdx
	movq	%r15, %rdi
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp599:
	leaq	56(%rsp), %r13
	leaq	64(%rsp), %r14
	leaq	72(%rsp), %rbp
	movq	$0, 104(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
.Ltmp601:
	leaq	104(%rsp), %rdi
	leaq	440(%rsp), %rsi
	leaq	296(%rsp), %rdx
	movq	%r12, %rcx
	callq	_RNvMs0_NtCs1muTxUaRwMI_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
.Ltmp602:
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	leaq	144(%rbx), %rdi
	leaq	440(%rsp), %rsi
	movq	memcpy@GOTPCREL(%rip), %r14
	movl	$152, %edx
	callq	*%r14
	leaq	296(%rbx), %rdi
	leaq	592(%rsp), %rsi
	movl	$152, %edx
	callq	*%r14
	movups	152(%rsp), %xmm0
	movups	168(%rsp), %xmm1
	movups	184(%rsp), %xmm2
	movups	%xmm2, 32(%rbx)
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
	movups	48(%rsp), %xmm0
	movups	64(%rsp), %xmm1
	movups	80(%rsp), %xmm2
	movups	%xmm1, 64(%rbx)
	movups	%xmm0, 48(%rbx)
	movups	%xmm2, 80(%rbx)
	movups	104(%rsp), %xmm0
	movups	120(%rsp), %xmm1
	movups	136(%rsp), %xmm2
	movups	%xmm2, 128(%rbx)
	movups	%xmm1, 112(%rbx)
	movups	%xmm0, 96(%rbx)
	movq	%rbx, %rax
	addq	$744, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB117_7:
	.cfi_def_cfa_offset 800
.Ltmp603:
	leaq	80(%rsp), %r10
	leaq	88(%rsp), %r9
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	jmp	.LBB117_6
.LBB117_5:
.Ltmp600:
	leaq	104(%rsp), %r15
	leaq	32(%rsp), %r9
	movq	%rsp, %r10
	leaq	8(%rsp), %rbp
	leaq	16(%rsp), %r14
	leaq	24(%rsp), %r13
.LBB117_6:
	leaq	160(%rsp), %r8
	leaq	168(%rsp), %rdi
	leaq	176(%rsp), %rsi
	leaq	184(%rsp), %rdx
	leaq	192(%rsp), %rcx
	movq	$0, (%r15)
	movq	$0, (%r13)
	movq	$0, (%r14)
	movq	$0, (%rbp)
	movq	$0, (%r10)
	movq	$0, (%r9)
	#MEMBARRIER
	jmp	.LBB117_9
.LBB117_8:
.Ltmp597:
	leaq	104(%rsp), %rcx
	movq	%rcx, 40(%rsp)
	movq	%rsp, %rcx
	leaq	8(%rsp), %rdx
	leaq	16(%rsp), %rsi
	leaq	24(%rsp), %rdi
	leaq	48(%rsp), %r8
.LBB117_9:
	movq	40(%rsp), %r9
	movq	$0, (%r9)
	movq	$0, (%r8)
	movq	$0, (%rdi)
	movq	$0, (%rsi)
	movq	$0, (%rdx)
	movq	$0, (%rcx)
	#MEMBARRIER
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	#MEMBARRIER
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	#MEMBARRIER
	jmp	.LBB117_10
.LBB117_11:
.Ltmp594:
.LBB117_10:
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	#MEMBARRIER
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	%rax, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end117:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384, .Lfunc_end117-_RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384
	.cfi_endproc
	.section	.gcc_except_table._RNvNtCs1muTxUaRwMI_12toyos_crypto4nist4p384,"a",@progbits
	.p2align	2, 0x0
GCC_except_table117:
.Lexception48:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end48-.Lcst_begin48
.Lcst_begin48:
	.uleb128 .Lfunc_begin48-.Lfunc_begin48
	.uleb128 .Ltmp592-.Lfunc_begin48
	.byte	0
	.byte	0
	.uleb128 .Ltmp592-.Lfunc_begin48
	.uleb128 .Ltmp593-.Ltmp592
	.uleb128 .Ltmp594-.Lfunc_begin48
	.byte	0
	.uleb128 .Ltmp595-.Lfunc_begin48
	.uleb128 .Ltmp596-.Ltmp595
	.uleb128 .Ltmp597-.Lfunc_begin48
	.byte	0
	.uleb128 .Ltmp598-.Lfunc_begin48
	.uleb128 .Ltmp599-.Ltmp598
	.uleb128 .Ltmp600-.Lfunc_begin48
	.byte	0
	.uleb128 .Ltmp601-.Lfunc_begin48
	.uleb128 .Ltmp602-.Ltmp601
	.uleb128 .Ltmp603-.Lfunc_begin48
	.byte	0
	.uleb128 .Ltmp602-.Lfunc_begin48
	.uleb128 .Lfunc_end117-.Ltmp602
	.byte	0
	.byte	0
.Lcst_end48:
	.p2align	2, 0x0

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI118_0:
	.byte	0
	.byte	1
	.byte	2
	.byte	3
	.byte	4
	.byte	5
	.byte	6
	.byte	7
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
.LCPI118_1:
	.byte	0
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
.LCPI118_2:
	.byte	255
	.byte	255
	.byte	255
	.byte	0
	.byte	0
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
.LCPI118_3:
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	0
	.byte	0
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
.LCPI118_4:
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	0
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
	.byte	255
.LCPI118_5:
	.short	32896
	.short	32896
	.short	32896
	.short	32896
	.short	0
	.short	0
	.short	0
	.short	0
.LCPI118_6:
	.zero	16,15
.LCPI118_7:
	.zero	16,63
.LCPI118_8:
	.zero	16,127
.LCPI118_9:
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.byte	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
.LCPI118_10:
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
	.short	3329
.LCPI118_11:
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.byte	8
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
	.zero	1
.LCPI118_12:
	.byte	0
	.byte	1
	.byte	2
	.byte	3
	.byte	4
	.byte	5
	.byte	6
	.byte	7
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise:
.Lfunc_begin49:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception49
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$688, %rsp
	.cfi_def_cfa_offset 720
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 128(%rsp)
	movaps	%xmm0, 112(%rsp)
	movaps	%xmm0, 96(%rsp)
	movaps	%xmm0, 80(%rsp)
	movaps	%xmm0, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movb	%dl, 15(%rsp)
	movq	%rsi, 144(%rsp)
	movq	$32, 152(%rsp)
	leaq	15(%rsp), %rax
	movq	%rax, 160(%rsp)
	movq	$1, 168(%rsp)
.Ltmp604:
	leaq	176(%rsp), %rdi
	leaq	144(%rsp), %rcx
	movl	$136, %esi
	movl	$2, %r8d
	movl	$31, %edx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new
.Ltmp605:
	movq	384(%rsp), %rax
	xorl	%r15d, %r15d
	leaq	176(%rsp), %r14
	jmp	.LBB118_2
	.p2align	4
.LBB118_3:
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 384(%rsp)
	xorl	%edi, %edi
	xorl	%eax, %eax
.LBB118_9:
	leaq	(%rsp,%rdi,8), %rcx
	addq	$176, %rcx
	movl	%eax, %edx
	andl	$7, %edx
	movzbl	(%rdx,%rcx), %ecx
	movb	%cl, 16(%rsp,%r15)
	incq	%r15
	incq	%rax
	movq	%rax, 384(%rsp)
	cmpq	$128, %r15
	je	.LBB118_10
.LBB118_2:
	cmpq	376(%rsp), %rax
	je	.LBB118_3
	movq	%rax, %rdi
	shrq	$3, %rdi
	cmpq	$199, %rax
	jbe	.LBB118_9
.Ltmp607:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.71(%rip), %rdx
	movl	$25, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp608:
	ud2
.LBB118_10:
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	leaq	176(%rsp), %rdi
	xorl	%r14d, %r14d
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	.LCPI118_12(%rip), %xmm0
	leaq	16(%rsp), %rax
	movdqa	.LCPI118_2(%rip), %xmm2
	movdqa	.LCPI118_3(%rip), %xmm3
	movdqa	.LCPI118_4(%rip), %xmm4
	movq	.LCPI118_5(%rip), %xmm5
	pxor	%xmm6, %xmm6
	movdqa	.LCPI118_6(%rip), %xmm7
	movdqa	.LCPI118_7(%rip), %xmm8
	movdqa	.LCPI118_8(%rip), %xmm9
	movdqa	.LCPI118_9(%rip), %xmm10
	movdqa	.LCPI118_10(%rip), %xmm11
	movdqa	.LCPI118_11(%rip), %xmm12
	.p2align	4
.LBB118_11:
	movzwl	(%rax), %ecx
	movd	%ecx, %xmm13
	movzwl	1(%rax), %ecx
	movd	%ecx, %xmm14
	movzbl	(%rax), %ecx
	movd	%ecx, %xmm15
	movzwl	2(%rax), %ecx
	movdqa	.LCPI118_1(%rip), %xmm1
	pandn	%xmm15, %xmm1
	movd	%ecx, %xmm15
	pslld	$8, %xmm13
	por	%xmm1, %xmm13
	psllq	$24, %xmm14
	movdqa	%xmm2, %xmm1
	pandn	%xmm14, %xmm1
	pand	%xmm2, %xmm13
	por	%xmm1, %xmm13
	pand	%xmm3, %xmm13
	psllq	$40, %xmm15
	movdqa	%xmm3, %xmm1
	pandn	%xmm15, %xmm1
	por	%xmm13, %xmm1
	pand	%xmm4, %xmm1
	movzbl	3(%rax), %ecx
	movd	%ecx, %xmm14
	psllq	$56, %xmm14
	movdqa	%xmm4, %xmm13
	pandn	%xmm14, %xmm13
	por	%xmm1, %xmm13
	movdqa	%xmm0, %xmm14
	psllw	$7, %xmm14
	pand	%xmm5, %xmm14
	pxor	%xmm1, %xmm1
	pcmpgtb	%xmm14, %xmm1
	movdqa	%xmm1, %xmm15
	pandn	%xmm13, %xmm15
	psrlw	$4, %xmm13
	pand	%xmm1, %xmm13
	pand	%xmm7, %xmm13
	por	%xmm15, %xmm13
	paddb	%xmm14, %xmm14
	pxor	%xmm1, %xmm1
	pcmpgtb	%xmm14, %xmm1
	movdqa	%xmm1, %xmm15
	pandn	%xmm13, %xmm15
	psrlw	$2, %xmm13
	pand	%xmm1, %xmm13
	pand	%xmm8, %xmm13
	por	%xmm15, %xmm13
	paddb	%xmm14, %xmm14
	pxor	%xmm1, %xmm1
	pcmpgtb	%xmm14, %xmm1
	movdqa	%xmm1, %xmm14
	pandn	%xmm13, %xmm14
	psrlw	$1, %xmm13
	pand	%xmm1, %xmm13
	pand	%xmm9, %xmm13
	por	%xmm14, %xmm13
	movdqa	%xmm13, %xmm1
	pand	%xmm10, %xmm1
	movdqa	%xmm13, %xmm14
	psrlw	$1, %xmm14
	pand	%xmm10, %xmm14
	paddb	%xmm1, %xmm14
	punpcklbw	%xmm6, %xmm14
	movdqa	%xmm13, %xmm1
	psrlw	$2, %xmm1
	pand	%xmm10, %xmm1
	psrlw	$3, %xmm13
	pand	%xmm10, %xmm13
	paddb	%xmm1, %xmm13
	punpcklbw	%xmm6, %xmm13
	psubw	%xmm13, %xmm14
	movdqa	%xmm14, %xmm1
	paddw	%xmm11, %xmm1
	movdqa	%xmm1, %xmm13
	psubusw	%xmm14, %xmm13
	psubw	%xmm13, %xmm1
	movdqu	%xmm1, 176(%rsp,%r14,2)
	addq	$8, %r14
	paddb	%xmm12, %xmm0
	addq	$4, %rax
	cmpq	$256, %r14
	jne	.LBB118_11
	leaq	176(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	xorl	%eax, %eax
	.p2align	4
.LBB118_13:
	movb	$0, 16(%rsp,%rax)
	movb	$0, 17(%rsp,%rax)
	movb	$0, 18(%rsp,%rax)
	movb	$0, 19(%rsp,%rax)
	movb	$0, 20(%rsp,%rax)
	movb	$0, 21(%rsp,%rax)
	movb	$0, 22(%rsp,%rax)
	movb	$0, 23(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB118_13
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$688, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB118_4:
	.cfi_def_cfa_offset 720
.Ltmp606:
	movq	%rax, %rbx
	jmp	.LBB118_5
.LBB118_17:
.Ltmp609:
	movq	%rax, %rbx
	leaq	176(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_
.LBB118_5:
	xorl	%eax, %eax
	.p2align	4
.LBB118_6:
	movb	$0, 16(%rsp,%rax)
	movb	$0, 17(%rsp,%rax)
	movb	$0, 18(%rsp,%rax)
	movb	$0, 19(%rsp,%rax)
	movb	$0, 20(%rsp,%rax)
	movb	$0, 21(%rsp,%rax)
	movb	$0, 22(%rsp,%rax)
	movb	$0, 23(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB118_6
	#MEMBARRIER
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end118:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise, .Lfunc_end118-_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise
	.cfi_endproc
	.section	.gcc_except_table._RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem5noise,"a",@progbits
	.p2align	2, 0x0
GCC_except_table118:
.Lexception49:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end49-.Lcst_begin49
.Lcst_begin49:
	.uleb128 .Ltmp604-.Lfunc_begin49
	.uleb128 .Ltmp605-.Ltmp604
	.uleb128 .Ltmp606-.Lfunc_begin49
	.byte	0
	.uleb128 .Ltmp607-.Lfunc_begin49
	.uleb128 .Ltmp608-.Ltmp607
	.uleb128 .Ltmp609-.Lfunc_begin49
	.byte	0
	.uleb128 .Ltmp608-.Lfunc_begin49
	.uleb128 .Lfunc_end118-.Ltmp608
	.byte	0
	.byte	0
.Lcst_end49:
	.p2align	2, 0x0

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem6sample,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem6sample
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem6sample,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem6sample:
.Lfunc_begin50:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception50
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$736, %rsp
	.cfi_def_cfa_offset 784
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	movb	%cl, 6(%rsp)
	movb	%dl, 7(%rsp)
	movq	%rsi, 224(%rsp)
	movq	$32, 232(%rsp)
	leaq	6(%rsp), %rax
	movq	%rax, 240(%rsp)
	movq	$2, 248(%rsp)
	leaq	8(%rsp), %r14
	leaq	224(%rsp), %rcx
	movl	$168, %esi
	movl	$2, %r8d
	movq	%r14, %rdi
	movl	$31, %edx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new
	leaq	224(%rsp), %rdi
	xorl	%r15d, %r15d
	movl	$512, %edx
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
	movq	216(%rsp), %rax
	jmp	.LBB119_1
	.p2align	4
.LBB119_16:
	cmpq	$256, %r15
	jae	.LBB119_17
.LBB119_1:
	movq	208(%rsp), %rdx
	cmpq	%rdx, %rax
	jne	.LBB119_3
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 216(%rsp)
	movq	208(%rsp), %rdx
	xorl	%edi, %edi
	xorl	%eax, %eax
	jmp	.LBB119_4
	.p2align	4
.LBB119_3:
	movq	%rax, %rdi
	shrq	$3, %rdi
	cmpq	$199, %rax
	ja	.LBB119_6
.LBB119_4:
	movq	8(%rsp,%rdi,8), %r12
	leal	(,%rax,8), %ecx
	shrq	%cl, %r12
	leaq	1(%rax), %rsi
	movq	%rsi, 216(%rsp)
	cmpq	%rdx, %rsi
	jne	.LBB119_5
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 216(%rsp)
	movq	208(%rsp), %rdx
	xorl	%edi, %edi
	xorl	%esi, %esi
	jmp	.LBB119_9
	.p2align	4
.LBB119_5:
	movq	%rsi, %rdi
	shrq	$3, %rdi
	cmpq	$199, %rax
	jae	.LBB119_6
.LBB119_9:
	movq	8(%rsp,%rdi,8), %r13
	leal	(,%rsi,8), %ecx
	shrq	%cl, %r13
	leaq	1(%rsi), %rax
	movq	%rax, 216(%rsp)
	cmpq	%rdx, %rax
	jne	.LBB119_10
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 216(%rsp)
	xorl	%edi, %edi
	xorl	%eax, %eax
	jmp	.LBB119_12
	.p2align	4
.LBB119_10:
	movq	%rax, %rdi
	shrq	$3, %rdi
	cmpq	$199, %rsi
	jae	.LBB119_6
.LBB119_12:
	movq	8(%rsp,%rdi,8), %rdx
	leal	(,%rax,8), %ecx
	shrq	%cl, %rdx
	incq	%rax
	movq	%rax, 216(%rsp)
	movzbl	%r12b, %esi
	movl	%r13d, %ecx
	andl	$15, %ecx
	shll	$8, %ecx
	orl	%esi, %ecx
	cmpl	$3329, %ecx
	jae	.LBB119_13
	movw	%cx, 224(%rsp,%r15,2)
	incq	%r15
.LBB119_13:
	movzbl	%r13b, %esi
	shrl	$4, %esi
	movzbl	%dl, %ecx
	shll	$4, %ecx
	orl	%esi, %ecx
	movzwl	%cx, %edx
	cmpl	$3328, %edx
	ja	.LBB119_16
	cmpq	$255, %r15
	ja	.LBB119_16
	movw	%cx, 224(%rsp,%r15,2)
	incq	%r15
	jmp	.LBB119_16
.LBB119_17:
	leaq	224(%rsp), %rsi
	movl	$512, %edx
	movq	%rbx, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$736, %rsp
	.cfi_def_cfa_offset 48
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB119_6:
	.cfi_def_cfa_offset 784
.Ltmp610:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.71(%rip), %rdx
	movl	$25, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp611:
	ud2
.LBB119_18:
.Ltmp612:
	movq	%rax, %rbx
	xorl	%eax, %eax
	.p2align	4
.LBB119_19:
	movw	$0, 224(%rsp,%rax)
	movw	$0, 226(%rsp,%rax)
	movw	$0, 228(%rsp,%rax)
	movw	$0, 230(%rsp,%rax)
	movw	$0, 232(%rsp,%rax)
	movw	$0, 234(%rsp,%rax)
	movw	$0, 236(%rsp,%rax)
	movw	$0, 238(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB119_19
	#MEMBARRIER
	leaq	8(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end119:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem6sample, .Lfunc_end119-_RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem6sample
	.cfi_endproc
	.section	.gcc_except_table._RNvNtCs1muTxUaRwMI_12toyos_crypto5mlkem6sample,"a",@progbits
	.p2align	2, 0x0
GCC_except_table119:
.Lexception50:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end50-.Lcst_begin50
.Lcst_begin50:
	.uleb128 .Lfunc_begin50-.Lfunc_begin50
	.uleb128 .Ltmp610-.Lfunc_begin50
	.byte	0
	.byte	0
	.uleb128 .Ltmp610-.Lfunc_begin50
	.uleb128 .Ltmp611-.Ltmp610
	.uleb128 .Ltmp612-.Lfunc_begin50
	.byte	0
	.uleb128 .Ltmp611-.Lfunc_begin50
	.uleb128 .Lfunc_end119-.Ltmp611
	.byte	0
	.byte	0
.Lcst_end50:
	.p2align	2, 0x0

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%r8, %rbx
	movq	%rcx, %r14
	movq	%rsi, %r13
	movq	%rdi, %r15
	cmpq	$256, %r8
	jb	.LBB120_1
	movzbl	_RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0(%rip), %eax
	cmpb	$1, %al
	je	.LBB120_1
	movzbl	%al, %eax
	cmpl	$2, %eax
	jne	.LBB120_7
.LBB120_4:
	movq	%r15, %rdi
	movq	%rdx, %rbp
	movq	%rdx, %rsi
	movq	%r13, %rdx
	movq	%r14, %rcx
	movq	%rbx, %r8
	callq	_RNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx27batches
	movq	%rax, %r12
	cmpq	%rbx, %rax
	jbe	.LBB120_12
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.77(%rip), %rcx
	movq	%r12, %rdi
	movq	%rbx, %rsi
	movq	%rbx, %rdx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.LBB120_1:
	xorl	%r12d, %r12d
	subq	%r12, %rbx
	jne	.LBB120_14
	jmp	.LBB120_28
.LBB120_7:
	movq	%rdx, %rbp
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	notl	%ecx
	testl	$469762048, %ecx
	jne	.LBB120_11
	callq	_RNvNtNtNtCsgxBkk5gSRhY_4core9core_arch3x865xsave7__xgetbv
	notl	%eax
	testb	$6, %al
	jne	.LBB120_11
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	cmpl	$7, %eax
	jb	.LBB120_11
	xorl	%ecx, %ecx
	movl	$7, %eax
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	testb	$32, %sil
	jne	.LBB120_29
.LBB120_11:
	movb	$1, _RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0(%rip)
	xorl	%r12d, %r12d
.LBB120_12:
	movq	%rbp, %rdx
	subq	%r12, %rbx
	je	.LBB120_28
.LBB120_14:
	addq	%r12, %r14
	shrq	$6, %r12
	addq	%rdx, %r12
	movsd	(%r13), %xmm0
	movaps	%xmm0, 128(%rsp)
	xorl	%ebp, %ebp
	jmp	.LBB120_16
	.p2align	4
.LBB120_15:
	addq	%r13, %r14
	incq	%rbp
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	subq	%r13, %rbx
	je	.LBB120_28
.LBB120_16:
	cmpq	$64, %rbx
	movl	$64, %r13d
	cmovbq	%rbx, %r13
	leaq	(%r12,%rbp), %rax
	movups	.Lanon.65f595193a40e4134698b8f1074b12b6.79(%rip), %xmm0
	movaps	%xmm0, 64(%rsp)
	movups	(%r15), %xmm0
	movups	16(%r15), %xmm1
	leaq	80(%rsp), %rcx
	movups	%xmm0, (%rcx)
	movups	%xmm1, 16(%rcx)
	movq	%rax, 112(%rsp)
	movaps	128(%rsp), %xmm0
	movlps	%xmm0, 120(%rsp)
	movq	%rsp, %rdi
	leaq	64(%rsp), %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds
	movl	$0, 64(%rsp)
	movl	$0, 68(%rsp)
	movl	$0, 72(%rsp)
	movl	$0, 76(%rsp)
	movl	$0, 80(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 92(%rsp)
	movl	$0, 96(%rsp)
	movl	$0, 100(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	#MEMBARRIER
	cmpq	$4, %rbx
	jae	.LBB120_18
	xorl	%eax, %eax
	jmp	.LBB120_26
	.p2align	4
.LBB120_18:
	cmpq	$32, %rbx
	jae	.LBB120_20
	xorl	%eax, %eax
	jmp	.LBB120_24
	.p2align	4
.LBB120_20:
	movl	%r13d, %eax
	movups	(%r14), %xmm0
	movups	16(%r14), %xmm1
	xorps	(%rsp), %xmm0
	xorps	16(%rsp), %xmm1
	andl	$96, %eax
	movups	%xmm0, (%r14)
	movups	%xmm1, 16(%r14)
	cmpq	$32, %rax
	je	.LBB120_22
	movups	32(%r14), %xmm0
	movups	48(%r14), %xmm1
	xorps	32(%rsp), %xmm0
	xorps	48(%rsp), %xmm1
	movups	%xmm0, 32(%r14)
	movups	%xmm1, 48(%r14)
.LBB120_22:
	cmpq	%rax, %r13
	je	.LBB120_15
	testb	$28, %r13b
	je	.LBB120_26
.LBB120_24:
	movq	%rax, %rcx
	movl	%r13d, %eax
	andl	$124, %eax
	.p2align	4
.LBB120_25:
	movl	(%rsp,%rcx), %edx
	xorl	%edx, (%r14,%rcx)
	addq	$4, %rcx
	cmpq	%rcx, %rax
	jne	.LBB120_25
	jmp	.LBB120_27
	.p2align	4
.LBB120_26:
	movzbl	(%rsp,%rax), %ecx
	xorb	%cl, (%r14,%rax)
	incq	%rax
.LBB120_27:
	cmpq	%rax, %r13
	jne	.LBB120_26
	jmp	.LBB120_15
.LBB120_28:
	movb	$-1, %al
	addq	$152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB120_29:
	.cfi_def_cfa_offset 208
	movb	$2, _RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0(%rip)
	movq	%rbp, %rdx
	jmp	.LBB120_4
.Lfunc_end120:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor, .Lfunc_end120-_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha10legacy_xor
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha3xor,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha3xor,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha3xor:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$152, %rsp
	.cfi_def_cfa_offset 208
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, 64(%rsp)
	movq	%rdi, 72(%rsp)
	movabsq	$274877906880, %rax
	cmpq	%rax, %rcx
	jbe	.LBB121_2
	xorl	%eax, %eax
	jmp	.LBB121_31
.LBB121_2:
	movq	%rcx, %rbx
	movq	%rdx, %r14
	cmpq	$256, %rcx
	jae	.LBB121_4
	xorl	%eax, %eax
	subq	%rax, %rbx
	jne	.LBB121_10
	jmp	.LBB121_30
.LBB121_4:
	movq	64(%rsp), %rax
	movl	(%rax), %r13d
	movzbl	_RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0(%rip), %eax
	cmpb	$1, %al
	je	.LBB121_8
	movzbl	%al, %eax
	cmpl	$2, %eax
	jne	.LBB121_25
.LBB121_6:
	shlq	$32, %r13
	incq	%r13
	movq	64(%rsp), %rax
	leaq	4(%rax), %rdx
	movq	72(%rsp), %rdi
	movq	%r13, %rsi
	movq	%r14, %rcx
	movq	%rbx, %r8
	callq	_RNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx27batches
	cmpq	%rbx, %rax
	ja	.LBB121_7
	subq	%rax, %rbx
	je	.LBB121_30
.LBB121_10:
	addq	%rax, %r14
	shrq	$6, %rax
	leaq	96(%rsp), %rbp
	xorl	%r13d, %r13d
	jmp	.LBB121_12
	.p2align	4
.LBB121_11:
	addq	%r12, %r14
	incq	%r13
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	subq	%r12, %rbx
	movq	%r15, %rax
	je	.LBB121_30
.LBB121_12:
	cmpq	$64, %rbx
	movl	$64, %r12d
	cmovbq	%rbx, %r12
	movq	%rax, %r15
	leal	1(%r13,%rax), %eax
	movups	.Lanon.65f595193a40e4134698b8f1074b12b6.79(%rip), %xmm0
	movaps	%xmm0, 80(%rsp)
	movq	72(%rsp), %rcx
	movups	(%rcx), %xmm0
	movups	16(%rcx), %xmm1
	movups	%xmm0, (%rbp)
	movups	%xmm1, 16(%rbp)
	movl	%eax, 128(%rsp)
	movq	64(%rsp), %rcx
	movl	8(%rcx), %eax
	movl	%eax, 44(%rbp)
	movq	(%rcx), %rax
	movq	%rax, 36(%rbp)
	movq	%rsp, %rdi
	leaq	80(%rsp), %rsi
	callq	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds
	movl	$0, 80(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 92(%rsp)
	movl	$0, 96(%rsp)
	movl	$0, 100(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	#MEMBARRIER
	cmpq	$4, %rbx
	jae	.LBB121_14
	xorl	%eax, %eax
	jmp	.LBB121_22
	.p2align	4
.LBB121_14:
	cmpq	$32, %rbx
	jae	.LBB121_16
	xorl	%eax, %eax
	jmp	.LBB121_20
	.p2align	4
.LBB121_16:
	movl	%r12d, %eax
	movups	(%r14), %xmm0
	movups	16(%r14), %xmm1
	xorps	(%rsp), %xmm0
	xorps	16(%rsp), %xmm1
	andl	$96, %eax
	movups	%xmm0, (%r14)
	movups	%xmm1, 16(%r14)
	cmpq	$32, %rax
	je	.LBB121_18
	movups	32(%r14), %xmm0
	movups	48(%r14), %xmm1
	xorps	32(%rsp), %xmm0
	xorps	48(%rsp), %xmm1
	movups	%xmm0, 32(%r14)
	movups	%xmm1, 48(%r14)
.LBB121_18:
	cmpq	%rax, %r12
	je	.LBB121_11
	testb	$28, %r12b
	je	.LBB121_22
.LBB121_20:
	movq	%rax, %rcx
	movl	%r12d, %eax
	andl	$124, %eax
	.p2align	4
.LBB121_21:
	movl	(%rsp,%rcx), %edx
	xorl	%edx, (%r14,%rcx)
	addq	$4, %rcx
	cmpq	%rcx, %rax
	jne	.LBB121_21
	jmp	.LBB121_23
	.p2align	4
.LBB121_22:
	movzbl	(%rsp,%rax), %ecx
	xorb	%cl, (%r14,%rax)
	incq	%rax
.LBB121_23:
	cmpq	%rax, %r12
	jne	.LBB121_22
	jmp	.LBB121_11
.LBB121_8:
	xorl	%eax, %eax
	subq	%rax, %rbx
	jne	.LBB121_10
	jmp	.LBB121_30
.LBB121_25:
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	notl	%ecx
	testl	$469762048, %ecx
	jne	.LBB121_29
	callq	_RNvNtNtNtCsgxBkk5gSRhY_4core9core_arch3x865xsave7__xgetbv
	notl	%eax
	testb	$6, %al
	jne	.LBB121_29
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	cmpl	$7, %eax
	jb	.LBB121_29
	movl	$7, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %rsi
	cpuid
	xchgq	%rbx, %rsi

	#NO_APP
	testb	$32, %sil
	jne	.LBB121_32
.LBB121_29:
	movb	$1, _RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0(%rip)
	xorl	%eax, %eax
	subq	%rax, %rbx
	jne	.LBB121_10
.LBB121_30:
	movb	$-1, %al
.LBB121_31:
	addq	$152, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB121_32:
	.cfi_def_cfa_offset 208
	movb	$2, _RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0(%rip)
	jmp	.LBB121_6
.LBB121_7:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.78(%rip), %rcx
	movq	%rax, %rdi
	movq	%rbx, %rsi
	movq	%rbx, %rdx
	callq	*_RNvNtNtCsgxBkk5gSRhY_4core5slice5index16slice_index_fail@GOTPCREL(%rip)
.Lfunc_end121:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha3xor, .Lfunc_end121-_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha3xor
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, -72(%rsp)
	movl	(%rsi), %r8d
	movl	4(%rsi), %r12d
	movl	8(%rsi), %r13d
	movl	12(%rsi), %edi
	movl	16(%rsi), %r9d
	movl	20(%rsi), %ebx
	movl	24(%rsi), %ebp
	movl	28(%rsi), %r14d
	movl	32(%rsi), %eax
	movl	%eax, -100(%rsp)
	movl	36(%rsi), %r10d
	movl	40(%rsi), %eax
	movl	%eax, -96(%rsp)
	movl	44(%rsi), %eax
	movl	%eax, -92(%rsp)
	movl	48(%rsi), %r11d
	movl	52(%rsi), %eax
	movl	56(%rsi), %ecx
	movq	%rsi, -80(%rsp)
	movl	60(%rsi), %edx
	movl	%r10d, %esi
	movl	$10, %r10d
	.p2align	4
.LBB122_1:
	movl	%r10d, -84(%rsp)
	addl	%r9d, %r8d
	xorl	%r8d, %r11d
	roll	$16, %r11d
	movl	-100(%rsp), %r10d
	addl	%r11d, %r10d
	xorl	%r10d, %r9d
	roll	$12, %r9d
	addl	%r9d, %r8d
	xorl	%r8d, %r11d
	roll	$8, %r11d
	addl	%r11d, %r10d
	movl	%r10d, -100(%rsp)
	xorl	%r10d, %r9d
	roll	$7, %r9d
	addl	%ebx, %r12d
	xorl	%r12d, %eax
	roll	$16, %eax
	addl	%eax, %esi
	xorl	%esi, %ebx
	roll	$12, %ebx
	addl	%ebx, %r12d
	xorl	%r12d, %eax
	roll	$8, %eax
	addl	%eax, %esi
	xorl	%esi, %ebx
	roll	$7, %ebx
	addl	%ebp, %r13d
	xorl	%r13d, %ecx
	roll	$16, %ecx
	movl	-96(%rsp), %r10d
	addl	%ecx, %r10d
	xorl	%r10d, %ebp
	roll	$12, %ebp
	addl	%ebp, %r13d
	xorl	%r13d, %ecx
	roll	$8, %ecx
	addl	%ecx, %r10d
	xorl	%r10d, %ebp
	roll	$7, %ebp
	addl	%r14d, %edi
	xorl	%edi, %edx
	roll	$16, %edx
	movl	-92(%rsp), %r15d
	addl	%edx, %r15d
	xorl	%r15d, %r14d
	roll	$12, %r14d
	addl	%r14d, %edi
	xorl	%edi, %edx
	roll	$8, %edx
	addl	%edx, %r15d
	xorl	%r15d, %r14d
	roll	$7, %r14d
	addl	%ebx, %r8d
	xorl	%r8d, %edx
	roll	$16, %edx
	addl	%edx, %r10d
	xorl	%r10d, %ebx
	roll	$12, %ebx
	addl	%ebx, %r8d
	xorl	%r8d, %edx
	roll	$8, %edx
	addl	%ebp, %r12d
	xorl	%r12d, %r11d
	roll	$16, %r11d
	addl	%r11d, %r15d
	xorl	%r15d, %ebp
	roll	$12, %ebp
	addl	%r14d, %r13d
	movl	%r13d, -96(%rsp)
	xorl	%r13d, %eax
	roll	$16, %eax
	movl	-100(%rsp), %r13d
	addl	%eax, %r13d
	movl	%r13d, -100(%rsp)
	xorl	%r13d, %r14d
	movl	-96(%rsp), %r13d
	roll	$12, %r14d
	addl	%r9d, %edi
	xorl	%edi, %ecx
	roll	$16, %ecx
	addl	%ecx, %esi
	xorl	%esi, %r9d
	roll	$12, %r9d
	addl	%ebp, %r12d
	movl	%r12d, -88(%rsp)
	addl	%r14d, %r13d
	xorl	%r13d, %eax
	roll	$8, %eax
	movl	-100(%rsp), %r12d
	addl	%eax, %r12d
	movl	%r12d, -100(%rsp)
	xorl	%r12d, %r14d
	movl	-88(%rsp), %r12d
	roll	$7, %r14d
	addl	%r9d, %edi
	xorl	%edi, %ecx
	roll	$8, %ecx
	addl	%edx, %r10d
	movl	%r10d, -96(%rsp)
	xorl	%r10d, %ebx
	movl	-84(%rsp), %r10d
	roll	$7, %ebx
	xorl	%r12d, %r11d
	roll	$8, %r11d
	addl	%r11d, %r15d
	movl	%r15d, -92(%rsp)
	xorl	%r15d, %ebp
	roll	$7, %ebp
	addl	%ecx, %esi
	xorl	%esi, %r9d
	roll	$7, %r9d
	decl	%r10d
	jne	.LBB122_1
	movl	%esi, %r15d
	movq	-80(%rsp), %rsi
	addl	(%rsi), %r8d
	movq	-72(%rsp), %r10
	movl	%r8d, (%r10)
	movd	%r9d, %xmm1
	movd	%edi, %xmm0
	movd	%r13d, %xmm3
	movd	%r12d, %xmm2
	movd	-100(%rsp), %xmm4
	movd	%r14d, %xmm5
	movd	%ebp, %xmm6
	addl	52(%rsi), %eax
	addl	56(%rsi), %ecx
	movd	%ebx, %xmm7
	addl	60(%rsi), %edx
	movdqu	4(%rsi), %xmm8
	movdqu	20(%rsi), %xmm9
	movdqu	36(%rsi), %xmm10
	movd	%r11d, %xmm11
	movd	-92(%rsp), %xmm12
	movd	-96(%rsp), %xmm13
	movd	%r15d, %xmm14
	punpckldq	%xmm1, %xmm0
	punpckldq	%xmm3, %xmm2
	punpcklqdq	%xmm0, %xmm2
	paddd	%xmm8, %xmm2
	movdqu	%xmm2, 4(%r10)
	punpckldq	%xmm4, %xmm5
	punpckldq	%xmm6, %xmm7
	punpcklqdq	%xmm5, %xmm7
	paddd	%xmm9, %xmm7
	movdqu	%xmm7, 20(%r10)
	punpckldq	%xmm11, %xmm12
	punpckldq	%xmm13, %xmm14
	punpcklqdq	%xmm12, %xmm14
	paddd	%xmm10, %xmm14
	movdqu	%xmm14, 36(%r10)
	movl	%eax, 52(%r10)
	movl	%ecx, 56(%r10)
	movl	%edx, 60(%r10)
	movl	$0, -4(%rsp)
	movl	$0, -8(%rsp)
	movl	$0, -12(%rsp)
	movl	$0, -16(%rsp)
	movl	$0, -20(%rsp)
	movl	$0, -24(%rsp)
	movl	$0, -28(%rsp)
	movl	$0, -32(%rsp)
	movl	$0, -36(%rsp)
	movl	$0, -40(%rsp)
	movl	$0, -44(%rsp)
	movl	$0, -48(%rsp)
	movl	$0, -52(%rsp)
	movl	$0, -56(%rsp)
	movl	$0, -60(%rsp)
	movl	$0, -64(%rsp)
	#MEMBARRIER
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end122:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds, .Lfunc_end122-_RNvNtCs1muTxUaRwMI_12toyos_crypto6chacha6rounds
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI123_0:
	.long	1779033703
	.long	3144134277
	.long	1013904242
	.long	2773480762
.LCPI123_1:
	.long	1359893119
	.long	2600822924
	.long	528734635
	.long	1541459225
	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_ssh,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_ssh
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_ssh,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_ssh:
.Lfunc_begin51:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception51
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$288, %rsp
	.cfi_def_cfa_offset 320
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %r14
	movq	%rsi, %rbx
	movq	%rdi, %r15
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movaps	.LCPI123_0(%rip), %xmm1
	movaps	%xmm1, 64(%rsp)
	movaps	.LCPI123_1(%rip), %xmm1
	movaps	%xmm1, 80(%rsp)
	movaps	%xmm0, 96(%rsp)
	movq	$0, 112(%rsp)
.Ltmp613:
	movq	%rsp, %rdi
	movl	$32, %edx
	callq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update@GOTPCREL(%rip)
.Ltmp614:
	cmpb	$-1, %al
	jne	.LBB123_2
.Ltmp615:
	movq	%rsp, %rdi
	movl	$32, %edx
	movq	%r14, %rsi
	callq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update@GOTPCREL(%rip)
.Ltmp616:
	cmpb	$-1, %al
	jne	.LBB123_5
	movaps	112(%rsp), %xmm0
	movaps	%xmm0, 272(%rsp)
	movaps	96(%rsp), %xmm0
	movaps	%xmm0, 256(%rsp)
	movaps	80(%rsp), %xmm0
	movaps	%xmm0, 240(%rsp)
	movaps	64(%rsp), %xmm0
	movaps	%xmm0, 224(%rsp)
	movaps	(%rsp), %xmm0
	movaps	16(%rsp), %xmm1
	movaps	32(%rsp), %xmm2
	movaps	48(%rsp), %xmm3
	movaps	%xmm3, 208(%rsp)
	movaps	%xmm2, 192(%rsp)
	movaps	%xmm1, 176(%rsp)
	movaps	%xmm0, 160(%rsp)
.Ltmp620:
	leaq	128(%rsp), %rdi
	leaq	160(%rsp), %rsi
	callq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize@GOTPCREL(%rip)
.Ltmp621:
	movups	128(%rsp), %xmm0
	movups	144(%rsp), %xmm1
	movups	%xmm1, 16(%r15)
	movups	%xmm0, (%r15)
	movb	$0, (%r14)
	movb	$0, 1(%r14)
	movb	$0, 2(%r14)
	movb	$0, 3(%r14)
	movb	$0, 4(%r14)
	movb	$0, 5(%r14)
	movb	$0, 6(%r14)
	movb	$0, 7(%r14)
	movb	$0, 8(%r14)
	movb	$0, 9(%r14)
	movb	$0, 10(%r14)
	movb	$0, 11(%r14)
	movb	$0, 12(%r14)
	movb	$0, 13(%r14)
	movb	$0, 14(%r14)
	movb	$0, 15(%r14)
	movb	$0, 16(%r14)
	movb	$0, 17(%r14)
	movb	$0, 18(%r14)
	movb	$0, 19(%r14)
	movb	$0, 20(%r14)
	movb	$0, 21(%r14)
	movb	$0, 22(%r14)
	movb	$0, 23(%r14)
	movb	$0, 24(%r14)
	movb	$0, 25(%r14)
	movb	$0, 26(%r14)
	movb	$0, 27(%r14)
	movb	$0, 28(%r14)
	movb	$0, 29(%r14)
	movb	$0, 30(%r14)
	movb	$0, 31(%r14)
	#MEMBARRIER
	movb	$0, (%rbx)
	movb	$0, 1(%rbx)
	movb	$0, 2(%rbx)
	movb	$0, 3(%rbx)
	movb	$0, 4(%rbx)
	movb	$0, 5(%rbx)
	movb	$0, 6(%rbx)
	movb	$0, 7(%rbx)
	movb	$0, 8(%rbx)
	movb	$0, 9(%rbx)
	movb	$0, 10(%rbx)
	movb	$0, 11(%rbx)
	movb	$0, 12(%rbx)
	movb	$0, 13(%rbx)
	movb	$0, 14(%rbx)
	movb	$0, 15(%rbx)
	movb	$0, 16(%rbx)
	movb	$0, 17(%rbx)
	movb	$0, 18(%rbx)
	movb	$0, 19(%rbx)
	movb	$0, 20(%rbx)
	movb	$0, 21(%rbx)
	movb	$0, 22(%rbx)
	movb	$0, 23(%rbx)
	movb	$0, 24(%rbx)
	movb	$0, 25(%rbx)
	movb	$0, 26(%rbx)
	movb	$0, 27(%rbx)
	movb	$0, 28(%rbx)
	movb	$0, 29(%rbx)
	movb	$0, 30(%rbx)
	movb	$0, 31(%rbx)
	#MEMBARRIER
	movq	%r15, %rax
	addq	$288, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB123_2:
	.cfi_def_cfa_offset 320
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.82(%rip), %r8
	jmp	.LBB123_6
.LBB123_5:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.83(%rip), %r8
.LBB123_6:
	leaq	160(%rsp), %rdx
	movb	$0, (%rdx)
.Ltmp617:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.80(%rip), %rdi
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.25(%rip), %rcx
	movl	$24, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core6result13unwrap_failed@GOTPCREL(%rip)
.Ltmp618:
	ud2
.LBB123_10:
.Ltmp622:
	movq	%rax, %r15
	jmp	.LBB123_11
.LBB123_12:
.Ltmp619:
	movq	%rax, %r15
	movq	%rsp, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto4hash6Sha256EBF_
.LBB123_11:
	movq	%r14, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%rbx, %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueINtNtCs1muTxUaRwMI_12toyos_crypto6secret6SecretKj20_EEBG_
	movq	%r15, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end123:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_ssh, .Lfunc_end123-_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_ssh
	.cfi_endproc
	.section	.gcc_except_table._RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_ssh,"a",@progbits
	.p2align	2, 0x0
GCC_except_table123:
.Lexception51:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end51-.Lcst_begin51
.Lcst_begin51:
	.uleb128 .Ltmp613-.Lfunc_begin51
	.uleb128 .Ltmp616-.Ltmp613
	.uleb128 .Ltmp619-.Lfunc_begin51
	.byte	0
	.uleb128 .Ltmp620-.Lfunc_begin51
	.uleb128 .Ltmp621-.Ltmp620
	.uleb128 .Ltmp622-.Lfunc_begin51
	.byte	0
	.uleb128 .Ltmp617-.Lfunc_begin51
	.uleb128 .Ltmp618-.Ltmp617
	.uleb128 .Ltmp619-.Lfunc_begin51
	.byte	0
	.uleb128 .Ltmp618-.Lfunc_begin51
	.uleb128 .Lfunc_end123-.Ltmp618
	.byte	0
	.byte	0
.Lcst_end51:
	.p2align	2, 0x0

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_tls,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_tls
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_tls,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_tls:
	.cfi_startproc
	movq	%rdi, %rax
	movups	(%rsi), %xmm0
	movups	16(%rsi), %xmm1
	movaps	%xmm1, -56(%rsp)
	movaps	%xmm0, -72(%rsp)
	movups	(%rdx), %xmm2
	movups	16(%rdx), %xmm3
	movaps	%xmm2, -40(%rsp)
	movaps	%xmm3, -24(%rsp)
	movups	%xmm3, 48(%rdi)
	movups	%xmm2, 32(%rdi)
	movups	%xmm1, 16(%rdi)
	movups	%xmm0, (%rdi)
	movb	$0, (%rdx)
	movb	$0, 1(%rdx)
	movb	$0, 2(%rdx)
	movb	$0, 3(%rdx)
	movb	$0, 4(%rdx)
	movb	$0, 5(%rdx)
	movb	$0, 6(%rdx)
	movb	$0, 7(%rdx)
	movb	$0, 8(%rdx)
	movb	$0, 9(%rdx)
	movb	$0, 10(%rdx)
	movb	$0, 11(%rdx)
	movb	$0, 12(%rdx)
	movb	$0, 13(%rdx)
	movb	$0, 14(%rdx)
	movb	$0, 15(%rdx)
	movb	$0, 16(%rdx)
	movb	$0, 17(%rdx)
	movb	$0, 18(%rdx)
	movb	$0, 19(%rdx)
	movb	$0, 20(%rdx)
	movb	$0, 21(%rdx)
	movb	$0, 22(%rdx)
	movb	$0, 23(%rdx)
	movb	$0, 24(%rdx)
	movb	$0, 25(%rdx)
	movb	$0, 26(%rdx)
	movb	$0, 27(%rdx)
	movb	$0, 28(%rdx)
	movb	$0, 29(%rdx)
	movb	$0, 30(%rdx)
	movb	$0, 31(%rdx)
	#MEMBARRIER
	movb	$0, (%rsi)
	movb	$0, 1(%rsi)
	movb	$0, 2(%rsi)
	movb	$0, 3(%rsi)
	movb	$0, 4(%rsi)
	movb	$0, 5(%rsi)
	movb	$0, 6(%rsi)
	movb	$0, 7(%rsi)
	movb	$0, 8(%rsi)
	movb	$0, 9(%rsi)
	movb	$0, 10(%rsi)
	movb	$0, 11(%rsi)
	movb	$0, 12(%rsi)
	movb	$0, 13(%rsi)
	movb	$0, 14(%rsi)
	movb	$0, 15(%rsi)
	movb	$0, 16(%rsi)
	movb	$0, 17(%rsi)
	movb	$0, 18(%rsi)
	movb	$0, 19(%rsi)
	movb	$0, 20(%rsi)
	movb	$0, 21(%rsi)
	movb	$0, 22(%rsi)
	movb	$0, 23(%rsi)
	movb	$0, 24(%rsi)
	movb	$0, 25(%rsi)
	movb	$0, 26(%rsi)
	movb	$0, 27(%rsi)
	movb	$0, 28(%rsi)
	movb	$0, 29(%rsi)
	movb	$0, 30(%rsi)
	movb	$0, 31(%rsi)
	#MEMBARRIER
	retq
.Lfunc_end124:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_tls, .Lfunc_end124-_RNvNtCs1muTxUaRwMI_12toyos_crypto6hybrid7for_tls
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1g,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1g
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1g,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1g:
.Lfunc_begin52:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception52
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$288, %rsp
	.cfi_def_cfa_offset 320
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %r8
	movq	%rsi, %rcx
	movq	%rdi, %rbx
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 272(%rsp)
	movaps	%xmm0, 256(%rsp)
	movaps	%xmm0, 240(%rsp)
	movaps	%xmm0, 224(%rsp)
	leaq	8(%rsp), %r14
	movl	$72, %esi
	movq	%r14, %rdi
	movl	$6, %edx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new
	xorl	%r15d, %r15d
	movq	216(%rsp), %rax
	jmp	.LBB125_1
	.p2align	4
.LBB125_2:
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 216(%rsp)
	xorl	%edi, %edi
	xorl	%eax, %eax
.LBB125_4:
	leaq	(%rsp,%rdi,8), %rcx
	addq	$8, %rcx
	movl	%eax, %edx
	andl	$7, %edx
	movzbl	(%rdx,%rcx), %ecx
	movb	%cl, 224(%rsp,%r15)
	incq	%r15
	incq	%rax
	movq	%rax, 216(%rsp)
	cmpq	$64, %r15
	je	.LBB125_5
.LBB125_1:
	cmpq	208(%rsp), %rax
	je	.LBB125_2
	movq	%rax, %rdi
	shrq	$3, %rdi
	cmpq	$199, %rax
	jbe	.LBB125_4
.Ltmp623:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.71(%rip), %rdx
	movl	$25, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp624:
	ud2
.LBB125_5:
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
	movaps	224(%rsp), %xmm0
	movaps	240(%rsp), %xmm1
	movaps	256(%rsp), %xmm2
	movaps	272(%rsp), %xmm3
	movups	%xmm3, 48(%rbx)
	movups	%xmm2, 32(%rbx)
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
	movq	%rbx, %rax
	addq	$288, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB125_8:
	.cfi_def_cfa_offset 320
.Ltmp625:
	movq	%rax, %rbx
	leaq	8(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end125:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1g, .Lfunc_end125-_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1g
	.cfi_endproc
	.section	.gcc_except_table._RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1g,"a",@progbits
	.p2align	2, 0x0
GCC_except_table125:
.Lexception52:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end52-.Lcst_begin52
.Lcst_begin52:
	.uleb128 .Lfunc_begin52-.Lfunc_begin52
	.uleb128 .Ltmp623-.Lfunc_begin52
	.byte	0
	.byte	0
	.uleb128 .Ltmp623-.Lfunc_begin52
	.uleb128 .Ltmp624-.Ltmp623
	.uleb128 .Ltmp625-.Lfunc_begin52
	.byte	0
	.uleb128 .Ltmp624-.Lfunc_begin52
	.uleb128 .Lfunc_end125-.Ltmp624
	.byte	0
	.byte	0
.Lcst_end52:
	.p2align	2, 0x0

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1h,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1h
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1h,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1h:
.Lfunc_begin53:
	.cfi_startproc
	.cfi_personality 155, DW.ref.rust_eh_personality
	.cfi_lsda 27, .Lexception53
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	subq	$256, %rsp
	.cfi_def_cfa_offset 288
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdx, %r8
	movq	%rsi, %rcx
	movq	%rdi, %rbx
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	leaq	40(%rsp), %r14
	movl	$136, %esi
	movq	%r14, %rdi
	movl	$6, %edx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge3new
	xorl	%r15d, %r15d
	movq	248(%rsp), %rax
	jmp	.LBB126_1
	.p2align	4
.LBB126_2:
	movq	%r14, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 248(%rsp)
	xorl	%edi, %edi
	xorl	%eax, %eax
.LBB126_4:
	leaq	(%rsp,%rdi,8), %rcx
	addq	$40, %rcx
	movl	%eax, %edx
	andl	$7, %edx
	movzbl	(%rdx,%rcx), %ecx
	movb	%cl, (%rsp,%r15)
	incq	%r15
	incq	%rax
	movq	%rax, 248(%rsp)
	cmpq	$32, %r15
	je	.LBB126_5
.LBB126_1:
	cmpq	240(%rsp), %rax
	je	.LBB126_2
	movq	%rax, %rdi
	shrq	$3, %rdi
	cmpq	$199, %rax
	jbe	.LBB126_4
.Ltmp626:
	leaq	.Lanon.65f595193a40e4134698b8f1074b12b6.71(%rip), %rdx
	movl	$25, %esi
	callq	*_RNvNtCsgxBkk5gSRhY_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Ltmp627:
	ud2
.LBB126_5:
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movaps	(%rsp), %xmm0
	movaps	16(%rsp), %xmm1
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
	movq	%rbx, %rax
	addq	$256, %rsp
	.cfi_def_cfa_offset 32
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.LBB126_8:
	.cfi_def_cfa_offset 288
.Ltmp628:
	movq	%rax, %rbx
	leaq	40(%rsp), %rdi
	callq	_RINvNtCsgxBkk5gSRhY_4core3ptr9drop_glueNtNtCs1muTxUaRwMI_12toyos_crypto6keccak6SpongeEBF_
	movq	%rbx, %rdi
	callq	_Unwind_Resume@PLT
.Lfunc_end126:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1h, .Lfunc_end126-_RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1h
	.cfi_endproc
	.section	.gcc_except_table._RNvNtCs1muTxUaRwMI_12toyos_crypto6keccak1h,"a",@progbits
	.p2align	2, 0x0
GCC_except_table126:
.Lexception53:
	.byte	255
	.byte	255
	.byte	1
	.uleb128 .Lcst_end53-.Lcst_begin53
.Lcst_begin53:
	.uleb128 .Lfunc_begin53-.Lfunc_begin53
	.uleb128 .Ltmp626-.Lfunc_begin53
	.byte	0
	.byte	0
	.uleb128 .Ltmp626-.Lfunc_begin53
	.uleb128 .Ltmp627-.Ltmp626
	.uleb128 .Ltmp628-.Lfunc_begin53
	.byte	0
	.uleb128 .Ltmp627-.Lfunc_begin53
	.uleb128 .Lfunc_end126-.Ltmp627
	.byte	0
	.byte	0
.Lcst_end53:
	.p2align	2, 0x0

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6secret4wipe,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret4wipe
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret4wipe,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret4wipe:
	.cfi_startproc
	testq	%rsi, %rsi
	je	.LBB127_7
	movq	%rsi, %rcx
	movq	%rdi, %rax
	andq	$7, %rcx
	je	.LBB127_4
	movq	%rdi, %rax
	.p2align	4
.LBB127_3:
	movb	$0, (%rax)
	incq	%rax
	decq	%rcx
	jne	.LBB127_3
.LBB127_4:
	cmpq	$8, %rsi
	jb	.LBB127_7
	addq	%rsi, %rdi
	.p2align	4
.LBB127_6:
	movb	$0, (%rax)
	movb	$0, 1(%rax)
	movb	$0, 2(%rax)
	movb	$0, 3(%rax)
	movb	$0, 4(%rax)
	movb	$0, 5(%rax)
	movb	$0, 6(%rax)
	movb	$0, 7(%rax)
	addq	$8, %rax
	cmpq	%rdi, %rax
	jne	.LBB127_6
.LBB127_7:
	#MEMBARRIER
	retq
.Lfunc_end127:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret4wipe, .Lfunc_end127-_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret4wipe
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe32,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe32
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe32,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe32:
	.cfi_startproc
	testq	%rsi, %rsi
	je	.LBB128_7
	leaq	(,%rsi,4), %rcx
	addq	$-4, %rcx
	movl	%ecx, %edx
	notl	%edx
	movq	%rdi, %rax
	testb	$28, %dl
	je	.LBB128_4
	movl	%ecx, %edx
	shrl	$2, %edx
	incl	%edx
	andl	$7, %edx
	negq	%rdx
	movq	%rdi, %rax
	.p2align	4
.LBB128_3:
	movl	$0, (%rax)
	addq	$4, %rax
	incq	%rdx
	jne	.LBB128_3
.LBB128_4:
	cmpq	$28, %rcx
	jb	.LBB128_7
	leaq	(%rdi,%rsi,4), %rcx
	.p2align	4
.LBB128_6:
	movl	$0, (%rax)
	movl	$0, 4(%rax)
	movl	$0, 8(%rax)
	movl	$0, 12(%rax)
	movl	$0, 16(%rax)
	movl	$0, 20(%rax)
	movl	$0, 24(%rax)
	movl	$0, 28(%rax)
	addq	$32, %rax
	cmpq	%rcx, %rax
	jne	.LBB128_6
.LBB128_7:
	#MEMBARRIER
	retq
.Lfunc_end128:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe32, .Lfunc_end128-_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe32
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe64,"ax",@progbits
	.globl	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe64
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe64,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe64:
	.cfi_startproc
	testq	%rsi, %rsi
	je	.LBB129_7
	leaq	(,%rsi,8), %rcx
	addq	$-8, %rcx
	movl	%ecx, %edx
	notl	%edx
	movq	%rdi, %rax
	testb	$56, %dl
	je	.LBB129_4
	movl	%ecx, %edx
	shrl	$3, %edx
	incl	%edx
	andl	$7, %edx
	negq	%rdx
	movq	%rdi, %rax
	.p2align	4
.LBB129_3:
	movq	$0, (%rax)
	addq	$8, %rax
	incq	%rdx
	jne	.LBB129_3
.LBB129_4:
	cmpq	$56, %rcx
	jb	.LBB129_7
	leaq	(%rdi,%rsi,8), %rcx
	.p2align	4
.LBB129_6:
	movq	$0, (%rax)
	movq	$0, 8(%rax)
	movq	$0, 16(%rax)
	movq	$0, 24(%rax)
	movq	$0, 32(%rax)
	movq	$0, 40(%rax)
	movq	$0, 48(%rax)
	movq	$0, 56(%rax)
	addq	$64, %rax
	cmpq	%rcx, %rax
	jne	.LBB129_6
.LBB129_7:
	#MEMBARRIER
	retq
.Lfunc_end129:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe64, .Lfunc_end129-_RNvNtCs1muTxUaRwMI_12toyos_crypto6secret6wipe64
	.cfi_endproc

	.section	.text._RNvNtCs1muTxUaRwMI_12toyos_crypto6x255198multiply,"ax",@progbits
	.p2align	4
	.type	_RNvNtCs1muTxUaRwMI_12toyos_crypto6x255198multiply,@function
_RNvNtCs1muTxUaRwMI_12toyos_crypto6x255198multiply:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$920, %rsp
	.cfi_def_cfa_offset 976
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r8
	movq	%rsi, %r11
	movq	%rdi, 816(%rsp)
	xorps	%xmm0, %xmm0
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movq	$0, 32(%rsp)
	xorl	%esi, %esi
	movabsq	$-6872316419617283935, %rdi
	.p2align	4
.LBB130_1:
	movq	%rsi, %rax
	mulq	%rdi
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%sil, %eax
	imull	$161, %eax, %eax
	movq	%rsi, %rdx
	shrq	$3, %rdx
	movzbl	(%r8,%rdx), %edx
	movl	%esi, %r9d
	andl	$7, %r9d
	xorl	%r10d, %r10d
	btl	%r9d, %edx
	setb	%r10b
	addl	%esi, %ecx
	shlq	%cl, %r10
	shrl	$13, %eax
	orq	%r10, (%rsp,%rax,8)
	incq	%rsi
	cmpq	$255, %rsi
	jne	.LBB130_1
	movq	32(%rsp), %rax
	movq	%rax, 864(%rsp)
	movaps	(%rsp), %xmm0
	movaps	16(%rsp), %xmm1
	movaps	%xmm1, 848(%rsp)
	movaps	%xmm0, 832(%rsp)
	movq	$1, 48(%rsp)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 56(%rsp)
	movups	%xmm0, 72(%rsp)
	movaps	%xmm0, 192(%rsp)
	movaps	%xmm0, 176(%rsp)
	movq	$0, 208(%rsp)
	movaps	%xmm0, 16(%rsp)
	movaps	%xmm0, (%rsp)
	movq	$0, 32(%rsp)
	xorl	%esi, %esi
	.p2align	4
.LBB130_3:
	movq	%rsi, %rax
	mulq	%rdi
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%sil, %eax
	imull	$161, %eax, %eax
	movq	%rsi, %rdx
	shrq	$3, %rdx
	movzbl	(%r8,%rdx), %edx
	movl	%esi, %r9d
	andl	$7, %r9d
	xorl	%r10d, %r10d
	btl	%r9d, %edx
	setb	%r10b
	addl	%esi, %ecx
	shlq	%cl, %r10
	shrl	$13, %eax
	orq	%r10, (%rsp,%rax,8)
	incq	%rsi
	cmpq	$255, %rsi
	jne	.LBB130_3
	movq	(%rsp), %rax
	movq	8(%rsp), %rcx
	movq	%rax, 128(%rsp)
	movq	%rcx, 120(%rsp)
	movq	16(%rsp), %rax
	movq	%rax, 112(%rsp)
	movq	24(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	$1, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movl	$254, %eax
	movq	$0, 448(%rsp)
	movq	%r11, 824(%rsp)
	.p2align	4
.LBB130_5:
	movq	%rax, 456(%rsp)
	movq	456(%rsp), %rax
	shrq	$3, %rax
	movzbl	(%r11,%rax), %eax
	movq	456(%rsp), %rcx
	movl	%ecx, %edx
	andl	$7, %edx
	movq	448(%rsp), %rcx
	xorl	%esi, %esi
	btl	%edx, %eax
	setb	%sil
	movq	%rsi, 448(%rsp)
	xorq	%rsi, %rcx
	movq	128(%rsp), %rdi
	movq	%rdi, 416(%rsp)
	movq	48(%rsp), %rdx
	movq	%rdx, 440(%rsp)
	movq	%rcx, (%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 432(%rsp)
	movq	(%rsp), %rsi
	movq	%rsi, %r8
	decq	%rsi
	negq	%r8
	andq	%rdx, %rsi
	movq	120(%rsp), %r13
	movq	%rcx, (%rsp)
	andq	%rdi, %r8
	movq	(%rsp), %rdi
	movq	%rdi, %rdx
	decq	%rdi
	negq	%rdx
	andq	%rax, %rdi
	movq	64(%rsp), %rax
	movq	%rax, 424(%rsp)
	movq	112(%rsp), %r10
	orq	%rsi, %r8
	movq	%rcx, (%rsp)
	movq	(%rsp), %r9
	movq	%r9, %rsi
	andq	%r13, %rdx
	negq	%rsi
	decq	%r9
	andq	%rax, %r9
	orq	%rdi, %rdx
	andq	%r10, %rsi
	movq	72(%rsp), %rbx
	movq	104(%rsp), %r11
	orq	%r9, %rsi
	movq	%rcx, (%rsp)
	movq	(%rsp), %r9
	movq	%r9, %rdi
	negq	%rdi
	decq	%r9
	andq	%rbx, %r9
	andq	%r11, %rdi
	orq	%r9, %rdi
	movq	80(%rsp), %rbp
	movq	%rcx, (%rsp)
	movq	96(%rsp), %r14
	movq	(%rsp), %r15
	movq	%r15, %r9
	negq	%r9
	decq	%r15
	andq	%rbp, %r15
	andq	%r14, %r9
	orq	%r15, %r9
	movq	%rcx, (%rsp)
	movq	(%rsp), %r12
	movq	%r12, %r15
	decq	%r12
	andq	416(%rsp), %r12
	negq	%r15
	andq	440(%rsp), %r15
	orq	%r12, %r15
	movq	%rcx, (%rsp)
	movq	(%rsp), %r12
	movq	%r12, %rax
	decq	%r12
	andq	%r13, %r12
	negq	%rax
	andq	432(%rsp), %rax
	orq	%r12, %rax
	movq	%rcx, (%rsp)
	movq	(%rsp), %r12
	movq	%r12, %r13
	decq	%r12
	andq	%r10, %r12
	negq	%r13
	andq	424(%rsp), %r13
	orq	%r12, %r13
	movq	%rcx, (%rsp)
	movq	(%rsp), %r12
	movq	%r12, %r10
	decq	%r12
	andq	%r11, %r12
	negq	%r10
	andq	%rbx, %r10
	movq	%rcx, (%rsp)
	movq	(%rsp), %r11
	movq	%r11, %rbx
	decq	%r11
	andq	%r14, %r11
	negq	%rbx
	orq	%r12, %r10
	andq	%rbp, %rbx
	orq	%r11, %rbx
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	%r15, 128(%rsp)
	movq	%rax, 120(%rsp)
	movq	%r13, 112(%rsp)
	movq	%r10, 104(%rsp)
	movq	%rbx, 96(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	%r8, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%rsi, 64(%rsp)
	movq	%rdi, 72(%rsp)
	movq	%r9, 80(%rsp)
	movq	168(%rsp), %r8
	movq	%r8, 416(%rsp)
	movq	176(%rsp), %rdx
	movq	%rdx, 432(%rsp)
	movq	184(%rsp), %rsi
	movq	%rsi, 440(%rsp)
	movq	%rcx, (%rsp)
	movq	(%rsp), %rax
	movq	%rax, %r14
	negq	%r14
	decq	%rax
	movq	160(%rsp), %r11
	andq	%rdx, %rax
	movq	%rcx, (%rsp)
	movq	(%rsp), %rdi
	movq	%rdi, %rdx
	andq	%r8, %r14
	negq	%rdx
	decq	%rdi
	andq	%rsi, %rdi
	orq	%rax, %r14
	movq	192(%rsp), %rbx
	movq	152(%rsp), %r15
	movq	%rcx, (%rsp)
	andq	%r11, %rdx
	movq	(%rsp), %rax
	movq	%rax, %rsi
	negq	%rsi
	orq	%rdi, %rdx
	decq	%rax
	andq	%rbx, %rax
	movq	200(%rsp), %r10
	movq	%r10, 424(%rsp)
	andq	%r15, %rsi
	movq	144(%rsp), %r8
	movq	%rcx, (%rsp)
	movq	(%rsp), %r9
	orq	%rax, %rsi
	movq	%r9, %rdi
	negq	%rdi
	decq	%r9
	andq	%r10, %r9
	andq	%r8, %rdi
	orq	%r9, %rdi
	movq	%rcx, (%rsp)
	movq	208(%rsp), %r10
	movq	136(%rsp), %r9
	movq	(%rsp), %rbp
	movq	%rcx, (%rsp)
	movq	(%rsp), %r12
	movq	%r12, %r13
	decq	%r12
	andq	416(%rsp), %r12
	negq	%r13
	andq	432(%rsp), %r13
	orq	%r12, %r13
	movq	%rcx, (%rsp)
	movq	(%rsp), %r12
	movq	%r12, %rax
	decq	%r12
	andq	%r11, %r12
	negq	%rax
	andq	440(%rsp), %rax
	orq	%r12, %rax
	movq	%rcx, (%rsp)
	movq	(%rsp), %r12
	movq	%r12, %r11
	decq	%r12
	andq	%r15, %r12
	negq	%r11
	andq	%rbx, %r11
	orq	%r12, %r11
	movq	%rcx, (%rsp)
	movq	(%rsp), %r15
	movq	%r15, %rbx
	decq	%r15
	andq	%r8, %r15
	negq	%rbx
	andq	424(%rsp), %rbx
	movq	%rbp, %r8
	negq	%r8
	orq	%r15, %rbx
	movq	%rcx, (%rsp)
	movq	(%rsp), %rcx
	movq	%rcx, %r15
	andq	%r9, %r8
	decq	%rcx
	andq	%r9, %rcx
	decq	%rbp
	andq	%r10, %rbp
	negq	%r15
	andq	%r10, %r15
	orq	%rcx, %r15
	orq	%rbp, %r8
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	%r13, 168(%rsp)
	movq	%rax, 160(%rsp)
	movq	%r11, 152(%rsp)
	movq	%rbx, 144(%rsp)
	movq	%r15, 136(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	%r14, 176(%rsp)
	movq	%rdx, 184(%rsp)
	movq	%rsi, 192(%rsp)
	movq	%rdi, 200(%rsp)
	movq	%r8, 208(%rsp)
	xorl	%eax, %eax
	addq	48(%rsp), %r14
	setb	%al
	xorl	%r9d, %r9d
	addq	56(%rsp), %rdx
	setb	%r9b
	xorl	%r10d, %r10d
	addq	64(%rsp), %rsi
	setb	%r10b
	xorl	%r11d, %r11d
	addq	72(%rsp), %rdi
	setb	%r11b
	xorl	%ebx, %ebx
	addq	80(%rsp), %r8
	setb	%bl
	shldq	$13, %r14, %rax
	movabsq	$2251799813685247, %r13
	andq	%r13, %r14
	addq	%rdx, %rax
	adcq	$0, %r9
	shldq	$13, %rax, %r9
	andq	%r13, %rax
	addq	%rsi, %r9
	adcq	$0, %r10
	shldq	$13, %r9, %r10
	andq	%r13, %r9
	addq	%rdi, %r10
	adcq	$0, %r11
	shldq	$13, %r10, %r11
	andq	%r13, %r10
	addq	%r8, %r11
	adcl	$0, %ebx
	movq	%r11, %rcx
	shrq	$51, %rcx
	shll	$13, %ebx
	orq	%rcx, %rbx
	leaq	(%rbx,%rbx,8), %rcx
	leaq	(%rbx,%rcx,2), %rdx
	addq	%r14, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rdx
	addq	%rax, %rdx
	andq	%r13, %r11
	movq	%rdx, %rsi
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %rdi
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r8
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rax
	shrq	$51, %rax
	andq	%r13, %rcx
	leaq	(%rax,%rax,8), %r9
	leaq	(%rax,%r9,2), %rax
	addq	%rcx, %rax
	andq	%r13, %rsi
	movq	%rax, %r9
	shrq	$51, %rax
	addq	%rsi, %rax
	andq	%r13, %rdi
	movq	%rax, %rcx
	shrq	$51, %rcx
	addq	%rdi, %rcx
	andq	%r13, %r8
	movq	%rcx, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	andq	%r13, %rdx
	movq	%rsi, %rdi
	shrq	$51, %rdi
	addq	%rdx, %rdi
	movq	%rdi, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r8
	leaq	(%rdx,%r8,2), %rdx
	andq	%r13, %r9
	addq	%r9, %rdx
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	%rdx, 576(%rsp)
	andq	%r13, %rax
	movq	%rax, 584(%rsp)
	andq	%r13, %rcx
	movq	%rcx, 592(%rsp)
	andq	%r13, %rsi
	movq	%rsi, 600(%rsp)
	andq	%r13, %rdi
	movq	%rdi, 608(%rsp)
	leaq	464(%rsp), %rdi
	leaq	576(%rsp), %rdx
	movq	%rdx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	48(%rsp), %rdi
	movq	56(%rsp), %rax
	subq	176(%rsp), %rdi
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	movabsq	$4503599627370458, %rbp
	addq	%rbp, %rdi
	adcq	$0, %rcx
	subq	184(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movq	%rcx, %rsi
	shldq	$13, %rdi, %rcx
	shrq	$51, %rsi
	addq	%rax, %rcx
	adcq	%rdx, %rsi
	movq	64(%rsp), %rax
	subq	192(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movabsq	$4503599627370494, %r12
	addq	%r12, %rcx
	adcq	$0, %rsi
	movq	%rsi, %r8
	shldq	$13, %rcx, %rsi
	shrq	$51, %r8
	addq	%rax, %rsi
	adcq	%rdx, %r8
	movq	72(%rsp), %rax
	subq	200(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r12, %rsi
	adcq	$0, %r8
	movq	%r8, %r9
	shldq	$13, %rsi, %r8
	shrq	$51, %r9
	addq	%rax, %r8
	adcq	%rdx, %r9
	movq	80(%rsp), %rax
	subq	208(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r12, %r8
	adcq	$0, %r9
	movq	%r9, %r10
	shldq	$13, %r8, %r9
	shrq	$51, %r10
	addq	%rax, %r9
	adcq	%rdx, %r10
	andq	%r13, %rdi
	andq	%r13, %rcx
	andq	%r13, %rsi
	andq	%r13, %r8
	addq	%r12, %r9
	adcq	$0, %r10
	movq	%r10, %rax
	shldq	$13, %r9, %rax
	shrq	$51, %r10
	andq	%r13, %r9
	leaq	(%r10,%r10,8), %rdx
	leaq	(%r10,%rdx,2), %r10
	movl	$19, %edx
	mulq	%rdx
	movl	$19, %r14d
	addq	%rdi, %rax
	adcq	%r10, %rdx
	shldq	$13, %rax, %rdx
	andq	%r13, %rax
	addq	%rcx, %rdx
	movq	%rdx, %rdi
	andq	%r13, %rdi
	shrq	$51, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	andq	%r13, %rsi
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r13, %r8
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r13, %rdx
	leaq	(%rcx,%rcx,8), %r9
	leaq	(%rcx,%r9,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %r9
	andq	%r13, %r9
	shrq	$51, %rcx
	addq	%rdi, %rcx
	movq	%rcx, %rax
	shrq	$51, %rax
	addq	%rsi, %rax
	movq	%rax, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	addq	%rdx, %rdi
	movq	%rdi, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r8
	leaq	(%rdx,%r8,2), %rdx
	addq	%r9, %rdx
	andq	%r13, %rcx
	andq	%r13, %rax
	andq	%r13, %rsi
	andq	%r13, %rdi
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	%rdx, 616(%rsp)
	movq	%rcx, 624(%rsp)
	movq	%rax, 632(%rsp)
	movq	%rsi, 640(%rsp)
	movq	%rdi, 648(%rsp)
	leaq	656(%rsp), %rdi
	leaq	616(%rsp), %rdx
	movq	%rdx, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	464(%rsp), %rdi
	movq	472(%rsp), %rax
	subq	656(%rsp), %rdi
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%rbp, %rdi
	adcq	$0, %rcx
	subq	664(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movq	%rcx, %rsi
	shldq	$13, %rdi, %rcx
	shrq	$51, %rsi
	addq	%rax, %rcx
	adcq	%rdx, %rsi
	movq	480(%rsp), %rax
	subq	672(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r12, %rcx
	adcq	$0, %rsi
	movq	%rsi, %r8
	shldq	$13, %rcx, %rsi
	shrq	$51, %r8
	addq	%rax, %rsi
	adcq	%rdx, %r8
	movq	488(%rsp), %rax
	subq	680(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r12, %rsi
	adcq	$0, %r8
	movq	%r8, %r9
	shldq	$13, %rsi, %r8
	shrq	$51, %r9
	addq	%rax, %r8
	adcq	%rdx, %r9
	movq	496(%rsp), %rax
	subq	688(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r12, %r8
	adcq	$0, %r9
	movq	%r9, %r10
	shldq	$13, %r8, %r9
	shrq	$51, %r10
	addq	%rax, %r9
	adcq	%rdx, %r10
	andq	%r13, %rdi
	andq	%r13, %rcx
	andq	%r13, %rsi
	andq	%r13, %r8
	addq	%r12, %r9
	adcq	$0, %r10
	movq	%r10, %rax
	shldq	$13, %r9, %rax
	shrq	$51, %r10
	andq	%r13, %r9
	leaq	(%r10,%r10,8), %r11
	mulq	%r14
	leaq	(%r10,%r11,2), %r10
	addq	%rdi, %rax
	adcq	%r10, %rdx
	shldq	$13, %rax, %rdx
	andq	%r13, %rax
	addq	%rcx, %rdx
	movq	%rdx, %rdi
	andq	%r13, %rdi
	shrq	$51, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	andq	%r13, %rsi
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r13, %r8
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r13, %rdx
	leaq	(%rcx,%rcx,8), %r9
	leaq	(%rcx,%r9,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %r10
	andq	%r13, %r10
	shrq	$51, %rcx
	addq	%rdi, %rcx
	movq	%rcx, %rdi
	shrq	$51, %rdi
	addq	%rsi, %rdi
	movq	%rdi, %r9
	shrq	$51, %r9
	addq	%r8, %r9
	movq	%r9, %rax
	shrq	$51, %rax
	addq	%rdx, %rax
	movq	%rax, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %rsi
	leaq	(%rdx,%rsi,2), %rdx
	addq	%r10, %rdx
	andq	%r13, %rcx
	andq	%r13, %rdi
	andq	%r13, %r9
	andq	%r13, %rax
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	%rdx, 696(%rsp)
	movq	%rcx, 704(%rsp)
	movq	168(%rsp), %rsi
	xorl	%ecx, %ecx
	addq	128(%rsp), %rsi
	setb	%cl
	movq	160(%rsp), %r11
	xorl	%edx, %edx
	addq	120(%rsp), %r11
	movq	%rdi, 712(%rsp)
	setb	%dl
	movq	152(%rsp), %r14
	xorl	%edi, %edi
	addq	112(%rsp), %r14
	setb	%dil
	movq	144(%rsp), %r15
	xorl	%r8d, %r8d
	addq	104(%rsp), %r15
	setb	%r8b
	movq	136(%rsp), %rbx
	xorl	%r10d, %r10d
	addq	96(%rsp), %rbx
	movq	%r9, 720(%rsp)
	setb	%r10b
	shldq	$13, %rsi, %rcx
	andq	%r13, %rsi
	addq	%r11, %rcx
	adcq	$0, %rdx
	shldq	$13, %rcx, %rdx
	andq	%r13, %rcx
	addq	%r14, %rdx
	adcq	$0, %rdi
	shldq	$13, %rdx, %rdi
	andq	%r13, %rdx
	addq	%r15, %rdi
	adcq	$0, %r8
	movq	%rax, 728(%rsp)
	shldq	$13, %rdi, %r8
	andq	%r13, %rdi
	addq	%rbx, %r8
	adcl	$0, %r10d
	movq	%r8, %rax
	shrq	$51, %rax
	shll	$13, %r10d
	orq	%rax, %r10
	andq	%r13, %r8
	leaq	(%r10,%r10,8), %rax
	leaq	(%r10,%rax,2), %r9
	addq	%rsi, %r9
	movq	%r9, %rax
	andq	%r13, %rax
	shrq	$51, %r9
	addq	%rcx, %r9
	movq	%r9, %rcx
	andq	%r13, %rcx
	shrq	$51, %r9
	addq	%rdx, %r9
	movq	%r9, %r10
	andq	%r13, %r10
	shrq	$51, %r9
	addq	%rdi, %r9
	movq	%r9, %rdi
	andq	%r13, %rdi
	shrq	$51, %r9
	addq	%r8, %r9
	movq	%r9, %rdx
	shrq	$51, %rdx
	andq	%r13, %r9
	leaq	(%rdx,%rdx,8), %rsi
	leaq	(%rdx,%rsi,2), %rsi
	addq	%rax, %rsi
	movq	%rsi, %r8
	andq	%r13, %r8
	shrq	$51, %rsi
	addq	%rcx, %rsi
	movq	%rsi, %rdx
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %rax
	shrq	$51, %rax
	addq	%rdi, %rax
	movq	%rax, %rcx
	shrq	$51, %rcx
	addq	%r9, %rcx
	movq	%rcx, %rdi
	shrq	$51, %rdi
	leaq	(%rdi,%rdi,8), %r9
	leaq	(%rdi,%r9,2), %r11
	addq	%r8, %r11
	andq	%r13, %rsi
	andq	%r13, %rdx
	andq	%r13, %rax
	andq	%r13, %rcx
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	128(%rsp), %r9
	subq	168(%rsp), %r9
	movl	$0, %ebx
	sbbq	%rbx, %rbx
	addq	%rbp, %r9
	adcq	$0, %rbx
	movq	120(%rsp), %r8
	subq	160(%rsp), %r8
	movl	$0, %r10d
	sbbq	%r10, %r10
	movq	%rbx, %rdi
	shldq	$13, %r9, %rbx
	shrq	$51, %rdi
	addq	%r8, %rbx
	adcq	%r10, %rdi
	movq	112(%rsp), %r10
	subq	152(%rsp), %r10
	movl	$0, %r14d
	sbbq	%r14, %r14
	addq	%r12, %rbx
	adcq	$0, %rdi
	movq	%rdi, %r8
	shldq	$13, %rbx, %rdi
	shrq	$51, %r8
	addq	%r10, %rdi
	adcq	%r14, %r8
	movq	104(%rsp), %r14
	subq	144(%rsp), %r14
	movl	$0, %r15d
	sbbq	%r15, %r15
	addq	%r12, %rdi
	adcq	$0, %r8
	movq	%r8, %r10
	shldq	$13, %rdi, %r8
	shrq	$51, %r10
	addq	%r14, %r8
	adcq	%r15, %r10
	movq	96(%rsp), %r14
	subq	136(%rsp), %r14
	movl	$0, %r15d
	sbbq	%r15, %r15
	movq	%r11, 736(%rsp)
	addq	%r12, %r8
	adcq	$0, %r10
	movq	%rsi, 744(%rsp)
	movq	%r10, %rsi
	shldq	$13, %r8, %r10
	shrq	$51, %rsi
	addq	%r14, %r10
	adcq	%r15, %rsi
	movq	%rdx, 752(%rsp)
	andq	%r13, %r9
	andq	%r13, %rbx
	andq	%r13, %rdi
	andq	%r13, %r8
	addq	%r12, %r10
	adcq	$0, %rsi
	movq	%rax, 760(%rsp)
	movq	%rsi, %rax
	shldq	$13, %r10, %rax
	shrq	$51, %rsi
	andq	%r13, %r10
	leaq	(%rsi,%rsi,8), %rdx
	leaq	(%rsi,%rdx,2), %rsi
	movl	$19, %r15d
	mulq	%r15
	addq	%r9, %rax
	adcq	%rsi, %rdx
	movq	%rcx, 768(%rsp)
	shldq	$13, %rax, %rdx
	andq	%r13, %rax
	addq	%rbx, %rdx
	movq	%rdx, %rsi
	andq	%r13, %rsi
	shrq	$51, %rdx
	addq	%rdi, %rdx
	movq	%rdx, %rdi
	andq	%r13, %rdi
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r13, %r8
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r13, %rdx
	leaq	(%rcx,%rcx,8), %r9
	leaq	(%rcx,%r9,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %r9
	andq	%r13, %r9
	shrq	$51, %rcx
	addq	%rsi, %rcx
	movq	%rcx, %rax
	shrq	$51, %rax
	addq	%rdi, %rax
	movq	%rax, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	addq	%rdx, %rdi
	movq	%rdi, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r8
	leaq	(%rdx,%r8,2), %rdx
	addq	%r9, %rdx
	andq	%r13, %rcx
	andq	%r13, %rax
	andq	%r13, %rsi
	andq	%r13, %rdi
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	%rdx, 776(%rsp)
	movq	%rcx, 784(%rsp)
	movq	%rax, 792(%rsp)
	movq	%rsi, 800(%rsp)
	movq	%rdi, 808(%rsp)
	leaq	504(%rsp), %rdi
	leaq	776(%rsp), %rsi
	leaq	576(%rsp), %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	leaq	320(%rsp), %rdi
	leaq	736(%rsp), %rsi
	leaq	616(%rsp), %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	320(%rsp), %rsi
	movq	328(%rsp), %r9
	xorl	%eax, %eax
	addq	504(%rsp), %rsi
	setb	%al
	xorl	%ecx, %ecx
	addq	512(%rsp), %r9
	setb	%cl
	movq	336(%rsp), %r10
	xorl	%edx, %edx
	addq	520(%rsp), %r10
	setb	%dl
	movq	344(%rsp), %r11
	xorl	%edi, %edi
	addq	528(%rsp), %r11
	setb	%dil
	movq	352(%rsp), %rbx
	xorl	%r8d, %r8d
	addq	536(%rsp), %rbx
	setb	%r8b
	shldq	$13, %rsi, %rax
	andq	%r13, %rsi
	addq	%r9, %rax
	adcq	$0, %rcx
	shldq	$13, %rax, %rcx
	andq	%r13, %rax
	addq	%r10, %rcx
	adcq	$0, %rdx
	shldq	$13, %rcx, %rdx
	andq	%r13, %rcx
	addq	%r11, %rdx
	adcq	$0, %rdi
	shldq	$13, %rdx, %rdi
	andq	%r13, %rdx
	addq	%rbx, %rdi
	adcl	$0, %r8d
	movq	%rdi, %r9
	shrq	$51, %r9
	shll	$13, %r8d
	orq	%r9, %r8
	andq	%r13, %rdi
	leaq	(%r8,%r8,8), %r9
	leaq	(%r8,%r9,2), %r8
	addq	%rsi, %r8
	movq	%r8, %rsi
	andq	%r13, %rsi
	shrq	$51, %r8
	addq	%rax, %r8
	movq	%r8, %r9
	andq	%r13, %r9
	shrq	$51, %r8
	addq	%rcx, %r8
	movq	%r8, %r10
	andq	%r13, %r10
	shrq	$51, %r8
	addq	%rdx, %r8
	movq	%r8, %r11
	andq	%r13, %r11
	shrq	$51, %r8
	addq	%rdi, %r8
	movq	%r8, %rax
	shrq	$51, %rax
	andq	%r13, %r8
	leaq	(%rax,%rax,8), %rcx
	leaq	(%rax,%rcx,2), %rax
	addq	%rsi, %rax
	movq	%rax, %rdi
	andq	%r13, %rdi
	shrq	$51, %rax
	addq	%r9, %rax
	movq	%rax, %rcx
	shrq	$51, %rcx
	addq	%r10, %rcx
	movq	%rcx, %rdx
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	movq	%rsi, %r8
	shrq	$51, %r8
	leaq	(%r8,%r8,8), %r9
	leaq	(%r8,%r9,2), %r8
	addq	%rdi, %r8
	andq	%r13, %rax
	andq	%r13, %rcx
	andq	%r13, %rdx
	andq	%r13, %rsi
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	movq	%r8, (%rsp)
	movq	%rax, 8(%rsp)
	movq	%rcx, 16(%rsp)
	movq	%rdx, 24(%rsp)
	movq	%rsi, 32(%rsp)
	leaq	224(%rsp), %rbx
	movq	%rbx, %rdi
	movq	%rsp, %r14
	movq	%r14, %rsi
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	224(%rsp), %rax
	movq	232(%rsp), %rcx
	movq	%rax, 128(%rsp)
	movq	%rcx, 120(%rsp)
	movq	240(%rsp), %rax
	movq	%rax, 112(%rsp)
	movq	248(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	256(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	504(%rsp), %rdi
	movq	512(%rsp), %rax
	subq	320(%rsp), %rdi
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%rbp, %rdi
	adcq	$0, %rcx
	subq	328(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movq	%rcx, %rsi
	shldq	$13, %rdi, %rcx
	shrq	$51, %rsi
	addq	%rax, %rcx
	adcq	%rdx, %rsi
	movq	520(%rsp), %rax
	subq	336(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r12, %rcx
	adcq	$0, %rsi
	movq	%rsi, %r8
	shldq	$13, %rcx, %rsi
	shrq	$51, %r8
	addq	%rax, %rsi
	adcq	%rdx, %r8
	movq	528(%rsp), %rax
	subq	344(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r12, %rsi
	adcq	$0, %r8
	movq	%r8, %r9
	shldq	$13, %rsi, %r8
	shrq	$51, %r9
	addq	%rax, %r8
	adcq	%rdx, %r9
	movq	536(%rsp), %rax
	subq	352(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r12, %r8
	adcq	$0, %r9
	movq	%r9, %r10
	shldq	$13, %r8, %r9
	shrq	$51, %r10
	addq	%rax, %r9
	adcq	%rdx, %r10
	andq	%r13, %rdi
	andq	%r13, %rcx
	andq	%r13, %rsi
	andq	%r13, %r8
	addq	%r12, %r9
	adcq	$0, %r10
	movq	%r10, %rax
	shldq	$13, %r9, %rax
	shrq	$51, %r10
	andq	%r13, %r9
	leaq	(%r10,%r10,8), %rdx
	leaq	(%r10,%rdx,2), %r10
	mulq	%r15
	addq	%rdi, %rax
	adcq	%r10, %rdx
	shldq	$13, %rax, %rdx
	andq	%r13, %rax
	addq	%rcx, %rdx
	movq	%rdx, %rdi
	andq	%r13, %rdi
	shrq	$51, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	andq	%r13, %rsi
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r13, %r8
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r13, %rdx
	leaq	(%rcx,%rcx,8), %r9
	leaq	(%rcx,%r9,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %r9
	andq	%r13, %r9
	shrq	$51, %rcx
	addq	%rdi, %rcx
	movq	%rcx, %rax
	shrq	$51, %rax
	addq	%rsi, %rax
	movq	%rax, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	addq	%rdx, %rdi
	movq	%rdi, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r8
	leaq	(%rdx,%r8,2), %rdx
	addq	%r9, %rdx
	andq	%r13, %rcx
	andq	%r13, %rax
	andq	%r13, %rsi
	andq	%r13, %rdi
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	movq	%rdx, (%rsp)
	movq	%rcx, 8(%rsp)
	movq	%rax, 16(%rsp)
	movq	%rsi, 24(%rsp)
	movq	%rdi, 32(%rsp)
	movq	%rbx, %rdi
	movq	%r14, %rsi
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	leaq	272(%rsp), %r15
	movq	%r15, %rdi
	leaq	832(%rsp), %rsi
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	272(%rsp), %rax
	movq	280(%rsp), %rcx
	movq	%rax, 168(%rsp)
	movq	%rcx, 160(%rsp)
	movq	288(%rsp), %rax
	movq	%rax, 152(%rsp)
	movq	296(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	304(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	%r14, %rdi
	leaq	464(%rsp), %rsi
	leaq	656(%rsp), %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	32(%rsp), %rax
	movq	%rax, 80(%rsp)
	movups	(%rsp), %xmm0
	movups	16(%rsp), %xmm1
	movaps	%xmm1, 64(%rsp)
	movaps	%xmm0, 48(%rsp)
	movq	$121665, (%rsp)
	leaq	8(%rsp), %rax
	xorps	%xmm0, %xmm0
	movups	%xmm0, 16(%rax)
	movups	%xmm0, (%rax)
	movq	%rbx, %rdi
	movq	%r14, %rsi
	leaq	696(%rsp), %r14
	movq	%r14, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	224(%rsp), %rsi
	movq	232(%rsp), %r9
	xorl	%eax, %eax
	addq	464(%rsp), %rsi
	setb	%al
	xorl	%ecx, %ecx
	addq	472(%rsp), %r9
	setb	%cl
	movq	240(%rsp), %r10
	xorl	%edx, %edx
	addq	480(%rsp), %r10
	setb	%dl
	movq	248(%rsp), %r11
	xorl	%edi, %edi
	addq	488(%rsp), %r11
	setb	%dil
	movq	256(%rsp), %rbx
	xorl	%r8d, %r8d
	addq	496(%rsp), %rbx
	setb	%r8b
	shldq	$13, %rsi, %rax
	andq	%r13, %rsi
	addq	%r9, %rax
	adcq	$0, %rcx
	shldq	$13, %rax, %rcx
	andq	%r13, %rax
	addq	%r10, %rcx
	adcq	$0, %rdx
	shldq	$13, %rcx, %rdx
	andq	%r13, %rcx
	addq	%r11, %rdx
	adcq	$0, %rdi
	shldq	$13, %rdx, %rdi
	andq	%r13, %rdx
	addq	%rbx, %rdi
	adcl	$0, %r8d
	movq	%rdi, %r9
	shrq	$51, %r9
	shll	$13, %r8d
	orq	%r9, %r8
	andq	%r13, %rdi
	leaq	(%r8,%r8,8), %r9
	leaq	(%r8,%r9,2), %r8
	addq	%rsi, %r8
	movq	%r8, %rsi
	andq	%r13, %rsi
	shrq	$51, %r8
	addq	%rax, %r8
	movq	%r8, %r9
	andq	%r13, %r9
	shrq	$51, %r8
	addq	%rcx, %r8
	movq	%r8, %r10
	andq	%r13, %r10
	shrq	$51, %r8
	addq	%rdx, %r8
	movq	%r8, %r11
	andq	%r13, %r11
	shrq	$51, %r8
	addq	%rdi, %r8
	movq	%r8, %rax
	shrq	$51, %rax
	andq	%r13, %r8
	leaq	(%rax,%rax,8), %rcx
	leaq	(%rax,%rcx,2), %rax
	addq	%rsi, %rax
	movq	%rax, %rdi
	andq	%r13, %rdi
	shrq	$51, %rax
	addq	%r9, %rax
	movq	%rax, %rcx
	shrq	$51, %rcx
	addq	%r10, %rcx
	movq	%rcx, %rdx
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rsi
	shrq	$51, %rsi
	addq	%r8, %rsi
	movq	%rsi, %r8
	shrq	$51, %r8
	leaq	(%r8,%r8,8), %r9
	leaq	(%r8,%r9,2), %r8
	addq	%rdi, %r8
	andq	%r13, %rax
	andq	%r13, %rcx
	andq	%r13, %rdx
	andq	%r13, %rsi
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 880(%rsp)
	#MEMBARRIER
	movq	%r8, 272(%rsp)
	movq	%rax, 280(%rsp)
	movq	%rcx, 288(%rsp)
	movq	%rdx, 296(%rsp)
	movq	%rsi, 304(%rsp)
	leaq	368(%rsp), %rdi
	movq	%r14, %rsi
	movq	%r15, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	824(%rsp), %r11
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	400(%rsp), %rax
	movq	%rax, 208(%rsp)
	movq	456(%rsp), %rax
	movups	368(%rsp), %xmm0
	movups	384(%rsp), %xmm1
	movaps	%xmm1, 192(%rsp)
	movaps	%xmm0, 176(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	#MEMBARRIER
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	#MEMBARRIER
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	movq	$0, 808(%rsp)
	#MEMBARRIER
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	#MEMBARRIER
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	#MEMBARRIER
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	#MEMBARRIER
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	#MEMBARRIER
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	addq	$-1, %rax
	jb	.LBB130_5
	movq	128(%rsp), %r10
	movq	448(%rsp), %r12
	movq	%r12, (%rsp)
	movq	(%rsp), %r8
	movq	120(%rsp), %r11
	movq	%r12, (%rsp)
	movq	(%rsp), %r9
	movq	112(%rsp), %rsi
	movq	%r12, (%rsp)
	movq	(%rsp), %rcx
	movq	104(%rsp), %rdi
	movq	%r12, (%rsp)
	movq	(%rsp), %rdx
	movq	80(%rsp), %rbx
	movq	96(%rsp), %r14
	movq	%r12, (%rsp)
	movq	(%rsp), %rax
	movq	%rax, %r15
	negq	%r15
	andq	%r14, %r15
	decq	%rax
	andq	%rbx, %rax
	orq	%r15, %rax
	movq	%r9, %xmm0
	negq	%r9
	andq	%r11, %r9
	movq	%r8, %xmm2
	negq	%r8
	andq	%r10, %r8
	punpcklqdq	%xmm0, %xmm2
	pcmpeqd	%xmm0, %xmm0
	paddq	%xmm0, %xmm2
	pand	48(%rsp), %xmm2
	movq	%r8, %xmm1
	movq	%r9, %xmm3
	punpcklqdq	%xmm3, %xmm1
	por	%xmm2, %xmm1
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	%rdx, %xmm2
	negq	%rdx
	andq	%rdi, %rdx
	movq	%rcx, %xmm3
	negq	%rcx
	andq	%rsi, %rcx
	punpcklqdq	%xmm2, %xmm3
	paddq	%xmm0, %xmm3
	pand	64(%rsp), %xmm3
	movq	%rcx, %xmm2
	movq	%rdx, %xmm4
	punpcklqdq	%xmm4, %xmm2
	por	%xmm3, %xmm2
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movdqa	%xmm1, 48(%rsp)
	movdqa	%xmm2, 64(%rsp)
	movq	%rax, 80(%rsp)
	movq	168(%rsp), %r10
	movq	%r12, (%rsp)
	movq	(%rsp), %r8
	movq	160(%rsp), %r11
	movq	%r12, (%rsp)
	movq	(%rsp), %r9
	movq	152(%rsp), %rsi
	movq	%r12, (%rsp)
	movq	(%rsp), %rcx
	movq	144(%rsp), %rdi
	movq	%r12, (%rsp)
	movq	(%rsp), %rdx
	movq	208(%rsp), %rbx
	movq	136(%rsp), %r14
	movq	%r12, (%rsp)
	movq	(%rsp), %rax
	movq	%rax, %r15
	negq	%r15
	andq	%r14, %r15
	decq	%rax
	andq	%rbx, %rax
	orq	%r15, %rax
	movq	%r9, %xmm1
	negq	%r9
	andq	%r11, %r9
	movq	%r8, %xmm2
	negq	%r8
	andq	%r10, %r8
	punpcklqdq	%xmm1, %xmm2
	paddq	%xmm0, %xmm2
	pand	176(%rsp), %xmm2
	movq	%r8, %xmm1
	movq	%r9, %xmm3
	punpcklqdq	%xmm3, %xmm1
	por	%xmm2, %xmm1
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	%rdx, %xmm2
	negq	%rdx
	andq	%rdi, %rdx
	movq	%rcx, %xmm3
	negq	%rcx
	andq	%rsi, %rcx
	punpcklqdq	%xmm2, %xmm3
	paddq	%xmm0, %xmm3
	pand	192(%rsp), %xmm3
	movq	%rcx, %xmm2
	movq	%rdx, %xmm4
	punpcklqdq	%xmm4, %xmm2
	por	%xmm3, %xmm2
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movdqa	%xmm1, 176(%rsp)
	movdqa	%xmm2, 192(%rsp)
	movq	%rax, 208(%rsp)
	movdqu	%xmm0, 239(%rsp)
	movdqu	%xmm0, 225(%rsp)
	movb	$-21, 224(%rsp)
	movb	$127, 255(%rsp)
	movq	%rsp, %rbx
	leaq	176(%rsp), %rsi
	leaq	224(%rsp), %rdx
	movl	$255, %ecx
	movq	%rbx, %rdi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3pow
	leaq	224(%rsp), %r14
	leaq	48(%rsp), %rsi
	movq	%r14, %rdi
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F3mul
	movq	816(%rsp), %rdi
	movq	%r14, %rsi
	callq	_RNvMs_NtCs1muTxUaRwMI_12toyos_crypto10field25519NtB4_1F5bytes
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 864(%rsp)
	#MEMBARRIER
	addq	$920, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end130:
	.size	_RNvNtCs1muTxUaRwMI_12toyos_crypto6x255198multiply, .Lfunc_end130-_RNvNtCs1muTxUaRwMI_12toyos_crypto6x255198multiply
	.cfi_endproc

	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI131_0:
	.zero	16,85
.LCPI131_1:
	.zero	16,51
.LCPI131_2:
	.zero	16,15
.LCPI131_3:
	.zero	16,170
.LCPI131_4:
	.zero	16,204
.LCPI131_5:
	.zero	16,240
	.section	.text._RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6411hash_blocks,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6411hash_blocks,@function
_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6411hash_blocks:
	.cfi_startproc
	movdqu	(%rdi), %xmm1
	movdqa	%xmm1, %xmm2
	psrlw	$1, %xmm2
	movdqa	.LCPI131_0(%rip), %xmm14
	pand	%xmm14, %xmm2
	paddw	%xmm1, %xmm1
	movdqa	%xmm14, %xmm3
	pandn	%xmm1, %xmm3
	por	%xmm2, %xmm3
	movdqa	%xmm3, %xmm2
	psrlw	$2, %xmm2
	movdqa	.LCPI131_1(%rip), %xmm1
	pand	%xmm1, %xmm2
	psllw	$2, %xmm3
	movdqa	%xmm1, %xmm4
	pandn	%xmm3, %xmm4
	por	%xmm2, %xmm4
	movdqa	%xmm4, %xmm5
	psrlw	$4, %xmm5
	movdqa	.LCPI131_2(%rip), %xmm2
	pand	%xmm2, %xmm5
	psllw	$4, %xmm4
	movdqa	%xmm2, %xmm3
	pandn	%xmm4, %xmm3
	por	%xmm5, %xmm3
	movdqu	(%rsi), %xmm4
	movdqa	%xmm4, %xmm5
	psrlw	$1, %xmm5
	pand	%xmm14, %xmm5
	paddw	%xmm4, %xmm4
	movdqa	%xmm14, %xmm6
	pandn	%xmm4, %xmm6
	por	%xmm5, %xmm6
	movdqa	%xmm6, %xmm4
	psrlw	$2, %xmm4
	pand	%xmm1, %xmm4
	psllw	$2, %xmm6
	movdqa	%xmm1, %xmm7
	pandn	%xmm6, %xmm7
	por	%xmm4, %xmm7
	movdqa	%xmm7, %xmm4
	psrlw	$4, %xmm4
	pand	%xmm2, %xmm4
	psllw	$4, %xmm7
	movdqa	%xmm2, %xmm5
	pandn	%xmm7, %xmm5
	por	%xmm4, %xmm5
	movq	%rcx, %rax
	shrq	$2, %rax
	pshufd	$238, %xmm3, %xmm0
	movdqa	%xmm0, -120(%rsp)
	je	.LBB131_3
	movdqa	%xmm3, %xmm4
	pclmulqdq	$0, %xmm3, %xmm4
	movdqa	%xmm3, %xmm6
	pclmulqdq	$17, %xmm3, %xmm6
	pxor	%xmm3, %xmm0
	movdqa	%xmm0, %xmm8
	pclmulqdq	$0, %xmm0, %xmm8
	movdqa	%xmm4, %xmm7
	pxor	%xmm6, %xmm7
	pxor	%xmm8, %xmm7
	movdqa	%xmm7, %xmm8
	pslldq	$8, %xmm8
	psrldq	$8, %xmm7
	pxor	%xmm6, %xmm7
	movdqa	%xmm7, %xmm9
	paddq	%xmm9, %xmm9
	movdqa	%xmm7, %xmm6
	psrlq	$63, %xmm6
	movdqa	%xmm6, %xmm10
	pslldq	$8, %xmm10
	por	%xmm9, %xmm10
	movdqa	%xmm7, %xmm9
	psllq	$2, %xmm9
	movdqa	%xmm7, %xmm11
	psrlq	$62, %xmm11
	pxor	%xmm11, %xmm6
	pslldq	$8, %xmm11
	por	%xmm9, %xmm11
	pxor	%xmm10, %xmm11
	movdqa	%xmm7, %xmm10
	psllq	$7, %xmm10
	movdqa	%xmm7, %xmm9
	psrlq	$57, %xmm9
	pxor	%xmm9, %xmm6
	pslldq	$8, %xmm9
	por	%xmm10, %xmm9
	pxor	%xmm8, %xmm9
	pxor	%xmm11, %xmm9
	psrldq	$8, %xmm6
	movdqa	%xmm6, %xmm8
	movdqa	%xmm6, %xmm10
	pxor	%xmm4, %xmm7
	pxor	%xmm6, %xmm7
	paddq	%xmm6, %xmm6
	psllq	$2, %xmm8
	pxor	%xmm6, %xmm8
	psllq	$7, %xmm10
	pxor	%xmm9, %xmm10
	pxor	%xmm8, %xmm10
	pxor	%xmm10, %xmm7
	movdqa	%xmm7, %xmm4
	pclmulqdq	$0, %xmm3, %xmm4
	movdqa	%xmm7, %xmm6
	pclmulqdq	$17, %xmm3, %xmm6
	pshufd	$238, %xmm7, %xmm9
	pxor	%xmm7, %xmm9
	movdqa	%xmm9, %xmm8
	movdqa	%xmm0, -24(%rsp)
	pclmulqdq	$0, %xmm0, %xmm8
	movdqa	%xmm4, %xmm0
	pxor	%xmm6, %xmm0
	pxor	%xmm8, %xmm0
	movdqa	%xmm0, %xmm8
	pslldq	$8, %xmm8
	psrldq	$8, %xmm0
	pxor	%xmm6, %xmm0
	movdqa	%xmm0, %xmm10
	paddq	%xmm10, %xmm10
	movdqa	%xmm0, %xmm6
	psrlq	$63, %xmm6
	movdqa	%xmm6, %xmm11
	pslldq	$8, %xmm11
	por	%xmm10, %xmm11
	movdqa	%xmm0, %xmm10
	psllq	$2, %xmm10
	movdqa	%xmm0, %xmm12
	psrlq	$62, %xmm12
	pxor	%xmm12, %xmm6
	pslldq	$8, %xmm12
	por	%xmm10, %xmm12
	pxor	%xmm11, %xmm12
	movdqa	%xmm0, %xmm11
	psllq	$7, %xmm11
	movdqa	%xmm0, %xmm10
	psrlq	$57, %xmm10
	pxor	%xmm10, %xmm6
	pslldq	$8, %xmm10
	por	%xmm11, %xmm10
	pxor	%xmm8, %xmm10
	pxor	%xmm12, %xmm10
	psrldq	$8, %xmm6
	movdqa	%xmm6, %xmm8
	movdqa	%xmm6, %xmm11
	pxor	%xmm4, %xmm0
	pxor	%xmm6, %xmm0
	paddq	%xmm6, %xmm6
	psllq	$2, %xmm8
	pxor	%xmm6, %xmm8
	psllq	$7, %xmm11
	pxor	%xmm10, %xmm11
	pxor	%xmm8, %xmm11
	pxor	%xmm11, %xmm0
	movdqa	%xmm7, %xmm4
	pclmulqdq	$0, %xmm7, %xmm4
	movdqa	%xmm7, -40(%rsp)
	movdqa	%xmm7, %xmm6
	pclmulqdq	$17, %xmm7, %xmm6
	movdqa	%xmm9, -56(%rsp)
	movdqa	%xmm9, %xmm8
	pclmulqdq	$0, %xmm9, %xmm8
	movdqa	%xmm4, %xmm10
	pxor	%xmm6, %xmm10
	pxor	%xmm8, %xmm10
	movdqa	%xmm10, %xmm8
	pslldq	$8, %xmm8
	psrldq	$8, %xmm10
	pxor	%xmm6, %xmm10
	movdqa	%xmm10, %xmm11
	paddq	%xmm11, %xmm11
	movdqa	%xmm10, %xmm6
	psrlq	$63, %xmm6
	movdqa	%xmm6, %xmm12
	pslldq	$8, %xmm12
	por	%xmm11, %xmm12
	movdqa	%xmm10, %xmm11
	psllq	$2, %xmm11
	movdqa	%xmm10, %xmm13
	psrlq	$62, %xmm13
	pxor	%xmm13, %xmm6
	pslldq	$8, %xmm13
	por	%xmm11, %xmm13
	pxor	%xmm12, %xmm13
	movdqa	%xmm10, %xmm12
	psllq	$7, %xmm12
	movdqa	%xmm10, %xmm11
	psrlq	$57, %xmm11
	pxor	%xmm11, %xmm6
	pslldq	$8, %xmm11
	por	%xmm12, %xmm11
	pxor	%xmm8, %xmm11
	pxor	%xmm13, %xmm11
	psrldq	$8, %xmm6
	movdqa	%xmm6, %xmm8
	movdqa	%xmm6, %xmm12
	pxor	%xmm4, %xmm10
	pxor	%xmm6, %xmm10
	paddq	%xmm6, %xmm6
	psllq	$2, %xmm8
	pxor	%xmm6, %xmm8
	psllq	$7, %xmm12
	pxor	%xmm11, %xmm12
	pxor	%xmm8, %xmm12
	pxor	%xmm12, %xmm10
	shlq	$6, %rax
	addq	%rdx, %rax
	pshufd	$238, %xmm10, %xmm4
	pxor	%xmm10, %xmm4
	movdqa	%xmm4, -88(%rsp)
	pshufd	$238, %xmm0, %xmm4
	movdqa	%xmm0, -72(%rsp)
	pxor	%xmm0, %xmm4
	movdqa	%xmm4, -104(%rsp)
	movq	%rdx, %rdi
	.p2align	4
.LBB131_2:
	movdqu	(%rdi), %xmm11
	movdqu	16(%rdi), %xmm8
	movdqu	32(%rdi), %xmm6
	movdqu	48(%rdi), %xmm4
	movdqa	%xmm11, %xmm12
	psrlw	$1, %xmm12
	paddw	%xmm11, %xmm11
	movdqa	%xmm14, %xmm7
	pand	%xmm14, %xmm12
	pandn	%xmm11, %xmm14
	por	%xmm12, %xmm14
	movdqa	%xmm14, %xmm12
	psrlw	$2, %xmm12
	psllw	$2, %xmm14
	movdqa	%xmm1, %xmm13
	movdqa	%xmm2, %xmm11
	pandn	%xmm14, %xmm13
	movdqa	%xmm8, %xmm14
	psrlw	$1, %xmm14
	pand	%xmm7, %xmm14
	pand	%xmm1, %xmm12
	paddw	%xmm8, %xmm8
	movdqa	%xmm7, %xmm15
	pandn	%xmm8, %xmm15
	por	%xmm12, %xmm13
	por	%xmm14, %xmm15
	movdqa	%xmm15, %xmm12
	psrlw	$2, %xmm12
	movdqa	%xmm13, %xmm14
	pand	%xmm1, %xmm12
	psllw	$2, %xmm15
	movdqa	%xmm1, %xmm8
	psllw	$4, %xmm13
	pandn	%xmm15, %xmm8
	por	%xmm12, %xmm8
	movdqa	%xmm8, %xmm12
	psllw	$4, %xmm8
	movdqa	%xmm6, %xmm15
	psrlw	$1, %xmm15
	pand	%xmm7, %xmm15
	psrlw	$4, %xmm14
	paddw	%xmm6, %xmm6
	movdqa	%xmm7, %xmm0
	pandn	%xmm6, %xmm0
	pandn	%xmm13, %xmm11
	por	%xmm15, %xmm0
	movdqa	%xmm0, %xmm6
	psrlw	$2, %xmm6
	psrlw	$4, %xmm12
	pand	%xmm1, %xmm6
	psllw	$2, %xmm0
	movdqa	%xmm1, %xmm15
	pand	%xmm2, %xmm14
	pandn	%xmm0, %xmm15
	por	%xmm6, %xmm15
	movdqa	%xmm15, %xmm0
	pand	%xmm2, %xmm12
	psrlw	$4, %xmm0
	psllw	$4, %xmm15
	movdqa	%xmm2, %xmm13
	pand	%xmm2, %xmm0
	pandn	%xmm15, %xmm13
	movdqa	%xmm4, %xmm6
	psrlw	$1, %xmm6
	por	%xmm14, %xmm11
	pand	%xmm7, %xmm6
	paddw	%xmm4, %xmm4
	movdqa	%xmm7, %xmm14
	por	%xmm0, %xmm13
	pandn	%xmm4, %xmm14
	por	%xmm6, %xmm14
	movdqa	%xmm14, %xmm0
	pxor	%xmm5, %xmm11
	psrlw	$2, %xmm0
	pand	%xmm1, %xmm0
	psllw	$2, %xmm14
	movdqa	%xmm2, %xmm5
	movdqa	%xmm1, %xmm4
	pandn	%xmm14, %xmm4
	por	%xmm0, %xmm4
	pandn	%xmm8, %xmm5
	movdqa	%xmm4, %xmm0
	psrlw	$4, %xmm0
	pand	%xmm2, %xmm0
	por	%xmm12, %xmm5
	psllw	$4, %xmm4
	movdqa	%xmm2, %xmm15
	pandn	%xmm4, %xmm15
	por	%xmm0, %xmm15
	movdqa	%xmm11, %xmm14
	pshufd	$238, %xmm11, %xmm8
	pxor	%xmm11, %xmm8
	pclmulqdq	$0, %xmm10, %xmm11
	pclmulqdq	$17, %xmm10, %xmm14
	pclmulqdq	$0, -88(%rsp), %xmm8
	movdqa	%xmm5, %xmm4
	pshufd	$238, %xmm5, %xmm12
	pxor	%xmm5, %xmm12
	movdqa	-72(%rsp), %xmm9
	pclmulqdq	$0, %xmm9, %xmm5
	movdqa	%xmm5, %xmm6
	pxor	%xmm11, %xmm5
	movdqa	%xmm11, %xmm0
	pxor	%xmm14, %xmm0
	pclmulqdq	$17, %xmm9, %xmm4
	pclmulqdq	$0, -104(%rsp), %xmm12
	movdqa	%xmm13, %xmm11
	pxor	%xmm8, %xmm0
	pshufd	$238, %xmm13, %xmm8
	pxor	%xmm13, %xmm8
	pxor	%xmm4, %xmm6
	movdqa	-40(%rsp), %xmm9
	pclmulqdq	$0, %xmm9, %xmm13
	pclmulqdq	$17, %xmm9, %xmm11
	pclmulqdq	$0, -56(%rsp), %xmm8
	pxor	%xmm12, %xmm6
	pxor	%xmm13, %xmm5
	pxor	%xmm11, %xmm13
	pxor	%xmm0, %xmm6
	movdqa	%xmm15, %xmm0
	pshufd	$238, %xmm15, %xmm12
	pxor	%xmm15, %xmm12
	pxor	%xmm8, %xmm13
	pclmulqdq	$0, %xmm3, %xmm15
	pclmulqdq	$17, %xmm3, %xmm0
	movdqa	%xmm13, %xmm8
	pclmulqdq	$0, -24(%rsp), %xmm12
	pxor	%xmm15, %xmm5
	psrldq	$8, %xmm13
	pxor	%xmm0, %xmm15
	pxor	%xmm12, %xmm15
	movdqa	%xmm15, %xmm12
	psrldq	$8, %xmm15
	pxor	%xmm13, %xmm15
	pslldq	$8, %xmm8
	pslldq	$8, %xmm12
	pxor	%xmm8, %xmm12
	pxor	%xmm14, %xmm15
	movdqa	%xmm7, %xmm14
	movdqa	%xmm6, %xmm8
	psrldq	$8, %xmm6
	pxor	%xmm6, %xmm15
	pslldq	$8, %xmm8
	pxor	%xmm4, %xmm11
	pxor	%xmm0, %xmm11
	pxor	%xmm12, %xmm8
	pxor	%xmm15, %xmm11
	movdqa	%xmm11, %xmm4
	movdqa	%xmm11, %xmm0
	movdqa	%xmm11, %xmm6
	paddq	%xmm6, %xmm6
	psrlq	$63, %xmm4
	movdqa	%xmm4, %xmm12
	pslldq	$8, %xmm12
	por	%xmm6, %xmm12
	movdqa	%xmm11, %xmm6
	psllq	$2, %xmm0
	psrlq	$62, %xmm6
	pxor	%xmm6, %xmm4
	pslldq	$8, %xmm6
	por	%xmm0, %xmm6
	movdqa	%xmm11, %xmm0
	pxor	%xmm11, %xmm5
	psrlq	$57, %xmm11
	psllq	$7, %xmm0
	pxor	%xmm11, %xmm4
	pslldq	$8, %xmm11
	por	%xmm0, %xmm11
	pxor	%xmm12, %xmm6
	pxor	%xmm8, %xmm11
	psrldq	$8, %xmm4
	movdqa	%xmm4, %xmm0
	pxor	%xmm6, %xmm11
	movdqa	%xmm4, %xmm6
	paddq	%xmm6, %xmm6
	psllq	$2, %xmm0
	pxor	%xmm6, %xmm0
	pxor	%xmm4, %xmm5
	psllq	$7, %xmm4
	pxor	%xmm11, %xmm4
	pxor	%xmm0, %xmm4
	pxor	%xmm4, %xmm5
	addq	$64, %rdi
	cmpq	%rax, %rdi
	jne	.LBB131_2
.LBB131_3:
	movl	%ecx, %eax
	shll	$4, %eax
	andl	$48, %eax
	je	.LBB131_6
	movabsq	$576460752303423484, %rdi
	andq	%rdi, %rcx
	shlq	$4, %rcx
	addq	%rcx, %rdx
	movdqa	-120(%rsp), %xmm13
	pxor	%xmm3, %xmm13
	xorl	%ecx, %ecx
	movdqa	.LCPI131_3(%rip), %xmm4
	movdqa	.LCPI131_4(%rip), %xmm6
	movdqa	.LCPI131_5(%rip), %xmm7
	.p2align	4
.LBB131_5:
	movdqu	(%rdx,%rcx), %xmm8
	movdqa	%xmm8, %xmm0
	psrlw	$1, %xmm0
	pand	%xmm14, %xmm0
	paddw	%xmm8, %xmm8
	pand	%xmm4, %xmm8
	por	%xmm0, %xmm8
	movdqa	%xmm8, %xmm0
	psrlw	$2, %xmm0
	pand	%xmm1, %xmm0
	psllw	$2, %xmm8
	pand	%xmm6, %xmm8
	por	%xmm0, %xmm8
	movdqa	%xmm8, %xmm0
	psrlw	$4, %xmm0
	pand	%xmm2, %xmm0
	psllw	$4, %xmm8
	pand	%xmm7, %xmm8
	por	%xmm0, %xmm8
	pxor	%xmm5, %xmm8
	movdqa	%xmm8, %xmm0
	pshufd	$238, %xmm8, %xmm9
	pxor	%xmm8, %xmm9
	pclmulqdq	$0, %xmm3, %xmm8
	pclmulqdq	$17, %xmm3, %xmm0
	pclmulqdq	$0, %xmm13, %xmm9
	movdqa	%xmm8, %xmm5
	pxor	%xmm0, %xmm5
	pxor	%xmm9, %xmm5
	movdqa	%xmm5, %xmm10
	pslldq	$8, %xmm10
	psrldq	$8, %xmm5
	pxor	%xmm0, %xmm5
	movdqa	%xmm5, %xmm0
	paddq	%xmm0, %xmm0
	movdqa	%xmm5, %xmm9
	psrlq	$63, %xmm9
	movdqa	%xmm9, %xmm11
	pslldq	$8, %xmm11
	por	%xmm0, %xmm11
	movdqa	%xmm5, %xmm0
	psllq	$2, %xmm0
	movdqa	%xmm5, %xmm12
	psrlq	$62, %xmm12
	pxor	%xmm12, %xmm9
	pslldq	$8, %xmm12
	por	%xmm0, %xmm12
	pxor	%xmm11, %xmm12
	movdqa	%xmm5, %xmm0
	psllq	$7, %xmm0
	movdqa	%xmm5, %xmm11
	psrlq	$57, %xmm11
	pxor	%xmm11, %xmm9
	pslldq	$8, %xmm11
	por	%xmm0, %xmm11
	pxor	%xmm10, %xmm11
	pxor	%xmm12, %xmm11
	psrldq	$8, %xmm9
	movdqa	%xmm9, %xmm0
	movdqa	%xmm9, %xmm10
	pxor	%xmm8, %xmm5
	pxor	%xmm9, %xmm5
	paddq	%xmm9, %xmm9
	psllq	$2, %xmm0
	pxor	%xmm9, %xmm0
	psllq	$7, %xmm10
	pxor	%xmm11, %xmm10
	pxor	%xmm0, %xmm10
	pxor	%xmm10, %xmm5
	addq	$16, %rcx
	cmpq	%rcx, %rax
	jne	.LBB131_5
.LBB131_6:
	movdqa	%xmm5, %xmm0
	psrlw	$1, %xmm0
	pand	.LCPI131_0(%rip), %xmm0
	paddw	%xmm5, %xmm5
	pand	.LCPI131_3(%rip), %xmm5
	por	%xmm0, %xmm5
	movdqa	%xmm5, %xmm0
	psrlw	$2, %xmm0
	pand	.LCPI131_1(%rip), %xmm0
	psllw	$2, %xmm5
	pand	.LCPI131_4(%rip), %xmm5
	por	%xmm0, %xmm5
	movdqa	%xmm5, %xmm0
	psrlw	$4, %xmm0
	pand	.LCPI131_2(%rip), %xmm0
	psllw	$4, %xmm5
	pand	.LCPI131_5(%rip), %xmm5
	por	%xmm0, %xmm5
	movdqu	%xmm5, (%rsi)
	retq
.Lfunc_end131:
	.size	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6411hash_blocks, .Lfunc_end131-_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6411hash_blocks
	.cfi_endproc

	.section	.text._RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414encrypt_native,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414encrypt_native,@function
_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414encrypt_native:
	.cfi_startproc
	movdqu	(%rdx), %xmm1
	movdqu	(%rdi), %xmm0
	pxor	%xmm1, %xmm0
	cmpq	$2, %rsi
	jb	.LBB132_7
	leaq	-1(%rsi), %r8
	leaq	-2(%rsi), %r9
	movl	%r8d, %eax
	andl	$3, %eax
	movl	$1, %ecx
	cmpq	$3, %r9
	jb	.LBB132_5
	leaq	64(%rdi), %r9
	andq	$-4, %r8
	negq	%r8
	.p2align	4
.LBB132_3:
	movdqu	-48(%r9), %xmm1
	aesenc	%xmm1, %xmm0
	movdqu	-32(%r9), %xmm1
	aesenc	%xmm1, %xmm0
	movdqu	-16(%r9), %xmm1
	aesenc	%xmm1, %xmm0
	movdqu	(%r9), %xmm1
	aesenc	%xmm1, %xmm0
	addq	$64, %r9
	leaq	(%r8,%rcx), %r10
	addq	$4, %r10
	addq	$4, %rcx
	cmpq	$1, %r10
	jne	.LBB132_3
	testq	%rax, %rax
	je	.LBB132_7
.LBB132_5:
	shlq	$4, %rcx
	addq	%rdi, %rcx
	shll	$4, %eax
	xorl	%r8d, %r8d
	.p2align	4
.LBB132_6:
	movdqu	(%rcx,%r8), %xmm1
	aesenc	%xmm1, %xmm0
	addq	$16, %r8
	cmpq	%r8, %rax
	jne	.LBB132_6
.LBB132_7:
	shlq	$4, %rsi
	movdqu	(%rdi,%rsi), %xmm1
	aesenclast	%xmm1, %xmm0
	movdqu	%xmm0, (%rdx)
	retq
.Lfunc_end132:
	.size	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414encrypt_native, .Lfunc_end132-_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414encrypt_native
	.cfi_endproc

	.section	.text._RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414product_native,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414product_native,@function
_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414product_native:
	.cfi_startproc
	movq	%rdx, %xmm1
	movq	%rsi, %xmm0
	punpcklqdq	%xmm1, %xmm0
	movq	%r8, %xmm2
	movq	%rcx, %xmm3
	punpcklqdq	%xmm2, %xmm3
	movdqa	%xmm0, %xmm4
	pclmulqdq	$0, %xmm3, %xmm4
	pxor	%xmm0, %xmm1
	pclmulqdq	$17, %xmm3, %xmm0
	pxor	%xmm2, %xmm3
	pclmulqdq	$0, %xmm1, %xmm3
	pshufd	$238, %xmm4, %xmm1
	movq	%xmm4, (%rdi)
	pxor	%xmm0, %xmm4
	pxor	%xmm3, %xmm4
	movq	%xmm1, %rax
	pshufd	$238, %xmm0, %xmm1
	movq	%xmm0, %rcx
	movq	%xmm4, %rdx
	xorq	%rax, %rdx
	pshufd	$238, %xmm4, %xmm0
	movq	%xmm0, %rax
	xorq	%rcx, %rax
	movq	%rdx, 8(%rdi)
	movq	%xmm1, 24(%rdi)
	movq	%rax, 16(%rdi)
	retq
.Lfunc_end133:
	.size	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414product_native, .Lfunc_end133-_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_6414product_native
	.cfi_endproc

	.section	.text._RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_643ctr,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_643ctr,@function
_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_643ctr:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	pxor	%xmm1, %xmm1
	movdqa	%xmm1, -24(%rsp)
	movl	8(%rdx), %eax
	movl	%eax, -16(%rsp)
	movq	(%rdx), %rax
	movq	%rax, -24(%rsp)
	movdqu	(%rdi), %xmm0
	movabsq	$9223372036854775744, %r10
	andq	%r8, %r10
	leaq	(%rcx,%r10), %rax
	movl	%r8d, %r9d
	andl	$63, %r9d
	testq	%r10, %r10
	je	.LBB134_11
	movdqa	-24(%rsp), %xmm2
	pxor	%xmm0, %xmm2
	movq	%rsi, %r10
	shlq	$4, %r10
	movdqu	(%rdi,%r10), %xmm3
	cmpq	$1, %rsi
	jbe	.LBB134_2
	leaq	-1(%rsi), %r10
	leaq	32(%rdi), %r11
	movq	%r10, %rbx
	andq	$-2, %rbx
	negq	%rbx
	xorl	%r14d, %r14d
	jmp	.LBB134_5
	.p2align	4
.LBB134_9:
	shlq	$4, %r15
	movdqu	(%rdi,%r15), %xmm8
	aesenc	%xmm8, %xmm4
	aesenc	%xmm8, %xmm5
	aesenc	%xmm8, %xmm6
	aesenc	%xmm8, %xmm7
.LBB134_10:
	aesenclast	%xmm3, %xmm4
	aesenclast	%xmm3, %xmm5
	aesenclast	%xmm3, %xmm6
	aesenclast	%xmm3, %xmm7
	movdqu	(%rcx), %xmm8
	pxor	%xmm4, %xmm8
	movdqu	16(%rcx), %xmm4
	pxor	%xmm5, %xmm4
	movdqu	32(%rcx), %xmm5
	pxor	%xmm6, %xmm5
	movdqu	48(%rcx), %xmm6
	pxor	%xmm7, %xmm6
	movdqu	%xmm8, (%rcx)
	movdqu	%xmm4, 16(%rcx)
	movdqu	%xmm5, 32(%rcx)
	movdqu	%xmm6, 48(%rcx)
	addq	$64, %rcx
	incl	%r14d
	cmpq	%rax, %rcx
	je	.LBB134_11
.LBB134_5:
	leal	2(,%r14,4), %ebp
	bswapl	%ebp
	movd	%ebp, %xmm4
	pslldq	$12, %xmm4
	leal	3(,%r14,4), %ebp
	bswapl	%ebp
	movd	%ebp, %xmm5
	pslldq	$12, %xmm5
	leal	4(,%r14,4), %ebp
	bswapl	%ebp
	movd	%ebp, %xmm6
	pslldq	$12, %xmm6
	leal	5(,%r14,4), %ebp
	bswapl	%ebp
	movd	%ebp, %xmm7
	pslldq	$12, %xmm7
	pxor	%xmm2, %xmm4
	pxor	%xmm2, %xmm5
	pxor	%xmm2, %xmm6
	pxor	%xmm2, %xmm7
	movl	$1, %r15d
	cmpq	$2, %rsi
	je	.LBB134_9
	movq	%r11, %r12
	.p2align	4
.LBB134_7:
	movdqu	-16(%r12), %xmm8
	movdqu	(%r12), %xmm9
	aesenc	%xmm8, %xmm4
	aesenc	%xmm8, %xmm5
	aesenc	%xmm8, %xmm6
	aesenc	%xmm8, %xmm7
	aesenc	%xmm9, %xmm4
	aesenc	%xmm9, %xmm5
	aesenc	%xmm9, %xmm6
	aesenc	%xmm9, %xmm7
	addq	$32, %r12
	leaq	(%rbx,%r15), %r13
	addq	$2, %r13
	addq	$2, %r15
	cmpq	$1, %r13
	jne	.LBB134_7
	testb	$1, %r10b
	jne	.LBB134_9
	jmp	.LBB134_10
.LBB134_2:
	movl	$5, %r10d
	.p2align	4
.LBB134_3:
	leal	-3(%r10), %r11d
	bswapl	%r11d
	movd	%r11d, %xmm4
	pslldq	$12, %xmm4
	leal	-2(%r10), %r11d
	bswapl	%r11d
	movd	%r11d, %xmm5
	pslldq	$12, %xmm5
	leal	-1(%r10), %r11d
	bswapl	%r11d
	movd	%r11d, %xmm6
	pslldq	$12, %xmm6
	movl	%r10d, %r11d
	bswapl	%r11d
	movd	%r11d, %xmm7
	pslldq	$12, %xmm7
	pxor	%xmm2, %xmm4
	pxor	%xmm2, %xmm5
	pxor	%xmm2, %xmm6
	pxor	%xmm2, %xmm7
	aesenclast	%xmm3, %xmm4
	aesenclast	%xmm3, %xmm5
	aesenclast	%xmm3, %xmm6
	aesenclast	%xmm3, %xmm7
	movdqu	(%rcx), %xmm8
	pxor	%xmm4, %xmm8
	movdqu	16(%rcx), %xmm4
	pxor	%xmm5, %xmm4
	movdqu	32(%rcx), %xmm5
	pxor	%xmm6, %xmm5
	movdqu	48(%rcx), %xmm6
	pxor	%xmm7, %xmm6
	movdqu	%xmm8, (%rcx)
	movdqu	%xmm4, 16(%rcx)
	movdqu	%xmm5, 32(%rcx)
	movdqu	%xmm6, 48(%rcx)
	addl	$4, %r10d
	addq	$64, %rcx
	cmpq	%rax, %rcx
	jne	.LBB134_3
.LBB134_11:
	movdqa	%xmm1, -40(%rsp)
	testq	%r9, %r9
	je	.LBB134_26
	shrq	$4, %r8
	movabsq	$576460752303423484, %rcx
	andq	%r8, %rcx
	movq	%rsi, %r8
	shlq	$4, %r8
	movdqu	(%rdi,%r8), %xmm1
	cmpq	$1, %rsi
	jbe	.LBB134_13
	leaq	-1(%rsi), %r8
	addq	$-2, %rsi
	movl	%r8d, %r10d
	andl	$3, %r10d
	leaq	64(%rdi), %r11
	andq	$-4, %r8
	negq	%r8
	movl	%r10d, %ebx
	shll	$4, %ebx
	xorl	%r14d, %r14d
	jmp	.LBB134_15
	.p2align	4
.LBB134_25:
	addq	%r15, %rax
	incq	%r14
	subq	%r15, %r9
	je	.LBB134_26
.LBB134_15:
	movl	8(%rdx), %ebp
	movl	%ebp, -32(%rsp)
	movq	(%rdx), %r15
	movq	%r15, -40(%rsp)
	leal	(%r14,%rcx), %ebp
	addl	$2, %ebp
	bswapl	%ebp
	movl	%ebp, -28(%rsp)
	movdqa	-40(%rsp), %xmm2
	pxor	%xmm0, %xmm2
	movl	$1, %r15d
	cmpq	$3, %rsi
	jb	.LBB134_19
	movq	%r11, %r12
	.p2align	4
.LBB134_17:
	movdqu	-48(%r12), %xmm3
	aesenc	%xmm3, %xmm2
	movdqu	-32(%r12), %xmm3
	aesenc	%xmm3, %xmm2
	movdqu	-16(%r12), %xmm3
	aesenc	%xmm3, %xmm2
	movdqu	(%r12), %xmm3
	aesenc	%xmm3, %xmm2
	addq	$64, %r12
	leaq	(%r8,%r15), %r13
	addq	$4, %r13
	addq	$4, %r15
	cmpq	$1, %r13
	jne	.LBB134_17
	testq	%r10, %r10
	je	.LBB134_21
.LBB134_19:
	shlq	$4, %r15
	addq	%rdi, %r15
	xorl	%r12d, %r12d
	.p2align	4
.LBB134_20:
	movdqu	(%r15,%r12), %xmm3
	aesenc	%xmm3, %xmm2
	addq	$16, %r12
	cmpq	%r12, %rbx
	jne	.LBB134_20
.LBB134_21:
	aesenclast	%xmm1, %xmm2
	movdqa	%xmm2, -40(%rsp)
	cmpq	$16, %r9
	movl	$16, %r15d
	cmovbq	%r9, %r15
	jae	.LBB134_27
	xorl	%r12d, %r12d
	jmp	.LBB134_23
	.p2align	4
.LBB134_27:
	movl	%r15d, %r12d
	andl	$16, %r12d
	movdqu	(%rax), %xmm2
	pxor	-40(%rsp), %xmm2
	movdqu	%xmm2, (%rax)
	jmp	.LBB134_24
	.p2align	4
.LBB134_23:
	movzbl	-40(%rsp,%r12), %ebp
	xorb	%bpl, (%rax,%r12)
	incq	%r12
.LBB134_24:
	cmpq	%r12, %r15
	jne	.LBB134_23
	jmp	.LBB134_25
.LBB134_13:
	xorl	%esi, %esi
	jmp	.LBB134_29
	.p2align	4
.LBB134_28:
	addq	%rdi, %rax
	incq	%rsi
	subq	%rdi, %r9
	je	.LBB134_26
.LBB134_29:
	movl	8(%rdx), %edi
	movl	%edi, -32(%rsp)
	movq	(%rdx), %rdi
	movq	%rdi, -40(%rsp)
	leal	(%rsi,%rcx), %edi
	addl	$2, %edi
	bswapl	%edi
	movl	%edi, -28(%rsp)
	movdqa	-40(%rsp), %xmm2
	pxor	%xmm0, %xmm2
	aesenclast	%xmm1, %xmm2
	movdqa	%xmm2, -40(%rsp)
	cmpq	$16, %r9
	movl	$16, %edi
	cmovbq	%r9, %rdi
	jae	.LBB134_33
	xorl	%r8d, %r8d
	jmp	.LBB134_31
	.p2align	4
.LBB134_33:
	movl	%edi, %r8d
	andl	$16, %r8d
	movdqu	(%rax), %xmm2
	pxor	-40(%rsp), %xmm2
	movdqu	%xmm2, (%rax)
	jmp	.LBB134_32
	.p2align	4
.LBB134_31:
	movzbl	-40(%rsp,%r8), %r10d
	xorb	%r10b, (%rax,%r8)
	incq	%r8
.LBB134_32:
	cmpq	%r8, %rdi
	jne	.LBB134_31
	jmp	.LBB134_28
.LBB134_26:
	movb	$0, -40(%rsp)
	movb	$0, -39(%rsp)
	movb	$0, -38(%rsp)
	movb	$0, -37(%rsp)
	movb	$0, -36(%rsp)
	movb	$0, -35(%rsp)
	movb	$0, -34(%rsp)
	movb	$0, -33(%rsp)
	movb	$0, -32(%rsp)
	movb	$0, -31(%rsp)
	movb	$0, -30(%rsp)
	movb	$0, -29(%rsp)
	movb	$0, -28(%rsp)
	movb	$0, -27(%rsp)
	movb	$0, -26(%rsp)
	movb	$0, -25(%rsp)
	#MEMBARRIER
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end134:
	.size	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_643ctr, .Lfunc_end134-_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_643ctr
	.cfi_endproc

	.section	.text._RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_647subword,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_647subword,@function
_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_647subword:
	.cfi_startproc
	movd	(%rdi), %xmm0
	pshufd	$0, %xmm0, %xmm0
	pxor	%xmm1, %xmm1
	aesenclast	%xmm1, %xmm0
	movd	%xmm0, (%rdi)
	retq
.Lfunc_end135:
	.size	_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_647subword, .Lfunc_end135-_RNvNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_647subword
	.cfi_endproc

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI136_0:
	.quad	2
	.quad	0
	.quad	3
	.quad	0
.LCPI136_1:
	.long	1634760805
	.long	857760878
	.long	2036477234
	.long	1797285236
	.long	1634760805
	.long	857760878
	.long	2036477234
	.long	1797285236
.LCPI136_2:
	.byte	3
	.byte	0
	.byte	1
	.byte	2
	.byte	7
	.byte	4
	.byte	5
	.byte	6
	.byte	11
	.byte	8
	.byte	9
	.byte	10
	.byte	15
	.byte	12
	.byte	13
	.byte	14
	.byte	3
	.byte	0
	.byte	1
	.byte	2
	.byte	7
	.byte	4
	.byte	5
	.byte	6
	.byte	11
	.byte	8
	.byte	9
	.byte	10
	.byte	15
	.byte	12
	.byte	13
	.byte	14
.LCPI136_3:
	.byte	14
	.byte	15
	.byte	12
	.byte	13
	.byte	2
	.byte	3
	.byte	0
	.byte	1
	.byte	6
	.byte	7
	.byte	4
	.byte	5
	.byte	10
	.byte	11
	.byte	8
	.byte	9
	.byte	30
	.byte	31
	.byte	28
	.byte	29
	.byte	18
	.byte	19
	.byte	16
	.byte	17
	.byte	22
	.byte	23
	.byte	20
	.byte	21
	.byte	26
	.byte	27
	.byte	24
	.byte	25
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.LCPI136_4:
	.long	1634760805
	.long	857760878
	.long	2036477234
	.long	1797285236
	.section	.text._RNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx27batches,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx27batches,@function
_RNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx27batches:
	.cfi_startproc
	movq	(%rdx), %rdx
	movabsq	$9223372036854775552, %rax
	andq	%r8, %rax
	vbroadcasti128	(%rdi), %ymm4
	vbroadcasti128	16(%rdi), %ymm5
	leaq	(%rcx,%rax), %rdi
	vmovq	%rsi, %xmm0
	vmovdqa	%xmm0, -56(%rsp)
	incq	%rsi
	xorl	%r8d, %r8d
	vmovq	%rdx, %xmm0
	vpbroadcastq	%xmm0, %ymm0
	vmovdqu	%ymm0, -40(%rsp)
	vmovdqa	.LCPI136_2(%rip), %ymm6
	vmovdqa	.LCPI136_3(%rip), %ymm7
	vbroadcasti128	.LCPI136_4(%rip), %ymm8
	.p2align	4
.LBB136_1:
	leaq	(,%r8,4), %r9
	vmovq	%r9, %xmm0
	vmovdqu	-40(%rsp), %ymm2
	vpunpcklqdq	%xmm2, %xmm0, %xmm0
	vpaddq	-56(%rsp), %xmm0, %xmm0
	vinserti128	$1, %xmm0, %ymm0, %ymm1
	vpaddq	.LCPI136_0(%rip), %ymm1, %ymm9
	leaq	(%rsi,%r8,4), %r9
	vpinsrq	$1, %rdx, %xmm0, %xmm0
	vmovq	%r9, %xmm1
	vpbroadcastq	%xmm1, %ymm1
	vpblendd	$48, %ymm1, %ymm0, %ymm0
	vpblendd	$192, %ymm2, %ymm0, %ymm2
	movl	$10, %r9d
	vmovdqa	%ymm9, %ymm11
	vmovdqa	%ymm5, %ymm12
	vmovdqa	.LCPI136_1(%rip), %ymm13
	vmovdqa	%ymm13, %ymm15
	vmovdqa	%ymm4, %ymm0
	vmovdqa	%ymm5, %ymm1
	vmovdqa	%ymm2, %ymm10
	vmovdqa	%ymm4, %ymm14
	.p2align	4
.LBB136_2:
	vpaddd	%ymm0, %ymm15, %ymm15
	vpxor	%ymm15, %ymm10, %ymm10
	vpshuflw	$177, %ymm10, %ymm10
	vpshufhw	$177, %ymm10, %ymm10
	vpaddd	%ymm1, %ymm10, %ymm1
	vpxor	%ymm0, %ymm1, %ymm0
	vpsrld	$20, %ymm0, %ymm3
	vpslld	$12, %ymm0, %ymm0
	vpor	%ymm3, %ymm0, %ymm0
	vpaddd	%ymm0, %ymm15, %ymm3
	vpshufb	%ymm6, %ymm3, %ymm15
	vpshufb	%ymm6, %ymm10, %ymm10
	vpxor	%ymm15, %ymm10, %ymm10
	vpaddd	%ymm1, %ymm10, %ymm1
	vpxor	%ymm0, %ymm1, %ymm0
	vpsrld	$25, %ymm0, %ymm15
	vpslld	$7, %ymm0, %ymm0
	vpor	%ymm0, %ymm15, %ymm0
	vpaddd	%ymm14, %ymm13, %ymm13
	vpxor	%ymm13, %ymm11, %ymm11
	vpshuflw	$177, %ymm11, %ymm11
	vpshufhw	$177, %ymm11, %ymm11
	vpaddd	%ymm11, %ymm12, %ymm12
	vpxor	%ymm14, %ymm12, %ymm14
	vpsrld	$20, %ymm14, %ymm15
	vpslld	$12, %ymm14, %ymm14
	vpor	%ymm15, %ymm14, %ymm14
	vpaddd	%ymm13, %ymm14, %ymm13
	vpshufb	%ymm6, %ymm13, %ymm15
	vpshufb	%ymm6, %ymm11, %ymm11
	vpxor	%ymm15, %ymm11, %ymm11
	vpaddd	%ymm11, %ymm12, %ymm12
	vpxor	%ymm14, %ymm12, %ymm14
	vpsrld	$25, %ymm14, %ymm15
	vpslld	$7, %ymm14, %ymm14
	vpor	%ymm15, %ymm14, %ymm14
	vpshufd	$57, %ymm0, %ymm0
	vpshufd	$57, %ymm14, %ymm14
	vpshufd	$78, %ymm1, %ymm1
	vpshufd	$78, %ymm12, %ymm12
	vpaddd	%ymm3, %ymm0, %ymm3
	vpshuflw	$177, %ymm3, %ymm15
	vpshufhw	$177, %ymm15, %ymm15
	vpshufb	%ymm7, %ymm10, %ymm10
	vpxor	%ymm15, %ymm10, %ymm10
	vpaddd	%ymm1, %ymm10, %ymm1
	vpxor	%ymm0, %ymm1, %ymm0
	vpsrld	$20, %ymm0, %ymm15
	vpslld	$12, %ymm0, %ymm0
	vpor	%ymm0, %ymm15, %ymm0
	vpaddd	%ymm3, %ymm0, %ymm15
	vpxor	%ymm15, %ymm10, %ymm3
	vpshufb	%ymm6, %ymm3, %ymm3
	vpaddd	%ymm3, %ymm1, %ymm1
	vpxor	%ymm0, %ymm1, %ymm0
	vpsrld	$25, %ymm0, %ymm10
	vpslld	$7, %ymm0, %ymm0
	vpor	%ymm0, %ymm10, %ymm0
	vpaddd	%ymm13, %ymm14, %ymm10
	vpshuflw	$177, %ymm10, %ymm13
	vpshufhw	$177, %ymm13, %ymm13
	vpshufb	%ymm7, %ymm11, %ymm11
	vpxor	%ymm13, %ymm11, %ymm11
	vpaddd	%ymm11, %ymm12, %ymm12
	vpxor	%ymm14, %ymm12, %ymm13
	vpsrld	$20, %ymm13, %ymm14
	vpslld	$12, %ymm13, %ymm13
	vpor	%ymm14, %ymm13, %ymm14
	vpaddd	%ymm10, %ymm14, %ymm13
	vpxor	%ymm13, %ymm11, %ymm10
	vpshufb	%ymm6, %ymm10, %ymm11
	vpaddd	%ymm11, %ymm12, %ymm10
	vpxor	%ymm14, %ymm10, %ymm12
	vpsrld	$25, %ymm12, %ymm14
	vpslld	$7, %ymm12, %ymm12
	vpor	%ymm14, %ymm12, %ymm12
	vpshufd	$147, %ymm0, %ymm0
	vpshufd	$147, %ymm12, %ymm14
	vpshufd	$78, %ymm1, %ymm1
	vpshufd	$78, %ymm10, %ymm12
	vpshufd	$57, %ymm3, %ymm10
	vpshufd	$57, %ymm11, %ymm11
	decl	%r9d
	jne	.LBB136_2
	vpaddd	%ymm8, %ymm15, %ymm3
	vpxor	(%rcx), %xmm3, %xmm15
	vmovdqu	%xmm15, (%rcx)
	vpaddd	%ymm4, %ymm0, %ymm0
	vextracti128	$1, %ymm3, %xmm3
	vpxor	64(%rcx), %xmm3, %xmm3
	vpaddd	%ymm5, %ymm1, %ymm1
	vmovdqu	%xmm3, 64(%rcx)
	vpxor	16(%rcx), %xmm0, %xmm3
	vmovdqu	%xmm3, 16(%rcx)
	vextracti128	$1, %ymm0, %xmm0
	vpxor	80(%rcx), %xmm0, %xmm0
	vpaddd	%ymm2, %ymm10, %ymm2
	vmovdqu	%xmm0, 80(%rcx)
	vpxor	32(%rcx), %xmm1, %xmm0
	vmovdqu	%xmm0, 32(%rcx)
	vextracti128	$1, %ymm1, %xmm0
	vpxor	96(%rcx), %xmm0, %xmm0
	vmovdqu	%xmm0, 96(%rcx)
	vpxor	48(%rcx), %xmm2, %xmm0
	vmovdqu	%xmm0, 48(%rcx)
	vextracti128	$1, %ymm2, %xmm0
	vpxor	112(%rcx), %xmm0, %xmm0
	vmovdqu	%xmm0, 112(%rcx)
	vpaddd	%ymm8, %ymm13, %ymm0
	vpaddd	%ymm4, %ymm14, %ymm1
	vpxor	128(%rcx), %xmm0, %xmm2
	vmovdqu	%xmm2, 128(%rcx)
	vextracti128	$1, %ymm0, %xmm0
	vpxor	192(%rcx), %xmm0, %xmm0
	vpaddd	%ymm5, %ymm12, %ymm2
	vmovdqu	%xmm0, 192(%rcx)
	vpxor	144(%rcx), %xmm1, %xmm0
	vmovdqu	%xmm0, 144(%rcx)
	vextracti128	$1, %ymm1, %xmm0
	vpxor	208(%rcx), %xmm0, %xmm0
	vpaddd	%ymm9, %ymm11, %ymm1
	vmovdqu	%xmm0, 208(%rcx)
	vpxor	160(%rcx), %xmm2, %xmm0
	vmovdqu	%xmm0, 160(%rcx)
	vextracti128	$1, %ymm2, %xmm0
	vpxor	224(%rcx), %xmm0, %xmm0
	vmovdqu	%xmm0, 224(%rcx)
	vpxor	176(%rcx), %xmm1, %xmm0
	vmovdqu	%xmm0, 176(%rcx)
	vextracti128	$1, %ymm1, %xmm0
	vpxor	240(%rcx), %xmm0, %xmm0
	vmovdqu	%xmm0, 240(%rcx)
	addq	$256, %rcx
	incq	%r8
	cmpq	%rdi, %rcx
	jne	.LBB136_1
	vzeroupper
	retq
.Lfunc_end136:
	.size	_RNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx27batches, .Lfunc_end136-_RNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx27batches
	.cfi_endproc

	.section	.text._RNvNtNtNtCsgxBkk5gSRhY_4core9core_arch3x865xsave7__xgetbv,"ax",@progbits
	.p2align	4
	.type	_RNvNtNtNtCsgxBkk5gSRhY_4core9core_arch3x865xsave7__xgetbv,@function
_RNvNtNtNtCsgxBkk5gSRhY_4core9core_arch3x865xsave7__xgetbv:
	.cfi_startproc
	xorl	%ecx, %ecx
	xgetbv
	shlq	$32, %rdx
	orq	%rdx, %rax
	retq
.Lfunc_end137:
	.size	_RNvNtNtNtCsgxBkk5gSRhY_4core9core_arch3x865xsave7__xgetbv, .Lfunc_end137-_RNvNtNtNtCsgxBkk5gSRhY_4core9core_arch3x865xsave7__xgetbv
	.cfi_endproc

	.section	.text._RNvXNtCs1muTxUaRwMI_12toyos_crypto10field25519NtB2_1FNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,"ax",@progbits
	.globl	_RNvXNtCs1muTxUaRwMI_12toyos_crypto10field25519NtB2_1FNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.p2align	4
	.type	_RNvXNtCs1muTxUaRwMI_12toyos_crypto10field25519NtB2_1FNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,@function
_RNvXNtCs1muTxUaRwMI_12toyos_crypto10field25519NtB2_1FNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop:
	.cfi_startproc
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 32(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end138:
	.size	_RNvXNtCs1muTxUaRwMI_12toyos_crypto10field25519NtB2_1FNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop, .Lfunc_end138-_RNvXNtCs1muTxUaRwMI_12toyos_crypto10field25519NtB2_1FNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.cfi_endproc

	.section	.text._RNvXNtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,"ax",@progbits
	.globl	_RNvXNtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.p2align	4
	.type	_RNvXNtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,@function
_RNvXNtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop:
	.cfi_startproc
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end139:
	.size	_RNvXNtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop, .Lfunc_end139-_RNvXNtCs1muTxUaRwMI_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.cfi_endproc

	.section	.text._RNvXNtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,"ax",@progbits
	.globl	_RNvXNtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.p2align	4
	.type	_RNvXNtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,@function
_RNvXNtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop:
	.cfi_startproc
	xorl	%eax, %eax
	.p2align	4
.LBB140_1:
	movw	$0, (%rdi,%rax)
	movw	$0, 2(%rdi,%rax)
	movw	$0, 4(%rdi,%rax)
	movw	$0, 6(%rdi,%rax)
	movw	$0, 8(%rdi,%rax)
	movw	$0, 10(%rdi,%rax)
	movw	$0, 12(%rdi,%rax)
	movw	$0, 14(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB140_1
	#MEMBARRIER
	retq
.Lfunc_end140:
	.size	_RNvXNtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop, .Lfunc_end140-_RNvXNtCs1muTxUaRwMI_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.cfi_endproc

	.section	.text._RNvXNtCs1muTxUaRwMI_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,"ax",@progbits
	.globl	_RNvXNtCs1muTxUaRwMI_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.p2align	4
	.type	_RNvXNtCs1muTxUaRwMI_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,@function
_RNvXNtCs1muTxUaRwMI_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop:
	.cfi_startproc
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	movq	$0, 120(%rdi)
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	movq	$0, 144(%rdi)
	movq	$0, 152(%rdi)
	movq	$0, 160(%rdi)
	movq	$0, 168(%rdi)
	movq	$0, 176(%rdi)
	movq	$0, 184(%rdi)
	movq	$0, 192(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end141:
	.size	_RNvXNtCs1muTxUaRwMI_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop, .Lfunc_end141-_RNvXNtCs1muTxUaRwMI_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.cfi_endproc

	.section	.text._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt,"ax",@progbits
	.p2align	4
	.type	_RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt,@function
_RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt:
	.cfi_startproc
	movq	%rsi, %rax
	movzbl	(%rdi), %ecx
	leaq	.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt(%rip), %rdx
	movq	(%rdx,%rcx,8), %rdx
	leaq	.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel(%rip), %rdi
	movslq	(%rdi,%rcx,4), %rsi
	addq	%rdi, %rsi
	movq	%rax, %rdi
	jmpq	*_RNvMsa_NtCsgxBkk5gSRhY_4core3fmtNtB5_9Formatter9write_str@GOTPCREL(%rip)
.Lfunc_end142:
	.size	_RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt, .Lfunc_end142-_RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt
	.cfi_endproc

	.section	.text._RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into,"ax",@progbits
	.globl	_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into
	.p2align	4
	.type	_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into,@function
_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into:
	.cfi_startproc
	cmpq	$32, %rdx
	jne	.LBB143_2
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$160, %rsp
	.cfi_def_cfa_offset 176
	.cfi_offset %rbx, -16
	movq	%rsi, %rbx
	movaps	112(%rdi), %xmm0
	movaps	%xmm0, 144(%rsp)
	movaps	96(%rdi), %xmm0
	movaps	%xmm0, 128(%rsp)
	movaps	80(%rdi), %xmm0
	movaps	%xmm0, 112(%rsp)
	movaps	64(%rdi), %xmm0
	movaps	%xmm0, 96(%rsp)
	movaps	(%rdi), %xmm0
	movaps	16(%rdi), %xmm1
	movaps	32(%rdi), %xmm2
	movaps	48(%rdi), %xmm3
	movaps	%xmm3, 80(%rsp)
	movaps	%xmm2, 64(%rsp)
	movaps	%xmm1, 48(%rsp)
	movaps	%xmm0, 32(%rsp)
	movq	%rsp, %rdi
	leaq	32(%rsp), %rsi
	callq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2568finalize@GOTPCREL(%rip)
	movups	(%rsp), %xmm0
	movups	16(%rsp), %xmm1
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	#MEMBARRIER
	movb	$-1, %al
	addq	$160, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	.cfi_restore %rbx
	retq
.LBB143_2:
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	movb	$0, 32(%rdi)
	movb	$0, 33(%rdi)
	movb	$0, 34(%rdi)
	movb	$0, 35(%rdi)
	movb	$0, 36(%rdi)
	movb	$0, 37(%rdi)
	movb	$0, 38(%rdi)
	movb	$0, 39(%rdi)
	movb	$0, 40(%rdi)
	movb	$0, 41(%rdi)
	movb	$0, 42(%rdi)
	movb	$0, 43(%rdi)
	movb	$0, 44(%rdi)
	movb	$0, 45(%rdi)
	movb	$0, 46(%rdi)
	movb	$0, 47(%rdi)
	movb	$0, 48(%rdi)
	movb	$0, 49(%rdi)
	movb	$0, 50(%rdi)
	movb	$0, 51(%rdi)
	movb	$0, 52(%rdi)
	movb	$0, 53(%rdi)
	movb	$0, 54(%rdi)
	movb	$0, 55(%rdi)
	movb	$0, 56(%rdi)
	movb	$0, 57(%rdi)
	movb	$0, 58(%rdi)
	movb	$0, 59(%rdi)
	movb	$0, 60(%rdi)
	movb	$0, 61(%rdi)
	movb	$0, 62(%rdi)
	movb	$0, 63(%rdi)
	#MEMBARRIER
	movl	$0, 64(%rdi)
	movl	$0, 68(%rdi)
	movl	$0, 72(%rdi)
	movl	$0, 76(%rdi)
	movl	$0, 80(%rdi)
	movl	$0, 84(%rdi)
	movl	$0, 88(%rdi)
	movl	$0, 92(%rdi)
	#MEMBARRIER
	xorl	%eax, %eax
	retq
.Lfunc_end143:
	.size	_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into, .Lfunc_end143-_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into
	.cfi_endproc

	.section	.text._RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update,"ax",@progbits
	.globl	_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update
	.p2align	4
	.type	_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update,@function
_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update:
	.cfi_startproc
	jmpq	*_RNvMNtCs1muTxUaRwMI_12toyos_crypto4hashNtB2_6Sha2566update@GOTPCREL(%rip)
.Lfunc_end144:
	.size	_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update, .Lfunc_end144-_RNvXs1_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update
	.cfi_endproc

	.section	.text._RNvXs1g_NtCsgxBkk5gSRhY_4core3fmtRoNtB6_5Debug3fmtCs1muTxUaRwMI_12toyos_crypto,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCsgxBkk5gSRhY_4core3fmtRoNtB6_5Debug3fmtCs1muTxUaRwMI_12toyos_crypto,@function
_RNvXs1g_NtCsgxBkk5gSRhY_4core3fmtRoNtB6_5Debug3fmtCs1muTxUaRwMI_12toyos_crypto:
	.cfi_startproc
	movq	(%rdi), %rdi
	movl	16(%rsi), %eax
	testl	$33554432, %eax
	jne	.LBB145_3
	testl	$67108864, %eax
	jne	.LBB145_2
	jmpq	*_RNvXNtNtCsgxBkk5gSRhY_4core3fmt3numoNtB4_7Display3fmt@GOTPCREL(%rip)
.LBB145_3:
	jmpq	*_RNvXsK_NtNtCsgxBkk5gSRhY_4core3fmt3numoNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB145_2:
	jmpq	*_RNvXsM_NtNtCsgxBkk5gSRhY_4core3fmt3numoNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Lfunc_end145:
	.size	_RNvXs1g_NtCsgxBkk5gSRhY_4core3fmtRoNtB6_5Debug3fmtCs1muTxUaRwMI_12toyos_crypto, .Lfunc_end145-_RNvXs1g_NtCsgxBkk5gSRhY_4core3fmtRoNtB6_5Debug3fmtCs1muTxUaRwMI_12toyos_crypto
	.cfi_endproc

	.section	.text._RNvXs2_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,"ax",@progbits
	.globl	_RNvXs2_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.p2align	4
	.type	_RNvXs2_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,@function
_RNvXs2_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop:
	.cfi_startproc
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	movb	$0, 32(%rdi)
	movb	$0, 33(%rdi)
	movb	$0, 34(%rdi)
	movb	$0, 35(%rdi)
	movb	$0, 36(%rdi)
	movb	$0, 37(%rdi)
	movb	$0, 38(%rdi)
	movb	$0, 39(%rdi)
	movb	$0, 40(%rdi)
	movb	$0, 41(%rdi)
	movb	$0, 42(%rdi)
	movb	$0, 43(%rdi)
	movb	$0, 44(%rdi)
	movb	$0, 45(%rdi)
	movb	$0, 46(%rdi)
	movb	$0, 47(%rdi)
	movb	$0, 48(%rdi)
	movb	$0, 49(%rdi)
	movb	$0, 50(%rdi)
	movb	$0, 51(%rdi)
	movb	$0, 52(%rdi)
	movb	$0, 53(%rdi)
	movb	$0, 54(%rdi)
	movb	$0, 55(%rdi)
	movb	$0, 56(%rdi)
	movb	$0, 57(%rdi)
	movb	$0, 58(%rdi)
	movb	$0, 59(%rdi)
	movb	$0, 60(%rdi)
	movb	$0, 61(%rdi)
	movb	$0, 62(%rdi)
	movb	$0, 63(%rdi)
	#MEMBARRIER
	movl	$0, 64(%rdi)
	movl	$0, 68(%rdi)
	movl	$0, 72(%rdi)
	movl	$0, 76(%rdi)
	movl	$0, 80(%rdi)
	movl	$0, 84(%rdi)
	movl	$0, 88(%rdi)
	movl	$0, 92(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end146:
	.size	_RNvXs2_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop, .Lfunc_end146-_RNvXs2_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.cfi_endproc

	.section	.text._RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into,"ax",@progbits
	.globl	_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into
	.p2align	4
	.type	_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into,@function
_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$280, %rsp
	.cfi_def_cfa_offset 304
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %rsi
	cmpq	$48, %rdx
	jne	.LBB147_2
	leaq	48(%rsp), %r14
	movl	$224, %edx
	movq	%r14, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rsp, %rdi
	movq	%r14, %rsi
	callq	*_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3848finalize@GOTPCREL(%rip)
	movups	(%rsp), %xmm0
	movups	16(%rsp), %xmm1
	movups	32(%rsp), %xmm2
	movups	%xmm2, 32(%rbx)
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	#MEMBARRIER
	movb	$-1, %al
	addq	$280, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB147_2:
	.cfi_def_cfa_offset 304
	xorl	%eax, %eax
	.p2align	4
.LBB147_3:
	movb	$0, (%rsi,%rax)
	movb	$0, 1(%rsi,%rax)
	movb	$0, 2(%rsi,%rax)
	movb	$0, 3(%rsi,%rax)
	movb	$0, 4(%rsi,%rax)
	movb	$0, 5(%rsi,%rax)
	movb	$0, 6(%rsi,%rax)
	movb	$0, 7(%rsi,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB147_3
	#MEMBARRIER
	movq	$0, 128(%rsi)
	movq	$0, 136(%rsi)
	movq	$0, 144(%rsi)
	movq	$0, 152(%rsi)
	movq	$0, 160(%rsi)
	movq	$0, 168(%rsi)
	movq	$0, 176(%rsi)
	movq	$0, 184(%rsi)
	#MEMBARRIER
	xorl	%eax, %eax
	addq	$280, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end147:
	.size	_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into, .Lfunc_end147-_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into
	.cfi_endproc

	.section	.text._RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update,"ax",@progbits
	.globl	_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update
	.p2align	4
	.type	_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update,@function
_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update:
	.cfi_startproc
	jmpq	*_RNvMs3_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha3846update@GOTPCREL(%rip)
.Lfunc_end148:
	.size	_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update, .Lfunc_end148-_RNvXs6_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update
	.cfi_endproc

	.section	.text._RNvXs7_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,"ax",@progbits
	.globl	_RNvXs7_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.p2align	4
	.type	_RNvXs7_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,@function
_RNvXs7_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop:
	.cfi_startproc
	xorl	%eax, %eax
	.p2align	4
.LBB149_1:
	movb	$0, (%rdi,%rax)
	movb	$0, 1(%rdi,%rax)
	movb	$0, 2(%rdi,%rax)
	movb	$0, 3(%rdi,%rax)
	movb	$0, 4(%rdi,%rax)
	movb	$0, 5(%rdi,%rax)
	movb	$0, 6(%rdi,%rax)
	movb	$0, 7(%rdi,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB149_1
	#MEMBARRIER
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	movq	$0, 144(%rdi)
	movq	$0, 152(%rdi)
	movq	$0, 160(%rdi)
	movq	$0, 168(%rdi)
	movq	$0, 176(%rdi)
	movq	$0, 184(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end149:
	.size	_RNvXs7_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop, .Lfunc_end149-_RNvXs7_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.cfi_endproc

	.section	.text._RNvXs_NtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,"ax",@progbits
	.globl	_RNvXs_NtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.p2align	4
	.type	_RNvXs_NtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,@function
_RNvXs_NtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop:
	.cfi_startproc
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	#MEMBARRIER
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	#MEMBARRIER
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	#MEMBARRIER
	retq
.Lfunc_end150:
	.size	_RNvXs_NtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop, .Lfunc_end150-_RNvXs_NtCs1muTxUaRwMI_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.cfi_endproc

	.section	.text._RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into,"ax",@progbits
	.globl	_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into
	.p2align	4
	.type	_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into,@function
_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$296, %rsp
	.cfi_def_cfa_offset 320
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rbx
	movq	%rdi, %rsi
	cmpq	$64, %rdx
	jne	.LBB151_2
	leaq	64(%rsp), %r14
	movl	$224, %edx
	movq	%r14, %rdi
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rsp, %rdi
	movq	%r14, %rsi
	callq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5128finalize@GOTPCREL(%rip)
	movups	(%rsp), %xmm0
	movups	16(%rsp), %xmm1
	movups	32(%rsp), %xmm2
	movups	48(%rsp), %xmm3
	movups	%xmm3, 48(%rbx)
	movups	%xmm2, 32(%rbx)
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	movb	$-1, %al
	addq	$296, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB151_2:
	.cfi_def_cfa_offset 320
	xorl	%eax, %eax
	.p2align	4
.LBB151_3:
	movb	$0, (%rsi,%rax)
	movb	$0, 1(%rsi,%rax)
	movb	$0, 2(%rsi,%rax)
	movb	$0, 3(%rsi,%rax)
	movb	$0, 4(%rsi,%rax)
	movb	$0, 5(%rsi,%rax)
	movb	$0, 6(%rsi,%rax)
	movb	$0, 7(%rsi,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB151_3
	#MEMBARRIER
	movq	$0, 128(%rsi)
	movq	$0, 136(%rsi)
	movq	$0, 144(%rsi)
	movq	$0, 152(%rsi)
	movq	$0, 160(%rsi)
	movq	$0, 168(%rsi)
	movq	$0, 176(%rsi)
	movq	$0, 184(%rsi)
	#MEMBARRIER
	xorl	%eax, %eax
	addq	$296, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end151:
	.size	_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into, .Lfunc_end151-_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into
	.cfi_endproc

	.section	.text._RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update,"ax",@progbits
	.globl	_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update
	.p2align	4
	.type	_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update,@function
_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update:
	.cfi_startproc
	jmpq	*_RNvMs8_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha5126update@GOTPCREL(%rip)
.Lfunc_end152:
	.size	_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update, .Lfunc_end152-_RNvXsb_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update
	.cfi_endproc

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.0,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.65f595193a40e4134698b8f1074b12b6.0:
	.asciz	"src/nist.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.0, 12

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.1,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.1,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCsgxBkk5gSRhY_4core3fmtRoNtB6_5Debug3fmtCs1muTxUaRwMI_12toyos_crypto
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.1, 32

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.2,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.65f595193a40e4134698b8f1074b12b6.2:
	.asciz	"src/montgomery.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.2, 18

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.3,@object
.Lanon.65f595193a40e4134698b8f1074b12b6.3:
	.asciz	"src/mlkem.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.3, 13

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.4,@object
.Lanon.65f595193a40e4134698b8f1074b12b6.4:
	.asciz	"src/keccak.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.4, 14

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.5,@object
.Lanon.65f595193a40e4134698b8f1074b12b6.5:
	.asciz	"src/aes.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.5, 11

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.6,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.6,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.6:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.5
	.asciz	"\n\000\000\000\000\000\000\000l\000\000\000\"\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.6, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.7,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.7,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.7:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.5
	.asciz	"\n\000\000\000\000\000\000\000J\000\000\000\021\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.7, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.8,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.65f595193a40e4134698b8f1074b12b6.8:
	.asciz	"src/rsa.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.8, 11

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.9,@object
.Lanon.65f595193a40e4134698b8f1074b12b6.9:
	.asciz	"src/ssh.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.9, 11

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.10,@object
.Lanon.65f595193a40e4134698b8f1074b12b6.10:
	.asciz	"src/hash.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.10, 12

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.11,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.11,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.11:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.10
	.asciz	"\013\000\000\000\000\000\000\000-\001\000\000\001\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.11, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.12,@object
	.section	.rodata.cst32,"aM",@progbits,32
.Lanon.65f595193a40e4134698b8f1074b12b6.12:
	.ascii	"\243xY\023\312M\353u\253\330AAM\np\000\230\350ywy@\307\214s\376o+\356l\003R"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.12, 32

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.13,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.65f595193a40e4134698b8f1074b12b6.13:
	.asciz	"src/ed25519.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.13, 15

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.14,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.14,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.14:
	.ascii	"Ed25519 base point"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.14, 18

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.15,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.15,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.15:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.13
	.asciz	"\016\000\000\000\000\000\000\000$\000\000\000\032\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.15, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.16,@object
	.section	.rodata.cst32,"aM",@progbits,32
.Lanon.65f595193a40e4134698b8f1074b12b6.16:
	.ascii	"\260\240\016J'\033\356\304x\344/\255\006\030C/\247\327\373=\231\000M+\013\337\301O\200$\203+"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.16, 32

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.17,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.65f595193a40e4134698b8f1074b12b6.17:
	.asciz	"src/poly1305.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.17, 16

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.18,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	4, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.18:
	.zero	16
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.18, 16

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.19,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.19,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.19:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.17
	.asciz	"\017\000\000\000\000\000\000\000W\000\000\000!\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.19, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.20,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.20,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.20:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.17
	.asciz	"\017\000\000\000\000\000\000\000\\\000\000\000\r\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.20, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.21,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.21,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.21:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.17
	.asciz	"\017\000\000\000\000\000\000\000]\000\000\000\030\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.21, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.22,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.22,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.22:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.17
	.asciz	"\017\000\000\000\000\000\000\000P\000\000\000\030\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.22, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.23,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.23,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.23:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.17
	.asciz	"\017\000\000\000\000\000\000\000A\000\000\000\030\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.23, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.24,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.24,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.24:
	.ascii	"called `Result::unwrap()` on an `Err` value"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.24, 43

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.25,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.25,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.25:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.quad	_RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.25, 32

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.26,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.26,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.26:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.2
	.asciz	"\021\000\000\000\000\000\000\000\200\000\000\000\r\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.26, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.27,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.27,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.27:
	.ascii	"assertion failed: matches!(N, 4 | 6) && p[0] & 1 == 1 && p[N - 1] >> 63 == 1"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.27, 76

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.28,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.28,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.28:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.2
	.asciz	"\021\000\000\000\000\000\000\000$\000\000\000\t\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.28, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.29,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.29,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.29:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.9
	.asciz	"\n\000\000\000\000\000\000\000Q\000\000\000\n\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.29, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.30,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.30,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.30:
	.ascii	"nonzero prime-order scalar"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.30, 26

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.31,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.65f595193a40e4134698b8f1074b12b6.31:
	.asciz	"src/ecc.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.31, 11

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.32,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.32,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.32:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.31
	.asciz	"\n\000\000\000\000\000\000\000a\000\000\000\001\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.32, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.33,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.33,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.33:
	.ascii	"curve arithmetic invariant"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.33, 26

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.34,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.34,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.34:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.31
	.asciz	"\n\000\000\000\000\000\000\000b\000\000\000\001\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.34, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.35,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.35,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.35:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.10
	.asciz	"\013\000\000\000\000\000\000\0009\001\000\000\001\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.35, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.36,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.36,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.36:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.10
	.asciz	"\013\000\000\000\000\000\000\000K\001\000\000\001\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.36, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.37,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.37,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.37:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\347\000\000\000.\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.37, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.38,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lanon.65f595193a40e4134698b8f1074b12b6.38:
	.zero	8
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.38, 8

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.39,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.39,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.39:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\364\000\000\000F\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.39, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.40,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.40,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.40:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\360\000\000\000\016\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.40, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.41,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.41,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.41:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\353\000\000\000\032\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.41, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.42,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.42,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.42:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\347\000\000\000\013\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.42, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.43,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.43,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.43:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\345\000\000\000\031\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.43, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.44,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.44,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.44:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\330\000\000\000\023\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.44, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.45,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.45,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.45:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000b\000\000\000$\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.45, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.46,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.46,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.46:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\310\000\000\000\027\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.46, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.47,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.47,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.47:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\312\000\000\000\020\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.47, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.48,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.48,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.48:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\313\000\000\000\027\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.48, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.49,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.49,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.49:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\311\000\000\000\027\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.49, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.50,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.50,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.50:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\270\000\000\000\037\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.50, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.51,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.51,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.51:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\224\000\000\000\017\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.51, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.52,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.52,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.52:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\205\000\000\000\025\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.52, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.53,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.53,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.53:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\221\000\000\000\r\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.53, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.54,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.54,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.54:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\210\000\000\0004\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.54, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.55,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.55,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.55:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\210\000\000\000R\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.55, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.56,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.56,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.56:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\202\000\000\000\r\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.56, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.57,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.57,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.57:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000~\000\000\000$\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.57, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.58,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.58,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.58:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000~\000\000\0007\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.58, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.59,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.59,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.59:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000r\000\000\0000\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.59, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.60,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.60,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.60:
	.ascii	"validated prime-order point and nonzero scalar"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.60, 46

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.61,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.61,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.61:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.0
	.asciz	"\013\000\000\000\000\000\000\000\256\000\000\000\016\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.61, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.62,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.62,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.62:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.3
	.asciz	"\f\000\000\000\000\000\000\000<\000\000\000$\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.62, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.63,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.63,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.63:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.3
	.asciz	"\f\000\000\000\000\000\000\000o\000\000\000\t\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.63, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.64,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.64,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.64:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.3
	.asciz	"\f\000\000\000\000\000\000\000t\000\000\000\021\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.64, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.65,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.65,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.65:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.3
	.asciz	"\f\000\000\000\000\000\000\000M\000\000\000\035\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.65, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.66,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.66,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.66:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.3
	.asciz	"\f\000\000\000\000\000\000\000N\000\000\000(\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.66, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.67,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.67,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.67:
	.ascii	"assertion failed: [72, 136, 168].contains(&rate)"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.67, 48

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.68,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.68,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.68:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.4
	.asciz	"\r\000\000\000\000\000\000\000.\000\000\000\t\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.68, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.69,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.69,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.69:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.4
	.asciz	"\r\000\000\000\000\000\000\0006\000\000\000\021\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.69, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.70,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.70,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.70:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.4
	.asciz	"\r\000\000\000\000\000\000\000>\000\000\000\t\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.70, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.71,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.71,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.71:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.4
	.asciz	"\r\000\000\000\000\000\000\000h\000\000\000\026\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.71, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.72,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.72,"a",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.72:
	.ascii	"\001\000\000\000\000\000\000\000\202\200\000\000\000\000\000\000\212\200\000\000\000\000\000\200\000\200\000\200\000\000\000\200\213\200\000\000\000\000\000\000\001\000\000\200\000\000\000\000\201\200\000\200\000\000\000\200\t\200\000\000\000\000\000\200\212\000\000\000\000\000\000\000\210\000\000\000\000\000\000\000\t\200\000\200\000\000\000\000\n\000\000\200\000\000\000\000\213\200\000\200\000\000\000\000\213\000\000\000\000\000\000\200\211\200\000\000\000\000\000\200\003\200\000\000\000\000\000\200\002\200\000\000\000\000\000\200\200\000\000\000\000\000\000\200\n\200\000\000\000\000\000\000\n\000\000\200\000\000\000\200\201\200\000\200\000\000\000\200\200\200\000\000\000\000\000\200\001\000\000\200\000\000\000\000\b\200\000\200\000\000\000\200"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.72, 192

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.73,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.73,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.73:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.8
	.asciz	"\n\000\000\000\000\000\000\000\376\000\000\000\t\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.73, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.74,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.74,"a",@progbits
	.p2align	2, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.74:
	.ascii	"\230/\212B\221D7q\317\373\300\265\245\333\265\351[\302V9\361\021\361Y\244\202?\222\325^\034\253\230\252\007\330\001[\203\022\276\2051$\303}\fUt]\276r\376\261\336\200\247\006\334\233t\361\233\301\301i\233\344\206G\276\357\306\235\301\017\314\241\f$o,\351-\252\204tJ\334\251\260\\\332\210\371vRQ>\230m\3061\250\310'\003\260\307\177Y\277\363\013\340\306G\221\247\325Qc\312\006g))\024\205\n\267'8!\033.\374m,M\023\r8STs\ne\273\njv.\311\302\201\205,r\222\241\350\277\242Kf\032\250p\213K\302\243Ql\307\031\350\222\321$\006\231\326\2055\016\364p\240j\020\026\301\244\031\bl7\036LwH'\265\274\2604\263\f\0349J\252\330NO\312\234[\363o.h\356\202\217toc\245x\024x\310\204\b\002\307\214\372\377\276\220\353lP\244\367\243\371\276\362xq\306"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.74, 256

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.75,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.75,"a",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.75:
	.ascii	"\"\256(\327\230/\212B\315e\357#\221D7q/;M\354\317\373\300\265\274\333\211\201\245\333\265\3518\265H\363[\302V9\031\320\005\266\361\021\361Y\233O\031\257\244\202?\222\030\201m\332\325^\034\253B\002\003\243\230\252\007\330\276opE\001[\203\022\214\262\344N\276\2051$\342\264\377\325\303}\fUo\211{\362t]\276r\261\226\026;\376\261\336\2005\022\307%\247\006\334\233\224&i\317t\361\233\301\322J\361\236\301i\233\344\343%O8\206G\276\357\265\325\214\213\306\235\301\017e\234\254w\314\241\f$u\002+Yo,\351-\203\344\246n\252\204tJ\324\373A\275\334\251\260\\\265S\021\203\332\210\371v\253\337f\356RQ>\230\0202\264-m\3061\250?!\373\230\310'\003\260\344\016\357\276\307\177Y\277\302\217\250=\363\013\340\306%\247\n\223G\221\247\325o\202\003\340Qc\312\006pn\016\ng))\024\374/\322F\205\n\267'&\311&\\8!\033.\355*\304Z\374m,M\337\263\225\235\023\r8S\336c\257\213Ts\ne\250\262w<\273\njv\346\256\355G.\311\302\201;5\202\024\205,r\222d\003\361L\241\350\277\242\0010B\274Kf\032\250\221\227\370\320p\213K\3020\276T\006\243Ql\307\030R\357\326\031\350\222\321\020\251eU$\006\231\326* qW\2055\016\364\270\321\2732p\240j\020\310\320\322\270\026\301\244\031S\253AQ\bl7\036\231\353\216\337LwH'\250H\233\341\265\274\2604cZ\311\305\263\f\0349\313\212A\343J\252\330Ns\343cwO\312\234[\243\270\262\326\363o.h\374\262\357]\356\202\217t`/\027Coc\245xr\253\360\241\024x\310\204\3549d\032\b\002\307\214(\036c#\372\377\276\220\351\275\202\336\353lP\244\025y\306\262\367\243\371\276+Sr\343\362xq\306\234a&\352\316>'\312\007\302\300!\307\270\206\321\036\353\340\315\326}\332\352x\321n\356\177O}\365\272o\027r\252g\360\006\246\230\310\242\305}c\n\256\r\371\276\004\230?\021\033G\034\0235\013q\033\204}\004#\365w\333(\223$\307@{\253\3122\274\276\311\025\n\276\236<L\r\020\234\304g\035C\266B>\313\276\324\305L*~e\374\234)\177Y\354\372\326:\253o\313_\027XGJ\214\031Dl"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.75, 640

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.76,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.65f595193a40e4134698b8f1074b12b6.76:
	.asciz	"src/chacha.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.76, 14

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.77,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.77,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.77:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.76
	.asciz	"\r\000\000\000\000\000\000\000f\000\000\000\033\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.77, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.78,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.78,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.78:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.76
	.asciz	"\r\000\000\000\000\000\000\000P\000\000\000\033\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.78, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.79,@object
	.section	.rodata.cst16,"aM",@progbits,16
	.p2align	2, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.79:
	.ascii	"expand 32-byte k"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.79, 16

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.80,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.80,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.80:
	.ascii	"fixed-size shared secret"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.80, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.81,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.65f595193a40e4134698b8f1074b12b6.81:
	.asciz	"src/hybrid.rs"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.81, 14

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.82,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.82,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.82:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.81
	.asciz	"\r\000\000\000\000\000\000\000\035\000\000\000\n\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.82, 24

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.83,@object
	.section	.data.rel.ro..Lanon.65f595193a40e4134698b8f1074b12b6.83,"aw",@progbits
	.p2align	3, 0x0
.Lanon.65f595193a40e4134698b8f1074b12b6.83:
	.quad	.Lanon.65f595193a40e4134698b8f1074b12b6.81
	.asciz	"\r\000\000\000\000\000\000\000\037\000\000\000\n\000\000"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.83, 24

	.type	_RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0,@object
	.section	.bss._RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0,"aw",@nobits
_RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0:
	.byte	0
	.size	_RNvNvNtNtNtCs1muTxUaRwMI_12toyos_crypto4arch6x86_644avx29available8ADMITTED.0, 1

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.84,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.84,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.84:
	.ascii	"Length"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.84, 6

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.85,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.85,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.85:
	.ascii	"Authentication"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.85, 14

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.86,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.86,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.86:
	.ascii	"InvalidKey"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.86, 10

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.87,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.87,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.87:
	.ascii	"InvalidPoint"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.87, 12

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.88,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.88,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.88:
	.ascii	"InvalidEncoding"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.88, 15

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.89,@object
	.section	.rodata.cst16,"aM",@progbits,16
.Lanon.65f595193a40e4134698b8f1074b12b6.89:
	.ascii	"InvalidSignature"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.89, 16

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.90,@object
.Lanon.65f595193a40e4134698b8f1074b12b6.90:
	.ascii	"CounterExhausted"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.90, 16

	.type	.Lanon.65f595193a40e4134698b8f1074b12b6.91,@object
	.section	.rodata..Lanon.65f595193a40e4134698b8f1074b12b6.91,"a",@progbits
.Lanon.65f595193a40e4134698b8f1074b12b6.91:
	.ascii	"Entropy"
	.size	.Lanon.65f595193a40e4134698b8f1074b12b6.91, 7

	.type	.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt,@object
	.section	.rodata..Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt,"a",@progbits
	.p2align	3, 0x0
.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt:
	.quad	6
	.quad	14
	.quad	10
	.quad	12
	.quad	15
	.quad	16
	.quad	16
	.quad	7
	.size	.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt, 64

	.type	.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel,@object
	.section	.rodata..Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel,"a",@progbits
	.p2align	2, 0x0
.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel:
	.long	.Lanon.65f595193a40e4134698b8f1074b12b6.84-.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel
	.long	.Lanon.65f595193a40e4134698b8f1074b12b6.85-.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel
	.long	.Lanon.65f595193a40e4134698b8f1074b12b6.86-.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel
	.long	.Lanon.65f595193a40e4134698b8f1074b12b6.87-.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel
	.long	.Lanon.65f595193a40e4134698b8f1074b12b6.88-.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel
	.long	.Lanon.65f595193a40e4134698b8f1074b12b6.89-.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel
	.long	.Lanon.65f595193a40e4134698b8f1074b12b6.90-.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel
	.long	.Lanon.65f595193a40e4134698b8f1074b12b6.91-.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel
	.size	.Lswitch.table._RNvXs1_Cs1muTxUaRwMI_12toyos_cryptoNtB5_5ErrorNtNtCsgxBkk5gSRhY_4core3fmt5Debug3fmt.127.rel, 32

	.globl	_RNvXsc_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.type	_RNvXsc_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop,@function
_RNvXsc_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha512NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop = _RNvXs7_NtCs1muTxUaRwMI_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsgxBkk5gSRhY_4core3ops4drop4Drop4drop
	.hidden	DW.ref.rust_eh_personality
	.weak	DW.ref.rust_eh_personality
	.section	.data.DW.ref.rust_eh_personality,"awG",@progbits,DW.ref.rust_eh_personality,comdat
	.p2align	3, 0x0
	.type	DW.ref.rust_eh_personality,@object
	.size	DW.ref.rust_eh_personality, 8
DW.ref.rust_eh_personality:
	.quad	rust_eh_personality
	.ident	"rustc version 1.98.1 (48a229cea 2026-09-01)"
	.section	".note.GNU-stack","",@progbits
