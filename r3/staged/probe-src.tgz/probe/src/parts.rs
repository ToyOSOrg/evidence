//! p256 additions (scratch): toyos-crypto's P-256 parts alone (field
//! operations, point formulas, table reads, the multiplications and
//! inversions), each a dependent chain through the crate's scratch-only
//! `p256_parts` hook, so a row is read without the rest; and the core clock,
//! from a chain of dependent adds (one cycle each on Zen 2 and Tiger Lake),
//! to read ns as cycles.

use crate::keep;
use crate::sampler::Row;

pub fn rows(rows: &mut Vec<Row>) {
    for (name, part) in toyos_crypto::p256_parts::PARTS {
        let ours = move || -> crate::sampler::Op { Box::new(move |n| keep(part(n))) };
        rows.push(Row { name: format!("p-256-parts/{name}"), run: [Some(ours()), Some(ours()), None, None, None] });
    }
}

pub fn clock() -> f64 {
    let mut best = f64::MAX;
    for _ in 0..5 {
        let start = std::time::Instant::now();
        let mut x = 0u64;
        unsafe {
            core::arch::asm!(
                "2:",
                ".rept 64", "add {x}, 1", ".endr",
                "dec {n}", "jnz 2b",
                x = inout(reg) x, n = inout(reg) (1u64 << 22) => _,
                options(nomem, nostack)
            );
        }
        keep(x);
        best = best.min(start.elapsed().as_nanos() as f64 / (64.0 * (1u64 << 22) as f64));
    }
    best
}
