
/// Scratch: the probe's P-256 parts, each run n times on a dependent chain,
/// at main (per-operation dispatch). Never lands.
#[doc(hidden)]
pub mod parts {
    use super::*;
    use core::hint::black_box;
    pub type Part = (&'static str, fn(u64) -> u64);
    type F = P256Field;
    fn k() -> Scalar<P256, 4> {
        Scalar([0x0123456789abcdef, 0xfedcba9876543210, 0x0f1e2d3c4b5a6978, 0x7f6e5d4c3b2a1908], core::marker::PhantomData)
    }
    fn field_mul(n: u64) -> u64 {
        let (mut x, y) = (Residue::<F, 4>::from_montgomery(P256::GX), Residue::<F, 4>::from_montgomery(P256::GY));
        for _ in 0..n { x = x.mul(&y); }
        x.integer()[0]
    }
    fn field_square(n: u64) -> u64 {
        let mut x = Residue::<F, 4>::from_montgomery(P256::GX);
        for _ in 0..n { x = x.square(); }
        x.integer()[0]
    }
    fn field_add(n: u64) -> u64 {
        let (mut x, y) = (Residue::<F, 4>::from_montgomery(P256::GX), Residue::<F, 4>::from_montgomery(P256::GY));
        for _ in 0..n { x = x.add(&y); }
        x.integer()[0]
    }
    fn field_sub(n: u64) -> u64 {
        let (mut x, y) = (Residue::<F, 4>::from_montgomery(P256::GX), Residue::<F, 4>::from_montgomery(P256::GY));
        for _ in 0..n { x = x.sub(&y); }
        x.integer()[0]
    }
    fn double(n: u64) -> u64 {
        let mut p = Point::<P256, 4>::base();
        for _ in 0..n { p = p.double(); }
        p.x.integer()[0]
    }
    fn add(n: u64) -> u64 {
        let mut p = Point::<P256, 4>::base();
        let q = p.double().double();
        for _ in 0..n { p = p.add_incomplete(&q).0; }
        p.x.integer()[0]
    }
    fn add_affine(n: u64) -> u64 {
        let mut p = Point::<P256, 4>::base().double();
        let q = P256_G_ODD[1];
        for _ in 0..n { p = p.add_affine(&q).0; }
        p.x.integer()[0]
    }
    fn lookup(n: u64) -> u64 {
        let p = Point::<P256, 4>::base().double();
        let mut table = [p; 16];
        table[1] = p.double();
        for j in 2..16 { table[j] = table[j - 1].add_public(&p); }
        for i in 0..n { black_box(Point::lookup(&table, (i % 33) as i8 - 16)); }
        0
    }
    fn multiples(n: u64) -> u64 {
        let p = Point::<P256, 4>::base().double();
        for _ in 0..n {
            let p = black_box(&p);
            let mut table = [*p; 16];
            table[1] = p.double();
            for j in 2..16 { table[j] = table[j - 1].add_public(p); }
            black_box(table);
        }
        0
    }
    fn variable_mul(n: u64) -> u64 {
        let p = Point::<P256, 4>::base().double();
        for _ in 0..n { black_box(black_box(&p).mul(&k())); }
        0
    }
    fn comb_mul(n: u64) -> u64 {
        for _ in 0..n { black_box(P256::base_mul(black_box(&k()))); }
        0
    }
    fn affine(n: u64) -> u64 {
        let p = Point::<P256, 4>::base().double();
        let (mut x, mut y) = ([0; 4], [0; 4]);
        for _ in 0..n { black_box(&p).affine(&mut x, &mut y).unwrap(); black_box((x, y)); }
        0
    }
    fn joint(n: u64) -> u64 {
        let p = Point::<P256, 4>::base().double();
        let (u1, u2) = (PublicScalar(k().0), PublicScalar([3, 5, 7, 0x0fff0000ffff0000]));
        for _ in 0..n { black_box(black_box(&p).joint(&u1, &u2)); }
        0
    }
    fn order_inverse(n: u64) -> u64 {
        for _ in 0..n { black_box(ModN::<P256, 4>::from_wide(black_box(&k().0)).invert()); }
        0
    }
    pub const PARTS: [Part; 14] = [
        ("field-mul", field_mul), ("field-square", field_square), ("field-add", field_add), ("field-sub", field_sub),
        ("double", double), ("add", add), ("add-affine", add_affine), ("lookup-16", lookup),
        ("multiples", multiples), ("variable-mul", variable_mul), ("comb-mul", comb_mul), ("affine", affine),
        ("joint", joint), ("order-inverse", order_inverse),
    ];
}
