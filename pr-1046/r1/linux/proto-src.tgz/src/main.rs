#![allow(dead_code)]
mod arch { #[inline(always)] pub fn value_barrier(mut v: u64) -> u64 { unsafe { core::arch::asm!("/* {0} */", inout(reg) v, options(pure, nomem, nostack, preserves_flags)) }; v } }
mod ct;
mod f51;
mod f64;
#[cfg(target_arch = "x86_64")]
mod adx;
use core::hint::black_box;
use f51::{Multiply, Tight};
use f64::Fe;
use std::time::Instant;

fn ladder51(scalar: &[u8; 32], point: &[u8; 32]) -> [u8; 32] {
    let x1 = Tight::from_bytes(point);
    let (mut x2, mut z2, mut x3, mut z3) = (Tight::ONE, Tight::ZERO, x1, Tight::ONE);
    let mut swap = 0;
    for i in (0..255).rev() {
        let bit = u64::from((scalar[i / 8] >> (i % 8)) & 1);
        let mask = ct::mask(swap ^ bit);
        Tight::swap(&mut x2, &mut x3, mask);
        Tight::swap(&mut z2, &mut z3, mask);
        swap = bit;
        let a = x2.add(&z2);
        let aa = a.square();
        let b = x2.sub(&z2);
        let bb = b.square();
        let e = aa.sub(&bb);
        let c = x3.add(&z3);
        let d = x3.sub(&z3);
        let da = d.mul(&a);
        let cb = c.mul(&b);
        x3 = da.add(&cb).square();
        z3 = x1.mul(&da.sub(&cb).square());
        x2 = aa.mul(&bb);
        z2 = e.mul(&aa.add(&e.mul_small(121665)));
    }
    let mask = ct::mask(swap);
    Tight::swap(&mut x2, &mut x3, mask);
    Tight::swap(&mut z2, &mut z3, mask);
    x2.mul(&z2.invert()).bytes()
}

pub trait F64Ops { fn mul(a: &Fe, b: &Fe) -> Fe; fn square(a: &Fe) -> Fe; }
pub struct Portable;
impl F64Ops for Portable { #[inline(always)] fn mul(a: &Fe, b: &Fe) -> Fe { a.mul(b) } #[inline(always)] fn square(a: &Fe) -> Fe { a.square() } }
#[cfg(target_arch = "x86_64")]
pub struct Adx;
#[cfg(target_arch = "x86_64")]
impl F64Ops for Adx { #[inline(always)] fn mul(a: &Fe, b: &Fe) -> Fe { Fe(unsafe { adx::mul(&a.0, &b.0) }) } #[inline(always)] fn square(a: &Fe) -> Fe { Fe(unsafe { adx::square(&a.0) }) } }
#[cfg(target_arch = "x86_64")]
pub struct AdxDual;
#[cfg(target_arch = "x86_64")]
impl F64Ops for AdxDual { #[inline(always)] fn mul(a: &Fe, b: &Fe) -> Fe { Fe(unsafe { adx::mul(&a.0, &b.0) }) } #[inline(always)] fn square(a: &Fe) -> Fe { Fe(unsafe { adx::square_dual(&a.0) }) } }
/// ADX behind a cached feature check per operation, as the crate dispatches.
#[cfg(target_arch = "x86_64")]
pub struct Dispatched;
#[cfg(target_arch = "x86_64")]
static FEAT: core::sync::atomic::AtomicU32 = core::sync::atomic::AtomicU32::new(0);
#[cfg(target_arch = "x86_64")]
#[inline(always)]
fn adx_ok() -> bool { let c = FEAT.load(core::sync::atomic::Ordering::Relaxed); if c != 0 { return c == 2; } adx_first() }
#[cfg(target_arch = "x86_64")]
#[cold]
#[inline(never)]
fn adx_first() -> bool { let ok = std::is_x86_feature_detected!("bmi2") && std::is_x86_feature_detected!("adx"); FEAT.store(if ok { 2 } else { 1 }, core::sync::atomic::Ordering::Relaxed); ok }
#[cfg(target_arch = "x86_64")]
impl F64Ops for Dispatched {
  #[inline(always)] fn mul(a: &Fe, b: &Fe) -> Fe { if adx_ok() { Fe(unsafe { adx::mul(&a.0, &b.0) }) } else { a.mul(b) } }
  #[inline(always)] fn square(a: &Fe) -> Fe { if adx_ok() { Fe(unsafe { adx::square(&a.0) }) } else { a.square() } }
}

fn ladder64<O: F64Ops>(scalar: &[u8; 32], point: &[u8; 32]) -> [u8; 32] {
    let x1 = Fe::from_bytes(point);
    let (mut x2, mut z2, mut x3, mut z3) = (Fe::ONE, Fe::ZERO, x1, Fe::ONE);
    let mut swap = 0;
    for i in (0..255).rev() {
        let bit = u64::from((scalar[i / 8] >> (i % 8)) & 1);
        let mask = ct::mask(swap ^ bit);
        Fe::swap(&mut x2, &mut x3, mask);
        Fe::swap(&mut z2, &mut z3, mask);
        swap = bit;
        let a = x2.add(&z2);
        let aa = O::square(&a);
        let b = x2.sub(&z2);
        let bb = O::square(&b);
        let e = aa.sub(&bb);
        let c = x3.add(&z3);
        let d = x3.sub(&z3);
        let da = O::mul(&d, &a);
        let cb = O::mul(&c, &b);
        x3 = O::square(&da.add(&cb));
        z3 = O::mul(&x1, &O::square(&da.sub(&cb)));
        x2 = O::mul(&aa, &bb);
        z2 = O::mul(&e, &aa.add(&e.mul_small(121665)));
    }
    let mask = ct::mask(swap);
    Fe::swap(&mut x2, &mut x3, mask);
    Fe::swap(&mut z2, &mut z3, mask);
    O::mul(&x2, &invert::<O>(&z2)).bytes()
}

fn invert<O: F64Ops>(z: &Fe) -> Fe {
    let st = |x: &Fe, k: u32| { let mut r = *x; for _ in 0..k { r = O::square(&r); } r };
    let m = |a: &Fe, b: &Fe| O::mul(a, b);
    let z2 = O::square(z);
    let z9 = m(&st(&z2, 2), z);
    let z11 = m(&z9, &z2);
    let z_5_0 = m(&O::square(&z11), &z9);
    let z_10_0 = m(&st(&z_5_0, 5), &z_5_0);
    let z_20_0 = m(&st(&z_10_0, 10), &z_10_0);
    let z_40_0 = m(&st(&z_20_0, 20), &z_20_0);
    let z_50_0 = m(&st(&z_40_0, 10), &z_10_0);
    let z_100_0 = m(&st(&z_50_0, 50), &z_50_0);
    let z_200_0 = m(&st(&z_100_0, 100), &z_100_0);
    let z_250_0 = m(&st(&z_200_0, 50), &z_50_0);
    m(&st(&z_250_0, 5), &z11)
}

fn time<T>(name: &str, iterations: u32, mut f: impl FnMut() -> T) {
    let mut samples: Vec<f64> = (0..15)
        .map(|_| {
            let start = Instant::now();
            for _ in 0..iterations { black_box(f()); }
            start.elapsed().as_nanos() as f64 / f64::from(iterations)
        })
        .collect();
    samples.sort_by(f64::total_cmp);
    println!("{name:30} median={:.1}ns min={:.1}ns", samples[7], samples[0]);
}

fn hex(s: &str) -> [u8; 32] { let mut o = [0; 32]; for i in 0..32 { o[i] = u8::from_str_radix(&s[2*i..2*i+2], 16).unwrap(); } o }

fn main() {
    // RFC 7748 section 5.2 vector 1.
    let mut k = hex("a546e36bf0527c9d3b16154b82465edd62144c0ac1fc5a18506a2244ba449ac4");
    k[0] &= 248; k[31] = (k[31] & 127) | 64;
    let u = hex("e6db6867583030db3594c1a424b15f7c726624ec26b3353b10a903a6d0ab1c4c");
    let want = hex("c3da55379de9c6908e94ea4df28d084f32eccf03491c71f754b4075577a28552");
    assert_eq!(ladder51(&k, &u), want);
    assert_eq!(ladder64::<Portable>(&k, &u), want);
    #[cfg(target_arch = "x86_64")]
    {
        let adx = std::is_x86_feature_detected!("bmi2") && std::is_x86_feature_detected!("adx");
        println!("cpu bmi2+adx: {adx}");
        if adx {
            assert_eq!(ladder64::<Adx>(&k, &u), want);
            assert_eq!(ladder64::<Dispatched>(&k, &u), want);
            assert_eq!(ladder64::<AdxDual>(&k, &u), want);
            // The kernels against the portable words, on chained values.
            let mut a = Fe::from_bytes(&u);
            let mut b = Fe::from_bytes(&k);
            for i in 0..100_000 {
                let (m1, m2) = (a.mul(&b), Fe(unsafe { adx::mul(&a.0, &b.0) }));
                assert_eq!(m1.0, m2.0, "mul at {i}");
                let (s1, s2) = (a.square(), Fe(unsafe { adx::square(&a.0) }));
                assert_eq!(s1.0, s2.0, "square at {i}");
                assert_eq!(s1.0, unsafe { adx::square_dual(&a.0) }, "square_dual at {i}");
                a = m1.add(&s1);
                b = b.sub(&m1);
                if i % 1000 == 0 { a = Fe([u64::MAX - i as u64; 4]); }
            }
            println!("kernels match the portable words on 100000 chained pairs");
        }
    }
    let x = Tight::from_bytes(&u);
    let y = Fe::from_bytes(&u);
    time("f51/mul-chain10", 200_000, || { let mut a = black_box(x); for _ in 0..10 { a = a.mul(&x); } a });
    time("f64p/mul-chain10", 200_000, || { let mut a = black_box(y); for _ in 0..10 { a = a.mul(&y); } a });
    time("f51/square-chain10", 200_000, || { let mut a = black_box(x); for _ in 0..10 { a = a.square(); } a });
    time("f64p/square-chain10", 200_000, || { let mut a = black_box(y); for _ in 0..10 { a = a.square(); } a });
    time("f51/mul-4way10", 100_000, || { let mut a = black_box([x; 4]); for _ in 0..10 { for v in &mut a { *v = v.mul(&x); } } a });
    time("f64p/mul-4way10", 100_000, || { let mut a = black_box([y; 4]); for _ in 0..10 { for v in &mut a { *v = v.mul(&y); } } a });
    #[cfg(target_arch = "x86_64")]
    if adx_ok() {
        time("f64adx/mul-chain10", 200_000, || { let mut a = black_box(y); for _ in 0..10 { a = Adx::mul(&a, &y); } a });
        time("f64adx/square-chain10", 200_000, || { let mut a = black_box(y); for _ in 0..10 { a = Adx::square(&a); } a });
        time("f64adxdual/square-chain10", 200_000, || { let mut a = black_box(y); for _ in 0..10 { a = AdxDual::square(&a); } a });
        time("f64adx/square-4way10", 100_000, || { let mut a = black_box([y; 4]); for _ in 0..10 { for v in &mut a { *v = Adx::square(v); } } a });
        time("f64adxdual/square-4way10", 100_000, || { let mut a = black_box([y; 4]); for _ in 0..10 { for v in &mut a { *v = AdxDual::square(v); } } a });
        time("f64adxdual/invert", 5_000, || invert::<AdxDual>(&black_box(y)));
        time("f64adxdual/ladder", 300, || ladder64::<AdxDual>(&black_box(k), &u));
        time("f64adx/mul-4way10", 100_000, || { let mut a = black_box([y; 4]); for _ in 0..10 { for v in &mut a { *v = Adx::mul(v, &y); } } a });
        time("f64adx/invert", 5_000, || invert::<Adx>(&black_box(y)));
        time("f64adx/ladder", 300, || ladder64::<Adx>(&black_box(k), &u));
        time("f64dispatched/ladder", 300, || ladder64::<Dispatched>(&black_box(k), &u));
    }
    time("f51/invert", 5_000, || black_box(x).invert());
    time("f64p/invert", 5_000, || invert::<Portable>(&black_box(y)));
    time("f51/ladder", 300, || ladder51(&black_box(k), &u));
    time("f64p/ladder", 300, || ladder64::<Portable>(&black_box(k), &u));
    #[cfg(target_arch = "x86_64")]
    if adx_ok() {
        time("f64adx/ladder(again)", 300, || ladder64::<Adx>(&black_box(k), &u));
    }
    time("f51/ladder(again)", 300, || ladder51(&black_box(k), &u));
}
