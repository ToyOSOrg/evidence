//! 2^255 - 19 in four 64-bit words, any value below 2^256.
#[derive(Clone, Copy)]
pub struct Fe(pub [u64; 4]);

#[inline(always)]
fn mac(acc: u64, a: u64, b: u64, carry: u64) -> (u64, u64) {
    let t = (a as u128) * (b as u128) + acc as u128 + carry as u128;
    (t as u64, (t >> 64) as u64)
}
#[inline(always)]
fn adc(a: u64, b: u64, c: u64) -> (u64, u64) {
    let t = a as u128 + b as u128 + c as u128;
    (t as u64, (t >> 64) as u64)
}
#[inline(always)]
fn sbb(a: u64, b: u64, borrow: u64) -> (u64, u64) {
    let t = (a as u128).wrapping_sub(b as u128).wrapping_sub(borrow as u128);
    (t as u64, (t >> 127) as u64)
}

/// r + top 2^256 for top below 2^58.
#[inline(always)]
fn fold(r: [u64; 4], top: u64) -> Fe {
    let (r0, c) = adc(r[0], top.wrapping_mul(38), 0);
    let (r1, c) = adc(r[1], 0, c);
    let (r2, c) = adc(r[2], 0, c);
    let (r3, c) = adc(r[3], 0, c);
    Fe([r0.wrapping_add(c.wrapping_mul(38)), r1, r2, r3])
}

#[inline(always)]
fn reduce(t: [u64; 8]) -> Fe {
    let (r0, c) = mac(t[0], t[4], 38, 0);
    let (r1, c) = mac(t[1], t[5], 38, c);
    let (r2, c) = mac(t[2], t[6], 38, c);
    let (r3, top) = mac(t[3], t[7], 38, c);
    fold([r0, r1, r2, r3], top)
}

impl Fe {
    pub const ZERO: Self = Self([0; 4]);
    pub const ONE: Self = Self([1, 0, 0, 0]);
    pub fn from_bytes(b: &[u8; 32]) -> Self {
        let w = |i: usize| u64::from_le_bytes(b[8 * i..8 * i + 8].try_into().unwrap());
        Self([w(0), w(1), w(2), w(3) & (u64::MAX >> 1)])
    }
    #[inline(always)]
    pub fn add(&self, b: &Self) -> Self {
        let (a, b) = (&self.0, &b.0);
        let (r0, c) = adc(a[0], b[0], 0);
        let (r1, c) = adc(a[1], b[1], c);
        let (r2, c) = adc(a[2], b[2], c);
        let (r3, c) = adc(a[3], b[3], c);
        fold([r0, r1, r2, r3], c)
    }
    #[inline(always)]
    pub fn sub(&self, b: &Self) -> Self {
        let (a, b) = (&self.0, &b.0);
        let (r0, c) = sbb(a[0], b[0], 0);
        let (r1, c) = sbb(a[1], b[1], c);
        let (r2, c) = sbb(a[2], b[2], c);
        let (r3, c) = sbb(a[3], b[3], c);
        let (r0, c) = sbb(r0, c.wrapping_mul(38), 0);
        let (r1, c) = sbb(r1, 0, c);
        let (r2, c) = sbb(r2, 0, c);
        let (r3, c) = sbb(r3, 0, c);
        Self([r0.wrapping_sub(c.wrapping_mul(38)), r1, r2, r3])
    }
    #[inline(never)]
    pub fn mul(&self, b: &Self) -> Self {
        let (a, b) = (&self.0, &b.0);
        let (t0, c) = mac(0, a[0], b[0], 0);
        let (t1, c) = mac(0, a[0], b[1], c);
        let (t2, c) = mac(0, a[0], b[2], c);
        let (t3, t4) = mac(0, a[0], b[3], c);
        let (t1, c) = mac(t1, a[1], b[0], 0);
        let (t2, c) = mac(t2, a[1], b[1], c);
        let (t3, c) = mac(t3, a[1], b[2], c);
        let (t4, t5) = mac(t4, a[1], b[3], c);
        let (t2, c) = mac(t2, a[2], b[0], 0);
        let (t3, c) = mac(t3, a[2], b[1], c);
        let (t4, c) = mac(t4, a[2], b[2], c);
        let (t5, t6) = mac(t5, a[2], b[3], c);
        let (t3, c) = mac(t3, a[3], b[0], 0);
        let (t4, c) = mac(t4, a[3], b[1], c);
        let (t5, c) = mac(t5, a[3], b[2], c);
        let (t6, t7) = mac(t6, a[3], b[3], c);
        reduce([t0, t1, t2, t3, t4, t5, t6, t7])
    }
    #[inline(never)]
    pub fn square(&self) -> Self {
        let a = &self.0;
        let (t1, c) = mac(0, a[0], a[1], 0);
        let (t2, c) = mac(0, a[0], a[2], c);
        let (t3, t4) = mac(0, a[0], a[3], c);
        let (t3, c) = mac(t3, a[1], a[2], 0);
        let (t4, t5) = mac(t4, a[1], a[3], c);
        let (t5, t6) = mac(t5, a[2], a[3], 0);
        let t7 = t6 >> 63;
        let (t6, t5, t4, t3, t2, t1) =
            (t6 << 1 | t5 >> 63, t5 << 1 | t4 >> 63, t4 << 1 | t3 >> 63, t3 << 1 | t2 >> 63, t2 << 1 | t1 >> 63, t1 << 1);
        let (t0, hi) = mac(0, a[0], a[0], 0);
        let (t1, c) = adc(t1, hi, 0);
        let (lo, hi) = mac(0, a[1], a[1], 0);
        let (t2, c) = adc(t2, lo, c);
        let (t3, c) = adc(t3, hi, c);
        let (lo, hi) = mac(0, a[2], a[2], 0);
        let (t4, c) = adc(t4, lo, c);
        let (t5, c) = adc(t5, hi, c);
        let (lo, hi) = mac(0, a[3], a[3], 0);
        let (t6, c) = adc(t6, lo, c);
        let (t7, _) = adc(t7, hi, c);
        reduce([t0, t1, t2, t3, t4, t5, t6, t7])
    }
    #[inline(always)]
    pub fn mul_small(&self, k: u64) -> Self {
        let a = &self.0;
        let (r0, c) = mac(0, a[0], k, 0);
        let (r1, c) = mac(0, a[1], k, c);
        let (r2, c) = mac(0, a[2], k, c);
        let (r3, top) = mac(0, a[3], k, c);
        fold([r0, r1, r2, r3], top)
    }
    pub fn swap(a: &mut Self, b: &mut Self, mask: u64) {
        for i in 0..4 {
            let t = (a.0[i] ^ b.0[i]) & mask;
            a.0[i] ^= t;
            b.0[i] ^= t;
        }
    }
    pub fn bytes(&self) -> [u8; 32] {
        let v = &self.0;
        let q = v[3] >> 63;
        let (v0, c) = adc(v[0], q * 19, 0);
        let (v1, c) = adc(v[1], 0, c);
        let (v2, c) = adc(v[2], 0, c);
        let v3 = (v[3] & (u64::MAX >> 1)) + c;
        let (w0, c) = adc(v0, 19, 0);
        let (w1, c) = adc(v1, 0, c);
        let (w2, c) = adc(v2, 0, c);
        let w3 = v3 + c;
        let m = 0u64.wrapping_sub(w3 >> 63);
        let r = [v0 ^ ((v0 ^ w0) & m), v1 ^ ((v1 ^ w1) & m), v2 ^ ((v2 ^ w2) & m), v3 ^ ((v3 ^ (w3 & (u64::MAX >> 1))) & m)];
        let mut out = [0; 32];
        for i in 0..4 {
            out[8 * i..8 * i + 8].copy_from_slice(&r[i].to_le_bytes());
        }
        out
    }
    pub fn square_times(&self, k: u32) -> Self {
        let mut r = *self;
        for _ in 0..k { r = r.square(); }
        r
    }
    pub fn invert(&self) -> Self {
        let z2 = self.square();
        let z9 = z2.square_times(2).mul(self);
        let z11 = z9.mul(&z2);
        let z_5_0 = z11.square().mul(&z9);
        let z_10_0 = z_5_0.square_times(5).mul(&z_5_0);
        let z_20_0 = z_10_0.square_times(10).mul(&z_10_0);
        let z_40_0 = z_20_0.square_times(20).mul(&z_20_0);
        let z_50_0 = z_40_0.square_times(10).mul(&z_10_0);
        let z_100_0 = z_50_0.square_times(50).mul(&z_50_0);
        let z_200_0 = z_100_0.square_times(100).mul(&z_100_0);
        let z_250_0 = z_200_0.square_times(50).mul(&z_50_0);
        z_250_0.square_times(5).mul(&z11)
    }
}
