	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 0
	.file	"toyos_crypto.2c7c694700c9b808-cgu.0"
	.def	_RINvNtCsbOZu4GxVKn0_4core3ptr9drop_glueNtNtCs3ONsSsjNgxw_12toyos_crypto7ed255195PointEBF_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RINvNtCsbOZu4GxVKn0_4core3ptr9drop_glueNtNtCs3ONsSsjNgxw_12toyos_crypto7ed255195PointEBF_,unique,0
	.p2align	4
_RINvNtCsbOZu4GxVKn0_4core3ptr9drop_glueNtNtCs3ONsSsjNgxw_12toyos_crypto7ed255195PointEBF_:
	movq	$0, (%rcx)
	movq	$0, 8(%rcx)
	movq	$0, 16(%rcx)
	movq	$0, 24(%rcx)
	movq	$0, 32(%rcx)
	#MEMBARRIER
	movq	$0, 40(%rcx)
	movq	$0, 48(%rcx)
	movq	$0, 56(%rcx)
	movq	$0, 64(%rcx)
	movq	$0, 72(%rcx)
	#MEMBARRIER
	movq	$0, 80(%rcx)
	movq	$0, 88(%rcx)
	movq	$0, 96(%rcx)
	movq	$0, 104(%rcx)
	movq	$0, 112(%rcx)
	#MEMBARRIER
	movq	$0, 120(%rcx)
	movq	$0, 128(%rcx)
	movq	$0, 136(%rcx)
	movq	$0, 144(%rcx)
	movq	$0, 152(%rcx)
	#MEMBARRIER
	retq

	.def	_RINvNtCsbOZu4GxVKn0_4core9panicking13assert_failedooECs3ONsSsjNgxw_12toyos_crypto;
	.scl	2;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_RINvNtCsbOZu4GxVKn0_4core9panicking13assert_failedooECs3ONsSsjNgxw_12toyos_crypto,unique,1
	.globl	_RINvNtCsbOZu4GxVKn0_4core9panicking13assert_failedooECs3ONsSsjNgxw_12toyos_crypto
_RINvNtCsbOZu4GxVKn0_4core9panicking13assert_failedooECs3ONsSsjNgxw_12toyos_crypto:
	pushq	%rsi
	subq	$80, %rsp
	movq	128(%rsp), %r11
	movq	136(%rsp), %rsi
	leaq	64(%rsp), %rax
	movq	%rdx, (%rax)
	leaq	72(%rsp), %r10
	movq	%r8, (%r10)
	movq	%rsi, 56(%rsp)
	movq	%r11, 48(%rsp)
	movq	%r9, 40(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.1(%rip), %r8
	movq	%r8, 32(%rsp)
	movq	%rax, %rdx
	movq	%r10, %r9
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking19assert_failed_inner
	ud2

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes6expand;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes6expand,unique,2
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes6expand:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$328, %rsp
	movq	%r9, %rdi
	movq	%r8, %r15
	movq	%rdx, %rsi
	movq	%rcx, 56(%rsp)
	leaq	88(%rsp), %rbx
	xorl	%r12d, %r12d
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %r8
	cpuid
	xchgq	%rbx, %r8

	#NO_APP
	movl	%ecx, 44(%rsp)
	movl	$240, %r8d
	subq	%r15, %r8
	leaq	(%rsp,%r15), %r14
	addq	$88, %r14
	movq	%r14, %rcx
	xorl	%edx, %edx
	callq	memset
	movq	%rbx, %rcx
	movq	%r14, %rbx
	movq	%rsi, %rdx
	movq	%r15, %r8
	callq	memcpy
	movq	%rdi, 48(%rsp)
	shlq	$4, %rdi
	subq	%r15, %rdi
	leaq	16(%rdi), %rcx
	xorl	%edx, %edx
	testb	$3, %dil
	setne	%dl
	andq	$-4, %rcx
	leaq	(%rcx,%rdx,4), %rax
	movq	%rax, 72(%rsp)
	movb	$1, %r13b
	movq	%r15, %rax
	xorq	$32, %rax
	movq	%rax, 64(%rsp)
	.p2align	4
.LBB2_1:
	leaq	(%r15,%r12), %rcx
	movl	-4(%rbx,%r12), %ebp
	movl	%ebp, 40(%rsp)
	movq	%rcx, %rax
	shrq	$32, %rax
	je	.LBB2_2
	movq	%rcx, %rax
	xorl	%edx, %edx
	divq	%r15
	testq	%rdx, %rdx
	je	.LBB2_5
.LBB2_6:
	movl	%ebp, %r14d
	shrl	$8, %r14d
	movl	%ebp, %edi
	shrl	$16, %edi
	movl	%ebp, %esi
	shrl	$24, %esi
	movl	%ecx, %eax
	andl	$31, %eax
	xorq	$16, %rax
	orq	64(%rsp), %rax
	jne	.LBB2_8
	movl	%ebp, %ecx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox
	movl	%eax, %ebp
	movl	%r14d, %ecx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox
	movl	%eax, %r14d
	movl	%edi, %ecx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox
	movl	%eax, %edi
	movl	%esi, %ecx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox
	leaq	(%r15,%r12), %rcx
	movl	%eax, %esi
	jmp	.LBB2_8
	.p2align	4
.LBB2_2:
	movl	%ecx, %eax
	xorl	%edx, %edx
	divl	%r15d
	testq	%rdx, %rdx
	jne	.LBB2_6
.LBB2_5:
	leaq	41(%rsp), %rax
	movzwl	(%rax), %ecx
	movzbl	2(%rax), %eax
	movb	%al, 42(%rsp)
	movw	%cx, 40(%rsp)
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox
	movl	%eax, %ebx
	movb	%al, 40(%rsp)
	movzbl	41(%rsp), %ecx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox
	movl	%eax, %r14d
	movzbl	42(%rsp), %ecx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox
	movl	%eax, %edi
	movl	%ebp, %ecx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox
	movl	%eax, %esi
	xorb	%r13b, %bl
	leal	(,%r13,2), %eax
	shrb	$7, %r13b
	movzbl	%r13b, %ecx
	movq	%rcx, 80(%rsp)
	leaq	(%r15,%r12), %rcx
	movq	80(%rsp), %r13
	negb	%r13b
	andb	$27, %r13b
	xorb	%al, %r13b
	movl	%ebx, %ebp
	leaq	(%rsp,%r15), %rbx
	addq	$88, %rbx
.LBB2_8:
	leaq	(%r15,%r12), %rax
	addq	$-240, %rax
	testq	%rax, %rax
	je	.LBB2_14
	xorb	88(%rsp,%r12), %bpl
	movb	%bpl, (%rbx,%r12)
	cmpq	$238, %rcx
	ja	.LBB2_14
	leaq	(%r15,%r12), %rax
	addq	$-238, %rax
	xorb	89(%rsp,%r12), %r14b
	movb	%r14b, 1(%rbx,%r12)
	testq	%rax, %rax
	je	.LBB2_14
	xorb	90(%rsp,%r12), %dil
	movb	%dil, 2(%rbx,%r12)
	cmpq	$236, %rcx
	ja	.LBB2_14
	xorb	91(%rsp,%r12), %sil
	movb	%sil, 3(%rbx,%r12)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	#MEMBARRIER
	addq	$4, %r12
	cmpq	%r12, 72(%rsp)
	jne	.LBB2_1
	movl	$240, %r8d
	movq	56(%rsp), %rsi
	movq	%rsi, %rcx
	leaq	88(%rsp), %rdx
	callq	memcpy
	movq	48(%rsp), %rax
	movq	%rax, 240(%rsi)
	movl	44(%rsp), %eax
	shrl	$25, %eax
	andb	$1, %al
	movb	%al, 248(%rsi)
	addq	$328, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB2_14:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.7(%rip), %r8
	movl	$240, %ecx
	movl	$240, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt,unique,3
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$392, %rsp
	movq	%rdx, %r12
	cmpb	$0, 248(%rcx)
	je	.LBB3_1
	movq	240(%rcx), %rax
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	decq	%rax
	leaq	32(%rsp), %rdx
	#APP

	movdqu	%xmm0, (%rdx)
	movdqu	%xmm1, 16(%rdx)
	movdqu	(%r12), %xmm0
	movdqu	(%rcx), %xmm1
	pxor	%xmm1, %xmm0
	addq	$16, %rcx
.Ltmp0:
	movdqu	(%rcx), %xmm1
	aesenc	%xmm1, %xmm0
	addq	$16, %rcx
	decq	%rax
	jne	.Ltmp0
	movdqu	(%rcx), %xmm1
	aesenclast	%xmm1, %xmm0
	movdqu	%xmm0, (%r12)
	movdqu	(%rdx), %xmm0
	movdqu	16(%rdx), %xmm1

	#NO_APP
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	jmp	.LBB3_10
.LBB3_1:
	movzbl	(%rcx), %eax
	xorb	%al, (%r12)
	movzbl	1(%rcx), %eax
	xorb	%al, 1(%r12)
	movzbl	2(%rcx), %eax
	xorb	%al, 2(%r12)
	movzbl	3(%rcx), %eax
	xorb	%al, 3(%r12)
	movzbl	4(%rcx), %eax
	xorb	%al, 4(%r12)
	movzbl	5(%rcx), %eax
	xorb	%al, 5(%r12)
	movzbl	6(%rcx), %eax
	xorb	%al, 6(%r12)
	movzbl	7(%rcx), %eax
	xorb	%al, 7(%r12)
	movzbl	8(%rcx), %eax
	xorb	%al, 8(%r12)
	movzbl	9(%rcx), %eax
	xorb	%al, 9(%r12)
	movzbl	10(%rcx), %eax
	xorb	%al, 10(%r12)
	movzbl	11(%rcx), %eax
	xorb	%al, 11(%r12)
	movzbl	12(%rcx), %eax
	xorb	%al, 12(%r12)
	movzbl	13(%rcx), %eax
	xorb	%al, 13(%r12)
	movzbl	14(%rcx), %eax
	xorb	%al, 14(%r12)
	movzbl	15(%rcx), %eax
	xorb	%al, 15(%r12)
	movq	240(%rcx), %r14
	testq	%r14, %r14
	je	.LBB3_10
	movl	$1, %eax
	movq	%r12, 120(%rsp)
	movq	%rcx, 96(%rsp)
	movq	%r14, 104(%rsp)
	.p2align	4
.LBB3_3:
	movq	%rax, 112(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB3_4:
	movq	%rax, 80(%rsp)
	movzbl	(%r12,%rax), %ecx
	movl	%ecx, %eax
	andl	$1, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	leal	(%rcx,%rcx), %r10d
	movl	%ecx, %eax
	shrl	$7, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r10b, %dl
	movl	%ecx, %r9d
	shrl	%r9d
	andl	$1, %r9d
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	addb	%dl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	$27, %r8b
	xorb	%dl, %r8b
	movl	%ecx, %r10d
	shrl	$2, %r10d
	andl	$1, %r10d
	movq	%r10, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%r8b, %r10b
	xorb	%r9b, %r10b
	addb	%r8b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r8b, %dl
	movl	%ecx, %r9d
	shrl	$3, %r9d
	andl	$1, %r9d
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r10b, %r9b
	addb	%dl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	$27, %r8b
	xorb	%dl, %r8b
	movl	%ecx, %r10d
	shrl	$4, %r10d
	andl	$1, %r10d
	movq	%r10, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%r8b, %r10b
	xorb	%r9b, %r10b
	addb	%r8b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r8b, %dl
	movl	%ecx, %r9d
	shrl	$5, %r9d
	andl	$1, %r9d
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r10b, %r9b
	addb	%dl, %dl
	shrb	$7, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	$27, %r8b
	xorb	%dl, %r8b
	shrl	$6, %ecx
	andl	$1, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r8b, %cl
	xorb	%r9b, %cl
	addb	%r8b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r8b, %dl
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %r11
	negb	%r11b
	andb	%dl, %r11b
	xorb	%cl, %r11b
	shrb	$7, %r8b
	movzbl	%r8b, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movl	%r11d, %eax
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r11b, %cl
	leal	(%r11,%r11), %edx
	movl	%r11d, %eax
	shrb	$7, %al
	movzbl	%al, %esi
	movq	%rsi, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%dl, %al
	movl	%edx, %r8d
	movl	%edx, 92(%rsp)
	movl	%r11d, %edx
	shrb	%dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	addb	%al, %al
	movl	%r8d, %ecx
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 384(%rsp)
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r11d, %r8d
	shrb	$2, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%r11d, %edx
	shrb	$3, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r11d, %r8d
	shrb	$4, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%r11d, %edx
	shrb	$5, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r11d, %r8d
	shrb	$6, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movq	%rsi, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%r8b, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movl	%eax, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 376(%rsp)
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	leal	(%rax,%rax), %r9d
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %ebx
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%r9b, %cl
	movl	%eax, %r8d
	shrb	%r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 368(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %r9b
	movzbl	%r9b, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %r9d
	shrb	$2, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, 360(%rsp)
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	addb	%dl, %dl
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %r8d
	shrb	$3, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 352(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	addb	%cl, %cl
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %r9d
	shrb	$4, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, 344(%rsp)
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	addb	%dl, %dl
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %r8d
	shrb	$5, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 336(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$6, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 320(%rsp)
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %eax
	movq	%rax, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%cl, %al
	xorb	%r9b, %al
	shrb	$7, %dl
	movzbl	%dl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movl	%eax, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 328(%rsp)
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %r14d
	movq	%r14, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	leal	(%rax,%rax), %r9d
	xorb	%r9b, %cl
	movl	%eax, %r8d
	shrb	%r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 312(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	shrb	$7, %r9b
	movzbl	%r9b, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %r9d
	shrb	$2, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, 304(%rsp)
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %r8d
	shrb	$3, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 296(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %r9d
	shrb	$4, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, 288(%rsp)
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %r8d
	shrb	$5, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 280(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$6, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 264(%rsp)
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %eax
	movq	%rax, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movq	%r14, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%cl, %al
	xorb	%r9b, %al
	shrb	$7, %dl
	movzbl	%dl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movl	%eax, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 272(%rsp)
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %r15d
	movq	%r15, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	leal	(%rax,%rax), %r9d
	xorb	%r9b, %cl
	movl	%eax, %r8d
	shrb	%r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 256(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	shrb	$7, %r9b
	movzbl	%r9b, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %r9d
	shrb	$2, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, 248(%rsp)
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %r8d
	shrb	$3, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 240(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %r9d
	shrb	$4, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, 232(%rsp)
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %r8d
	shrb	$5, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 224(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$6, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 208(%rsp)
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %eax
	movq	%rax, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movq	%r15, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%cl, %al
	xorb	%r9b, %al
	shrb	$7, %dl
	movzbl	%dl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movl	%eax, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 216(%rsp)
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	movl	%eax, %ecx
	shrb	$7, %cl
	movzbl	%cl, %r12d
	movq	%r12, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	leal	(%rax,%rax), %r9d
	xorb	%r9b, %cl
	movl	%eax, %r8d
	shrb	%r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 200(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	shrb	$7, %r9b
	movzbl	%r9b, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %r9d
	shrb	$2, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, 192(%rsp)
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %r8d
	shrb	$3, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 184(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%eax, %r9d
	shrb	$4, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, 176(%rsp)
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %r9
	negb	%r9b
	andb	%dl, %r9b
	xorb	%r8b, %r9b
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%eax, %r8d
	shrb	$5, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 168(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	shrb	$6, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 160(%rsp)
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%r8b, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movq	%r12, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%al, %r10b
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movl	%r10d, %eax
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 152(%rsp)
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%r10b, %al
	movl	%r10d, %ecx
	shrb	$7, %cl
	movzbl	%cl, %ebp
	movq	%rbp, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	leal	(%r10,%r10), %edx
	xorb	%dl, %cl
	movl	%r10d, %r8d
	shrb	%r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 144(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%al, %r8b
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movl	%r10d, %eax
	shrb	$2, %al
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, 136(%rsp)
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%r8b, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%dl, %dl
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%dl, %cl
	movl	%r10d, %r8d
	shrb	$3, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 128(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%al, %r8b
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %r13
	negb	%r13b
	andb	$27, %r13b
	xorb	%cl, %r13b
	movl	%r10d, %eax
	shrb	$4, %al
	andb	$1, %al
	movzbl	%al, %edi
	movq	%rdi, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%r13b, %al
	xorb	%r8b, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%r13b, %r13b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%r13b, %cl
	movl	%r10d, %edx
	shrb	$5, %dl
	andb	$1, %dl
	movzbl	%dl, %r9d
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%cl, %dl
	xorb	%al, %dl
	shrb	$7, %r13b
	movzbl	%r13b, %eax
	movq	%rax, 32(%rsp)
	addb	%cl, %cl
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	shrb	$6, %r10b
	andb	$1, %r10b
	movzbl	%r10b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%al, %r10b
	xorb	%dl, %r10b
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	addb	%al, %al
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	%rbp, 32(%rsp)
	movq	32(%rsp), %r13
	negb	%r13b
	andb	%cl, %r13b
	xorb	%r10b, %r13b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	376(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%r11b, %al
	movq	%rsi, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	92(%rsp), %cl
	movq	368(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%al, %r10b
	movq	384(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	360(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%cl, %cl
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r10b, %dl
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	352(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	addb	%al, %al
	negb	%r10b
	andb	$27, %r10b
	xorb	%al, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	344(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	336(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	addb	%al, %al
	negb	%r10b
	andb	$27, %r10b
	xorb	%al, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	320(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	%rbx, 32(%rsp)
	addb	%al, %al
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%dl, %r10b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	328(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%r10b, %al
	leal	(%r10,%r10), %edx
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	312(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	negb	%r10b
	andb	$27, %r10b
	xorb	%dl, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%al, %cl
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	304(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	296(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	addb	%al, %al
	negb	%r10b
	andb	$27, %r10b
	xorb	%al, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	288(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	280(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	addb	%al, %al
	negb	%r10b
	andb	$27, %r10b
	xorb	%al, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	264(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	%r14, 32(%rsp)
	addb	%al, %al
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%dl, %r10b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	272(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%r10b, %al
	leal	(%r10,%r10), %edx
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	256(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	negb	%r10b
	andb	$27, %r10b
	xorb	%dl, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%al, %cl
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	248(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	240(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	addb	%al, %al
	negb	%r10b
	andb	$27, %r10b
	xorb	%al, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	232(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	224(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	addb	%al, %al
	negb	%r10b
	andb	$27, %r10b
	xorb	%al, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	208(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	%r15, 32(%rsp)
	addb	%al, %al
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%dl, %r10b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	216(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%r10b, %al
	leal	(%r10,%r10), %edx
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	200(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	negb	%r10b
	andb	$27, %r10b
	xorb	%dl, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%al, %cl
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	192(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	184(%rsp), %rcx
	movq	%rcx, 32(%rsp)
	addb	%al, %al
	negb	%r10b
	andb	$27, %r10b
	xorb	%al, %r10b
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	xorb	%dl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	176(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	addb	%r10b, %r10b
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	168(%rsp), %r10
	movq	%r10, 32(%rsp)
	addb	%al, %al
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%dl, %r10b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movq	160(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r10b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	%r12, 32(%rsp)
	movq	120(%rsp), %r12
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%dl, %r10b
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	152(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%r10b, %cl
	leal	(%r10,%r10), %r11d
	shrb	$7, %r10b
	movzbl	%r10b, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%r11b, %al
	movq	144(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	addb	%al, %al
	shrb	$7, %r11b
	movzbl	%r11b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	136(%rsp), %r10
	movq	%r10, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%dl, %r10b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movq	128(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r10b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	%rdi, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	%cl, %r10b
	xorb	%dl, %r10b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movq	%r9, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r10b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%cl, %dl
	movq	%rbp, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	%dl, %al
	xorb	%r8b, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movl	%r13d, %ecx
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	%al, %cl
	leal	(%rax,%rax), %r8d
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%r8b, %al
	movl	%r13d, %edx
	shrb	%dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%cl, %dl
	addb	%al, %al
	shrb	$7, %r8b
	movzbl	%r8b, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r13d, %r8d
	shrb	$2, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%r13d, %edx
	shrb	$3, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r13d, %r8d
	shrb	$4, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%r13d, %edx
	shrb	$5, %dl
	andb	$1, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%r13d, %r8d
	shrb	$6, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%dl, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	shrb	$7, %r13b
	movzbl	%r13b, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	%al, %dl
	xorb	%r8b, %dl
	shrb	$7, %cl
	movzbl	%cl, %eax
	movl	%edx, %ecx
	rolb	%cl
	movq	%rax, 32(%rsp)
	movl	%edx, %eax
	rolb	$2, %al
	xorb	%cl, %al
	movl	%edx, %ecx
	rolb	$3, %cl
	movl	%edx, %r8d
	rolb	$4, %r8b
	xorb	%cl, %r8b
	xorb	%al, %r8b
	xorb	%dl, %r8b
	movq	32(%rsp), %rax
	xorb	$99, %r8b
	movq	80(%rsp), %rax
	movb	%r8b, (%r12,%rax)
	incq	%rax
	cmpq	$16, %rax
	jne	.LBB3_4
	movq	104(%rsp), %rcx
	movq	112(%rsp), %r13
	cmpq	%rcx, %r13
	movq	%r13, %rax
	adcq	$0, %rax
	movq	%rax, 80(%rsp)
	movzbl	1(%r12), %eax
	movzbl	2(%r12), %edx
	movzbl	3(%r12), %r8d
	movzbl	5(%r12), %r9d
	movzbl	6(%r12), %r10d
	movzbl	7(%r12), %r11d
	movzbl	9(%r12), %ebx
	movzbl	10(%r12), %esi
	movzbl	11(%r12), %edi
	movzbl	13(%r12), %ebp
	movzbl	14(%r12), %r14d
	movzbl	15(%r12), %r15d
	movb	%r9b, 1(%r12)
	movb	%bl, 5(%r12)
	movb	%bpl, 9(%r12)
	movb	%al, 13(%r12)
	movb	%sil, 2(%r12)
	movb	%r14b, 6(%r12)
	movq	%rcx, %r14
	movb	%dl, 10(%r12)
	movb	%r10b, 14(%r12)
	movb	%r15b, 3(%r12)
	movb	%r8b, 7(%r12)
	movb	%r11b, 11(%r12)
	movb	%dil, 15(%r12)
	movb	$0, 32(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 65(%rsp)
	#MEMBARRIER
	cmpq	%rcx, %r13
	je	.LBB3_6
	movzbl	(%r12), %r8d
	movzbl	1(%r12), %r11d
	movzbl	2(%r12), %r10d
	movzbl	3(%r12), %edx
	movl	%r11d, %r9d
	xorb	%r8b, %r9b
	movl	%r9d, %eax
	xorb	%r10b, %al
	movl	%eax, %ebx
	xorb	%dl, %bl
	leal	(%r9,%r9), %esi
	movl	%r9d, %edi
	shrb	$7, %dil
	movzbl	%dil, %edi
	movq	%rdi, 32(%rsp)
	movq	32(%rsp), %rdi
	negb	%dil
	andb	$27, %dil
	xorb	%sil, %dil
	xorb	%r8b, %dil
	xorb	%bl, %dil
	movb	%dil, (%r12)
	movl	%r10d, %esi
	xorb	%r11b, %sil
	leal	(%rsi,%rsi), %edi
	shrb	$7, %sil
	movzbl	%sil, %esi
	movq	%rsi, 32(%rsp)
	movq	32(%rsp), %rsi
	negb	%sil
	andb	$27, %sil
	xorb	%dil, %sil
	xorb	%r11b, %sil
	xorb	%bl, %sil
	movb	%sil, 1(%r12)
	xorb	%dl, %r10b
	leal	(%r10,%r10), %r11d
	shrb	$7, %r10b
	movzbl	%r10b, %r10d
	movq	%r10, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	$27, %r10b
	xorb	%r11b, %r10b
	xorb	%dl, %r9b
	xorb	%r10b, %r9b
	movb	%r9b, 2(%r12)
	xorb	%r8b, %dl
	leal	(%rdx,%rdx), %r8d
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r8b, %dl
	xorb	%al, %dl
	movb	%dl, 3(%r12)
	movzbl	4(%r12), %r8d
	movzbl	5(%r12), %r11d
	movzbl	6(%r12), %r10d
	movzbl	7(%r12), %edx
	movl	%r11d, %r9d
	xorb	%r8b, %r9b
	movl	%r9d, %eax
	xorb	%r10b, %al
	movl	%eax, %ebx
	xorb	%dl, %bl
	leal	(%r9,%r9), %esi
	movl	%r9d, %edi
	shrb	$7, %dil
	movzbl	%dil, %edi
	movq	%rdi, 32(%rsp)
	movq	32(%rsp), %rdi
	negb	%dil
	andb	$27, %dil
	xorb	%sil, %dil
	xorb	%r8b, %dil
	xorb	%bl, %dil
	movb	%dil, 4(%r12)
	movl	%r10d, %esi
	xorb	%r11b, %sil
	leal	(%rsi,%rsi), %edi
	shrb	$7, %sil
	movzbl	%sil, %esi
	movq	%rsi, 32(%rsp)
	movq	32(%rsp), %rsi
	negb	%sil
	andb	$27, %sil
	xorb	%dil, %sil
	xorb	%r11b, %sil
	xorb	%bl, %sil
	movb	%sil, 5(%r12)
	xorb	%dl, %r10b
	leal	(%r10,%r10), %r11d
	shrb	$7, %r10b
	movzbl	%r10b, %r10d
	movq	%r10, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	$27, %r10b
	xorb	%r11b, %r10b
	xorb	%dl, %r9b
	xorb	%r10b, %r9b
	movb	%r9b, 6(%r12)
	xorb	%r8b, %dl
	leal	(%rdx,%rdx), %r8d
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r8b, %dl
	xorb	%al, %dl
	movb	%dl, 7(%r12)
	movzbl	8(%r12), %r8d
	movzbl	9(%r12), %r11d
	movzbl	10(%r12), %r10d
	movzbl	11(%r12), %edx
	movl	%r11d, %r9d
	xorb	%r8b, %r9b
	movl	%r9d, %eax
	xorb	%r10b, %al
	movl	%eax, %ebx
	xorb	%dl, %bl
	leal	(%r9,%r9), %esi
	movl	%r9d, %edi
	shrb	$7, %dil
	movzbl	%dil, %edi
	movq	%rdi, 32(%rsp)
	movq	32(%rsp), %rdi
	negb	%dil
	andb	$27, %dil
	xorb	%sil, %dil
	xorb	%r8b, %dil
	xorb	%bl, %dil
	movb	%dil, 8(%r12)
	movl	%r10d, %esi
	xorb	%r11b, %sil
	leal	(%rsi,%rsi), %edi
	shrb	$7, %sil
	movzbl	%sil, %esi
	movq	%rsi, 32(%rsp)
	movq	32(%rsp), %rsi
	negb	%sil
	andb	$27, %sil
	xorb	%dil, %sil
	xorb	%r11b, %sil
	xorb	%bl, %sil
	movb	%sil, 9(%r12)
	xorb	%dl, %r10b
	leal	(%r10,%r10), %r11d
	shrb	$7, %r10b
	movzbl	%r10b, %r10d
	movq	%r10, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	$27, %r10b
	xorb	%r11b, %r10b
	xorb	%dl, %r9b
	xorb	%r10b, %r9b
	movb	%r9b, 10(%r12)
	xorb	%r8b, %dl
	leal	(%rdx,%rdx), %r8d
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r8b, %dl
	xorb	%al, %dl
	movb	%dl, 11(%r12)
	movzbl	12(%r12), %r8d
	movzbl	13(%r12), %r11d
	movzbl	14(%r12), %r10d
	movzbl	15(%r12), %edx
	movl	%r11d, %r9d
	xorb	%r8b, %r9b
	movl	%r9d, %eax
	xorb	%r10b, %al
	movl	%eax, %ebx
	xorb	%dl, %bl
	leal	(%r9,%r9), %esi
	movl	%r9d, %edi
	shrb	$7, %dil
	movzbl	%dil, %edi
	movq	%rdi, 32(%rsp)
	movq	32(%rsp), %rdi
	negb	%dil
	andb	$27, %dil
	xorb	%sil, %dil
	xorb	%r8b, %dil
	xorb	%bl, %dil
	movb	%dil, 12(%r12)
	movl	%r10d, %esi
	xorb	%r11b, %sil
	leal	(%rsi,%rsi), %edi
	shrb	$7, %sil
	movzbl	%sil, %esi
	movq	%rsi, 32(%rsp)
	movq	32(%rsp), %rsi
	negb	%sil
	andb	$27, %sil
	xorb	%dil, %sil
	xorb	%r11b, %sil
	xorb	%bl, %sil
	movb	%sil, 13(%r12)
	xorb	%dl, %r10b
	leal	(%r10,%r10), %r11d
	shrb	$7, %r10b
	movzbl	%r10b, %r10d
	movq	%r10, 32(%rsp)
	movq	32(%rsp), %r10
	negb	%r10b
	andb	$27, %r10b
	xorb	%r11b, %r10b
	xorb	%dl, %r9b
	xorb	%r10b, %r9b
	movb	%r9b, 14(%r12)
	xorb	%r8b, %dl
	leal	(%rdx,%rdx), %r8d
	shrb	$7, %dl
	movzbl	%dl, %edx
	movq	%rdx, 32(%rsp)
	movq	32(%rsp), %rdx
	negb	%dl
	andb	$27, %dl
	xorb	%r8b, %dl
	xorb	%al, %dl
	movb	%dl, 15(%r12)
.LBB3_6:
	movq	%r13, %rax
	shlq	$4, %rax
	cmpq	$240, %rax
	jae	.LBB3_12
	movq	96(%rsp), %rcx
	movzbl	(%rcx,%rax), %edx
	xorb	%dl, (%r12)
	movzbl	1(%rcx,%rax), %edx
	xorb	%dl, 1(%r12)
	movzbl	2(%rcx,%rax), %edx
	xorb	%dl, 2(%r12)
	movzbl	3(%rcx,%rax), %edx
	xorb	%dl, 3(%r12)
	movzbl	4(%rcx,%rax), %edx
	xorb	%dl, 4(%r12)
	movzbl	5(%rcx,%rax), %edx
	xorb	%dl, 5(%r12)
	movzbl	6(%rcx,%rax), %edx
	xorb	%dl, 6(%r12)
	movzbl	7(%rcx,%rax), %edx
	xorb	%dl, 7(%r12)
	movzbl	8(%rcx,%rax), %edx
	xorb	%dl, 8(%r12)
	movzbl	9(%rcx,%rax), %edx
	xorb	%dl, 9(%r12)
	movzbl	10(%rcx,%rax), %edx
	xorb	%dl, 10(%r12)
	movzbl	11(%rcx,%rax), %edx
	xorb	%dl, 11(%r12)
	movzbl	12(%rcx,%rax), %edx
	xorb	%dl, 12(%r12)
	movzbl	13(%rcx,%rax), %edx
	xorb	%dl, 13(%r12)
	movzbl	14(%rcx,%rax), %edx
	xorb	%dl, 14(%r12)
	movzbl	15(%rcx,%rax), %eax
	xorb	%al, 15(%r12)
	cmpq	%r14, %r13
	jae	.LBB3_10
	movq	80(%rsp), %rdx
	movq	%rdx, %rax
	cmpq	%r14, %rdx
	jbe	.LBB3_3
.LBB3_10:
	addq	$392, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB3_12:
	leaq	16(%rax), %rdx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.6(%rip), %r9
	movl	$240, %r8d
	movq	%rax, %rcx
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3gcmNtB2_3Gcm3tag;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3gcmNtB2_3Gcm3tag,unique,4
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3gcmNtB2_3Gcm3tag:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$120, %rsp
	movq	%r9, %rsi
	movq	%r8, 96(%rsp)
	movq	%rcx, 112(%rsp)
	movq	224(%rsp), %rax
	movabsq	$9223372036854775792, %r9
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movzbl	272(%rdx), %r8d
	movq	(%rdx), %r15
	bswapq	%r15
	movq	%rdx, 104(%rsp)
	movq	8(%rdx), %rcx
	bswapq	%rcx
	movq	%rcx, 80(%rsp)
	movb	%r8b, 47(%rsp)
	testb	%r8b, %r8b
	je	.LBB4_1
	movq	%rax, %rbx
	andq	%r9, %rbx
	leaq	(%rsi,%rbx), %r13
	movl	%eax, %edi
	andl	$15, %edi
	cmpq	$16, %rax
	jb	.LBB4_31
	movq	48(%rsp), %rdx
	movq	56(%rsp), %rax
	xorl	%r14d, %r14d
	movq	80(%rsp), %r12
	.p2align	4
.LBB4_29:
	xorq	8(%rsi,%r14), %rax
	xorq	(%rsi,%r14), %rdx
	bswapq	%rdx
	bswapq	%rax
	movq	%rax, %rcx
	movq	%r12, %r8
	movq	%r15, %r9
	callq	_RNvNtNtCs3ONsSsjNgxw_12toyos_crypto4arch6x86_645ghash
	bswapq	%rax
	bswapq	%rdx
	addq	$16, %r14
	cmpq	%r14, %rbx
	jne	.LBB4_29
	movq	%rdx, 48(%rsp)
	movq	%rax, 56(%rsp)
	jmp	.LBB4_31
.LBB4_1:
	movq	%rsi, %r13
	movq	%rax, %rdi
.LBB4_31:
	movabsq	$-2233785415175766016, %rsi
	testq	%rdi, %rdi
	movq	%r15, 88(%rsp)
	je	.LBB4_2
	xorl	%ebx, %ebx
	jmp	.LBB4_33
	.p2align	4
.LBB4_43:
	movq	%r9, %rcx
	movq	80(%rsp), %r8
	movq	%r15, %r9
	callq	_RNvNtNtCs3ONsSsjNgxw_12toyos_crypto4arch6x86_645ghash
	movq	%rdx, %r8
.LBB4_44:
	bswapq	%r8
	bswapq	%rax
	addq	%r14, %r13
	movq	%rax, 56(%rsp)
	movq	%r8, 48(%rsp)
	subq	%r14, %rdi
	movq	88(%rsp), %r15
	je	.LBB4_2
.LBB4_33:
	cmpq	$16, %rdi
	movl	$16, %r14d
	cmovbq	%rdi, %r14
	movl	%r14d, %eax
	andl	$3, %eax
	cmpq	$4, %rdi
	jae	.LBB4_35
	xorl	%edx, %edx
	jmp	.LBB4_38
	.p2align	4
.LBB4_35:
	movl	%r14d, %ecx
	andl	$28, %ecx
	xorl	%edx, %edx
	.p2align	4
.LBB4_36:
	movzbl	(%r13,%rdx), %r8d
	xorb	%r8b, 48(%rsp,%rdx)
	movzbl	1(%r13,%rdx), %r8d
	xorb	%r8b, 49(%rsp,%rdx)
	movzbl	2(%r13,%rdx), %r8d
	xorb	%r8b, 50(%rsp,%rdx)
	movzbl	3(%r13,%rdx), %r8d
	xorb	%r8b, 51(%rsp,%rdx)
	addq	$4, %rdx
	cmpq	%rdx, %rcx
	jne	.LBB4_36
	testq	%rax, %rax
	je	.LBB4_40
.LBB4_38:
	leaq	(%rdx,%r13), %rcx
	addq	%rsp, %rdx
	addq	$48, %rdx
	xorl	%r8d, %r8d
	.p2align	4
.LBB4_39:
	movzbl	(%rcx,%r8), %r9d
	xorb	%r9b, (%rdx,%r8)
	incq	%r8
	cmpq	%r8, %rax
	jne	.LBB4_39
.LBB4_40:
	movq	48(%rsp), %rdx
	bswapq	%rdx
	movq	56(%rsp), %r9
	bswapq	%r9
	cmpb	$0, 47(%rsp)
	jne	.LBB4_43
	movl	$129, %r10d
	movq	80(%rsp), %r11
	xorl	%eax, %eax
	xorl	%r8d, %r8d
	.p2align	4
.LBB4_42:
	leal	-2(%r10), %ecx
	movq	%r9, %r12
	shrdq	%cl, %rdx, %r12
	movq	%rdx, %rbp
	shrq	%cl, %rbp
	testb	$64, %cl
	cmoveq	%r12, %rbp
	andl	$1, %ebp
	movq	%rbp, 64(%rsp)
	xorl	%ecx, %ecx
	subq	64(%rsp), %rcx
	movl	$0, %r12d
	sbbq	%r12, %r12
	andq	%r15, %r12
	xorq	%r12, %r8
	andq	%r11, %rcx
	xorq	%rcx, %rax
	movl	%r11d, %ecx
	andl	$1, %ecx
	movq	%rcx, 64(%rsp)
	cmpq	64(%rsp), %rbx
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	shrdq	$1, %r15, %r11
	shrq	%r15
	andq	%rsi, %rcx
	xorq	%rcx, %r15
	decl	%r10d
	cmpl	$1, %r10d
	ja	.LBB4_42
	jmp	.LBB4_44
.LBB4_2:
	movq	240(%rsp), %rdi
	movq	232(%rsp), %rbx
	cmpb	$0, 47(%rsp)
	je	.LBB4_3
	movabsq	$9223372036854775792, %rbp
	andq	%rdi, %rbp
	leaq	(%rbx,%rbp), %r13
	movq	%rdi, %rax
	andl	$15, %edi
	cmpq	$16, %rax
	jb	.LBB4_8
	movq	48(%rsp), %rdx
	movq	56(%rsp), %rax
	xorl	%r14d, %r14d
	movq	80(%rsp), %r12
	.p2align	4
.LBB4_6:
	xorq	8(%rbx,%r14), %rax
	xorq	(%rbx,%r14), %rdx
	bswapq	%rdx
	bswapq	%rax
	movq	%rax, %rcx
	movq	%r12, %r8
	movq	%r15, %r9
	callq	_RNvNtNtCs3ONsSsjNgxw_12toyos_crypto4arch6x86_645ghash
	bswapq	%rax
	bswapq	%rdx
	addq	$16, %r14
	cmpq	%r14, %rbp
	jne	.LBB4_6
	movq	%rdx, 48(%rsp)
	movq	%rax, 56(%rsp)
.LBB4_8:
	testq	%rdi, %rdi
	je	.LBB4_45
.LBB4_9:
	xorl	%ebx, %ebx
	jmp	.LBB4_10
	.p2align	4
.LBB4_20:
	movq	%rbp, %rcx
	movq	%r12, %rdx
	movq	80(%rsp), %r8
	movq	%r15, %r9
	callq	_RNvNtNtCs3ONsSsjNgxw_12toyos_crypto4arch6x86_645ghash
.LBB4_21:
	addq	%r14, %r13
	movq	%rax, %rcx
	bswapq	%rcx
	movq	%rcx, 56(%rsp)
	movq	%rdx, %rcx
	bswapq	%rcx
	movq	%rcx, 48(%rsp)
	subq	%r14, %rdi
	movq	88(%rsp), %r15
	je	.LBB4_22
.LBB4_10:
	cmpq	$16, %rdi
	movl	$16, %r14d
	cmovbq	%rdi, %r14
	movl	%r14d, %eax
	andl	$3, %eax
	cmpq	$4, %rdi
	jae	.LBB4_12
	xorl	%edx, %edx
	jmp	.LBB4_15
	.p2align	4
.LBB4_12:
	movl	%r14d, %ecx
	andl	$28, %ecx
	xorl	%edx, %edx
	.p2align	4
.LBB4_13:
	movzbl	(%r13,%rdx), %r8d
	xorb	%r8b, 48(%rsp,%rdx)
	movzbl	1(%r13,%rdx), %r8d
	xorb	%r8b, 49(%rsp,%rdx)
	movzbl	2(%r13,%rdx), %r8d
	xorb	%r8b, 50(%rsp,%rdx)
	movzbl	3(%r13,%rdx), %r8d
	xorb	%r8b, 51(%rsp,%rdx)
	addq	$4, %rdx
	cmpq	%rdx, %rcx
	jne	.LBB4_13
	testq	%rax, %rax
	je	.LBB4_17
.LBB4_15:
	leaq	(%rdx,%r13), %rcx
	addq	%rsp, %rdx
	addq	$48, %rdx
	xorl	%r8d, %r8d
	.p2align	4
.LBB4_16:
	movzbl	(%rcx,%r8), %r9d
	xorb	%r9b, (%rdx,%r8)
	incq	%r8
	cmpq	%r8, %rax
	jne	.LBB4_16
.LBB4_17:
	movq	48(%rsp), %r12
	bswapq	%r12
	movq	56(%rsp), %rbp
	bswapq	%rbp
	cmpb	$0, 47(%rsp)
	jne	.LBB4_20
	movl	$129, %r10d
	movq	80(%rsp), %r11
	xorl	%eax, %eax
	xorl	%edx, %edx
	.p2align	4
.LBB4_19:
	leal	-2(%r10), %ecx
	movq	%rbp, %r9
	shrdq	%cl, %r12, %r9
	movq	%r12, %r8
	shrq	%cl, %r8
	testb	$64, %cl
	cmoveq	%r9, %r8
	andl	$1, %r8d
	movq	%r8, 64(%rsp)
	xorl	%ecx, %ecx
	subq	64(%rsp), %rcx
	movl	$0, %r8d
	sbbq	%r8, %r8
	andq	%r15, %r8
	xorq	%r8, %rdx
	andq	%r11, %rcx
	xorq	%rcx, %rax
	movl	%r11d, %ecx
	andl	$1, %ecx
	movq	%rcx, 64(%rsp)
	cmpq	64(%rsp), %rbx
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	shrdq	$1, %r15, %r11
	shrq	%r15
	andq	%rsi, %rcx
	xorq	%rcx, %r15
	decl	%r10d
	cmpl	$1, %r10d
	ja	.LBB4_19
	jmp	.LBB4_21
.LBB4_3:
	movq	%rbx, %r13
	testq	%rdi, %rdi
	jne	.LBB4_9
.LBB4_45:
	movq	48(%rsp), %rdx
	movq	56(%rsp), %rax
	bswapq	%rdx
	bswapq	%rax
.LBB4_22:
	movq	240(%rsp), %rcx
	leaq	(,%rcx,8), %r8
	xorq	%rax, %r8
	movq	224(%rsp), %r11
	shldq	$3, %rcx, %r11
	xorq	%rdx, %r11
	cmpb	$0, 47(%rsp)
	je	.LBB4_23
	movq	%r8, %rcx
	movq	%r11, %rdx
	movq	80(%rsp), %r8
	movq	%r15, %r9
	callq	_RNvNtNtCs3ONsSsjNgxw_12toyos_crypto4arch6x86_645ghash
	movq	%rax, %r13
	movq	%rdx, %rbp
	jmp	.LBB4_26
.LBB4_23:
	movl	$129, %eax
	xorl	%edx, %edx
	xorl	%r13d, %r13d
	xorl	%ebp, %ebp
	movq	80(%rsp), %rdi
	.p2align	4
.LBB4_24:
	leal	-2(%rax), %ecx
	movq	%r8, %r9
	shrdq	%cl, %r11, %r9
	movq	%r11, %r10
	shrq	%cl, %r10
	testb	$64, %cl
	cmoveq	%r9, %r10
	andl	$1, %r10d
	movq	%r10, 64(%rsp)
	xorl	%ecx, %ecx
	subq	64(%rsp), %rcx
	movl	$0, %r9d
	sbbq	%r9, %r9
	andq	%r15, %r9
	xorq	%r9, %rbp
	andq	%rdi, %rcx
	xorq	%rcx, %r13
	movl	%edi, %ecx
	andl	$1, %ecx
	movq	%rcx, 64(%rsp)
	cmpq	64(%rsp), %rdx
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	shrdq	$1, %r15, %rdi
	shrq	%r15
	andq	%rsi, %rcx
	xorq	%rcx, %r15
	decl	%eax
	cmpl	$1, %eax
	ja	.LBB4_24
.LBB4_26:
	bswapq	%rbp
	bswapq	%r13
	movq	%r13, 56(%rsp)
	movq	%rbp, 48(%rsp)
	movb	$0, 78(%rsp)
	movw	$0, 76(%rsp)
	movq	96(%rsp), %rcx
	movq	(%rcx), %rax
	movq	%rax, 64(%rsp)
	movl	8(%rcx), %eax
	movl	%eax, 72(%rsp)
	movb	$1, 79(%rsp)
	movq	104(%rsp), %rcx
	addq	$16, %rcx
	leaq	64(%rsp), %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt
	movzbl	64(%rsp), %eax
	xorb	%bpl, %al
	movb	%al, 48(%rsp)
	movl	%r13d, %eax
	shrl	$8, %eax
	movl	%ebp, %ecx
	shrl	$8, %ecx
	xorb	65(%rsp), %cl
	movb	%cl, 49(%rsp)
	movl	%r13d, %ecx
	shrl	$16, %ecx
	movl	%ebp, %edx
	shrl	$16, %edx
	xorb	66(%rsp), %dl
	movb	%dl, 50(%rsp)
	movl	%r13d, %edx
	shrl	$24, %edx
	movl	%ebp, %r8d
	shrl	$24, %r8d
	xorb	67(%rsp), %r8b
	movb	%r8b, 51(%rsp)
	movq	%r13, %r8
	movq	%rbp, %r9
	shrq	$32, %r9
	xorb	68(%rsp), %r9b
	shrq	$32, %r8
	movb	%r9b, 52(%rsp)
	movq	%r13, %r9
	movq	%rbp, %r10
	shrq	$40, %r10
	xorb	69(%rsp), %r10b
	movb	%r10b, 53(%rsp)
	movq	%rbp, %r10
	shrq	$48, %r10
	xorb	70(%rsp), %r10b
	shrq	$40, %r9
	shrq	$56, %rbp
	xorb	71(%rsp), %bpl
	movb	%r10b, 54(%rsp)
	movb	%bpl, 55(%rsp)
	xorb	72(%rsp), %r13b
	movb	%r13b, 56(%rsp)
	xorb	73(%rsp), %al
	movb	%al, 57(%rsp)
	xorb	74(%rsp), %cl
	xorb	75(%rsp), %dl
	movb	%cl, 58(%rsp)
	movb	%dl, 59(%rsp)
	xorb	76(%rsp), %r8b
	movb	%r8b, 60(%rsp)
	xorb	77(%rsp), %r9b
	movb	%r9b, 61(%rsp)
	movzbl	78(%rsp), %eax
	xorb	%al, 62(%rsp)
	movzbl	79(%rsp), %eax
	xorb	%al, 63(%rsp)
	movq	48(%rsp), %rax
	movq	112(%rsp), %rcx
	movq	%rax, (%rcx)
	movq	56(%rsp), %rax
	movq	%rax, 8(%rcx)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	#MEMBARRIER
	addq	$120, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB2_4Hash6digest;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB2_4Hash6digest,unique,5
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB2_4Hash6digest:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$552, %rsp
	movq	%r9, %rsi
	movq	%r8, %rdi
	movq	%rcx, %rbx
	movq	$0, 312(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	shlq	$4, %rsi
	addq	%r8, %rsi
	testb	%dl, %dl
	je	.LBB5_20
	movzbl	%dl, %eax
	cmpl	$1, %eax
	jne	.LBB5_3
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movabsq	$-3766243637369397544, %rax
	movq	%rax, 160(%rsp)
	movabsq	$7105036623409894663, %rax
	movq	%rax, 168(%rsp)
	movabsq	$-7973340178411365097, %rax
	movq	%rax, 176(%rsp)
	movabsq	$1526699215303891257, %rax
	movq	%rax, 184(%rsp)
	movabsq	$7436329637833083697, %rax
	movq	%rax, 192(%rsp)
	movabsq	$-8163818279084223215, %rax
	movq	%rax, 200(%rsp)
	movabsq	$-2662702644619276377, %rax
	movq	%rax, 208(%rsp)
	movabsq	$5167115440072839076, %rax
	movq	%rax, 216(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	leaq	32(%rsp), %r14
	.p2align	4
.LBB5_10:
	movq	(%rdi), %rdx
	movq	8(%rdi), %r8
	movq	%r14, %rcx
	callq	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846update
	cmpb	$-1, %al
	jne	.LBB5_11
	addq	$16, %rdi
	cmpq	%rsi, %rdi
	jne	.LBB5_10
	leaq	320(%rsp), %rsi
	leaq	32(%rsp), %rdx
	movl	$224, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	leaq	256(%rsp), %rcx
	movq	%rsi, %rdx
	callq	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3848finalize
	jmp	.LBB5_8
.LBB5_20:
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movabsq	$-4942790177982912921, %rax
	movq	%rax, 96(%rsp)
	movabsq	$-6534734903820487822, %rax
	movq	%rax, 104(%rsp)
	movabsq	$-7276294671082564993, %rax
	movq	%rax, 112(%rsp)
	movabsq	$6620516960021240235, %rax
	movq	%rax, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	leaq	32(%rsp), %r14
	.p2align	4
.LBB5_5:
	movq	(%rdi), %rdx
	movq	8(%rdi), %r8
	movq	%r14, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update
	cmpb	$-1, %al
	jne	.LBB5_6
	addq	$16, %rdi
	cmpq	%rsi, %rdi
	jne	.LBB5_5
	leaq	320(%rsp), %rdx
	leaq	32(%rsp), %rsi
	movl	$16, %ecx
	movq	%rdx, %rdi
	rep;movsq (%rsi), %es:(%rdi)
	leaq	256(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2568finalize
	jmp	.LBB5_8
.LBB5_3:
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movabsq	$7640891576956012808, %rax
	movq	%rax, 160(%rsp)
	movabsq	$-4942790177534073029, %rax
	movq	%rax, 168(%rsp)
	movabsq	$4354685564936845355, %rax
	movq	%rax, 176(%rsp)
	movabsq	$-6534734903238641935, %rax
	movq	%rax, 184(%rsp)
	movabsq	$5840696475078001361, %rax
	movq	%rax, 192(%rsp)
	movabsq	$-7276294671716946913, %rax
	movq	%rax, 200(%rsp)
	movabsq	$2270897969802886507, %rax
	movq	%rax, 208(%rsp)
	movabsq	$6620516959819538809, %rax
	movq	%rax, 216(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	leaq	32(%rsp), %r14
	.p2align	4
.LBB5_14:
	movq	(%rdi), %rdx
	movq	8(%rdi), %r8
	movq	%r14, %rcx
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update
	cmpb	$-1, %al
	jne	.LBB5_15
	addq	$16, %rdi
	cmpq	%rsi, %rdi
	jne	.LBB5_14
	leaq	320(%rsp), %rsi
	leaq	32(%rsp), %rdx
	movl	$224, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	leaq	256(%rsp), %rcx
	movq	%rsi, %rdx
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5128finalize
.LBB5_8:
	movq	312(%rsp), %rax
	movq	%rax, 57(%rbx)
	movq	304(%rsp), %rax
	movq	%rax, 49(%rbx)
	movq	296(%rsp), %rax
	movq	%rax, 41(%rbx)
	movq	288(%rsp), %rax
	movq	%rax, 33(%rbx)
	movq	280(%rsp), %rax
	movq	%rax, 25(%rbx)
	movq	272(%rsp), %rax
	movq	%rax, 17(%rbx)
	movq	256(%rsp), %rax
	movq	264(%rsp), %rcx
	movq	%rcx, 9(%rbx)
	movq	%rax, 1(%rbx)
	movb	$0, (%rbx)
	jmp	.LBB5_19
.LBB5_11:
	movw	$1, (%rbx)
	xorl	%eax, %eax
	.p2align	4
.LBB5_12:
	movb	$0, 32(%rsp,%rax)
	movb	$0, 33(%rsp,%rax)
	movb	$0, 34(%rsp,%rax)
	movb	$0, 35(%rsp,%rax)
	movb	$0, 36(%rsp,%rax)
	movb	$0, 37(%rsp,%rax)
	movb	$0, 38(%rsp,%rax)
	movb	$0, 39(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB5_12
	jmp	.LBB5_17
.LBB5_6:
	movw	$1, (%rbx)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	#MEMBARRIER
	movl	$0, 96(%rsp)
	movl	$0, 100(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	jmp	.LBB5_18
.LBB5_15:
	movw	$1, (%rbx)
	xorl	%eax, %eax
	.p2align	4
.LBB5_16:
	movb	$0, 32(%rsp,%rax)
	movb	$0, 33(%rsp,%rax)
	movb	$0, 34(%rsp,%rax)
	movb	$0, 35(%rsp,%rax)
	movb	$0, 36(%rsp,%rax)
	movb	$0, 37(%rsp,%rax)
	movb	$0, 38(%rsp,%rax)
	movb	$0, 39(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB5_16
.LBB5_17:
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
.LBB5_18:
	#MEMBARRIER
.LBB5_19:
	addq	$552, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3new;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3new,unique,6
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3new:
	subq	$64, %rsp
	movzbl	(%rdx), %eax
	movb	%al, 63(%rsp)
	movb	%al, (%rcx)
	movzbl	1(%rdx), %eax
	movb	%al, 62(%rsp)
	movb	%al, 1(%rcx)
	movzbl	2(%rdx), %eax
	movb	%al, 61(%rsp)
	movb	%al, 2(%rcx)
	movzbl	3(%rdx), %eax
	movb	%al, 60(%rsp)
	movb	%al, 3(%rcx)
	movzbl	4(%rdx), %eax
	movb	%al, 59(%rsp)
	movb	%al, 4(%rcx)
	movzbl	5(%rdx), %eax
	movb	%al, 58(%rsp)
	movb	%al, 5(%rcx)
	movzbl	6(%rdx), %eax
	movb	%al, 57(%rsp)
	movb	%al, 6(%rcx)
	movzbl	7(%rdx), %eax
	movb	%al, 56(%rsp)
	movb	%al, 7(%rcx)
	movzbl	8(%rdx), %eax
	movb	%al, 55(%rsp)
	movb	%al, 8(%rcx)
	movzbl	9(%rdx), %eax
	movb	%al, 54(%rsp)
	movb	%al, 9(%rcx)
	movzbl	10(%rdx), %eax
	movb	%al, 53(%rsp)
	movb	%al, 10(%rcx)
	movzbl	11(%rdx), %eax
	movb	%al, 52(%rsp)
	movb	%al, 11(%rcx)
	movzbl	12(%rdx), %eax
	movb	%al, 51(%rsp)
	movb	%al, 12(%rcx)
	movzbl	13(%rdx), %eax
	movb	%al, 50(%rsp)
	movb	%al, 13(%rcx)
	movzbl	14(%rdx), %eax
	movb	%al, 49(%rsp)
	movb	%al, 14(%rcx)
	movzbl	15(%rdx), %eax
	movb	%al, 48(%rsp)
	movb	%al, 15(%rcx)
	movzbl	16(%rdx), %eax
	movb	%al, 47(%rsp)
	movb	%al, 16(%rcx)
	movzbl	17(%rdx), %eax
	movb	%al, 46(%rsp)
	movb	%al, 17(%rcx)
	movzbl	18(%rdx), %eax
	movb	%al, 45(%rsp)
	movb	%al, 18(%rcx)
	movzbl	19(%rdx), %eax
	movb	%al, 44(%rsp)
	movb	%al, 19(%rcx)
	movzbl	20(%rdx), %eax
	movb	%al, 43(%rsp)
	movb	%al, 20(%rcx)
	movzbl	21(%rdx), %eax
	movb	%al, 42(%rsp)
	movb	%al, 21(%rcx)
	movzbl	22(%rdx), %eax
	movb	%al, 41(%rsp)
	movb	%al, 22(%rcx)
	movzbl	23(%rdx), %eax
	movb	%al, 40(%rsp)
	movb	%al, 23(%rcx)
	movzbl	24(%rdx), %eax
	movb	%al, 39(%rsp)
	movb	%al, 24(%rcx)
	movzbl	25(%rdx), %eax
	movb	%al, 38(%rsp)
	movb	%al, 25(%rcx)
	movzbl	26(%rdx), %eax
	movb	%al, 37(%rsp)
	movb	%al, 26(%rcx)
	movzbl	27(%rdx), %eax
	movb	%al, 36(%rsp)
	movb	%al, 27(%rcx)
	movzbl	28(%rdx), %eax
	movb	%al, 35(%rsp)
	movb	%al, 28(%rcx)
	movzbl	29(%rdx), %eax
	movb	%al, 34(%rsp)
	movb	%al, 29(%rcx)
	movzbl	30(%rdx), %eax
	movb	%al, 33(%rsp)
	movb	%al, 30(%rcx)
	movzbl	31(%rdx), %eax
	movb	%al, 32(%rsp)
	movb	%al, 31(%rcx)
	movzbl	32(%rdx), %eax
	movb	%al, 31(%rsp)
	movb	%al, 32(%rcx)
	movzbl	33(%rdx), %eax
	movb	%al, 30(%rsp)
	movb	%al, 33(%rcx)
	movzbl	34(%rdx), %eax
	movb	%al, 29(%rsp)
	movb	%al, 34(%rcx)
	movzbl	35(%rdx), %eax
	movb	%al, 28(%rsp)
	movb	%al, 35(%rcx)
	movzbl	36(%rdx), %eax
	movb	%al, 27(%rsp)
	movb	%al, 36(%rcx)
	movzbl	37(%rdx), %eax
	movb	%al, 26(%rsp)
	movb	%al, 37(%rcx)
	movzbl	38(%rdx), %eax
	movb	%al, 25(%rsp)
	movb	%al, 38(%rcx)
	movzbl	39(%rdx), %eax
	movb	%al, 24(%rsp)
	movb	%al, 39(%rcx)
	movzbl	40(%rdx), %eax
	movb	%al, 23(%rsp)
	movb	%al, 40(%rcx)
	movzbl	41(%rdx), %eax
	movb	%al, 22(%rsp)
	movb	%al, 41(%rcx)
	movzbl	42(%rdx), %eax
	movb	%al, 21(%rsp)
	movb	%al, 42(%rcx)
	movzbl	43(%rdx), %eax
	movb	%al, 20(%rsp)
	movb	%al, 43(%rcx)
	movzbl	44(%rdx), %eax
	movb	%al, 19(%rsp)
	movb	%al, 44(%rcx)
	movzbl	45(%rdx), %eax
	movb	%al, 18(%rsp)
	movb	%al, 45(%rcx)
	movzbl	46(%rdx), %eax
	movb	%al, 17(%rsp)
	movb	%al, 46(%rcx)
	movzbl	47(%rdx), %eax
	movb	%al, 16(%rsp)
	movb	%al, 47(%rcx)
	movzbl	48(%rdx), %eax
	movb	%al, 15(%rsp)
	movb	%al, 48(%rcx)
	movzbl	49(%rdx), %eax
	movb	%al, 14(%rsp)
	movb	%al, 49(%rcx)
	movzbl	50(%rdx), %eax
	movb	%al, 13(%rsp)
	movb	%al, 50(%rcx)
	movzbl	51(%rdx), %eax
	movb	%al, 12(%rsp)
	movb	%al, 51(%rcx)
	movzbl	52(%rdx), %eax
	movb	%al, 11(%rsp)
	movb	%al, 52(%rcx)
	movzbl	53(%rdx), %eax
	movb	%al, 10(%rsp)
	movb	%al, 53(%rcx)
	movzbl	54(%rdx), %eax
	movb	%al, 9(%rsp)
	movb	%al, 54(%rcx)
	movzbl	55(%rdx), %eax
	movb	%al, 8(%rsp)
	movb	%al, 55(%rcx)
	movzbl	56(%rdx), %eax
	movb	%al, 7(%rsp)
	movb	%al, 56(%rcx)
	movzbl	57(%rdx), %eax
	movb	%al, 6(%rsp)
	movb	%al, 57(%rcx)
	movzbl	58(%rdx), %eax
	movb	%al, 5(%rsp)
	movb	%al, 58(%rcx)
	movzbl	59(%rdx), %eax
	movb	%al, 4(%rsp)
	movb	%al, 59(%rcx)
	movzbl	60(%rdx), %eax
	movb	%al, 3(%rsp)
	movb	%al, 60(%rcx)
	movzbl	61(%rdx), %eax
	movb	%al, 2(%rsp)
	movb	%al, 61(%rcx)
	movzbl	62(%rdx), %eax
	movb	%al, 1(%rsp)
	movb	%al, 62(%rcx)
	movzbl	63(%rdx), %eax
	movb	%al, (%rsp)
	movb	%al, 63(%rcx)
	movb	$0, 63(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 1(%rsp)
	movb	$0, (%rsp)
	#MEMBARRIER
	addq	$64, %rsp
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3tag;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3tag,unique,7
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3tag:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$312, %rsp
	movq	%r9, %r14
	movq	%rcx, 184(%rsp)
	bswapl	%r8d
	movabsq	$7719281312240119090, %rax
	movq	%rax, 128(%rsp)
	movabsq	$3684054920433006693, %rax
	movq	%rax, 120(%rsp)
	movq	(%rdx), %rax
	movq	8(%rdx), %rcx
	movq	%rax, 136(%rsp)
	movq	%rcx, 144(%rsp)
	movq	16(%rdx), %rax
	movq	%rax, 152(%rsp)
	movq	24(%rdx), %rax
	movq	%rax, 160(%rsp)
	movq	$0, 168(%rsp)
	movl	$0, 176(%rsp)
	movl	%r8d, 180(%rsp)
	leaq	40(%rsp), %rcx
	leaq	120(%rsp), %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha6rounds
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	movl	$0, 144(%rsp)
	movl	$0, 148(%rsp)
	movl	$0, 152(%rsp)
	movl	$0, 156(%rsp)
	movl	$0, 160(%rsp)
	movl	$0, 164(%rsp)
	movl	$0, 168(%rsp)
	movl	$0, 172(%rsp)
	movl	$0, 176(%rsp)
	movl	$0, 180(%rsp)
	#MEMBARRIER
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movzwl	40(%rsp), %ebx
	movzbl	42(%rsp), %eax
	movzbl	44(%rsp), %r10d
	movzbl	45(%rsp), %esi
	movzbl	46(%rsp), %r11d
	movzbl	43(%rsp), %ebp
	movzbl	47(%rsp), %r12d
	movzbl	48(%rsp), %edi
	movzwl	49(%rsp), %r13d
	shll	$8, %r13d
	movzbl	51(%rsp), %r15d
	movzbl	52(%rsp), %r8d
	movzbl	53(%rsp), %r9d
	movzbl	54(%rsp), %ecx
	movzbl	55(%rsp), %edx
	andb	$15, %bpl
	andb	$15, %r12b
	andb	$15, %r15b
	andb	$15, %dl
	movzbl	%dl, %edx
	shlq	$56, %rdx
	shlq	$48, %rcx
	orq	%rdx, %rcx
	shlq	$40, %r9
	orq	%rcx, %r9
	andl	$-4, %r8d
	shlq	$32, %r8
	movzbl	%r15b, %r15d
	shll	$24, %r15d
	orq	%r8, %r15
	orq	%r13, %r15
	movzbl	%r12b, %ecx
	shlq	$56, %rcx
	shlq	$48, %r11
	orq	%rcx, %r11
	shlq	$40, %rsi
	andl	$-4, %r10d
	shlq	$32, %r10
	movzbl	%bpl, %ecx
	shll	$24, %ecx
	shll	$16, %eax
	orq	%rbx, %rax
	orq	%rcx, %rax
	orq	%r10, %rax
	orq	%rsi, %rax
	leal	(%r15,%rdi), %r8d
	orq	%r11, %rax
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	movq	%rdx, 200(%rsp)
	movq	%rcx, 192(%rsp)
	movl	%eax, %ecx
	andl	$67108863, %ecx
	shrq	$26, %rax
	shldq	$12, %r11, %r8
	andl	$67108863, %eax
	andl	$67092735, %r8d
	shrq	$14, %r15
	movl	%r15d, %edx
	shrq	$40, %r9
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	%rcx, 224(%rsp)
	movq	%rax, 232(%rsp)
	movq	%r8, 240(%rsp)
	movq	%rdx, 248(%rsp)
	movq	%r9, 256(%rsp)
	movq	$0, 304(%rsp)
	movb	$0, 120(%rsp)
	movb	$0, 119(%rsp)
	movb	$0, 118(%rsp)
	movb	$0, 117(%rsp)
	movb	$0, 116(%rsp)
	movb	$0, 115(%rsp)
	movb	$0, 114(%rsp)
	movb	$0, 113(%rsp)
	movb	$0, 112(%rsp)
	movb	$0, 111(%rsp)
	movb	$0, 110(%rsp)
	movb	$0, 109(%rsp)
	movb	$0, 108(%rsp)
	movb	$0, 107(%rsp)
	movb	$0, 106(%rsp)
	movb	$0, 105(%rsp)
	#MEMBARRIER
	leaq	192(%rsp), %r15
	movl	$4, %r8d
	movq	%r15, %rcx
	movq	%r14, %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update
	movq	%r15, %rcx
	movq	416(%rsp), %rdx
	movq	424(%rsp), %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update
	movq	184(%rsp), %rcx
	movq	%r15, %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056finish
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	movb	$0, 96(%rsp)
	movb	$0, 97(%rsp)
	movb	$0, 98(%rsp)
	movb	$0, 99(%rsp)
	movb	$0, 100(%rsp)
	movb	$0, 101(%rsp)
	movb	$0, 102(%rsp)
	movb	$0, 103(%rsp)
	#MEMBARRIER
	addq	$312, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm,unique,8
	.globl	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey10aes128_gcm:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$600, %rsp
	movq	%r8, %rdi
	movq	%rcx, %rsi
	leaq	344(%rsp), %rbx
	movl	$16, %r8d
	movl	$10, %r9d
	movq	%rbx, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes6expand
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	leaq	56(%rsp), %rdx
	movq	%rbx, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt
	movq	56(%rsp), %rax
	movq	64(%rsp), %rcx
	movq	%rcx, 80(%rsp)
	movq	%rax, 72(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %r8
	cpuid
	xchgq	%rbx, %r8

	#NO_APP
	movl	%ecx, %ebp
	leaq	88(%rsp), %rcx
	movl	$256, %r8d
	movq	%rbx, %rdx
	callq	memcpy
	shrb	%bpl
	andb	$1, %bpl
	leaq	72(%rsp), %rdx
	movl	$272, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movb	%bpl, 272(%rsi)
	movq	(%rdi), %rax
	movq	%rax, 288(%rsi)
	movl	8(%rdi), %eax
	movl	%eax, 296(%rsi)
	movq	$0, 280(%rsi)
	movb	$0, 300(%rsi)
	movb	$0, 344(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 42(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$600, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm,unique,9
	.globl	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey10aes256_gcm:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$616, %rsp
	movq	%r8, %rdi
	movq	%rcx, %rsi
	leaq	360(%rsp), %rbx
	movl	$32, %r8d
	movl	$14, %r9d
	movq	%rbx, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes6expand
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	leaq	72(%rsp), %rdx
	movq	%rbx, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt
	movq	72(%rsp), %rax
	movq	80(%rsp), %rcx
	movq	%rcx, 96(%rsp)
	movq	%rax, 88(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %r8
	cpuid
	xchgq	%rbx, %r8

	#NO_APP
	movl	%ecx, %ebp
	leaq	104(%rsp), %rcx
	movl	$256, %r8d
	movq	%rbx, %rdx
	callq	memcpy
	shrb	%bpl
	andb	$1, %bpl
	leaq	88(%rsp), %rdx
	movl	$272, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movb	%bpl, 272(%rsi)
	movq	(%rdi), %rax
	movq	%rax, 288(%rsi)
	movl	8(%rdi), %eax
	movl	%eax, 296(%rsi)
	movq	$0, 280(%rsi)
	movb	$0, 300(%rsi)
	movb	$0, 360(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 42(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$616, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey4seal;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey4seal,unique,10
	.globl	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey4seal
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB2_10SealingKey4seal:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$120, %rsp
	movq	%rcx, %rax
	cmpb	$1, 300(%rdx)
	jne	.LBB10_2
	movw	$1537, (%rax)
	jmp	.LBB10_25
.LBB10_2:
	movq	%r9, %rdi
	movq	%rdx, %rsi
	movl	296(%rdx), %r9d
	movl	%r9d, 80(%rsp)
	movq	288(%rdx), %r10
	movq	280(%rdx), %rcx
	movq	%rcx, %rdx
	bswapq	%rdx
	movq	%r10, 72(%rsp)
	xorb	%dl, 76(%rsp)
	movl	%edx, %r10d
	shrl	$8, %r10d
	xorb	%r10b, 77(%rsp)
	movl	%edx, %r10d
	shrl	$16, %r10d
	xorb	%r10b, 78(%rsp)
	movl	%edx, %r10d
	shrl	$24, %r10d
	xorb	%r10b, 79(%rsp)
	movq	%rdx, %r10
	shrq	$32, %r10
	xorb	%r10b, %r9b
	movb	%r9b, 80(%rsp)
	movq	%rdx, %r9
	shrq	$40, %r9
	xorb	%r9b, 81(%rsp)
	movq	%rdx, %r9
	shrq	$48, %r9
	xorb	%r9b, 82(%rsp)
	shrq	$56, %rdx
	xorb	%dl, 83(%rsp)
	movzbl	272(%rsi), %edx
	cmpb	$2, %dl
	setne	%r9b
	movl	$4294967294, %r10d
	cmpq	%r10, %rcx
	seta	%r10b
	movb	$6, %cl
	testb	%r10b, %r9b
	jne	.LBB10_6
	movq	232(%rsp), %r14
	movq	224(%rsp), %rbx
	cmpb	$2, %dl
	je	.LBB10_17
	movabsq	$68719476704, %rcx
	cmpq	%rcx, %r14
	seta	%cl
	movq	%rdi, %rdx
	shrq	$61, %rdx
	setne	%dl
	orb	%cl, %dl
	jne	.LBB10_5
	movq	%r8, 112(%rsp)
	movq	%rax, 88(%rsp)
	testq	%r14, %r14
	je	.LBB10_26
	leaq	16(%rsi), %r12
	xorl	%r15d, %r15d
	leaq	56(%rsp), %r13
	jmp	.LBB10_13
	.p2align	4
.LBB10_12:
	addq	%rbp, %rbx
	incl	%r15d
	subq	%rbp, %r14
	je	.LBB10_26
.LBB10_13:
	cmpq	$16, %r14
	movl	$16, %ebp
	cmovbq	%r14, %rbp
	movl	80(%rsp), %eax
	movl	%eax, 64(%rsp)
	movq	72(%rsp), %rax
	movq	%rax, 56(%rsp)
	leal	2(%r15), %eax
	bswapl	%eax
	movl	%eax, 68(%rsp)
	movq	%r12, %rcx
	movq	%r13, %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt
	movl	%ebp, %eax
	andl	$3, %eax
	cmpq	$4, %r14
	jae	.LBB10_15
	xorl	%ecx, %ecx
	jmp	.LBB10_10
	.p2align	4
.LBB10_15:
	movl	%ebp, %edx
	andl	$28, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB10_16:
	movzbl	56(%rsp,%rcx), %r8d
	xorb	%r8b, (%rbx,%rcx)
	movzbl	57(%rsp,%rcx), %r8d
	xorb	%r8b, 1(%rbx,%rcx)
	movzbl	58(%rsp,%rcx), %r8d
	xorb	%r8b, 2(%rbx,%rcx)
	movzbl	59(%rsp,%rcx), %r8d
	xorb	%r8b, 3(%rbx,%rcx)
	addq	$4, %rcx
	cmpq	%rcx, %rdx
	jne	.LBB10_16
	testq	%rax, %rax
	je	.LBB10_12
.LBB10_10:
	leaq	(%rsp,%rcx), %rdx
	addq	$56, %rdx
	addq	%rbx, %rcx
	xorl	%r8d, %r8d
	.p2align	4
.LBB10_11:
	movzbl	(%rdx,%r8), %r9d
	xorb	%r9b, (%rcx,%r8)
	incq	%r8
	cmpq	%r8, %rax
	jne	.LBB10_11
	jmp	.LBB10_12
.LBB10_17:
	movabsq	$274877906880, %rcx
	cmpq	%rcx, %r14
	jbe	.LBB10_18
.LBB10_5:
	xorl	%ecx, %ecx
	jmp	.LBB10_6
.LBB10_26:
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	#MEMBARRIER
	movq	232(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	224(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	%rdi, 32(%rsp)
	leaq	56(%rsp), %rcx
	leaq	72(%rsp), %r8
	movq	%rsi, %rdx
	movq	112(%rsp), %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3gcmNtB2_3Gcm3tag
	jmp	.LBB10_21
.LBB10_18:
	movq	%r8, %r15
	movq	%rax, 88(%rsp)
	leaq	72(%rsp), %rdx
	movq	%rsi, %rcx
	movq	%rbx, %r8
	movq	%r14, %r9
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha3xor
	cmpb	$-1, %al
	je	.LBB10_20
	xorl	%ecx, %ecx
	movq	88(%rsp), %rax
.LBB10_6:
	movb	%cl, 1(%rax)
	movb	$1, (%rax)
.LBB10_25:
	addq	$120, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB10_20:
	movq	%r14, 48(%rsp)
	movq	%rbx, 40(%rsp)
	movq	%rdi, 32(%rsp)
	leaq	56(%rsp), %rcx
	leaq	72(%rsp), %r8
	movq	%rsi, %rdx
	movq	%r15, %r9
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4aead10chacha_tag
.LBB10_21:
	movzbl	56(%rsp), %ecx
	movq	57(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	64(%rsp), %rax
	movq	%rax, 103(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	#MEMBARRIER
	movq	280(%rsi), %rdx
	cmpq	$-1, %rdx
	movq	88(%rsp), %rax
	je	.LBB10_22
	incq	%rdx
	movq	%rdx, 280(%rsi)
	jmp	.LBB10_24
.LBB10_22:
	movb	$1, 300(%rsi)
.LBB10_24:
	movl	80(%rsp), %edx
	movl	%edx, 9(%rax)
	movq	72(%rsp), %rdx
	movq	%rdx, 1(%rax)
	movb	%cl, 13(%rax)
	movq	96(%rsp), %rcx
	movq	103(%rsp), %rdx
	movq	%rcx, 14(%rax)
	movq	%rdx, 21(%rax)
	movb	$0, (%rax)
	jmp	.LBB10_25

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566digest;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566digest,unique,11
	.globl	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566digest
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566digest:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$288, %rsp
	movq	%rcx, %rbx
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movabsq	$-4942790177982912921, %rax
	movq	%rax, 96(%rsp)
	movabsq	$-6534734903820487822, %rax
	movq	%rax, 104(%rsp)
	movabsq	$-7276294671082564993, %rax
	movq	%rax, 112(%rsp)
	movabsq	$6620516960021240235, %rax
	movq	%rax, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	leaq	32(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update
	cmpb	$-1, %al
	je	.LBB11_2
	movw	$1, (%rbx)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	#MEMBARRIER
	movl	$0, 96(%rsp)
	movl	$0, 100(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	#MEMBARRIER
	jmp	.LBB11_3
.LBB11_2:
	leaq	160(%rsp), %rdx
	leaq	32(%rsp), %rsi
	movl	$16, %ecx
	movq	%rdx, %rdi
	rep;movsq (%rsi), %es:(%rdi)
	leaq	1(%rbx), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2568finalize
	movb	$0, (%rbx)
.LBB11_3:
	movq	%rbx, %rax
	addq	$288, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update,unique,12
	.globl	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$40, %rsp
	movq	%r8, %rsi
	movq	%rdx, %rbx
	movq	%rcx, %rdi
	movq	104(%rcx), %rax
	movq	96(%rcx), %rcx
	addq	%r8, %rcx
	adcq	$0, %rax
	setb	%dl
	movq	%rcx, %r8
	shrq	$61, %r8
	orq	%rax, %r8
	setne	%r8b
	orb	%dl, %r8b
	je	.LBB12_2
	xorl	%eax, %eax
	jmp	.LBB12_13
.LBB12_2:
	movq	%rcx, 96(%rdi)
	movq	%rax, 104(%rdi)
	movq	112(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB12_6
	movl	$64, %r14d
	subq	%rcx, %r14
	cmpq	%rsi, %r14
	cmovaeq	%rsi, %r14
	leaq	(%r14,%rcx), %rdx
	cmpq	%rcx, %rdx
	jb	.LBB12_5
	cmpq	$65, %rdx
	jae	.LBB12_5
	addq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%r14, %r8
	callq	memcpy
	movq	112(%rdi), %rax
	addq	%r14, %rax
	movq	%rax, 112(%rdi)
	subq	%r14, %rsi
	addq	%r14, %rbx
	cmpq	$64, %rax
	jne	.LBB12_6
	leaq	64(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress256
	movq	$0, 112(%rdi)
.LBB12_6:
	cmpq	$64, %rsi
	jb	.LBB12_9
	leaq	64(%rdi), %r14
	.p2align	4
.LBB12_8:
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress256
	addq	$-64, %rsi
	addq	$64, %rbx
	cmpq	$63, %rsi
	ja	.LBB12_8
.LBB12_9:
	movb	$-1, %al
	testq	%rsi, %rsi
	je	.LBB12_13
	movq	112(%rdi), %rcx
	leaq	(%rcx,%rsi), %rdx
	cmpq	%rcx, %rdx
	jb	.LBB12_5
	cmpq	$65, %rdx
	jae	.LBB12_5
	addq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movb	$-1, %al
	addq	%rsi, 112(%rdi)
.LBB12_13:
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq
.LBB12_5:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.10(%rip), %r9
	movl	$64, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2568finalize;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2568finalize,unique,13
	.globl	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2568finalize
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2568finalize:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$32, %rsp
	movq	%rcx, %rsi
	movq	112(%rdx), %rcx
	cmpq	$63, %rcx
	ja	.LBB13_5
	movq	%rdx, %rdi
	movb	$-128, (%rdx,%rcx)
	movq	112(%rdx), %rax
	leaq	1(%rax), %rcx
	movq	%rcx, 112(%rdx)
	cmpq	$64, %rcx
	ja	.LBB13_6
	movl	$63, %r8d
	subq	%rax, %r8
	addq	%rdi, %rcx
	xorl	%edx, %edx
	callq	memset
	cmpq	$56, 112(%rdi)
	jbe	.LBB13_4
	leaq	64(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress256
	movq	$0, 56(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 8(%rdi)
	movq	$0, (%rdi)
.LBB13_4:
	movq	96(%rdi), %rax
	shlq	$3, %rax
	bswapq	%rax
	movq	%rax, 56(%rdi)
	leaq	64(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress256
	movl	64(%rdi), %eax
	movl	68(%rdi), %ecx
	bswapl	%eax
	bswapl	%ecx
	movl	72(%rdi), %edx
	bswapl	%edx
	movl	76(%rdi), %r8d
	bswapl	%r8d
	movl	80(%rdi), %r9d
	bswapl	%r9d
	movl	84(%rdi), %r10d
	bswapl	%r10d
	movl	88(%rdi), %r11d
	bswapl	%r11d
	movl	92(%rdi), %ebx
	bswapl	%ebx
	movl	%eax, (%rsi)
	movl	%ecx, 4(%rsi)
	movl	%edx, 8(%rsi)
	movl	%r8d, 12(%rsi)
	movl	%r9d, 16(%rsi)
	movl	%r10d, 20(%rsi)
	movl	%r11d, 24(%rsi)
	movl	%ebx, 28(%rsi)
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	movb	$0, 32(%rdi)
	movb	$0, 33(%rdi)
	movb	$0, 34(%rdi)
	movb	$0, 35(%rdi)
	movb	$0, 36(%rdi)
	movb	$0, 37(%rdi)
	movb	$0, 38(%rdi)
	movb	$0, 39(%rdi)
	movb	$0, 40(%rdi)
	movb	$0, 41(%rdi)
	movb	$0, 42(%rdi)
	movb	$0, 43(%rdi)
	movb	$0, 44(%rdi)
	movb	$0, 45(%rdi)
	movb	$0, 46(%rdi)
	movb	$0, 47(%rdi)
	movb	$0, 48(%rdi)
	movb	$0, 49(%rdi)
	movb	$0, 50(%rdi)
	movb	$0, 51(%rdi)
	movb	$0, 52(%rdi)
	movb	$0, 53(%rdi)
	movb	$0, 54(%rdi)
	movb	$0, 55(%rdi)
	movb	$0, 56(%rdi)
	movb	$0, 57(%rdi)
	movb	$0, 58(%rdi)
	movb	$0, 59(%rdi)
	movb	$0, 60(%rdi)
	movb	$0, 61(%rdi)
	movb	$0, 62(%rdi)
	movb	$0, 63(%rdi)
	#MEMBARRIER
	movl	$0, 64(%rdi)
	movl	$0, 68(%rdi)
	movl	$0, 72(%rdi)
	movl	$0, 76(%rdi)
	movl	$0, 80(%rdi)
	movl	$0, 84(%rdi)
	movl	$0, 88(%rdi)
	movl	$0, 92(%rdi)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq
.LBB13_6:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.10(%rip), %r9
	movl	$64, %edx
	movl	$64, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB13_5:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.10(%rip), %r8
	movl	$64, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_,unique,14
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$872, %rsp
	movq	%r9, 224(%rsp)
	movq	%r8, %rbx
	movq	%rdx, %rsi
	movq	%rcx, 736(%rsp)
	leaq	96(%r9), %rdi
	leaq	64(%rdx), %r14
	movq	%rdx, 720(%rsp)
	leaq	776(%rsp), %r12
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	movq	%r14, %r9
	movq	%r14, 704(%rsp)
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	64(%rbx), %r15
	leaq	808(%rsp), %r13
	movq	%r13, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r8
	movq	%r15, %r9
	movq	%r15, 712(%rsp)
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	432(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	movq	%r13, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	560(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rbx, %r8
	movq	%rbx, 728(%rsp)
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	32(%rsi), %rbp
	leaq	32(%rsp), %r12
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r8
	movq	%r13, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	464(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rbp, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	32(%rbx), %r12
	leaq	32(%rsp), %r13
	movq	%r13, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	leaq	776(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	592(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%r12, %r8
	movq	%r13, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	560(%rsp), %rdx
	movq	568(%rsp), %rcx
	subq	432(%rsp), %rdx
	movl	$1, %eax
	sbbq	$0, %rax
	subq	440(%rsp), %rcx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%rax, %rcx
	adcq	$0, %r9
	addq	$-1, %rcx
	adcq	$-1, %r9
	movq	576(%rsp), %r8
	xorq	$-2, %r9
	subq	448(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	584(%rsp), %rax
	subq	456(%rsp), %rax
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r10, %rax
	adcq	$-1, %r9
	movq	%rax, %r10
	addq	$1, %r10
	adcq	$0, %r9
	xorq	$1, %r9
	movq	%r9, 32(%rsp)
	xorl	%esi, %esi
	subq	32(%rsp), %rsi
	movq	224(%rsp), %rbx
	movq	96(%rbx), %r9
	movq	104(%rbx), %r15
	movq	%r9, %r11
	movq	%r9, %rbp
	andq	%rsi, %r11
	movq	%r15, %r10
	movq	%r15, %r14
	movq	%r15, 672(%rsp)
	andq	%rsi, %r10
	movq	112(%rbx), %r15
	movq	%r15, %r9
	movq	%r15, %r12
	andq	%rsi, %r9
	movq	120(%rbx), %r15
	andq	%r15, %rsi
	movq	%r15, 216(%rsp)
	addq	%rdx, %r11
	adcq	%rcx, %r10
	adcq	%r8, %r9
	adcq	$1, %rax
	addq	%rsi, %rax
	movq	592(%rsp), %rdx
	movq	600(%rsp), %rcx
	subq	464(%rsp), %rdx
	movl	$1, %r8d
	sbbq	$0, %r8
	subq	472(%rsp), %rcx
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%r8, %rcx
	adcq	$0, %rsi
	addq	$-1, %rcx
	adcq	$-1, %rsi
	movq	608(%rsp), %r8
	xorq	$-2, %rsi
	subq	480(%rsp), %r8
	movq	%r11, 152(%rsp)
	movl	$1, %r11d
	sbbq	$0, %r11
	movq	%r10, 160(%rsp)
	addq	%rsi, %r8
	adcq	$-1, %r11
	movq	%r9, 168(%rsp)
	addq	$1, %r8
	adcq	$0, %r11
	xorq	$-2, %r11
	movq	616(%rsp), %r9
	subq	488(%rsp), %r9
	movq	%rax, 176(%rsp)
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%r11, %r9
	adcq	$-1, %rax
	movq	%r9, %r10
	addq	$1, %r10
	adcq	$0, %rax
	xorq	$1, %rax
	movq	%rax, 32(%rsp)
	xorl	%eax, %eax
	subq	32(%rsp), %rax
	movq	%rbp, %r10
	andq	%rax, %r10
	movq	%r14, %r11
	andq	%rax, %r11
	movq	%r12, %r14
	movq	%r12, %rsi
	andq	%rax, %rsi
	andq	%r15, %rax
	addq	%rdx, %r10
	adcq	%rcx, %r11
	adcq	%r8, %rsi
	adcq	$1, %r9
	addq	%rax, %r9
	movq	%r10, 184(%rsp)
	movq	%r11, 192(%rsp)
	movq	%rsi, 200(%rsp)
	movq	%r9, 208(%rsp)
	leaq	840(%rsp), %r12
	leaq	152(%rsp), %rsi
	movq	%r12, %rcx
	movq	%rdi, %r13
	movq	%rdi, %rdx
	movq	%rsi, %r8
	movq	%rsi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	496(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	528(%rsp), %rcx
	movq	%rdi, %rdx
	leaq	432(%rsp), %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	336(%rsp), %rcx
	leaq	184(%rsp), %r8
	movq	%rdi, %rdx
	movq	%rdi, 680(%rsp)
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	336(%rsp), %rcx
	movq	344(%rsp), %rax
	subq	496(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	504(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rax
	adcq	$0, %r8
	addq	$-1, %rax
	adcq	$-1, %r8
	movq	352(%rsp), %rdx
	xorq	$-2, %r8
	subq	512(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdx
	adcq	$-1, %r9
	addq	$1, %rdx
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	360(%rsp), %rbx
	subq	520(%rsp), %rbx
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%r9, %rbx
	adcq	$-1, %r8
	movq	%rbx, %r9
	addq	$1, %r9
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, 32(%rsp)
	xorl	%r8d, %r8d
	subq	32(%rsp), %r8
	movq	%rbp, %r15
	movq	%rbp, 656(%rsp)
	andq	%r8, %rbp
	movq	672(%rsp), %rdi
	movq	%rdi, %r12
	andq	%r8, %r12
	movq	%r14, %rsi
	andq	%r8, %rsi
	andq	216(%rsp), %r8
	addq	%rcx, %rbp
	adcq	%rax, %r12
	adcq	%rdx, %rsi
	adcq	$1, %rbx
	addq	%r8, %rbx
	movq	%rbp, 624(%rsp)
	movq	%r12, 144(%rsp)
	movq	%rsi, 136(%rsp)
	movq	%rbx, 128(%rsp)
	leaq	32(%rsp), %rcx
	movq	%r13, %rdx
	leaq	528(%rsp), %r8
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	subq	32(%rsp), %rbp
	movl	$1, %eax
	sbbq	$0, %rax
	subq	40(%rsp), %r12
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r12
	adcq	$0, %rcx
	addq	$-1, %r12
	adcq	$-1, %rcx
	xorq	$-2, %rcx
	subq	48(%rsp), %rsi
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%rcx, %rsi
	adcq	$-1, %rax
	addq	$1, %rsi
	adcq	$0, %rax
	xorq	$-2, %rax
	subq	56(%rsp), %rbx
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %rbx
	adcq	$-1, %rcx
	movq	%rbx, %rax
	addq	$1, %rax
	adcq	$0, %rcx
	xorq	$1, %rcx
	movq	%rcx, 232(%rsp)
	xorl	%eax, %eax
	subq	232(%rsp), %rax
	movq	%r15, %rcx
	andq	%rax, %rcx
	movq	%rdi, %rdx
	andq	%rax, %rdx
	movq	%r14, 664(%rsp)
	movq	%r14, %r13
	andq	%rax, %r13
	movq	216(%rsp), %r15
	andq	%r15, %rax
	addq	%rbp, %rcx
	movq	%rcx, %r8
	movq	%rcx, 696(%rsp)
	adcq	%r12, %rdx
	movq	%rdx, 688(%rsp)
	adcq	%rsi, %r13
	adcq	$1, %rbx
	addq	%rax, %rbx
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 624(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	movq	528(%rsp), %rcx
	movq	536(%rsp), %rax
	subq	%r8, %rcx
	movl	$1, %r8d
	sbbq	$0, %r8
	subq	%rdx, %rax
	movl	$1, %r9d
	sbbq	$0, %r9
	movq	544(%rsp), %rdx
	addq	%r8, %rax
	adcq	$0, %r9
	addq	$-1, %rax
	adcq	$-1, %r9
	xorq	$-2, %r9
	subq	%r13, %rdx
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %rdx
	adcq	$-1, %r10
	addq	$1, %rdx
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	552(%rsp), %r8
	subq	%rbx, %r8
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r10, %r8
	adcq	$-1, %r9
	movq	%r8, %r10
	addq	$1, %r10
	adcq	$0, %r9
	xorq	$1, %r9
	movq	%r9, 32(%rsp)
	xorl	%r9d, %r9d
	subq	32(%rsp), %r9
	movq	656(%rsp), %rbp
	movq	%rbp, %r10
	andq	%r9, %r10
	movq	%rdi, %r11
	andq	%r9, %r11
	andq	%r9, %r14
	andq	%r15, %r9
	addq	%rcx, %r10
	adcq	%rax, %r11
	adcq	%rdx, %r14
	adcq	$1, %r8
	addq	%r9, %r8
	movq	%r10, 336(%rsp)
	movq	%r11, 344(%rsp)
	movq	%r14, 352(%rsp)
	movq	%r8, 360(%rsp)
	leaq	232(%rsp), %rcx
	leaq	336(%rsp), %r9
	movq	680(%rsp), %r14
	movq	%r14, %rdx
	leaq	184(%rsp), %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	32(%rsp), %rcx
	movq	%r14, %rdx
	leaq	464(%rsp), %r8
	leaq	496(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	232(%rsp), %rcx
	movq	240(%rsp), %rax
	subq	32(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	40(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rax
	adcq	$0, %r8
	addq	$-1, %rax
	adcq	$-1, %r8
	movq	248(%rsp), %rdx
	xorq	$-2, %r8
	subq	48(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdx
	adcq	$-1, %r9
	addq	$1, %rdx
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	256(%rsp), %rsi
	subq	56(%rsp), %rsi
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %rsi
	adcq	$-1, %r10
	movq	%rsi, %r8
	addq	$1, %r8
	adcq	$0, %r10
	xorq	$1, %r10
	movq	%r10, 624(%rsp)
	xorl	%r9d, %r9d
	subq	624(%rsp), %r9
	andq	%r9, %rbp
	andq	%r9, %rdi
	movq	664(%rsp), %r8
	andq	%r9, %r8
	andq	%r15, %r9
	addq	%rcx, %rbp
	movq	%rbp, %r15
	adcq	%rax, %rdi
	adcq	%rdx, %r8
	movq	%r8, %rbp
	adcq	$1, %rsi
	addq	%r9, %rsi
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	leaq	32(%rsp), %r12
	movq	%r12, %rcx
	movq	%r14, %rdx
	movq	704(%rsp), %r8
	movq	712(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	624(%rsp), %rcx
	movq	%r14, %rdx
	leaq	152(%rsp), %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	696(%rsp), %rax
	movq	%rax, 232(%rsp)
	movq	688(%rsp), %rax
	movq	%rax, 240(%rsp)
	movq	%r13, 248(%rsp)
	movq	%rbx, 256(%rsp)
	movq	%r15, 264(%rsp)
	movq	%rdi, 272(%rsp)
	movq	%rbp, 280(%rsp)
	movq	%rsi, 288(%rsp)
	movq	624(%rsp), %rax
	movq	632(%rsp), %rcx
	movq	%rax, 296(%rsp)
	movq	%rcx, 304(%rsp)
	movq	640(%rsp), %rax
	movq	%rax, 312(%rsp)
	movq	648(%rsp), %rax
	movq	%rax, 320(%rsp)
	leaq	32(%rsp), %r15
	movq	%r15, %rcx
	movq	720(%rsp), %rbx
	movq	%rbx, %rdx
	movq	224(%rsp), %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_
	movq	$0, 768(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 744(%rsp)
	movq	160(%rsp), %rax
	orq	152(%rsp), %rax
	orq	168(%rsp), %rax
	orq	176(%rsp), %rax
	orq	184(%rsp), %rax
	orq	192(%rsp), %rax
	orq	200(%rsp), %rax
	xorl	%r9d, %r9d
	orq	208(%rsp), %rax
	sete	%r9b
	leaq	336(%rsp), %rdi
	leaq	232(%rsp), %rdx
	movq	%rdi, %rcx
	movq	%r15, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	$0, 768(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 744(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	728(%rsp), %rsi
	movq	72(%rsi), %rax
	orq	64(%rsi), %rax
	orq	80(%rsi), %rax
	xorl	%r9d, %r9d
	orq	88(%rsi), %rax
	sete	%r9b
	leaq	32(%rsp), %r14
	movq	%r14, %rcx
	movq	%rdi, %rdx
	movq	%rbx, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	72(%rbx), %rax
	orq	64(%rbx), %rax
	orq	80(%rbx), %rax
	xorl	%r9d, %r9d
	orq	88(%rbx), %rax
	sete	%r9b
	movq	736(%rsp), %rcx
	movq	%r14, %rdx
	movq	%rsi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	#MEMBARRIER
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	#MEMBARRIER
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	#MEMBARRIER
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 864(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	#MEMBARRIER
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	#MEMBARRIER
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	#MEMBARRIER
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	#MEMBARRIER
	addq	$872, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_,unique,15
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$440, %rsp
	movq	%r9, %r14
	movq	%r8, 144(%rsp)
	movq	%rdx, 136(%rsp)
	movq	%rcx, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	160(%r9), %rax
	movq	168(%r9), %rcx
	movq	%rax, 64(%rsp)
	movq	%rcx, 72(%rsp)
	movq	176(%r9), %rax
	movq	%rax, 80(%rsp)
	movq	184(%r9), %rax
	movq	%rax, 88(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movl	$255, %r12d
	leaq	152(%rsp), %r13
	leaq	32(%rsp), %rbp
	leaq	248(%rsp), %rbx
	leaq	344(%rsp), %r15
	.p2align	4
.LBB15_1:
	movq	%r13, %rcx
	movq	%rbp, %rdx
	movq	%r14, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_
	movq	%rbx, %rcx
	movq	%r13, %rdx
	movq	136(%rsp), %r8
	movq	%r14, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_
	movq	%r12, %rax
	shrq	$6, %rax
	movq	144(%rsp), %rcx
	movq	(%rcx,%rax,8), %rax
	xorl	%r9d, %r9d
	btq	%r12, %rax
	setb	%r9b
	movq	%r15, %rcx
	movq	%r13, %rdx
	movq	%rbx, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movl	$12, %ecx
	movq	%rbp, %rdi
	movq	%r15, %rsi
	rep;movsq (%rsi), %es:(%rdi)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	addq	$-1, %r12
	jb	.LBB15_1
	leaq	32(%rsp), %rsi
	movl	$12, %ecx
	movq	128(%rsp), %rdi
	rep;movsq (%rsi), %es:(%rdi)
	addq	$440, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_,unique,16
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$328, %rsp
	movq	%rcx, %rsi
	movq	72(%rdx), %rax
	orq	64(%rdx), %rax
	orq	80(%rdx), %rax
	orq	88(%rdx), %rax
	movq	$0, 40(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	je	.LBB16_1
	movq	%r8, %rdi
	movq	%rdx, %rbx
	leaq	64(%rdx), %r8
	addq	$96, %rdi
	leaq	200(%rsp), %r14
	movq	%r14, %rcx
	movq	%rdi, %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_
	leaq	232(%rsp), %r15
	movq	%r15, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	296(%rsp), %r12
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%rbx, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$1, 40(%rsp)
	leaq	264(%rsp), %rcx
	leaq	40(%rsp), %r9
	movq	%rdi, %rdx
	movq	%r12, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	addq	$32, %rbx
	leaq	168(%rsp), %r12
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r8
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	136(%rsp), %r14
	movq	%r14, %rcx
	movq	%rdi, %rdx
	movq	%rbx, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$1, 40(%rsp)
	leaq	104(%rsp), %rcx
	leaq	40(%rsp), %r9
	movq	%rdi, %rdx
	movq	%r14, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	264(%rsp), %rax
	movq	272(%rsp), %rcx
	movq	%rax, 40(%rsp)
	movq	%rcx, 48(%rsp)
	movq	280(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	288(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	104(%rsp), %rax
	movq	112(%rsp), %rcx
	movq	%rax, 72(%rsp)
	movq	%rcx, 80(%rsp)
	movq	120(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	128(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	96(%rsp), %rax
	movq	%rax, 64(%rsi)
	movq	88(%rsp), %rax
	movq	%rax, 56(%rsi)
	movq	80(%rsp), %rax
	movq	%rax, 48(%rsi)
	movq	72(%rsp), %rax
	movq	%rax, 40(%rsi)
	movq	64(%rsp), %rax
	movq	%rax, 32(%rsi)
	movq	56(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 16(%rsi)
	movq	%rax, 8(%rsi)
	movb	$0, (%rsi)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	jmp	.LBB16_3
.LBB16_1:
	movw	$769, (%rsi)
.LBB16_3:
	addq	$328, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_,unique,17
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6doubleB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$632, %rsp
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, 552(%rsp)
	leaq	96(%r8), %r13
	leaq	64(%rdx), %r8
	movq	%r8, 264(%rsp)
	leaq	304(%rsp), %rbp
	movq	%rbp, %rcx
	movq	%r13, %rdx
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	32(%rbx), %r8
	movq	%r8, 256(%rsp)
	leaq	440(%rsp), %r14
	movq	%r14, %rcx
	movq	%r13, %rdx
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	568(%rsp), %rcx
	movq	%r13, %rdx
	movq	%rbx, %r8
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$3, 32(%rsp)
	leaq	128(%rdi), %rsi
	leaq	272(%rsp), %r15
	leaq	32(%rsp), %r8
	movq	%r15, %rcx
	movq	%r13, %rdx
	movq	%rsi, %r9
	movq	%rsi, 528(%rsp)
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	(%rbx), %rcx
	movq	8(%rbx), %rax
	subq	304(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	312(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rax
	adcq	$0, %r8
	addq	$-1, %rax
	adcq	$-1, %r8
	movq	16(%rbx), %rdx
	xorq	$-2, %r8
	subq	320(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdx
	adcq	$-1, %r9
	addq	$1, %rdx
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	24(%rbx), %r8
	movq	%rbx, 536(%rsp)
	subq	328(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	movq	%r8, %r9
	addq	$1, %r9
	adcq	$0, %r10
	xorq	$1, %r10
	movq	%r10, 32(%rsp)
	xorl	%r9d, %r9d
	subq	32(%rsp), %r9
	movq	96(%rdi), %r10
	movq	%r10, 344(%rsp)
	movq	104(%rdi), %r11
	movq	%r11, 512(%rsp)
	movq	%rdi, %r14
	movq	%rdi, 544(%rsp)
	andq	%r9, %r10
	andq	%r9, %r11
	movq	112(%rdi), %rdi
	movq	%rdi, 336(%rsp)
	andq	%r9, %rdi
	movq	120(%r14), %r14
	movq	%r14, 504(%rsp)
	andq	%r14, %r9
	addq	%rcx, %r10
	adcq	%rax, %r11
	adcq	%rdx, %rdi
	adcq	$1, %r8
	addq	%r9, %r8
	movq	%r10, 160(%rsp)
	movq	%r11, 168(%rsp)
	movq	%rdi, 176(%rsp)
	movq	%r8, 184(%rsp)
	leaq	32(%rsp), %r12
	movq	%r12, %rcx
	movq	%r13, %rdx
	movq	%rbx, %r8
	movq	%rbp, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	leaq	128(%rsp), %rbp
	leaq	160(%rsp), %r8
	movq	%rbp, %rcx
	movq	%r13, %rdx
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	600(%rsp), %rbx
	movq	%rbx, %rcx
	movq	%r13, %rdx
	movq	%r13, %rdi
	movq	%r15, %r8
	movq	%rbp, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	leaq	128(%rsp), %rcx
	movq	%r13, %rdx
	movq	%rbx, %r8
	movq	%rbx, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$8, 32(%rsp)
	leaq	160(%rsp), %r15
	leaq	32(%rsp), %r8
	movq	%r15, %rcx
	movq	%r13, %rdx
	movq	%rsi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	32(%rsp), %rcx
	movq	%r13, %rdx
	movq	%r15, %r8
	leaq	568(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	128(%rsp), %rcx
	movq	136(%rsp), %rax
	subq	32(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	40(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rax
	adcq	$0, %r8
	addq	$-1, %rax
	adcq	$-1, %r8
	movq	144(%rsp), %rdx
	xorq	$-2, %r8
	subq	48(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdx
	adcq	$-1, %r9
	addq	$1, %rdx
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	152(%rsp), %rbp
	subq	56(%rsp), %rbp
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%r9, %rbp
	adcq	$-1, %r8
	movq	%rbp, %r9
	addq	$1, %r9
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, 272(%rsp)
	xorl	%r8d, %r8d
	subq	272(%rsp), %r8
	movq	344(%rsp), %rbx
	movq	%rbx, %r9
	andq	%r8, %r9
	movq	512(%rsp), %rsi
	movq	%rsi, %r10
	andq	%r8, %r10
	movq	336(%rsp), %r14
	movq	%r14, %r11
	andq	%r8, %r11
	movq	504(%rsp), %r13
	andq	%r13, %r8
	addq	%rcx, %r9
	movq	%r9, 368(%rsp)
	adcq	%rax, %r10
	movq	%r10, 360(%rsp)
	adcq	%rdx, %r11
	movq	%r11, 352(%rsp)
	adcq	$1, %rbp
	addq	%r8, %rbp
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	leaq	32(%rsp), %r15
	movq	%r15, %rcx
	movq	%rdi, %rdx
	movq	256(%rsp), %r8
	movq	264(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	leaq	160(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%r15, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	160(%rsp), %r9
	movq	168(%rsp), %r8
	subq	440(%rsp), %r9
	movl	$1, %eax
	sbbq	$0, %rax
	subq	448(%rsp), %r8
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r8
	adcq	$0, %rcx
	addq	$-1, %r8
	adcq	$-1, %rcx
	movq	176(%rsp), %r10
	xorq	$-2, %rcx
	subq	456(%rsp), %r10
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%rcx, %r10
	adcq	$-1, %rax
	addq	$1, %r10
	adcq	$0, %rax
	xorq	$-2, %rax
	movq	184(%rsp), %r12
	subq	464(%rsp), %r12
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r12
	adcq	$-1, %rcx
	movq	%r12, %rax
	addq	$1, %rax
	adcq	$0, %rcx
	xorq	$1, %rcx
	movq	%rcx, 128(%rsp)
	xorl	%r11d, %r11d
	subq	128(%rsp), %r11
	movq	%rbx, %rax
	andq	%r11, %rax
	movq	%rsi, %rcx
	andq	%r11, %rcx
	movq	%r14, %r15
	movq	%r14, %rdx
	andq	%r11, %rdx
	andq	%r13, %r11
	addq	%r9, %rax
	adcq	%r8, %rcx
	adcq	%r10, %rdx
	adcq	$1, %r12
	addq	%r11, %r12
	subq	304(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	subq	312(%rsp), %rcx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rcx
	adcq	$0, %r9
	addq	$-1, %rcx
	adcq	$-1, %r9
	xorq	$-2, %r9
	subq	320(%rsp), %rdx
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%r9, %rdx
	adcq	$-1, %r8
	addq	$1, %rdx
	adcq	$0, %r8
	xorq	$-2, %r8
	subq	328(%rsp), %r12
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %r12
	adcq	$-1, %r9
	movq	%r12, %r8
	addq	$1, %r8
	adcq	$0, %r9
	xorq	$1, %r9
	movq	%r9, 128(%rsp)
	xorl	%r8d, %r8d
	subq	128(%rsp), %r8
	movq	%rbx, %r9
	movq	%rbx, %r14
	andq	%r8, %r9
	movq	%rsi, %r10
	movq	%rsi, %rbx
	andq	%r8, %r10
	movq	%r15, %r11
	andq	%r8, %r11
	andq	%r13, %r8
	addq	%rax, %r9
	movq	%r9, 264(%rsp)
	adcq	%rcx, %r10
	movq	%r10, 256(%rsp)
	adcq	%rdx, %r11
	movq	%r11, 520(%rsp)
	adcq	$1, %r12
	addq	%r8, %r12
	movq	$0, 128(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$4, 32(%rsp)
	leaq	272(%rsp), %rsi
	leaq	32(%rsp), %r8
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	528(%rsp), %r15
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	408(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	leaq	568(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	408(%rsp), %rcx
	movq	416(%rsp), %rax
	subq	368(%rsp), %rcx
	movl	$1, %r8d
	sbbq	$0, %r8
	subq	360(%rsp), %rax
	movl	$1, %r9d
	sbbq	$0, %r9
	movq	424(%rsp), %rdx
	addq	%r8, %rax
	adcq	$0, %r9
	addq	$-1, %rax
	adcq	$-1, %r9
	xorq	$-2, %r9
	subq	352(%rsp), %rdx
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %rdx
	adcq	$-1, %r10
	addq	$1, %rdx
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	432(%rsp), %r8
	subq	%rbp, %r8
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r10, %r8
	adcq	$-1, %r9
	movq	%r8, %r10
	addq	$1, %r10
	adcq	$0, %r9
	xorq	$1, %r9
	movq	%r9, 32(%rsp)
	xorl	%r9d, %r9d
	subq	32(%rsp), %r9
	movq	%r14, %r10
	andq	%r9, %r10
	movq	%rbx, %r11
	andq	%r9, %r11
	movq	336(%rsp), %r14
	movq	%r14, %rsi
	andq	%r9, %rsi
	andq	%r13, %r9
	addq	%rcx, %r10
	adcq	%rax, %r11
	adcq	%rdx, %rsi
	adcq	$1, %r8
	addq	%r9, %r8
	movq	%r10, 376(%rsp)
	movq	%r11, 384(%rsp)
	movq	%rsi, 392(%rsp)
	movq	%r8, 400(%rsp)
	leaq	472(%rsp), %rcx
	leaq	376(%rsp), %r9
	movq	%rdi, %rdx
	leaq	600(%rsp), %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$8, 32(%rsp)
	leaq	160(%rsp), %rsi
	leaq	32(%rsp), %r8
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	32(%rsp), %r15
	movq	%r15, %rcx
	movq	%rdi, %rdx
	leaq	440(%rsp), %r8
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	128(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	472(%rsp), %rcx
	subq	128(%rsp), %rcx
	movl	$1, %eax
	sbbq	$0, %rax
	movq	480(%rsp), %rdx
	subq	136(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%rax, %rdx
	adcq	$0, %r9
	addq	$-1, %rdx
	adcq	$-1, %r9
	xorq	$-2, %r9
	movq	488(%rsp), %r8
	subq	144(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	496(%rsp), %rax
	subq	152(%rsp), %rax
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%r10, %rax
	adcq	$-1, %r11
	movq	%rax, %r9
	addq	$1, %r9
	adcq	$0, %r11
	xorq	$1, %r11
	movq	%r11, 560(%rsp)
	xorl	%esi, %esi
	subq	560(%rsp), %rsi
	movq	344(%rsp), %r10
	andq	%rsi, %r10
	andq	%rsi, %rbx
	andq	%rsi, %r14
	andq	%r13, %rsi
	addq	%rcx, %r10
	adcq	%rdx, %rbx
	adcq	%r8, %r14
	adcq	$1, %rax
	addq	%rsi, %rax
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	536(%rsp), %rdx
	movq	72(%rdx), %rcx
	orq	64(%rdx), %rcx
	orq	80(%rdx), %rcx
	xorl	%r9d, %r9d
	orq	88(%rdx), %rcx
	movq	368(%rsp), %rcx
	movq	%rcx, 160(%rsp)
	movq	360(%rsp), %rcx
	movq	%rcx, 168(%rsp)
	movq	352(%rsp), %rcx
	movq	%rcx, 176(%rsp)
	movq	%rbp, 184(%rsp)
	movq	%r10, 192(%rsp)
	movq	%rbx, 200(%rsp)
	movq	%r14, 208(%rsp)
	movq	%rax, 216(%rsp)
	movq	264(%rsp), %rax
	movq	%rax, 224(%rsp)
	movq	256(%rsp), %rax
	movq	%rax, 232(%rsp)
	movq	520(%rsp), %rax
	movq	%rax, 240(%rsp)
	movq	%r12, 248(%rsp)
	movq	544(%rsp), %rcx
	movq	184(%rcx), %rax
	movq	%rax, 88(%rsp)
	movq	176(%rcx), %rax
	movq	%rax, 80(%rsp)
	movq	168(%rcx), %rax
	movq	%rax, 72(%rsp)
	movq	160(%rcx), %rax
	movq	%rax, 64(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	sete	%r9b
	leaq	160(%rsp), %rdx
	leaq	32(%rsp), %r8
	movq	552(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_
	movq	$0, 128(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	#MEMBARRIER
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	addq	$632, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_,unique,18
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6selectB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$32, %rsp
	movq	%r9, %r10
	movq	%r8, %r9
	movq	%rdx, %r8
	movq	%rcx, 24(%rsp)
	movq	(%rdx), %rax
	movq	(%r9), %r11
	movq	%r10, (%rsp)
	movq	(%rsp), %rcx
	movq	%rcx, %rsi
	negq	%rsi
	andq	%r11, %rsi
	decq	%rcx
	andq	%rax, %rcx
	orq	%rsi, %rcx
	movq	%rcx, 16(%rsp)
	movq	8(%rdx), %r11
	movq	8(%r9), %rsi
	movq	%r10, (%rsp)
	movq	(%rsp), %rax
	movq	%rax, %rdi
	negq	%rdi
	andq	%rsi, %rdi
	decq	%rax
	andq	%r11, %rax
	orq	%rdi, %rax
	movq	%rax, 8(%rsp)
	movq	16(%rdx), %rsi
	movq	16(%r9), %rdi
	movq	%r10, (%rsp)
	movq	(%rsp), %r11
	movq	%r11, %rbx
	negq	%rbx
	andq	%rdi, %rbx
	decq	%r11
	andq	%rsi, %r11
	orq	%rbx, %r11
	movq	24(%rdx), %rdi
	movq	24(%r9), %rbx
	movq	%r10, (%rsp)
	movq	(%rsp), %rsi
	movq	%rsi, %r14
	negq	%r14
	andq	%rbx, %r14
	decq	%rsi
	andq	%rdi, %rsi
	orq	%r14, %rsi
	movq	32(%rdx), %rbx
	movq	32(%r9), %r14
	movq	%r10, (%rsp)
	movq	(%rsp), %rdi
	movq	%rdi, %r15
	negq	%r15
	andq	%r14, %r15
	decq	%rdi
	andq	%rbx, %rdi
	orq	%r15, %rdi
	movq	40(%rdx), %r14
	movq	40(%r9), %r15
	movq	%r10, (%rsp)
	movq	(%rsp), %rbx
	movq	%rbx, %r12
	negq	%r12
	andq	%r15, %r12
	decq	%rbx
	andq	%r14, %rbx
	orq	%r12, %rbx
	movq	48(%rdx), %r15
	movq	48(%r9), %r12
	movq	%r10, (%rsp)
	movq	(%rsp), %r14
	movq	%r14, %r13
	negq	%r13
	andq	%r12, %r13
	decq	%r14
	andq	%r15, %r14
	orq	%r13, %r14
	movq	56(%rdx), %r12
	movq	56(%r9), %r13
	movq	%r10, (%rsp)
	movq	(%rsp), %r15
	movq	%r15, %rbp
	negq	%rbp
	andq	%r13, %rbp
	decq	%r15
	andq	%r12, %r15
	orq	%rbp, %r15
	movq	64(%rdx), %r13
	movq	64(%r9), %rbp
	movq	%r10, (%rsp)
	movq	(%rsp), %rdx
	movq	%rdx, %r12
	negq	%r12
	andq	%rbp, %r12
	decq	%rdx
	andq	%r13, %rdx
	orq	%r12, %rdx
	movq	72(%r8), %r12
	movq	72(%r9), %rbp
	movq	%r10, (%rsp)
	movq	(%rsp), %rcx
	movq	%rcx, %r13
	negq	%r13
	andq	%rbp, %r13
	decq	%rcx
	andq	%r12, %rcx
	orq	%r13, %rcx
	movq	80(%r8), %r12
	movq	%r10, (%rsp)
	movq	80(%r9), %r13
	movq	(%rsp), %rax
	movq	%rax, %rbp
	negq	%rbp
	andq	%r13, %rbp
	decq	%rax
	andq	%r12, %rax
	orq	%rbp, %rax
	movq	88(%r8), %r8
	movq	88(%r9), %r9
	movq	%r10, (%rsp)
	movq	(%rsp), %r10
	movq	%r10, %r12
	negq	%r12
	andq	%r9, %r12
	decq	%r10
	andq	%r8, %r10
	orq	%r12, %r10
	movq	24(%rsp), %r8
	movq	16(%rsp), %r9
	movq	%r9, (%r8)
	movq	8(%rsp), %r9
	movq	%r9, 8(%r8)
	movq	%r11, 16(%r8)
	movq	%rsi, 24(%r8)
	movq	%rdi, 32(%r8)
	movq	%rbx, 40(%r8)
	movq	%r14, 48(%r8)
	movq	%r15, 56(%r8)
	movq	%rdx, 64(%r8)
	movq	%rcx, 72(%r8)
	movq	%rax, 80(%r8)
	movq	%r10, 88(%r8)
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_,unique,19
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$1288, %rsp
	movq	%r9, 568(%rsp)
	movq	%r8, %rbx
	movq	%rdx, %rsi
	movq	%rcx, 1040(%rsp)
	leaq	144(%r9), %r12
	leaq	96(%rdx), %r14
	movq	%rdx, 1024(%rsp)
	leaq	1144(%rsp), %rdi
	movq	%rdi, %rcx
	movq	%r12, %rdx
	movq	%r14, %r8
	movq	%r14, %r9
	movq	%r14, 1008(%rsp)
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	96(%rbx), %r15
	leaq	1192(%rsp), %rbp
	movq	%rbp, %rcx
	movq	%r12, %rdx
	movq	%r15, %r8
	movq	%r15, %r9
	movq	%r15, 1016(%rsp)
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	728(%rsp), %rcx
	movq	%r12, %rdx
	movq	%rsi, %r8
	movq	%rbp, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	872(%rsp), %rcx
	movq	%r12, %rdx
	movq	%rbx, %r8
	movq	%rbx, 1032(%rsp)
	movq	%rdi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	48(%rsi), %r13
	leaq	88(%rsp), %rsi
	movq	%rsi, %rcx
	movq	%r12, %rdx
	movq	%r15, %r8
	movq	%rbp, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	776(%rsp), %rcx
	movq	%r12, %rdx
	movq	%r12, %r15
	movq	%r12, 248(%rsp)
	movq	%r13, %r8
	movq	%rsi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	leaq	48(%rbx), %r12
	leaq	88(%rsp), %r13
	movq	%r13, %rcx
	movq	%r15, %rdx
	movq	%r14, %r8
	movq	%rdi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	920(%rsp), %rcx
	movq	%r15, %rdx
	movq	%r12, %r8
	movq	%r13, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	872(%rsp), %rdx
	movq	880(%rsp), %rcx
	subq	728(%rsp), %rdx
	movl	$1, %eax
	sbbq	$0, %rax
	subq	736(%rsp), %rcx
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rax, %rcx
	adcq	$0, %r8
	addq	$-1, %rcx
	adcq	$-1, %r8
	movq	888(%rsp), %rdi
	xorq	$-2, %r8
	subq	744(%rsp), %rdi
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%r8, %rdi
	adcq	$-1, %rax
	addq	$1, %rdi
	adcq	$0, %rax
	movq	896(%rsp), %rbx
	xorq	$-2, %rax
	subq	752(%rsp), %rbx
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rax, %rbx
	adcq	$-1, %r8
	addq	$1, %rbx
	adcq	$0, %r8
	movq	904(%rsp), %r14
	xorq	$-2, %r8
	subq	760(%rsp), %r14
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %r14
	adcq	$-1, %r9
	addq	$1, %r14
	adcq	$0, %r9
	xorq	$-2, %r9
	movq	912(%rsp), %rax
	subq	768(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%r9, %rax
	adcq	$-1, %r8
	movq	%rax, %r9
	addq	$1, %r9
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, 88(%rsp)
	xorl	%r15d, %r15d
	subq	88(%rsp), %r15
	movq	568(%rsp), %r12
	movq	144(%r12), %r13
	movq	152(%r12), %r11
	movq	%r11, 240(%rsp)
	movq	%r13, %rsi
	andq	%r15, %rsi
	andq	%r15, %r11
	movq	160(%r12), %rbp
	movq	%rbp, %r10
	movq	%rbp, 264(%rsp)
	andq	%r15, %r10
	movq	168(%r12), %r8
	movq	%r8, 256(%rsp)
	andq	%r15, %r8
	movq	176(%r12), %r9
	movq	%r9, 232(%rsp)
	andq	%r15, %r9
	movq	184(%r12), %r12
	andq	%r12, %r15
	movq	%r12, 560(%rsp)
	addq	%rdx, %rsi
	adcq	%rcx, %r11
	adcq	%rdi, %r10
	adcq	%rbx, %r8
	adcq	%r14, %r9
	adcq	$1, %rax
	addq	%r15, %rax
	movq	920(%rsp), %rcx
	subq	776(%rsp), %rcx
	movl	$1, %edi
	sbbq	$0, %rdi
	movq	928(%rsp), %rdx
	subq	784(%rsp), %rdx
	movl	$1, %ebx
	sbbq	$0, %rbx
	addq	%rdi, %rdx
	adcq	$0, %rbx
	addq	$-1, %rdx
	adcq	$-1, %rbx
	xorq	$-2, %rbx
	movq	936(%rsp), %rdi
	subq	792(%rsp), %rdi
	movl	$1, %r14d
	sbbq	$0, %r14
	addq	%rbx, %rdi
	adcq	$-1, %r14
	addq	$1, %rdi
	adcq	$0, %r14
	xorq	$-2, %r14
	movq	944(%rsp), %rbx
	subq	800(%rsp), %rbx
	movl	$1, %r15d
	sbbq	$0, %r15
	addq	%r14, %rbx
	adcq	$-1, %r15
	addq	$1, %rbx
	adcq	$0, %r15
	xorq	$-2, %r15
	movq	952(%rsp), %r14
	subq	808(%rsp), %r14
	movq	%rsi, 416(%rsp)
	movl	$1, %esi
	sbbq	$0, %rsi
	movq	%r11, 424(%rsp)
	addq	%r15, %r14
	adcq	$-1, %rsi
	movq	%r10, 432(%rsp)
	addq	$1, %r14
	adcq	$0, %rsi
	xorq	$-2, %rsi
	movq	960(%rsp), %r10
	subq	816(%rsp), %r10
	movq	%r8, 440(%rsp)
	movl	$1, %r8d
	sbbq	$0, %r8
	movq	%r9, 448(%rsp)
	addq	%rsi, %r10
	adcq	$-1, %r8
	movq	%r10, %r9
	addq	$1, %r9
	adcq	$0, %r8
	movq	%rax, 456(%rsp)
	xorq	$1, %r8
	movq	%r8, 88(%rsp)
	xorl	%eax, %eax
	subq	88(%rsp), %rax
	movq	%r13, 40(%rsp)
	movq	%r13, %r8
	andq	%rax, %r8
	movq	240(%rsp), %r9
	andq	%rax, %r9
	movq	%rbp, %r11
	andq	%rax, %r11
	movq	256(%rsp), %rbp
	movq	%rbp, %rsi
	andq	%rax, %rsi
	movq	232(%rsp), %r15
	andq	%rax, %r15
	andq	%r12, %rax
	addq	%rcx, %r8
	adcq	%rdx, %r9
	adcq	%rdi, %r11
	adcq	%rbx, %rsi
	adcq	%r14, %r15
	adcq	$1, %r10
	addq	%rax, %r10
	movq	%r8, 464(%rsp)
	movq	%r9, 472(%rsp)
	movq	%r11, 480(%rsp)
	movq	%rsi, 488(%rsp)
	movq	%r15, 496(%rsp)
	movq	%r10, 504(%rsp)
	leaq	1240(%rsp), %r12
	leaq	416(%rsp), %rdi
	movq	%r12, %rcx
	movq	248(%rsp), %rsi
	movq	%rsi, %rdx
	movq	%rdi, %r8
	movq	%rdi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	824(%rsp), %rcx
	movq	%rsi, %rdx
	movq	%rdi, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	512(%rsp), %rcx
	movq	%rsi, %rdx
	leaq	728(%rsp), %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	272(%rsp), %rcx
	leaq	464(%rsp), %r8
	movq	%rsi, %rdx
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	272(%rsp), %rcx
	movq	280(%rsp), %rax
	subq	824(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	832(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rax
	adcq	$0, %r8
	addq	$-1, %rax
	adcq	$-1, %r8
	movq	288(%rsp), %rdx
	xorq	$-2, %r8
	subq	840(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdx
	adcq	$-1, %r9
	addq	$1, %rdx
	adcq	$0, %r9
	movq	296(%rsp), %r8
	xorq	$-2, %r9
	subq	848(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$0, %r10
	movq	304(%rsp), %r9
	xorq	$-2, %r10
	subq	856(%rsp), %r9
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%r10, %r9
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$0, %r11
	xorq	$-2, %r11
	movq	312(%rsp), %r10
	subq	864(%rsp), %r10
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%r11, %r10
	adcq	$-1, %rsi
	movq	%r10, %r11
	addq	$1, %r11
	adcq	$0, %rsi
	xorq	$1, %rsi
	movq	%rsi, 88(%rsp)
	xorl	%r11d, %r11d
	subq	88(%rsp), %r11
	andq	%r11, %r13
	movq	240(%rsp), %r12
	movq	%r12, %rdi
	andq	%r11, %rdi
	movq	264(%rsp), %rbx
	andq	%r11, %rbx
	movq	%rbp, %r14
	andq	%r11, %r14
	movq	232(%rsp), %rbp
	movq	%rbp, %r15
	andq	%r11, %r15
	andq	560(%rsp), %r11
	addq	%rcx, %r13
	adcq	%rax, %rdi
	adcq	%rdx, %rbx
	adcq	%r8, %r14
	adcq	%r9, %r15
	adcq	$1, %r10
	addq	%r11, %r10
	movq	%r13, 1048(%rsp)
	movq	%rdi, 80(%rsp)
	movq	%rbx, 72(%rsp)
	movq	%r14, 64(%rsp)
	movq	%r15, 56(%rsp)
	movq	%r10, 48(%rsp)
	movq	512(%rsp), %rax
	leaq	(%rax,%rax), %rcx
	movq	%rcx, 88(%rsp)
	movq	520(%rsp), %rcx
	shrdq	$63, %rcx, %rax
	movq	%rax, 96(%rsp)
	movq	528(%rsp), %rax
	shrdq	$63, %rax, %rcx
	movq	%rcx, 104(%rsp)
	movq	536(%rsp), %rcx
	shrdq	$63, %rcx, %rax
	movq	%rax, 112(%rsp)
	movq	544(%rsp), %rax
	shrdq	$63, %rax, %rcx
	movq	%rcx, 120(%rsp)
	movq	552(%rsp), %r9
	shrdq	$63, %r9, %rax
	movq	%rax, 128(%rsp)
	shrq	$63, %r9
	leaq	584(%rsp), %rcx
	leaq	88(%rsp), %r8
	movq	248(%rsp), %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	80(%rsp), %rax
	movq	1048(%rsp), %rcx
	subq	584(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	592(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rax
	adcq	$0, %r8
	addq	$-1, %rax
	adcq	$-1, %r8
	movq	72(%rsp), %rdx
	xorq	$-2, %r8
	subq	600(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdx
	adcq	$-1, %r9
	addq	$1, %rdx
	adcq	$0, %r9
	movq	64(%rsp), %r8
	xorq	$-2, %r9
	subq	608(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$0, %r10
	movq	56(%rsp), %r9
	xorq	$-2, %r10
	subq	616(%rsp), %r9
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%r10, %r9
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$0, %r11
	xorq	$-2, %r11
	movq	48(%rsp), %r13
	subq	624(%rsp), %r13
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r11, %r13
	adcq	$-1, %r10
	movq	%r13, %r11
	addq	$1, %r11
	adcq	$0, %r10
	xorq	$1, %r10
	movq	%r10, 88(%rsp)
	xorl	%r10d, %r10d
	subq	88(%rsp), %r10
	movq	40(%rsp), %r11
	andq	%r10, %r11
	movq	%r11, %rsi
	movq	%r12, %r11
	andq	%r10, %r11
	movq	%r11, %rdi
	movq	264(%rsp), %r12
	movq	%r12, %r11
	andq	%r10, %r11
	movq	%r11, %rbx
	movq	256(%rsp), %r11
	andq	%r10, %r11
	movq	%r11, %r14
	andq	%r10, %rbp
	movq	%rbp, %r11
	movq	560(%rsp), %rbp
	andq	%rbp, %r10
	addq	%rcx, %rsi
	movq	%rsi, 1000(%rsp)
	adcq	%rax, %rdi
	movq	%rdi, 992(%rsp)
	adcq	%rdx, %rbx
	movq	%rbx, 984(%rsp)
	adcq	%r8, %r14
	movq	%r14, %rax
	movq	%r14, 976(%rsp)
	adcq	%r9, %r11
	movq	%r11, %rcx
	movq	%r11, 968(%rsp)
	adcq	$1, %r13
	addq	%r10, %r13
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	#MEMBARRIER
	movq	$0, 1048(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	512(%rsp), %r15
	movq	520(%rsp), %r14
	subq	%rsi, %r15
	movl	$1, %r8d
	sbbq	$0, %r8
	subq	%rdi, %r14
	movl	$1, %r9d
	sbbq	$0, %r9
	movq	528(%rsp), %rdi
	addq	%r8, %r14
	adcq	$0, %r9
	addq	$-1, %r14
	adcq	$-1, %r9
	xorq	$-2, %r9
	subq	%rbx, %rdi
	movl	$1, %r10d
	sbbq	$0, %r10
	movq	536(%rsp), %rsi
	addq	%r9, %rdi
	adcq	$-1, %r10
	addq	$1, %rdi
	adcq	$0, %r10
	xorq	$-2, %r10
	subq	%rax, %rsi
	movl	$1, %r11d
	sbbq	$0, %r11
	movq	544(%rsp), %r9
	addq	%r10, %rsi
	adcq	$-1, %r11
	addq	$1, %rsi
	adcq	$0, %r11
	xorq	$-2, %r11
	subq	%rcx, %r9
	movl	$1, %ebx
	sbbq	$0, %rbx
	addq	%r11, %r9
	adcq	$-1, %rbx
	addq	$1, %r9
	adcq	$0, %rbx
	xorq	$-2, %rbx
	movq	552(%rsp), %r10
	subq	%r13, %r10
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%rbx, %r10
	adcq	$-1, %r11
	movq	%r10, %rbx
	addq	$1, %rbx
	adcq	$0, %r11
	xorq	$1, %r11
	movq	%r11, 88(%rsp)
	xorl	%r11d, %r11d
	subq	88(%rsp), %r11
	movq	40(%rsp), %rbx
	andq	%r11, %rbx
	movq	240(%rsp), %r8
	andq	%r11, %r8
	movq	%r12, %rdx
	andq	%r11, %rdx
	movq	256(%rsp), %r12
	movq	%r12, %rcx
	andq	%r11, %rcx
	movq	232(%rsp), %rax
	andq	%r11, %rax
	andq	%rbp, %r11
	addq	%r15, %rbx
	adcq	%r14, %r8
	adcq	%rdi, %rdx
	adcq	%rsi, %rcx
	adcq	%r9, %rax
	adcq	$1, %r10
	addq	%r11, %r10
	movq	%rbx, 584(%rsp)
	movq	%r8, 592(%rsp)
	movq	%rdx, 600(%rsp)
	movq	%rcx, 608(%rsp)
	movq	%rax, 616(%rsp)
	movq	%r10, 624(%rsp)
	leaq	272(%rsp), %rcx
	leaq	584(%rsp), %r9
	movq	248(%rsp), %rsi
	movq	%rsi, %rdx
	leaq	464(%rsp), %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	88(%rsp), %rcx
	movq	%rsi, %rdx
	leaq	776(%rsp), %r8
	leaq	824(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	272(%rsp), %rcx
	movq	280(%rsp), %rax
	subq	88(%rsp), %rcx
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	96(%rsp), %rax
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rax
	adcq	$0, %r8
	addq	$-1, %rax
	adcq	$-1, %r8
	movq	288(%rsp), %rdx
	xorq	$-2, %r8
	subq	104(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdx
	adcq	$-1, %r9
	addq	$1, %rdx
	adcq	$0, %r9
	movq	296(%rsp), %r8
	xorq	$-2, %r9
	subq	112(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$0, %r10
	movq	304(%rsp), %r9
	xorq	$-2, %r10
	subq	120(%rsp), %r9
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%r10, %r9
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$0, %r11
	xorq	$-2, %r11
	movq	312(%rsp), %rbx
	subq	128(%rsp), %rbx
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%r11, %rbx
	adcq	$-1, %rsi
	movq	%rbx, %r10
	addq	$1, %r10
	adcq	$0, %rsi
	xorq	$1, %rsi
	movq	%rsi, 1048(%rsp)
	xorl	%r11d, %r11d
	subq	1048(%rsp), %r11
	movq	40(%rsp), %rsi
	andq	%r11, %rsi
	movq	240(%rsp), %rdi
	andq	%r11, %rdi
	movq	264(%rsp), %r14
	andq	%r11, %r14
	andq	%r11, %r12
	movq	232(%rsp), %r10
	andq	%r11, %r10
	andq	%rbp, %r11
	addq	%rcx, %rsi
	movq	%rsi, 40(%rsp)
	adcq	%rax, %rdi
	movq	%rdi, %rbp
	adcq	%rdx, %r14
	adcq	%r8, %r12
	movq	%r12, %r15
	adcq	%r9, %r10
	movq	%r10, %rdi
	adcq	$1, %rbx
	addq	%r11, %rbx
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	#MEMBARRIER
	leaq	88(%rsp), %r12
	movq	%r12, %rcx
	movq	248(%rsp), %rsi
	movq	%rsi, %rdx
	movq	1008(%rsp), %r8
	movq	1016(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	1048(%rsp), %rcx
	movq	%rsi, %rdx
	leaq	416(%rsp), %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	1000(%rsp), %rax
	movq	%rax, 272(%rsp)
	movq	992(%rsp), %rax
	movq	%rax, 280(%rsp)
	movq	984(%rsp), %rax
	movq	%rax, 288(%rsp)
	movq	976(%rsp), %rax
	movq	%rax, 296(%rsp)
	movq	968(%rsp), %rax
	movq	%rax, 304(%rsp)
	movq	%r13, 312(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, 320(%rsp)
	movq	%rbp, 328(%rsp)
	movq	%r14, 336(%rsp)
	movq	%r15, 344(%rsp)
	movq	%rdi, 352(%rsp)
	movq	%rbx, 360(%rsp)
	movq	1048(%rsp), %rax
	movq	1056(%rsp), %rcx
	movq	%rax, 368(%rsp)
	movq	%rcx, 376(%rsp)
	movq	1064(%rsp), %rax
	movq	%rax, 384(%rsp)
	movq	1072(%rsp), %rax
	movq	%rax, 392(%rsp)
	movq	1080(%rsp), %rax
	movq	%rax, 400(%rsp)
	movq	1088(%rsp), %rax
	movq	%rax, 408(%rsp)
	leaq	88(%rsp), %r15
	movq	%r15, %rcx
	movq	1024(%rsp), %rbx
	movq	%rbx, %rdx
	movq	568(%rsp), %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_
	movq	$0, 1136(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1096(%rsp)
	movq	424(%rsp), %rax
	orq	416(%rsp), %rax
	orq	432(%rsp), %rax
	orq	440(%rsp), %rax
	orq	448(%rsp), %rax
	orq	456(%rsp), %rax
	orq	464(%rsp), %rax
	orq	472(%rsp), %rax
	orq	480(%rsp), %rax
	orq	488(%rsp), %rax
	orq	496(%rsp), %rax
	xorl	%r9d, %r9d
	orq	504(%rsp), %rax
	sete	%r9b
	leaq	584(%rsp), %rdi
	leaq	272(%rsp), %rdx
	movq	%rdi, %rcx
	movq	%r15, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, 1136(%rsp)
	movq	$0, 1128(%rsp)
	movq	$0, 1120(%rsp)
	movq	$0, 1112(%rsp)
	movq	$0, 1104(%rsp)
	movq	$0, 1096(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	1032(%rsp), %rsi
	movq	104(%rsi), %rax
	orq	96(%rsi), %rax
	orq	112(%rsi), %rax
	orq	120(%rsi), %rax
	orq	128(%rsi), %rax
	xorl	%r9d, %r9d
	orq	136(%rsi), %rax
	sete	%r9b
	leaq	88(%rsp), %r14
	movq	%r14, %rcx
	movq	%rdi, %rdx
	movq	%rbx, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	104(%rbx), %rax
	orq	96(%rbx), %rax
	orq	112(%rbx), %rax
	orq	120(%rbx), %rax
	orq	128(%rbx), %rax
	xorl	%r9d, %r9d
	orq	136(%rbx), %rax
	sete	%r9b
	movq	1040(%rsp), %rcx
	movq	%r14, %rdx
	movq	%rsi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 576(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	#MEMBARRIER
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	#MEMBARRIER
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	#MEMBARRIER
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 864(%rsp)
	#MEMBARRIER
	movq	$0, 1240(%rsp)
	movq	$0, 1248(%rsp)
	movq	$0, 1256(%rsp)
	movq	$0, 1264(%rsp)
	movq	$0, 1272(%rsp)
	movq	$0, 1280(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 960(%rsp)
	#MEMBARRIER
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	#MEMBARRIER
	movq	$0, 872(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 912(%rsp)
	#MEMBARRIER
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	#MEMBARRIER
	movq	$0, 1192(%rsp)
	movq	$0, 1200(%rsp)
	movq	$0, 1208(%rsp)
	movq	$0, 1216(%rsp)
	movq	$0, 1224(%rsp)
	movq	$0, 1232(%rsp)
	#MEMBARRIER
	movq	$0, 1144(%rsp)
	movq	$0, 1152(%rsp)
	movq	$0, 1160(%rsp)
	movq	$0, 1168(%rsp)
	movq	$0, 1176(%rsp)
	movq	$0, 1184(%rsp)
	#MEMBARRIER
	addq	$1288, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_,unique,20
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$616, %rsp
	movq	%r9, %rdi
	movq	%r8, %rbx
	movq	%rdx, %r14
	movq	%rcx, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	240(%r9), %rax
	movq	248(%r9), %rcx
	movq	%rax, 80(%rsp)
	movq	%rcx, 88(%rsp)
	movq	256(%r9), %rax
	movq	%rax, 96(%rsp)
	movq	264(%r9), %rax
	movq	%rax, 104(%rsp)
	movq	272(%r9), %rax
	movq	%rax, 112(%rsp)
	movq	280(%r9), %rax
	movq	%rax, 120(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movl	$383, %esi
	leaq	184(%rsp), %r15
	leaq	32(%rsp), %r12
	leaq	328(%rsp), %r13
	leaq	472(%rsp), %rbp
	.p2align	4
.LBB20_1:
	movq	%r15, %rcx
	movq	%r12, %rdx
	movq	%rdi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_
	movq	%r13, %rcx
	movq	%r15, %rdx
	movq	%r14, %r8
	movq	%rdi, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_
	movq	%rsi, %rax
	shrq	$6, %rax
	movq	(%rbx,%rax,8), %rax
	xorl	%r9d, %r9d
	btq	%rsi, %rax
	setb	%r9b
	movq	%rbp, %rcx
	movq	%r15, %rdx
	movq	%r13, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	movl	$144, %r8d
	movq	%r12, %rcx
	movq	%rbp, %rdx
	callq	memcpy
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	addq	$-1, %rsi
	jb	.LBB20_1
	leaq	32(%rsp), %rdx
	movl	$144, %r8d
	movq	176(%rsp), %rcx
	callq	memcpy
	addq	$616, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_,unique,21
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$472, %rsp
	movq	%rcx, %rbx
	movq	104(%rdx), %rax
	orq	96(%rdx), %rax
	orq	112(%rdx), %rax
	orq	120(%rdx), %rax
	orq	128(%rdx), %rax
	orq	136(%rdx), %rax
	movq	$0, 40(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	je	.LBB21_1
	movq	%r8, %rsi
	movq	%rdx, %rdi
	leaq	96(%rdx), %r8
	addq	$144, %rsi
	leaq	376(%rsp), %r14
	movq	%r14, %rcx
	movq	%rsi, %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_
	leaq	424(%rsp), %r15
	movq	%r15, %rcx
	movq	%rsi, %rdx
	movq	%r14, %r8
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	184(%rsp), %r12
	movq	%r12, %rcx
	movq	%rsi, %rdx
	movq	%rdi, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$1, 40(%rsp)
	leaq	136(%rsp), %rcx
	leaq	40(%rsp), %r9
	movq	%rsi, %rdx
	movq	%r12, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	addq	$48, %rdi
	leaq	328(%rsp), %r12
	movq	%r12, %rcx
	movq	%rsi, %rdx
	movq	%r15, %r8
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	280(%rsp), %r14
	movq	%r14, %rcx
	movq	%rsi, %rdx
	movq	%rdi, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$1, 40(%rsp)
	leaq	232(%rsp), %rcx
	leaq	40(%rsp), %r9
	movq	%rsi, %rdx
	movq	%r14, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	136(%rsp), %rax
	movq	144(%rsp), %rcx
	movq	%rax, 40(%rsp)
	movq	%rcx, 48(%rsp)
	movq	152(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	160(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	168(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	176(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	232(%rsp), %rax
	movq	240(%rsp), %rcx
	movq	%rax, 88(%rsp)
	movq	%rcx, 96(%rsp)
	movq	248(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	256(%rsp), %rax
	movq	%rax, 112(%rsp)
	movq	264(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	272(%rsp), %rax
	movq	%rax, 128(%rsp)
	leaq	8(%rbx), %rdi
	leaq	40(%rsp), %rsi
	movl	$12, %ecx
	rep;movsq (%rsi), %es:(%rdi)
	movb	$0, (%rbx)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	#MEMBARRIER
	jmp	.LBB21_3
.LBB21_1:
	movw	$769, (%rbx)
.LBB21_3:
	addq	$472, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_,unique,22
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6doubleB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$984, %rsp
	movq	%r8, %rdi
	movq	%rdx, %rbp
	movq	%rcx, 880(%rsp)
	leaq	144(%r8), %r12
	leaq	96(%rdx), %r8
	leaq	424(%rsp), %r13
	movq	%r13, %rcx
	movq	%r12, %rdx
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	48(%rbp), %r8
	leaq	736(%rsp), %rsi
	movq	%rsi, %rcx
	movq	%r12, %rdx
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	888(%rsp), %rcx
	movq	%r12, %rdx
	movq	%rbp, %r8
	movq	%rsi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$3, 40(%rsp)
	leaq	192(%rdi), %r15
	leaq	544(%rsp), %rsi
	leaq	40(%rsp), %r8
	movq	%rsi, %rcx
	movq	%r12, %rdx
	movq	%r15, %r9
	movq	%r15, 488(%rsp)
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	leaq	184(%rsp), %rbx
	movq	%rbx, %rcx
	movq	%r12, %rdx
	movq	%rbp, %r8
	movq	%r13, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_
	movq	424(%rsp), %rax
	addq	(%rbp), %rax
	movq	8(%rbp), %rcx
	adcq	$0, %rcx
	movq	%rax, 40(%rsp)
	setb	%al
	addq	432(%rsp), %rcx
	movzbl	%al, %eax
	adcq	16(%rbp), %rax
	movq	%rcx, 48(%rsp)
	setb	%cl
	addq	440(%rsp), %rax
	movzbl	%cl, %ecx
	adcq	24(%rbp), %rcx
	movq	%rax, 56(%rsp)
	setb	%al
	addq	448(%rsp), %rcx
	movzbl	%al, %eax
	adcq	32(%rbp), %rax
	movq	%rcx, 64(%rsp)
	setb	%cl
	addq	456(%rsp), %rax
	movzbl	%cl, %ecx
	adcq	40(%rbp), %rcx
	movq	%rax, 72(%rsp)
	setb	%al
	addq	464(%rsp), %rcx
	movzbl	%al, %r9d
	adcq	$0, %r9
	movq	%rcx, 80(%rsp)
	leaq	280(%rsp), %r13
	leaq	40(%rsp), %r8
	movq	%r13, %rcx
	movq	%r12, %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	leaq	40(%rsp), %r14
	movq	%r14, %rcx
	movq	%r12, %rdx
	movq	%rbx, %r8
	movq	%r13, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	936(%rsp), %rbx
	movq	%rbx, %rcx
	movq	%r12, %rdx
	movq	%r12, 240(%rsp)
	movq	%rsi, %r8
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	#MEMBARRIER
	leaq	184(%rsp), %rcx
	movq	%r12, %rdx
	movq	%rbx, %r8
	movq	%rbx, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$8, 40(%rsp)
	leaq	280(%rsp), %rsi
	leaq	40(%rsp), %r8
	movq	%rsi, %rcx
	movq	%r12, %rdx
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	leaq	40(%rsp), %rcx
	movq	%r12, %rdx
	movq	%rsi, %r8
	leaq	888(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	184(%rsp), %r12
	movq	192(%rsp), %rcx
	subq	40(%rsp), %r12
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	48(%rsp), %rcx
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rdx, %rcx
	adcq	$0, %r8
	addq	$-1, %rcx
	adcq	$-1, %r8
	movq	200(%rsp), %rdx
	xorq	$-2, %r8
	subq	56(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%r8, %rdx
	adcq	$-1, %r9
	addq	$1, %rdx
	adcq	$0, %r9
	movq	208(%rsp), %r8
	xorq	$-2, %r9
	subq	64(%rsp), %r8
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$0, %r10
	movq	216(%rsp), %r9
	xorq	$-2, %r10
	subq	72(%rsp), %r9
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%r10, %r9
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$0, %r11
	xorq	$-2, %r11
	movq	224(%rsp), %rsi
	subq	80(%rsp), %rsi
	movl	$1, %r10d
	sbbq	$0, %r10
	addq	%r11, %rsi
	adcq	$-1, %r10
	movq	%rsi, %r11
	addq	$1, %r11
	adcq	$0, %r10
	xorq	$1, %r10
	movq	%r10, 544(%rsp)
	xorl	%r10d, %r10d
	subq	544(%rsp), %r10
	movq	%rdi, 872(%rsp)
	movq	144(%rdi), %r14
	movq	%r14, 480(%rsp)
	movq	152(%rdi), %r11
	movq	%r11, 232(%rsp)
	andq	%r10, %r14
	andq	%r10, %r11
	movq	%r11, %rbx
	movq	160(%rdi), %r15
	movq	%r15, 256(%rsp)
	andq	%r10, %r15
	movq	168(%rdi), %r13
	movq	%r13, 264(%rsp)
	andq	%r10, %r13
	movq	176(%rdi), %rax
	movq	%rax, 248(%rsp)
	andq	%r10, %rax
	movq	184(%rdi), %r11
	movq	%r11, 472(%rsp)
	andq	%r11, %r10
	addq	%r12, %r14
	movq	%r14, 536(%rsp)
	adcq	%rcx, %rbx
	movq	%rbx, 528(%rsp)
	adcq	%rdx, %r15
	movq	%r15, 520(%rsp)
	adcq	%r8, %r13
	movq	%r13, 512(%rsp)
	adcq	%r9, %rax
	movq	%rax, 504(%rsp)
	adcq	$1, %rsi
	addq	%r10, %rsi
	movq	%rsi, 496(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	96(%rbp), %rcx
	movq	%rcx, 864(%rsp)
	movq	48(%rbp), %rax
	addq	%rcx, %rax
	movq	%rax, 40(%rsp)
	movq	56(%rbp), %rax
	adcq	$0, %rax
	setb	%cl
	movq	104(%rbp), %rdx
	movq	%rdx, 856(%rsp)
	addq	%rdx, %rax
	movq	%rax, 48(%rsp)
	movzbl	%cl, %eax
	adcq	64(%rbp), %rax
	setb	%cl
	movq	112(%rbp), %rdx
	movq	%rdx, 848(%rsp)
	addq	%rdx, %rax
	movq	%rax, 56(%rsp)
	movzbl	%cl, %eax
	adcq	72(%rbp), %rax
	setb	%cl
	movq	120(%rbp), %rdx
	movq	%rdx, 840(%rsp)
	addq	%rdx, %rax
	movq	%rax, 64(%rsp)
	movzbl	%cl, %eax
	adcq	80(%rbp), %rax
	setb	%cl
	movq	128(%rbp), %rdx
	movq	%rdx, 832(%rsp)
	addq	%rdx, %rax
	movq	%rax, 72(%rsp)
	movzbl	%cl, %eax
	adcq	88(%rbp), %rax
	movq	136(%rbp), %rdx
	movq	%rdx, 824(%rsp)
	setb	%cl
	addq	%rdx, %rax
	movq	%rax, 80(%rsp)
	movzbl	%cl, %r9d
	adcq	$0, %r9
	leaq	280(%rsp), %rsi
	leaq	40(%rsp), %r8
	movq	%rsi, %rcx
	movq	240(%rsp), %rdi
	movq	%rdi, %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	leaq	40(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	movq	%rsi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	40(%rsp), %r15
	movq	48(%rsp), %r11
	subq	736(%rsp), %r15
	movl	$1, %eax
	sbbq	$0, %rax
	subq	744(%rsp), %r11
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r11
	adcq	$0, %rcx
	addq	$-1, %r11
	adcq	$-1, %rcx
	movq	56(%rsp), %rsi
	xorq	$-2, %rcx
	subq	752(%rsp), %rsi
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%rcx, %rsi
	adcq	$-1, %rax
	addq	$1, %rsi
	adcq	$0, %rax
	movq	64(%rsp), %r14
	xorq	$-2, %rax
	subq	760(%rsp), %r14
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rax, %r14
	adcq	$-1, %rcx
	addq	$1, %r14
	adcq	$0, %rcx
	movq	72(%rsp), %r8
	xorq	$-2, %rcx
	subq	768(%rsp), %r8
	movl	$1, %edx
	sbbq	$0, %rdx
	addq	%rcx, %r8
	adcq	$-1, %rdx
	addq	$1, %r8
	adcq	$0, %rdx
	xorq	$-2, %rdx
	movq	80(%rsp), %rbp
	subq	776(%rsp), %rbp
	movl	$1, %ecx
	sbbq	$0, %rcx
	addq	%rdx, %rbp
	adcq	$-1, %rcx
	movq	%rbp, %rdx
	addq	$1, %rdx
	adcq	$0, %rcx
	xorq	$1, %rcx
	movq	%rcx, 184(%rsp)
	xorl	%eax, %eax
	subq	184(%rsp), %rax
	movq	480(%rsp), %rcx
	movq	%rcx, %rbx
	andq	%rax, %rbx
	movq	232(%rsp), %rdi
	andq	%rax, %rdi
	movq	256(%rsp), %rdx
	andq	%rax, %rdx
	movq	264(%rsp), %r12
	movq	%r12, %r10
	andq	%rax, %r10
	movq	248(%rsp), %r9
	andq	%rax, %r9
	movq	472(%rsp), %r13
	andq	%r13, %rax
	addq	%r15, %rbx
	adcq	%r11, %rdi
	adcq	%rsi, %rdx
	adcq	%r14, %r10
	adcq	%r8, %r9
	adcq	$1, %rbp
	addq	%rax, %rbp
	subq	424(%rsp), %rbx
	movl	$1, %eax
	sbbq	$0, %rax
	subq	432(%rsp), %rdi
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rax, %rdi
	adcq	$0, %r8
	addq	$-1, %rdi
	adcq	$-1, %r8
	xorq	$-2, %r8
	subq	440(%rsp), %rdx
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%r8, %rdx
	adcq	$-1, %rax
	addq	$1, %rdx
	adcq	$0, %rax
	xorq	$-2, %rax
	subq	448(%rsp), %r10
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rax, %r10
	adcq	$-1, %r8
	addq	$1, %r10
	adcq	$0, %r8
	xorq	$-2, %r8
	subq	456(%rsp), %r9
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%r8, %r9
	adcq	$-1, %rax
	addq	$1, %r9
	adcq	$0, %rax
	xorq	$-2, %rax
	subq	464(%rsp), %rbp
	movl	$1, %r8d
	sbbq	$0, %r8
	addq	%rax, %rbp
	adcq	$-1, %r8
	movq	%rbp, %rax
	addq	$1, %rax
	adcq	$0, %r8
	xorq	$1, %r8
	movq	%r8, 184(%rsp)
	xorl	%eax, %eax
	subq	184(%rsp), %rax
	movq	%rcx, %r8
	andq	%rax, %r8
	movq	%r8, %r11
	movq	232(%rsp), %r8
	andq	%rax, %r8
	movq	%r8, %rsi
	movq	256(%rsp), %r14
	movq	%r14, %r8
	andq	%rax, %r8
	movq	%r8, %r15
	movq	%r12, %rcx
	andq	%rax, %rcx
	movq	248(%rsp), %r12
	movq	%r12, %r8
	andq	%rax, %r8
	andq	%r13, %rax
	addq	%rbx, %r11
	movq	%r11, 816(%rsp)
	adcq	%rdi, %rsi
	movq	%rsi, 808(%rsp)
	adcq	%rdx, %r15
	movq	%r15, 800(%rsp)
	adcq	%r10, %rcx
	movq	%rcx, 792(%rsp)
	adcq	%r9, %r8
	movq	%r8, 784(%rsp)
	adcq	$1, %rbp
	addq	%rax, %rbp
	movq	$0, 184(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$4, 40(%rsp)
	leaq	544(%rsp), %rsi
	leaq	40(%rsp), %r8
	movq	%rsi, %rcx
	movq	240(%rsp), %rdi
	movq	%rdi, %rdx
	movq	488(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	leaq	688(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	leaq	888(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	688(%rsp), %r15
	movq	696(%rsp), %rcx
	subq	536(%rsp), %r15
	movl	$1, %r8d
	sbbq	$0, %r8
	subq	528(%rsp), %rcx
	movl	$1, %r9d
	sbbq	$0, %r9
	movq	704(%rsp), %rdx
	addq	%r8, %rcx
	adcq	$0, %r9
	addq	$-1, %rcx
	adcq	$-1, %r9
	xorq	$-2, %r9
	subq	520(%rsp), %rdx
	movl	$1, %r10d
	sbbq	$0, %r10
	movq	712(%rsp), %r8
	addq	%r9, %rdx
	adcq	$-1, %r10
	addq	$1, %rdx
	adcq	$0, %r10
	xorq	$-2, %r10
	subq	512(%rsp), %r8
	movl	$1, %r11d
	sbbq	$0, %r11
	movq	720(%rsp), %r9
	addq	%r10, %r8
	adcq	$-1, %r11
	addq	$1, %r8
	adcq	$0, %r11
	xorq	$-2, %r11
	subq	504(%rsp), %r9
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%r11, %r9
	adcq	$-1, %rsi
	addq	$1, %r9
	adcq	$0, %rsi
	xorq	$-2, %rsi
	movq	728(%rsp), %r10
	subq	496(%rsp), %r10
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%rsi, %r10
	adcq	$-1, %r11
	movq	%r10, %rsi
	addq	$1, %rsi
	adcq	$0, %r11
	xorq	$1, %r11
	movq	%r11, 40(%rsp)
	xorl	%r11d, %r11d
	subq	40(%rsp), %r11
	movq	480(%rsp), %r13
	movq	%r13, %rsi
	andq	%r11, %rsi
	movq	232(%rsp), %rdi
	andq	%r11, %rdi
	movq	%r14, %rbx
	andq	%r11, %rbx
	movq	264(%rsp), %r14
	andq	%r11, %r14
	movq	%r12, %rax
	andq	%r11, %rax
	movq	472(%rsp), %r12
	andq	%r12, %r11
	addq	%r15, %rsi
	adcq	%rcx, %rdi
	adcq	%rdx, %rbx
	adcq	%r8, %r14
	adcq	%r9, %rax
	adcq	$1, %r10
	addq	%r11, %r10
	movq	%rsi, 640(%rsp)
	movq	%rdi, 648(%rsp)
	movq	%rbx, 656(%rsp)
	movq	%r14, 664(%rsp)
	movq	%rax, 672(%rsp)
	movq	%r10, 680(%rsp)
	leaq	592(%rsp), %rcx
	leaq	640(%rsp), %r9
	movq	240(%rsp), %rdi
	movq	%rdi, %rdx
	leaq	936(%rsp), %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$8, 40(%rsp)
	leaq	280(%rsp), %rsi
	leaq	40(%rsp), %r8
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	488(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	leaq	40(%rsp), %r14
	movq	%r14, %rcx
	movq	%rdi, %rdx
	leaq	736(%rsp), %r8
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	184(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	592(%rsp), %rcx
	subq	184(%rsp), %rcx
	movl	$1, %eax
	sbbq	$0, %rax
	movq	600(%rsp), %rdx
	subq	192(%rsp), %rdx
	movl	$1, %r9d
	sbbq	$0, %r9
	addq	%rax, %rdx
	adcq	$0, %r9
	addq	$-1, %rdx
	adcq	$-1, %r9
	xorq	$-2, %r9
	movq	608(%rsp), %r8
	subq	200(%rsp), %r8
	movl	$1, %eax
	sbbq	$0, %rax
	addq	%r9, %r8
	adcq	$-1, %rax
	addq	$1, %r8
	adcq	$0, %rax
	xorq	$-2, %rax
	movq	616(%rsp), %r9
	subq	208(%rsp), %r9
	movl	$1, %r11d
	sbbq	$0, %r11
	addq	%rax, %r9
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$0, %r11
	xorq	$-2, %r11
	movq	624(%rsp), %r10
	subq	216(%rsp), %r10
	movl	$1, %esi
	sbbq	$0, %rsi
	addq	%r11, %r10
	adcq	$-1, %rsi
	addq	$1, %r10
	adcq	$0, %rsi
	xorq	$-2, %rsi
	movq	632(%rsp), %rax
	subq	224(%rsp), %rax
	movl	$1, %edi
	sbbq	$0, %rdi
	addq	%rsi, %rax
	adcq	$-1, %rdi
	movq	%rax, %r11
	addq	$1, %r11
	adcq	$0, %rdi
	xorq	$1, %rdi
	movq	%rdi, 272(%rsp)
	xorl	%r15d, %r15d
	subq	272(%rsp), %r15
	andq	%r15, %r13
	movq	232(%rsp), %rsi
	andq	%r15, %rsi
	movq	256(%rsp), %rdi
	andq	%r15, %rdi
	movq	264(%rsp), %rbx
	andq	%r15, %rbx
	movq	248(%rsp), %r14
	andq	%r15, %r14
	andq	%r12, %r15
	addq	%rcx, %r13
	adcq	%rdx, %rsi
	movq	%rsi, %rdx
	adcq	%r8, %rdi
	adcq	%r9, %rbx
	adcq	%r10, %r14
	adcq	$1, %rax
	addq	%r15, %rax
	movq	856(%rsp), %r9
	orq	864(%rsp), %r9
	movq	848(%rsp), %rsi
	orq	840(%rsp), %rsi
	orq	%r9, %rsi
	orq	832(%rsp), %rsi
	xorl	%r9d, %r9d
	orq	824(%rsp), %rsi
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	#MEMBARRIER
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	#MEMBARRIER
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	#MEMBARRIER
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	#MEMBARRIER
	movq	536(%rsp), %rsi
	movq	%rsi, 280(%rsp)
	movq	528(%rsp), %rsi
	movq	%rsi, 288(%rsp)
	movq	520(%rsp), %rsi
	movq	%rsi, 296(%rsp)
	movq	512(%rsp), %rsi
	movq	%rsi, 304(%rsp)
	movq	504(%rsp), %rsi
	movq	%rsi, 312(%rsp)
	movq	496(%rsp), %rsi
	movq	%rsi, 320(%rsp)
	movq	%r13, 328(%rsp)
	movq	%rdx, 336(%rsp)
	movq	%rdi, 344(%rsp)
	movq	%rbx, 352(%rsp)
	movq	%r14, 360(%rsp)
	movq	%rax, 368(%rsp)
	movq	816(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	808(%rsp), %rax
	movq	%rax, 384(%rsp)
	movq	800(%rsp), %rax
	movq	%rax, 392(%rsp)
	movq	792(%rsp), %rax
	movq	%rax, 400(%rsp)
	movq	784(%rsp), %rax
	movq	%rax, 408(%rsp)
	movq	%rbp, 416(%rsp)
	movq	872(%rsp), %rcx
	movq	280(%rcx), %rax
	movq	%rax, 128(%rsp)
	movq	272(%rcx), %rax
	movq	%rax, 120(%rsp)
	movq	264(%rcx), %rax
	movq	%rax, 112(%rsp)
	movq	256(%rcx), %rax
	movq	%rax, 104(%rsp)
	movq	248(%rcx), %rax
	movq	%rax, 96(%rsp)
	movq	240(%rcx), %rax
	movq	%rax, 88(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	sete	%r9b
	leaq	280(%rsp), %rdx
	leaq	40(%rsp), %r8
	movq	880(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_
	movq	$0, 184(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	#MEMBARRIER
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 960(%rsp)
	movq	$0, 968(%rsp)
	movq	$0, 976(%rsp)
	#MEMBARRIER
	movq	$0, 888(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	#MEMBARRIER
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	addq	$984, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_,unique,23
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6selectB4_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$80, %rsp
	movq	%r9, %rsi
	movq	%r8, %rdi
	movq	%rdx, %r11
	movq	%rcx, %r14
	movq	(%rdx), %rax
	movq	(%r8), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 72(%rsp)
	movq	8(%r11), %rax
	movq	8(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 64(%rsp)
	movq	16(%r11), %rax
	movq	16(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 56(%rsp)
	movq	24(%r11), %rax
	movq	24(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 48(%rsp)
	movq	32(%r11), %rax
	movq	32(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 40(%rsp)
	movq	40(%r11), %rax
	movq	40(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 32(%rsp)
	movq	48(%r11), %rax
	movq	48(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 24(%rsp)
	movq	56(%r11), %rax
	movq	56(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 16(%rsp)
	movq	64(%r11), %rax
	movq	64(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%r8, 8(%rsp)
	movq	72(%r11), %rax
	movq	72(%rdi), %rcx
	movq	%r9, (%rsp)
	movq	(%rsp), %r13
	movq	%r13, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r13
	andq	%rax, %r13
	orq	%rdx, %r13
	movq	80(%r11), %rax
	movq	%r9, (%rsp)
	movq	80(%rdi), %rcx
	movq	(%rsp), %rbp
	movq	%rbp, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%rbp
	andq	%rax, %rbp
	orq	%rdx, %rbp
	movq	%r9, (%rsp)
	movq	88(%r11), %rax
	movq	88(%rdi), %rcx
	movq	(%rsp), %rbx
	movq	%rbx, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%rbx
	andq	%rax, %rbx
	orq	%rdx, %rbx
	movq	%r9, (%rsp)
	movq	96(%r11), %rax
	movq	96(%rdi), %rcx
	movq	(%rsp), %r10
	movq	%r10, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r10
	andq	%rax, %r10
	orq	%rdx, %r10
	movq	%r9, (%rsp)
	movq	104(%r11), %rax
	movq	104(%rdi), %rcx
	movq	(%rsp), %r9
	movq	%r9, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r9
	andq	%rax, %r9
	orq	%rdx, %r9
	movq	%rsi, (%rsp)
	movq	112(%r11), %rax
	movq	112(%rdi), %rcx
	movq	(%rsp), %r8
	movq	%r8, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r8
	andq	%rax, %r8
	orq	%rdx, %r8
	movq	%rsi, (%rsp)
	movq	120(%r11), %r15
	movq	120(%rdi), %rax
	movq	(%rsp), %rdx
	movq	%rdx, %rcx
	negq	%rcx
	andq	%rax, %rcx
	decq	%rdx
	andq	%r15, %rdx
	orq	%rcx, %rdx
	movq	%rsi, (%rsp)
	movq	128(%r11), %r12
	movq	128(%rdi), %r15
	movq	(%rsp), %rcx
	movq	%rcx, %rax
	negq	%rax
	andq	%r15, %rax
	decq	%rcx
	andq	%r12, %rcx
	orq	%rax, %rcx
	movq	%rsi, (%rsp)
	movq	136(%r11), %rax
	movq	136(%rdi), %r11
	movq	(%rsp), %rsi
	movq	%rsi, %rdi
	negq	%rdi
	andq	%r11, %rdi
	decq	%rsi
	andq	%rax, %rsi
	orq	%rdi, %rsi
	movq	72(%rsp), %rax
	movq	%rax, (%r14)
	movq	64(%rsp), %rax
	movq	%rax, 8(%r14)
	movq	56(%rsp), %rax
	movq	%rax, 16(%r14)
	movq	48(%rsp), %rax
	movq	%rax, 24(%r14)
	movq	40(%rsp), %rax
	movq	%rax, 32(%r14)
	movq	32(%rsp), %rax
	movq	%rax, 40(%r14)
	movq	24(%rsp), %rax
	movq	%rax, 48(%r14)
	movq	16(%rsp), %rax
	movq	%rax, 56(%r14)
	movq	8(%rsp), %rax
	movq	%rax, 64(%r14)
	movq	%r13, 72(%r14)
	movq	%rbp, 80(%r14)
	movq	%rbx, 88(%r14)
	movq	%r10, 96(%r14)
	movq	%r9, 104(%r14)
	movq	%r8, 112(%r14)
	movq	%rdx, 120(%r14)
	movq	%rcx, 128(%r14)
	movq	%rsi, 136(%r14)
	addq	$80, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point11small_order;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point11small_order,unique,24
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point11small_order:
	pushq	%r15
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$832, %rsp
	movq	%rcx, %rdx
	leaq	512(%rsp), %rsi
	movq	%rsi, %rcx
	movq	%rdx, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add
	leaq	672(%rsp), %rdi
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	movq	%rsi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add
	leaq	352(%rsp), %rbx
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	movq	%rdi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	leaq	72(%rsp), %rsi
	movq	$1, 72(%rsp)
	leaq	112(%rsp), %rdi
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$1, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	leaq	192(%rsp), %r14
	movq	%r14, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	432(%rsp), %rbx
	leaq	232(%rsp), %r15
	leaq	32(%rsp), %rdx
	movq	%r15, %rcx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r14, %rcx
	movq	%r15, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq
	movq	%rax, %r14
	leaq	392(%rsp), %rdx
	leaq	272(%rsp), %r15
	movq	%r15, %rcx
	movq	%rdi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	312(%rsp), %rdi
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r15, %rcx
	movq	%rdi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq
	andl	%r14d, %eax
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	#MEMBARRIER
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	#MEMBARRIER
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	#MEMBARRIER
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	#MEMBARRIER
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	#MEMBARRIER
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	#MEMBARRIER
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	#MEMBARRIER
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	#MEMBARRIER
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	#MEMBARRIER
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	#MEMBARRIER
	addq	$832, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point2eq;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point2eq,unique,25
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point2eq:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$200, %rsp
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	leaq	80(%rdx), %rbx
	leaq	40(%rsp), %r14
	movq	%r14, %rcx
	movq	%rdi, %rdx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	80(%rdi), %r15
	leaq	80(%rsp), %r12
	movq	%r12, %rcx
	movq	%rsi, %rdx
	movq	%r15, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r14, %rcx
	movq	%r12, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq
	movq	%rax, %r14
	addq	$40, %rdi
	leaq	120(%rsp), %r12
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	addq	$40, %rsi
	leaq	160(%rsp), %rdi
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	movq	%r15, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r12, %rcx
	movq	%rdi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq
	andl	%r14d, %eax
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	addq	$200, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add,unique,26
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$496, %rsp
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	leaq	40(%rdx), %r14
	leaq	80(%rsp), %r12
	movq	%r12, %rcx
	movq	%r14, %rdx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3sub
	leaq	40(%rdi), %r15
	leaq	32(%rsp), %r13
	movq	%r13, %rcx
	movq	%r15, %rdx
	movq	%rdi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3sub
	leaq	240(%rsp), %rcx
	movq	%r12, %rdx
	movq	%r13, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	leaq	80(%rsp), %r12
	movq	%r12, %rcx
	movq	%r14, %rdx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3add
	leaq	32(%rsp), %r14
	movq	%r14, %rcx
	movq	%r15, %rdx
	movq	%rdi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3add
	leaq	280(%rsp), %rcx
	movq	%r12, %rdx
	movq	%r14, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	leaq	120(%rbx), %rdx
	leaq	120(%rdi), %r8
	leaq	128(%rsp), %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	xorl	%r8d, %r8d
	movabsq	$-6872316419617283935, %r9
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.11(%rip), %r10
	.p2align	4
.LBB26_1:
	movq	%r8, %rax
	mulq	%r9
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%r8b, %eax
	imull	$161, %eax, %eax
	movq	%r8, %rdx
	shrq	$3, %rdx
	movzbl	(%rdx,%r10), %edx
	movl	%r8d, %r11d
	andl	$7, %r11d
	xorl	%r14d, %r14d
	btl	%r11d, %edx
	setb	%r14b
	addl	%r8d, %ecx
	shlq	%cl, %r14
	shrl	$13, %eax
	orq	%r14, 32(%rsp,%rax,8)
	incq	%r8
	cmpq	$255, %r8
	jne	.LBB26_1
	movq	64(%rsp), %rax
	movq	%rax, 112(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 88(%rsp)
	movq	%rax, 80(%rsp)
	leaq	192(%rsp), %r14
	leaq	128(%rsp), %rdx
	leaq	80(%rsp), %r8
	movq	%r14, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$2, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	leaq	320(%rsp), %rcx
	leaq	32(%rsp), %r8
	movq	%r14, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	addq	$80, %rbx
	addq	$80, %rdi
	leaq	80(%rsp), %r14
	movq	%r14, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$2, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	leaq	360(%rsp), %rcx
	leaq	32(%rsp), %r8
	movq	%r14, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	xorl	%r8d, %r8d
	movq	280(%rsp), %rbx
	movq	288(%rsp), %rax
	subq	240(%rsp), %rbx
	movl	$0, %edi
	sbbq	%rdi, %rdi
	movabsq	$4503599627370458, %r10
	addq	%r10, %rbx
	adcq	$0, %rdi
	subq	248(%rsp), %rax
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	movq	%rdi, %r14
	shldq	$13, %rbx, %rdi
	shrq	$51, %r14
	addq	%rax, %rdi
	adcq	%rcx, %r14
	movq	296(%rsp), %rax
	subq	256(%rsp), %rax
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	movabsq	$4503599627370494, %r9
	addq	%r9, %rdi
	adcq	$0, %r14
	movq	%r14, %r15
	shldq	$13, %rdi, %r14
	shrq	$51, %r15
	addq	%rax, %r14
	adcq	%rcx, %r15
	movq	304(%rsp), %rax
	subq	264(%rsp), %rax
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%r9, %r14
	adcq	$0, %r15
	movq	%r15, %r12
	shldq	$13, %r14, %r15
	shrq	$51, %r12
	addq	%rax, %r15
	adcq	%rcx, %r12
	movq	312(%rsp), %rax
	subq	272(%rsp), %rax
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%r9, %r15
	adcq	$0, %r12
	movq	%r12, %rdx
	shldq	$13, %r15, %r12
	shrq	$51, %rdx
	addq	%rax, %r12
	adcq	%rcx, %rdx
	movabsq	$2251799813685247, %rcx
	andq	%rcx, %rbx
	andq	%rcx, %rdi
	andq	%rcx, %r14
	andq	%rcx, %r15
	addq	%r9, %r12
	adcq	$0, %rdx
	movq	%rdx, %rax
	shldq	$13, %r12, %rax
	shrq	$51, %rdx
	andq	%rcx, %r12
	leaq	(%rdx,%rdx,8), %r11
	leaq	(%rdx,%r11,2), %r13
	movl	$19, %r11d
	mulq	%r11
	addq	%rbx, %rax
	adcq	%r13, %rdx
	shldq	$13, %rax, %rdx
	andq	%rcx, %rax
	addq	%rdi, %rdx
	movq	%rdx, %rbx
	andq	%rcx, %rbx
	shrq	$51, %rdx
	addq	%r14, %rdx
	movq	%rdx, %r14
	andq	%rcx, %r14
	shrq	$51, %rdx
	addq	%r15, %rdx
	movq	%rdx, %r15
	andq	%rcx, %r15
	shrq	$51, %rdx
	addq	%r12, %rdx
	movq	%rdx, %rdi
	shrq	$51, %rdi
	andq	%rcx, %rdx
	leaq	(%rdi,%rdi,8), %r12
	leaq	(%rdi,%r12,2), %rdi
	addq	%rax, %rdi
	movq	%rdi, %rax
	andq	%rcx, %rax
	shrq	$51, %rdi
	addq	%rbx, %rdi
	movq	%rdi, %rbx
	shrq	$51, %rbx
	addq	%r14, %rbx
	movq	%rbx, %r14
	shrq	$51, %r14
	addq	%r15, %r14
	movq	%r14, %r15
	shrq	$51, %r15
	addq	%rdx, %r15
	movq	%r15, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r12
	leaq	(%rdx,%r12,2), %rdx
	addq	%rax, %rdx
	andq	%rcx, %rdi
	andq	%rcx, %rbx
	andq	%rcx, %r14
	andq	%rcx, %r15
	movq	%rdx, 424(%rsp)
	movq	%rdi, 432(%rsp)
	movq	%rbx, 440(%rsp)
	movq	%r14, 448(%rsp)
	movq	%r15, 456(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	360(%rsp), %rbx
	movq	368(%rsp), %rax
	subq	320(%rsp), %rbx
	movl	$0, %edi
	sbbq	%rdi, %rdi
	addq	%r10, %rbx
	adcq	$0, %rdi
	subq	328(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movq	%rdi, %r10
	shldq	$13, %rbx, %rdi
	shrq	$51, %r10
	addq	%rax, %rdi
	adcq	%rdx, %r10
	movq	376(%rsp), %rax
	subq	336(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r9, %rdi
	adcq	$0, %r10
	movq	%r10, %r14
	shldq	$13, %rdi, %r10
	shrq	$51, %r14
	addq	%rax, %r10
	adcq	%rdx, %r14
	movq	384(%rsp), %rax
	subq	344(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r9, %r10
	adcq	$0, %r14
	movq	%r14, %r15
	shrq	$51, %r15
	shldq	$13, %r10, %r14
	addq	%rax, %r14
	adcq	%rdx, %r15
	movq	392(%rsp), %rax
	subq	352(%rsp), %rax
	sbbq	%r8, %r8
	addq	%r9, %r14
	adcq	$0, %r15
	movq	%r15, %rdx
	shldq	$13, %r14, %r15
	shrq	$51, %rdx
	addq	%rax, %r15
	adcq	%r8, %rdx
	andq	%rcx, %rbx
	andq	%rcx, %rdi
	andq	%rcx, %r10
	andq	%rcx, %r14
	addq	%r9, %r15
	adcq	$0, %rdx
	movq	%rdx, %rax
	shldq	$13, %r15, %rax
	shrq	$51, %rdx
	andq	%rcx, %r15
	leaq	(%rdx,%rdx,8), %r8
	leaq	(%rdx,%r8,2), %r8
	mulq	%r11
	addq	%rbx, %rax
	adcq	%r8, %rdx
	shldq	$13, %rax, %rdx
	andq	%rcx, %rax
	addq	%rdi, %rdx
	movq	%rdx, %r9
	andq	%rcx, %r9
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%rcx, %r10
	shrq	$51, %rdx
	addq	%r14, %rdx
	movq	%rdx, %r11
	andq	%rcx, %r11
	shrq	$51, %rdx
	addq	%r15, %rdx
	movq	%rdx, %r8
	shrq	$51, %r8
	andq	%rcx, %rdx
	leaq	(%r8,%r8,8), %rdi
	leaq	(%r8,%rdi,2), %r8
	addq	%rax, %r8
	movq	%r8, %rax
	andq	%rcx, %rax
	shrq	$51, %r8
	addq	%r9, %r8
	movq	%r8, %r9
	shrq	$51, %r9
	addq	%r10, %r9
	movq	%r9, %r10
	shrq	$51, %r10
	addq	%r11, %r10
	movq	%r10, %r11
	shrq	$51, %r11
	addq	%rdx, %r11
	movq	%r11, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %rdi
	leaq	(%rdx,%rdi,2), %rdx
	addq	%rax, %rdx
	andq	%rcx, %r8
	andq	%rcx, %r9
	andq	%rcx, %r10
	andq	%rcx, %r11
	movq	%rdx, 192(%rsp)
	movq	%r8, 200(%rsp)
	movq	%r9, 208(%rsp)
	movq	%r10, 216(%rsp)
	movq	%r11, 224(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	#MEMBARRIER
	movq	320(%rsp), %r9
	movq	328(%rsp), %rdi
	xorl	%eax, %eax
	addq	360(%rsp), %r9
	setb	%al
	xorl	%edx, %edx
	addq	368(%rsp), %rdi
	setb	%dl
	movq	336(%rsp), %rbx
	xorl	%r8d, %r8d
	addq	376(%rsp), %rbx
	setb	%r8b
	movq	344(%rsp), %r14
	xorl	%r10d, %r10d
	addq	384(%rsp), %r14
	setb	%r10b
	movq	352(%rsp), %r15
	xorl	%r11d, %r11d
	addq	392(%rsp), %r15
	setb	%r11b
	shldq	$13, %r9, %rax
	andq	%rcx, %r9
	addq	%rdi, %rax
	adcq	$0, %rdx
	shldq	$13, %rax, %rdx
	andq	%rcx, %rax
	addq	%rbx, %rdx
	adcq	$0, %r8
	shldq	$13, %rdx, %r8
	andq	%rcx, %rdx
	addq	%r14, %r8
	adcq	$0, %r10
	shldq	$13, %r8, %r10
	andq	%rcx, %r8
	addq	%r15, %r10
	adcl	$0, %r11d
	movq	%r10, %rdi
	shrq	$51, %rdi
	shll	$13, %r11d
	orq	%rdi, %r11
	andq	%rcx, %r10
	leaq	(%r11,%r11,8), %rdi
	leaq	(%r11,%rdi,2), %r11
	addq	%r9, %r11
	movq	%r11, %r9
	andq	%rcx, %r9
	shrq	$51, %r11
	addq	%rax, %r11
	movq	%r11, %rdi
	andq	%rcx, %rdi
	shrq	$51, %r11
	addq	%rdx, %r11
	movq	%r11, %rdx
	andq	%rcx, %rdx
	shrq	$51, %r11
	addq	%r8, %r11
	movq	%r11, %r8
	andq	%rcx, %r8
	shrq	$51, %r11
	addq	%r10, %r11
	movq	%r11, %rax
	shrq	$51, %rax
	andq	%rcx, %r11
	leaq	(%rax,%rax,8), %r10
	leaq	(%rax,%r10,2), %rax
	addq	%r9, %rax
	movq	%rax, %r9
	andq	%rcx, %r9
	shrq	$51, %rax
	addq	%rdi, %rax
	movq	%rax, %r10
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	shrq	$51, %r8
	addq	%r11, %r8
	movq	%r8, %r11
	shrq	$51, %r11
	leaq	(%r11,%r11,8), %rdi
	leaq	(%r11,%rdi,2), %r11
	addq	%r9, %r11
	andq	%rcx, %rax
	andq	%rcx, %r10
	andq	%rcx, %rdx
	andq	%rcx, %r8
	movq	%r11, 128(%rsp)
	movq	%rax, 136(%rsp)
	movq	%r10, 144(%rsp)
	movq	%rdx, 152(%rsp)
	movq	%r8, 160(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	240(%rsp), %r9
	movq	248(%rsp), %rdi
	xorl	%eax, %eax
	addq	280(%rsp), %r9
	setb	%al
	xorl	%edx, %edx
	addq	288(%rsp), %rdi
	setb	%dl
	movq	256(%rsp), %rbx
	xorl	%r8d, %r8d
	addq	296(%rsp), %rbx
	setb	%r8b
	movq	264(%rsp), %r14
	xorl	%r10d, %r10d
	addq	304(%rsp), %r14
	setb	%r10b
	movq	272(%rsp), %r15
	xorl	%r11d, %r11d
	addq	312(%rsp), %r15
	setb	%r11b
	shldq	$13, %r9, %rax
	andq	%rcx, %r9
	addq	%rdi, %rax
	adcq	$0, %rdx
	shldq	$13, %rax, %rdx
	andq	%rcx, %rax
	addq	%rbx, %rdx
	adcq	$0, %r8
	shldq	$13, %rdx, %r8
	andq	%rcx, %rdx
	addq	%r14, %r8
	adcq	$0, %r10
	shldq	$13, %r8, %r10
	andq	%rcx, %r8
	addq	%r15, %r10
	adcl	$0, %r11d
	movq	%r10, %rdi
	shrq	$51, %rdi
	shll	$13, %r11d
	orq	%rdi, %r11
	andq	%rcx, %r10
	leaq	(%r11,%r11,8), %rdi
	leaq	(%r11,%rdi,2), %r11
	addq	%r9, %r11
	movq	%r11, %r9
	andq	%rcx, %r9
	shrq	$51, %r11
	addq	%rax, %r11
	movq	%r11, %rdi
	andq	%rcx, %rdi
	shrq	$51, %r11
	addq	%rdx, %r11
	movq	%r11, %rdx
	andq	%rcx, %rdx
	shrq	$51, %r11
	addq	%r8, %r11
	movq	%r11, %r8
	andq	%rcx, %r8
	shrq	$51, %r11
	addq	%r10, %r11
	movq	%r11, %rax
	shrq	$51, %rax
	andq	%rcx, %r11
	leaq	(%rax,%rax,8), %r10
	leaq	(%rax,%r10,2), %rax
	addq	%r9, %rax
	movq	%rax, %r9
	andq	%rcx, %r9
	shrq	$51, %rax
	addq	%rdi, %rax
	movq	%rax, %r10
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	shrq	$51, %r8
	addq	%r11, %r8
	movq	%r8, %r11
	shrq	$51, %r11
	leaq	(%r11,%r11,8), %rdi
	leaq	(%r11,%rdi,2), %r11
	addq	%r9, %r11
	andq	%rcx, %rax
	andq	%rcx, %r10
	andq	%rcx, %rdx
	andq	%rcx, %r8
	movq	%r11, 80(%rsp)
	movq	%rax, 88(%rsp)
	movq	%r10, 96(%rsp)
	movq	%rdx, 104(%rsp)
	movq	%r8, 112(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 480(%rsp)
	#MEMBARRIER
	leaq	424(%rsp), %rdi
	leaq	192(%rsp), %rbx
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	40(%rsi), %rcx
	leaq	128(%rsp), %r14
	leaq	80(%rsp), %r15
	movq	%r14, %rdx
	movq	%r15, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	32(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%r15, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	80(%rsi), %rcx
	movq	%rbx, %rdx
	movq	%r14, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	64(%rsp), %rax
	movq	%rax, 152(%rsi)
	movq	56(%rsp), %rax
	movq	%rax, 144(%rsi)
	movq	48(%rsp), %rax
	movq	%rax, 136(%rsi)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 128(%rsi)
	movq	%rax, 120(%rsi)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	addq	$496, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3mul;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3mul,unique,27
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3mul:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$616, %rsp
	movq	%r8, 536(%rsp)
	movq	%rdx, 528(%rsp)
	movq	%rcx, 520(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$1, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$1, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movl	$255, %esi
	.p2align	4
.LBB27_1:
	movq	%rsi, 608(%rsp)
	leaq	200(%rsp), %rdi
	movq	%rdi, %rcx
	leaq	40(%rsp), %rdx
	movq	%rdx, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add
	leaq	360(%rsp), %rcx
	movq	%rdi, %rdx
	movq	528(%rsp), %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add
	movq	%rsi, %rax
	shrq	$3, %rax
	movq	536(%rsp), %rcx
	movzbl	(%rcx,%rax), %eax
	movl	%esi, %ecx
	andl	$7, %ecx
	xorl	%r8d, %r8d
	btl	%ecx, %eax
	setb	%r8b
	movq	200(%rsp), %rax
	movq	208(%rsp), %rcx
	movq	360(%rsp), %rdx
	movq	368(%rsp), %r9
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r11
	movq	%r11, %r10
	negq	%r10
	andq	%rdx, %r10
	decq	%r11
	andq	%rax, %r11
	orq	%r10, %r11
	movq	%r11, 600(%rsp)
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %rdx
	movq	%rdx, %rax
	negq	%rax
	andq	%r9, %rax
	decq	%rdx
	andq	%rcx, %rdx
	orq	%rax, %rdx
	movq	%rdx, 592(%rsp)
	movq	216(%rsp), %rax
	movq	376(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r9
	andq	%rax, %r9
	orq	%rdx, %r9
	movq	%r9, 584(%rsp)
	movq	224(%rsp), %rax
	movq	384(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r9
	andq	%rax, %r9
	orq	%rdx, %r9
	movq	%r9, 576(%rsp)
	movq	232(%rsp), %rax
	movq	392(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r9
	andq	%rax, %r9
	orq	%rdx, %r9
	movq	%r9, 568(%rsp)
	movq	240(%rsp), %rax
	movq	400(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r9
	andq	%rax, %r9
	orq	%rdx, %r9
	movq	%r9, 560(%rsp)
	movq	248(%rsp), %rax
	movq	408(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r9
	andq	%rax, %r9
	orq	%rdx, %r9
	movq	%r9, 552(%rsp)
	movq	256(%rsp), %rax
	movq	416(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r9
	andq	%rax, %r9
	orq	%rdx, %r9
	movq	%r9, 544(%rsp)
	movq	264(%rsp), %rax
	movq	424(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %rbp
	movq	%rbp, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%rbp
	andq	%rax, %rbp
	orq	%rdx, %rbp
	movq	272(%rsp), %rax
	movq	432(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r12
	movq	%r12, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r12
	andq	%rax, %r12
	orq	%rdx, %r12
	movq	280(%rsp), %rax
	movq	440(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %rbx
	movq	%rbx, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%rbx
	andq	%rax, %rbx
	orq	%rdx, %rbx
	movq	288(%rsp), %rax
	movq	448(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r14
	movq	%r14, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r14
	andq	%rax, %r14
	orq	%rdx, %r14
	movq	296(%rsp), %rax
	movq	456(%rsp), %rcx
	movq	%r8, 32(%rsp)
	movq	32(%rsp), %r15
	movq	%r15, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r15
	andq	%rax, %r15
	orq	%rdx, %r15
	movq	304(%rsp), %rax
	movq	%r8, 32(%rsp)
	movq	464(%rsp), %rcx
	movq	32(%rsp), %r13
	movq	%r13, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r13
	andq	%rax, %r13
	orq	%rdx, %r13
	movq	%r8, 32(%rsp)
	movq	312(%rsp), %rax
	movq	472(%rsp), %rcx
	movq	32(%rsp), %r11
	movq	%r11, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r11
	andq	%rax, %r11
	orq	%rdx, %r11
	movq	%r8, 32(%rsp)
	movq	320(%rsp), %rax
	movq	480(%rsp), %rcx
	movq	32(%rsp), %r10
	movq	%r10, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r10
	andq	%rax, %r10
	orq	%rdx, %r10
	movq	%r8, 32(%rsp)
	movq	328(%rsp), %rax
	movq	488(%rsp), %rcx
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	negq	%rdx
	andq	%rcx, %rdx
	decq	%r9
	andq	%rax, %r9
	orq	%rdx, %r9
	movq	%r8, 32(%rsp)
	movq	336(%rsp), %rsi
	movq	496(%rsp), %rax
	movq	32(%rsp), %rdx
	movq	%rdx, %rcx
	negq	%rcx
	andq	%rax, %rcx
	decq	%rdx
	andq	%rsi, %rdx
	orq	%rcx, %rdx
	movq	%r8, 32(%rsp)
	movq	344(%rsp), %rdi
	movq	504(%rsp), %rsi
	movq	32(%rsp), %rcx
	movq	%rcx, %rax
	negq	%rax
	andq	%rsi, %rax
	decq	%rcx
	andq	%rdi, %rcx
	orq	%rax, %rcx
	movq	%r8, 32(%rsp)
	movq	352(%rsp), %rax
	movq	512(%rsp), %rsi
	movq	32(%rsp), %r8
	movq	%r8, %rdi
	negq	%rdi
	andq	%rsi, %rdi
	movq	608(%rsp), %rsi
	decq	%r8
	andq	%rax, %r8
	orq	%rdi, %r8
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	600(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	592(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	584(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	576(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	568(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	560(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	552(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	544(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	%rbp, 104(%rsp)
	movq	%r12, 112(%rsp)
	movq	%rbx, 120(%rsp)
	movq	%r14, 128(%rsp)
	movq	%r15, 136(%rsp)
	movq	%r13, 144(%rsp)
	movq	%r11, 152(%rsp)
	movq	%r10, 160(%rsp)
	movq	%r9, 168(%rsp)
	movq	%rdx, 176(%rsp)
	movq	%rcx, 184(%rsp)
	movq	%r8, 192(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	#MEMBARRIER
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	#MEMBARRIER
	addq	$-1, %rsi
	jb	.LBB27_1
	leaq	40(%rsp), %rdx
	movl	$160, %r8d
	movq	520(%rsp), %rcx
	callq	memcpy
	addq	$616, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point4base;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point4base,unique,28
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point4base:
	pushq	%rsi
	subq	$256, %rsp
	movq	%rcx, %rsi
	movabsq	$7378697629483820646, %rax
	movq	%rax, 80(%rsp)
	movq	%rax, 73(%rsp)
	movq	%rax, 65(%rsp)
	movq	%rax, 57(%rsp)
	movb	$88, 56(%rsp)
	leaq	88(%rsp), %rcx
	leaq	56(%rsp), %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point6decode
	cmpb	$1, 88(%rsp)
	je	.LBB28_1
	leaq	96(%rsp), %rdx
	movl	$160, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	addq	$256, %rsp
	popq	%rsi
	retq
.LBB28_1:
	movzbl	89(%rsp), %eax
	movb	%al, 55(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.15(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.14(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	55(%rsp), %r8
	movl	$18, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point6decode;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point6decode,unique,29
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point6decode:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$696, %rsp
	movq	%rcx, %rbx
	movq	24(%rdx), %rax
	movq	%rax, 184(%rsp)
	movq	16(%rdx), %rax
	movq	%rax, 176(%rsp)
	movq	(%rdx), %rax
	movq	8(%rdx), %rcx
	movq	%rcx, 168(%rsp)
	movq	%rax, 160(%rsp)
	movzbl	191(%rsp), %ebp
	movl	%ebp, %eax
	andb	$127, %al
	movb	%al, 191(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	xorl	%r8d, %r8d
	movabsq	$-6872316419617283935, %r12
	.p2align	4
.LBB29_1:
	movq	%r8, %rax
	mulq	%r12
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%r8b, %eax
	imull	$161, %eax, %eax
	movq	%r8, %rdx
	shrq	$3, %rdx
	movzbl	160(%rsp,%rdx), %edx
	movl	%r8d, %r9d
	andl	$7, %r9d
	xorl	%r10d, %r10d
	btl	%r9d, %edx
	setb	%r10b
	addl	%r8d, %ecx
	shlq	%cl, %r10
	shrl	$13, %eax
	orq	%r10, 80(%rsp,%rax,8)
	incq	%r8
	cmpq	$255, %r8
	jne	.LBB29_1
	movq	112(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	104(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	96(%rsp), %rax
	movq	%rax, 360(%rsp)
	movq	80(%rsp), %rax
	movq	88(%rsp), %rcx
	movq	%rcx, 352(%rsp)
	movq	%rax, 344(%rsp)
	leaq	80(%rsp), %rcx
	leaq	344(%rsp), %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F5bytes
	movzbl	80(%rsp), %r8d
	movzbl	81(%rsp), %ecx
	movzbl	82(%rsp), %edx
	movzbl	83(%rsp), %eax
	xorb	160(%rsp), %r8b
	xorb	161(%rsp), %cl
	orb	%r8b, %cl
	movzbl	84(%rsp), %r8d
	xorb	162(%rsp), %dl
	xorb	163(%rsp), %al
	orb	%dl, %al
	movzbl	85(%rsp), %edx
	orb	%cl, %al
	movzbl	86(%rsp), %ecx
	xorb	164(%rsp), %r8b
	xorb	165(%rsp), %dl
	orb	%r8b, %dl
	movzbl	87(%rsp), %r8d
	xorb	166(%rsp), %cl
	orb	%dl, %cl
	movzbl	88(%rsp), %edx
	orb	%al, %cl
	movzbl	89(%rsp), %r9d
	xorb	167(%rsp), %r8b
	xorb	168(%rsp), %dl
	orb	%r8b, %dl
	movzbl	90(%rsp), %eax
	xorb	169(%rsp), %r9b
	orb	%dl, %r9b
	movzbl	91(%rsp), %edx
	xorb	170(%rsp), %al
	orb	%r9b, %al
	movzbl	92(%rsp), %r8d
	orb	%cl, %al
	movzbl	93(%rsp), %r9d
	xorb	171(%rsp), %dl
	xorb	172(%rsp), %r8b
	orb	%dl, %r8b
	movzbl	94(%rsp), %edx
	xorb	173(%rsp), %r9b
	orb	%r8b, %r9b
	movzbl	95(%rsp), %ecx
	xorb	174(%rsp), %dl
	orb	%r9b, %dl
	movzbl	96(%rsp), %r8d
	xorb	175(%rsp), %cl
	orb	%dl, %cl
	movzbl	97(%rsp), %edx
	orb	%al, %cl
	movzbl	98(%rsp), %eax
	xorb	176(%rsp), %r8b
	xorb	177(%rsp), %dl
	orb	%r8b, %dl
	movzbl	99(%rsp), %r8d
	xorb	178(%rsp), %al
	orb	%dl, %al
	movzbl	100(%rsp), %edx
	xorb	179(%rsp), %r8b
	orb	%al, %r8b
	movzbl	101(%rsp), %eax
	xorb	180(%rsp), %dl
	orb	%r8b, %dl
	movzbl	102(%rsp), %r8d
	xorb	181(%rsp), %al
	orb	%dl, %al
	movzbl	103(%rsp), %edx
	orb	%cl, %al
	movzbl	104(%rsp), %ecx
	xorb	182(%rsp), %r8b
	xorb	183(%rsp), %dl
	orb	%r8b, %dl
	movzbl	105(%rsp), %r8d
	xorb	184(%rsp), %cl
	orb	%dl, %cl
	movzbl	106(%rsp), %edx
	xorb	185(%rsp), %r8b
	orb	%cl, %r8b
	movzbl	107(%rsp), %ecx
	xorb	186(%rsp), %dl
	orb	%r8b, %dl
	movzbl	108(%rsp), %r8d
	xorb	187(%rsp), %cl
	orb	%dl, %cl
	movzbl	109(%rsp), %edx
	xorb	188(%rsp), %r8b
	orb	%cl, %r8b
	movzbl	110(%rsp), %ecx
	xorb	189(%rsp), %dl
	xorb	190(%rsp), %cl
	orb	%al, %r8b
	orb	%dl, %cl
	orb	%r8b, %cl
	movzbl	111(%rsp), %eax
	xorb	191(%rsp), %al
	xorl	%edx, %edx
	orb	%cl, %al
	setne	%dl
	movq	%rdx, 32(%rsp)
	cmpq	$0, 32(%rsp)
	je	.LBB29_5
	movw	$769, (%rbx)
	jmp	.LBB29_4
.LBB29_5:
	movl	%ebp, %r14d
	shrb	$7, %r14b
	movabsq	$2251799813685247, %r15
	leaq	424(%rsp), %rcx
	leaq	344(%rsp), %rdx
	movq	%rdx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movabsq	$4503599627370457, %r9
	xorl	%ecx, %ecx
	addq	424(%rsp), %r9
	setb	%cl
	shldq	$13, %r9, %rcx
	xorl	%r8d, %r8d
	addq	432(%rsp), %rcx
	movq	$1, 464(%rsp)
	setb	%r8b
	movabsq	$4503599627370494, %r13
	addq	%r13, %rcx
	adcq	$0, %r8
	shldq	$13, %rcx, %r8
	movq	$0, 384(%rsp)
	xorl	%r10d, %r10d
	addq	440(%rsp), %r8
	setb	%r10b
	addq	%r13, %r8
	adcq	$0, %r10
	movq	$0, 624(%rsp)
	shldq	$13, %r8, %r10
	xorl	%r11d, %r11d
	addq	448(%rsp), %r10
	setb	%r11b
	addq	%r13, %r10
	adcq	$0, %r11
	shldq	$13, %r10, %r11
	movq	$0, 560(%rsp)
	xorl	%eax, %eax
	addq	456(%rsp), %r11
	setb	%al
	andq	%r15, %r9
	andq	%r15, %rcx
	andq	%r15, %r8
	andq	%r15, %r10
	addq	%r13, %r11
	adcq	$0, %rax
	movq	$0, 544(%rsp)
	shldq	$13, %r11, %rax
	andq	%r15, %r11
	movl	$19, %edx
	mulq	%rdx
	addq	%r9, %rax
	movq	%rax, %r9
	andq	%r15, %r9
	shrq	$51, %rax
	shll	$13, %edx
	orq	%rax, %rdx
	addq	%rcx, %rdx
	movq	%rdx, %rcx
	andq	%r15, %rcx
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r15, %r8
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%r15, %r10
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rax
	shrq	$51, %rax
	andq	%r15, %rdx
	leaq	(%rax,%rax,8), %r11
	leaq	(%rax,%r11,2), %rax
	addq	%r9, %rax
	movq	%rax, %r9
	andq	%r15, %r9
	shrq	$51, %rax
	addq	%rcx, %rax
	movq	%rax, %rcx
	shrq	$51, %rcx
	addq	%r8, %rcx
	movq	%rcx, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	movq	%r8, %r10
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r11
	leaq	(%rdx,%r11,2), %rdx
	addq	%r9, %rdx
	andq	%r15, %rax
	andq	%r15, %rcx
	andq	%r15, %r8
	andq	%r15, %r10
	movq	%rdx, 504(%rsp)
	movq	%rax, 512(%rsp)
	movq	%rcx, 520(%rsp)
	movq	%r8, 528(%rsp)
	movq	%r10, 536(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	xorl	%r8d, %r8d
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.11(%rip), %r9
	.p2align	4
.LBB29_6:
	movq	%r8, %rax
	mulq	%r12
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%r8b, %eax
	imull	$161, %eax, %eax
	movq	%r8, %rdx
	shrq	$3, %rdx
	movzbl	(%rdx,%r9), %edx
	movl	%r8d, %r10d
	andl	$7, %r10d
	xorl	%r11d, %r11d
	btl	%r10d, %edx
	setb	%r11b
	addl	%r8d, %ecx
	shlq	%cl, %r11
	shrl	$13, %eax
	orq	%r11, 80(%rsp,%rax,8)
	incq	%r8
	cmpq	$255, %r8
	jne	.LBB29_6
	movq	112(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	104(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	96(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	80(%rsp), %rax
	movq	88(%rsp), %rcx
	movq	%rcx, 40(%rsp)
	movq	%rax, 32(%rsp)
	leaq	80(%rsp), %rcx
	leaq	32(%rsp), %rdx
	leaq	424(%rsp), %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$1, 560(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 656(%rsp)
	movq	80(%rsp), %rcx
	xorl	%eax, %eax
	incq	%rcx
	sete	%al
	shldq	$13, %rcx, %rax
	andq	%r15, %rcx
	xorl	%edx, %edx
	addq	88(%rsp), %rax
	movq	$0, 336(%rsp)
	setb	%dl
	shldq	$13, %rax, %rdx
	andq	%r15, %rax
	xorl	%r8d, %r8d
	addq	96(%rsp), %rdx
	movq	$0, 328(%rsp)
	setb	%r8b
	shldq	$13, %rdx, %r8
	andq	%r15, %rdx
	xorl	%r9d, %r9d
	addq	104(%rsp), %r8
	setb	%r9b
	shldq	$13, %r8, %r9
	andq	%r15, %r8
	xorl	%r10d, %r10d
	addq	112(%rsp), %r9
	setb	%r10b
	movq	%r9, %r11
	shrq	$51, %r11
	shll	$13, %r10d
	orq	%r11, %r10
	andq	%r15, %r9
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r10
	addq	%rcx, %r10
	movq	%r10, %rcx
	andq	%r15, %rcx
	shrq	$51, %r10
	addq	%rax, %r10
	movq	%r10, %r11
	andq	%r15, %r11
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	andq	%r15, %rdx
	shrq	$51, %r10
	addq	%r8, %r10
	movq	%r10, %r8
	andq	%r15, %r8
	shrq	$51, %r10
	addq	%r9, %r10
	movq	%r10, %rax
	shrq	$51, %rax
	andq	%r15, %r10
	leaq	(%rax,%rax,8), %r9
	leaq	(%rax,%r9,2), %rax
	addq	%rcx, %rax
	movq	%rax, %rcx
	andq	%r15, %rcx
	shrq	$51, %rax
	addq	%r11, %rax
	movq	%rax, %r9
	shrq	$51, %r9
	addq	%rdx, %r9
	movq	%r9, %rdx
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	movq	%r8, %r10
	shrq	$51, %r10
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r10
	addq	%rcx, %r10
	andq	%r15, %rax
	andq	%r15, %r9
	andq	%r15, %rdx
	andq	%r15, %r8
	movq	%r10, 384(%rsp)
	movq	%rax, 392(%rsp)
	movq	%r9, 400(%rsp)
	movq	%rdx, 408(%rsp)
	movq	%r8, 416(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 624(%rsp)
	#MEMBARRIER
	movq	$0, 560(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$-1, 55(%rsp)
	movq	$-1, 49(%rsp)
	movq	$-1, 41(%rsp)
	movq	$-1, 33(%rsp)
	movb	$-21, 32(%rsp)
	movb	$127, 63(%rsp)
	leaq	80(%rsp), %rsi
	leaq	384(%rsp), %rdx
	leaq	32(%rsp), %r8
	movl	$255, %r9d
	movq	%rsi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3pow
	leaq	464(%rsp), %rdi
	leaq	504(%rsp), %rdx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$-1, 647(%rsp)
	movq	$-1, 641(%rsp)
	movq	$-1, 633(%rsp)
	movq	$-1, 625(%rsp)
	movb	$-2, 624(%rsp)
	movb	$15, 655(%rsp)
	leaq	240(%rsp), %rcx
	leaq	624(%rsp), %r8
	movl	$252, %r9d
	movq	%rdi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3pow
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	xorl	%r8d, %r8d
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.16(%rip), %r9
	.p2align	4
.LBB29_8:
	movq	%r8, %rax
	mulq	%r12
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%r8b, %eax
	imull	$161, %eax, %eax
	movq	%r8, %rdx
	shrq	$3, %rdx
	movzbl	(%rdx,%r9), %edx
	movl	%r8d, %r10d
	andl	$7, %r10d
	xorl	%r11d, %r11d
	btl	%r10d, %edx
	setb	%r11b
	addl	%r8d, %ecx
	shlq	%cl, %r11
	shrl	$13, %eax
	orq	%r11, 80(%rsp,%rax,8)
	incq	%r8
	cmpq	$255, %r8
	jne	.LBB29_8
	movq	112(%rsp), %rax
	movq	%rax, 64(%rsp)
	movq	104(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	96(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	80(%rsp), %rax
	movq	88(%rsp), %rcx
	movq	%rcx, 40(%rsp)
	movq	%rax, 32(%rsp)
	leaq	288(%rsp), %rcx
	leaq	240(%rsp), %rsi
	leaq	32(%rsp), %r8
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	leaq	80(%rsp), %rdi
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	movq	%rsi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	464(%rsp), %rsi
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq
	movq	288(%rsp), %rdx
	movq	296(%rsp), %r8
	movq	240(%rsp), %r9
	movq	248(%rsp), %r10
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	%rcx, %r11
	negq	%r11
	andq	%r9, %r11
	decq	%rcx
	andq	%rdx, %rcx
	orq	%r11, %rcx
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rdx
	movq	%rdx, %r9
	negq	%r9
	andq	%r10, %r9
	decq	%rdx
	andq	%r8, %rdx
	orq	%r9, %rdx
	movq	304(%rsp), %r9
	movq	256(%rsp), %r10
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %r8
	movq	%r8, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%r8
	andq	%r9, %r8
	orq	%r11, %r8
	movq	312(%rsp), %r9
	movq	264(%rsp), %r10
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %r11
	movq	%r11, %rdi
	negq	%rdi
	andq	%r10, %rdi
	decq	%r11
	andq	%r9, %r11
	orq	%rdi, %r11
	movq	320(%rsp), %r9
	movq	272(%rsp), %r10
	movq	%rax, 32(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, %rdi
	negq	%rdi
	andq	%r10, %rdi
	decq	%rax
	andq	%r9, %rax
	orq	%rdi, %rax
	movq	%rcx, 192(%rsp)
	movq	%rdx, 200(%rsp)
	movq	%r8, 208(%rsp)
	movq	%r11, 216(%rsp)
	movq	%rax, 224(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	leaq	80(%rsp), %rdi
	leaq	192(%rsp), %rdx
	movq	%rdi, %rcx
	movq	%rdx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	testq	%rax, %rax
	je	.LBB29_11
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	leaq	192(%rsp), %rcx
	leaq	80(%rsp), %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq
	testq	%rax, %rax
	sete	%al
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	testb	%bpl, %bpl
	setns	%cl
	orb	%al, %cl
	je	.LBB29_11
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 688(%rsp)
	xorl	%ecx, %ecx
	movabsq	$4503599627370458, %r10
	subq	192(%rsp), %r10
	movq	$0, 680(%rsp)
	sbbq	%rcx, %rcx
	movq	%rcx, %r8
	shrq	$51, %r8
	shldq	$13, %r10, %rcx
	andq	%r15, %r10
	subq	200(%rsp), %rcx
	sbbq	$0, %r8
	addq	%r13, %rcx
	adcq	$0, %r8
	movq	%r8, %r9
	shrq	$51, %r9
	shldq	$13, %rcx, %r8
	andq	%r15, %rcx
	subq	208(%rsp), %r8
	sbbq	$0, %r9
	addq	%r13, %r8
	adcq	$0, %r9
	movq	%r9, %r11
	shrq	$51, %r11
	shldq	$13, %r8, %r9
	andq	%r15, %r8
	subq	216(%rsp), %r9
	sbbq	$0, %r11
	addq	%r13, %r9
	adcq	$0, %r11
	movq	%r11, %rdx
	shrq	$51, %rdx
	shldq	$13, %r9, %r11
	andq	%r15, %r9
	subq	224(%rsp), %r11
	sbbq	$0, %rdx
	movq	$0, 672(%rsp)
	addq	%r13, %r11
	adcq	$0, %rdx
	movq	%rdx, %rax
	shldq	$13, %r11, %rax
	shrq	$51, %rdx
	andq	%r15, %r11
	leaq	(%rdx,%rdx,8), %rsi
	leaq	(%rdx,%rsi,2), %rsi
	movl	$19, %edx
	mulq	%rdx
	addq	%r10, %rax
	adcq	%rsi, %rdx
	shldq	$13, %rax, %rdx
	andq	%r15, %rax
	addq	%rcx, %rdx
	movq	%rdx, %r10
	andq	%r15, %r10
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r15, %r8
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %r9
	andq	%r15, %r9
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r15, %rdx
	leaq	(%rcx,%rcx,8), %r11
	leaq	(%rcx,%r11,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	andq	%r15, %rax
	shrq	$51, %rcx
	addq	%r10, %rcx
	movq	%rcx, %r10
	shrq	$51, %r10
	addq	%r8, %r10
	movq	%r10, %r8
	shrq	$51, %r8
	addq	%r9, %r8
	movq	%r8, %r9
	shrq	$51, %r9
	addq	%rdx, %r9
	movq	%r9, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r11
	leaq	(%rdx,%r11,2), %rdx
	addq	%rax, %rdx
	andq	%r15, %rcx
	andq	%r15, %r10
	andq	%r15, %r8
	andq	%r15, %r9
	movq	%rdx, 616(%rsp)
	movq	%rcx, 608(%rsp)
	movq	%r10, 600(%rsp)
	movq	%r8, 592(%rsp)
	movq	%r9, 584(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 672(%rsp)
	#MEMBARRIER
	leaq	80(%rsp), %rcx
	leaq	192(%rsp), %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F5bytes
	movzbl	80(%rsp), %eax
	andb	$1, %al
	xorb	%r14b, %al
	movzbl	%al, %ecx
	movq	616(%rsp), %rdx
	movq	192(%rsp), %r8
	movq	200(%rsp), %r9
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	%r10, %rax
	negq	%rax
	decq	%r10
	andq	%r8, %r10
	andq	%rdx, %rax
	orq	%r10, %rax
	movq	608(%rsp), %r8
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r10
	movq	%r10, %rdx
	negq	%rdx
	decq	%r10
	andq	%r9, %r10
	andq	%r8, %rdx
	orq	%r10, %rdx
	movq	208(%rsp), %r9
	movq	600(%rsp), %r10
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r11
	movq	%r11, %r8
	negq	%r8
	decq	%r11
	andq	%r9, %r11
	andq	%r10, %r8
	orq	%r11, %r8
	movq	216(%rsp), %r9
	movq	592(%rsp), %r10
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r11
	movq	%r11, %rsi
	negq	%rsi
	decq	%r11
	andq	%r9, %r11
	andq	%r10, %rsi
	orq	%r11, %rsi
	movq	224(%rsp), %r9
	movq	584(%rsp), %r10
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	%rcx, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%rcx
	andq	%r9, %rcx
	orq	%r11, %rcx
	movq	%rax, 32(%rsp)
	movq	%rdx, 40(%rsp)
	movq	%r8, 48(%rsp)
	movq	%rsi, 56(%rsp)
	movq	%rcx, 64(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 584(%rsp)
	#MEMBARRIER
	leaq	128(%rbx), %rcx
	leaq	32(%rsp), %rdx
	leaq	344(%rsp), %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	376(%rsp), %rax
	movq	%rax, 152(%rsp)
	movq	368(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	360(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	344(%rsp), %rax
	movq	352(%rsp), %rcx
	movq	%rcx, 128(%rsp)
	movq	%rax, 120(%rsp)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rax, 80(%rsp)
	movq	%rcx, 88(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	64(%rsp), %rax
	movq	%rax, 112(%rsp)
	leaq	8(%rbx), %rdi
	leaq	80(%rsp), %rsi
	movl	$10, %ecx
	rep;movsq (%rsi), %es:(%rdi)
	movq	$1, 88(%rbx)
	movq	$0, 96(%rbx)
	movq	$0, 104(%rbx)
	movq	$0, 112(%rbx)
	movq	$0, 120(%rbx)
	movb	$0, (%rbx)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	#MEMBARRIER
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	jmp	.LBB29_13
.LBB29_11:
	movw	$769, (%rbx)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	#MEMBARRIER
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
.LBB29_4:
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
.LBB29_13:
	#MEMBARRIER
	addq	$696, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056absorb;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056absorb,unique,30
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056absorb:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$80, %rsp
	movq	%rcx, %r12
	movl	%edx, %r14d
	andl	$67108863, %r14d
	addq	72(%rcx), %r14
	movq	%r8, %r10
	shldq	$12, %rdx, %r10
	shrq	$26, %rdx
	andl	$67108863, %edx
	addq	80(%rcx), %rdx
	andl	$67108863, %r10d
	addq	88(%rcx), %r10
	movq	%r8, %rsi
	shrq	$14, %rsi
	andl	$67108863, %esi
	addq	96(%rcx), %rsi
	shrq	$40, %r8
	addq	104(%rcx), %r8
	movzbl	%r9b, %ebx
	shll	$24, %ebx
	addq	%r8, %rbx
	movq	32(%rcx), %rdi
	movq	40(%rcx), %rax
	movq	%rax, (%rsp)
	movq	%r14, %rax
	imulq	%rdi, %rax
	movq	64(%rcx), %rcx
	movq	%rcx, 24(%rsp)
	movq	%rdx, %r8
	imulq	%rcx, %r8
	leaq	(%r8,%r8,4), %r8
	addq	%rax, %r8
	movq	56(%r12), %r11
	leaq	(%r10,%r10,4), %r13
	movq	%r13, %rbp
	imulq	%r11, %rbp
	movq	%r11, 8(%rsp)
	addq	%r8, %rbp
	movq	48(%r12), %rcx
	movq	%rcx, 16(%rsp)
	leaq	(%rsi,%rsi,4), %r8
	movq	%r8, %rax
	imulq	%rcx, %rax
	leaq	(%rbx,%rbx,4), %r9
	movq	%r9, %r15
	movq	(%rsp), %rcx
	imulq	%rcx, %r15
	addq	%rax, %r15
	addq	%rbp, %r15
	movq	%r14, %rax
	imulq	%rcx, %rax
	movq	%rdx, %rbp
	movq	%rdi, 32(%rsp)
	imulq	%rdi, %rbp
	addq	%rax, %rbp
	movq	%r8, %rax
	imulq	%r11, %rax
	addq	%rbp, %rax
	movq	24(%rsp), %rcx
	imulq	%rcx, %r13
	addq	%r13, %rax
	movq	%r9, %r13
	movq	16(%rsp), %r11
	imulq	%r11, %r13
	addq	%rax, %r13
	movq	%r14, %rax
	imulq	%r11, %rax
	movq	%rdx, %rbp
	movq	(%rsp), %r11
	imulq	%r11, %rbp
	addq	%rax, %rbp
	movq	%r10, %rax
	imulq	%rdi, %rax
	addq	%rbp, %rax
	imulq	%rcx, %r8
	movq	%r9, %rbp
	movq	8(%rsp), %rcx
	imulq	%rcx, %rbp
	addq	%r8, %rbp
	addq	%rax, %rbp
	movq	%r14, %rax
	imulq	%rcx, %rax
	movq	%rdx, %rcx
	movq	16(%rsp), %rdi
	imulq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%r10, %rax
	imulq	%r11, %rax
	addq	%rcx, %rax
	movq	%rsi, %rcx
	movq	32(%rsp), %r11
	imulq	%r11, %rcx
	movq	24(%rsp), %r8
	imulq	%r8, %r9
	addq	%rcx, %r9
	addq	%rax, %r9
	imulq	%r8, %r14
	imulq	8(%rsp), %rdx
	addq	%r14, %rdx
	imulq	%rdi, %r10
	addq	%rdx, %r10
	imulq	(%rsp), %rsi
	imulq	%r11, %rbx
	addq	%rsi, %rbx
	addq	%r10, %rbx
	movq	%r15, %rdx
	shrq	$26, %rdx
	addq	%r13, %rdx
	movq	%rdx, %rax
	shrq	$26, %rax
	addq	%rbp, %rax
	movq	%rax, %rcx
	shrq	$26, %rcx
	addq	%r9, %rcx
	andl	$67108863, %eax
	movq	%rax, 88(%r12)
	movq	%rcx, %rax
	shrq	$26, %rax
	addq	%rbx, %rax
	andl	$67108863, %ecx
	movq	%rcx, 96(%r12)
	movl	%eax, %ecx
	andl	$67108863, %ecx
	movq	%rcx, 104(%r12)
	andl	$67108863, %r15d
	andl	$67108863, %edx
	shrq	$26, %rax
	leaq	(%rax,%rax,4), %rax
	addq	%r15, %rax
	movq	%rax, %rcx
	shrq	$26, %rcx
	addq	%rdx, %rcx
	movq	%rcx, 80(%r12)
	andl	$67108863, %eax
	movq	%rax, 72(%r12)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	addq	$80, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056finish;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056finish,unique,31
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056finish:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$88, %rsp
	movq	%rdx, %rsi
	movq	%rcx, %rdi
	movq	112(%rdx), %rcx
	testq	%rcx, %rcx
	je	.LBB31_4
	cmpq	$16, %rcx
	jae	.LBB31_6
	movb	$1, 16(%rsi,%rcx)
	movq	112(%rsi), %rdx
	leaq	1(%rdx), %rcx
	cmpq	$16, %rcx
	ja	.LBB31_5
	leaq	16(%rsi), %rax
	movl	$15, %r8d
	subq	%rdx, %r8
	addq	%rcx, %rax
	movq	%rax, %rcx
	xorl	%edx, %edx
	callq	memset
	movzbl	16(%rsi), %eax
	movzbl	17(%rsi), %edx
	movzbl	18(%rsi), %ecx
	movzbl	19(%rsi), %r8d
	movzbl	20(%rsi), %r9d
	movzbl	21(%rsi), %r10d
	movzbl	22(%rsi), %r11d
	movzbl	23(%rsi), %ebx
	shlq	$56, %rbx
	shlq	$48, %r11
	orq	%rbx, %r11
	shlq	$40, %r10
	orq	%r11, %r10
	shlq	$32, %r9
	orq	%r10, %r9
	shll	$24, %r8d
	orq	%r9, %r8
	shll	$16, %ecx
	orq	%r8, %rcx
	shll	$8, %edx
	orq	%rcx, %rdx
	orq	%rax, %rdx
	movq	24(%rsi), %r8
	movq	%rsi, %rcx
	xorl	%r9d, %r9d
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056absorb
	movb	$0, 32(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 45(%rsp)
	#MEMBARRIER
.LBB31_4:
	movq	72(%rsi), %rdx
	movq	%rdx, %rax
	shrq	$26, %rax
	addq	80(%rsi), %rax
	andl	$67108863, %edx
	movq	%rax, %rcx
	shrq	$26, %rcx
	addq	88(%rsi), %rcx
	movq	%rcx, %r10
	shrq	$26, %r10
	addq	96(%rsi), %r10
	andl	$67108863, %eax
	andl	$67108863, %ecx
	movq	%r10, %r11
	shrq	$26, %r11
	addq	104(%rsi), %r11
	andl	$67108863, %r10d
	movq	%r11, %r8
	shrq	$26, %r8
	leaq	(%r8,%r8,4), %r9
	addq	%rdx, %r9
	andl	$67108863, %r11d
	movq	%r9, %r8
	shrq	$26, %r8
	addl	%eax, %r8d
	andl	$67108863, %r9d
	movl	%r8d, %edx
	shrl	$26, %edx
	addl	%ecx, %edx
	andl	$67108863, %r8d
	movl	%edx, %ecx
	shrl	$26, %ecx
	addl	%r10d, %ecx
	andl	$67108863, %edx
	movl	%ecx, %eax
	shrl	$26, %eax
	addq	%r11, %rax
	andl	$67108863, %ecx
	movl	%eax, %r10d
	shrl	$26, %r10d
	leal	(%r10,%r10,4), %r10d
	andl	$67108863, %eax
	leal	(%r9,%r10), %r12d
	addl	$5, %r12d
	movl	%r10d, %r11d
	addl	%r9d, %r11d
	movl	%r12d, %r15d
	shrl	$26, %r15d
	addl	%r8d, %r15d
	movl	%r15d, %r14d
	shrl	$26, %r14d
	addl	%edx, %r14d
	movl	%r14d, %ebp
	shrl	$26, %ebp
	addl	%ecx, %ebp
	movl	%ebp, %r10d
	shrl	$26, %r10d
	addq	%rax, %r10
	xorl	%ebx, %ebx
	cmpq	$67108864, %r10
	setae	%bl
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %r13
	movl	%r13d, %r9d
	negl	%r9d
	andl	%r12d, %r9d
	decl	%r13d
	andl	%r11d, %r13d
	andl	$67108863, %r9d
	orl	%r13d, %r9d
	movq	%r9, 72(%rsi)
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %r12
	movl	%r12d, %r11d
	negl	%r11d
	andl	%r15d, %r11d
	decl	%r12d
	andl	%r8d, %r12d
	andl	$67108863, %r11d
	orl	%r12d, %r11d
	movq	%r11, 80(%rsi)
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %r15
	movl	%r15d, %r8d
	negl	%r8d
	andl	%r14d, %r8d
	decl	%r15d
	andl	%edx, %r15d
	andl	$67108863, %r8d
	orl	%r15d, %r8d
	movq	%r8, 88(%rsi)
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %r14
	movl	%r14d, %edx
	negl	%edx
	andl	%ebp, %edx
	decl	%r14d
	andl	%ecx, %r14d
	andl	$67108863, %edx
	orl	%r14d, %edx
	movq	%rdx, 96(%rsi)
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rbx
	movl	%ebx, %ecx
	negl	%ecx
	andl	%r10d, %ecx
	decl	%ebx
	andl	%ebx, %eax
	andl	$67108863, %ecx
	orl	%eax, %ecx
	movq	%rcx, 104(%rsi)
	shlq	$26, %r11
	orq	%r9, %r11
	movl	%r8d, %eax
	shrl	$12, %eax
	shlq	$52, %r8
	orq	%r11, %r8
	shlq	$14, %rdx
	orq	%rax, %rdx
	shlq	$40, %rcx
	orq	%rdx, %rcx
	addq	(%rsi), %r8
	adcq	8(%rsi), %rcx
	movq	%rcx, 8(%rdi)
	movq	%r8, (%rdi)
	movq	$0, 32(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsi)
	movq	$0, 40(%rsi)
	movq	$0, 48(%rsi)
	movq	$0, 56(%rsi)
	movq	$0, 64(%rsi)
	#MEMBARRIER
	movq	$0, 72(%rsi)
	movq	$0, 80(%rsi)
	movq	$0, 88(%rsi)
	movq	$0, 96(%rsi)
	movq	$0, 104(%rsi)
	#MEMBARRIER
	movb	$0, 16(%rsi)
	movb	$0, 17(%rsi)
	movb	$0, 18(%rsi)
	movb	$0, 19(%rsi)
	movb	$0, 20(%rsi)
	movb	$0, 21(%rsi)
	movb	$0, 22(%rsi)
	movb	$0, 23(%rsi)
	movb	$0, 24(%rsi)
	movb	$0, 25(%rsi)
	movb	$0, 26(%rsi)
	movb	$0, 27(%rsi)
	movb	$0, 28(%rsi)
	movb	$0, 29(%rsi)
	movb	$0, 30(%rsi)
	movb	$0, 31(%rsi)
	#MEMBARRIER
	movb	$0, (%rsi)
	movb	$0, 1(%rsi)
	movb	$0, 2(%rsi)
	movb	$0, 3(%rsi)
	movb	$0, 4(%rsi)
	movb	$0, 5(%rsi)
	movb	$0, 6(%rsi)
	movb	$0, 7(%rsi)
	movb	$0, 8(%rsi)
	movb	$0, 9(%rsi)
	movb	$0, 10(%rsi)
	movb	$0, 11(%rsi)
	movb	$0, 12(%rsi)
	movb	$0, 13(%rsi)
	movb	$0, 14(%rsi)
	movb	$0, 15(%rsi)
	#MEMBARRIER
	addq	$88, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB31_5:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.21(%rip), %r9
	movl	$16, %edx
	movl	$16, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB31_6:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.20(%rip), %r8
	movl	$16, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update,unique,32
	.p2align	4
_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$56, %rsp
	movq	%r8, %rsi
	movq	%rdx, %rbx
	movq	%rcx, %rdi
	movq	112(%rcx), %rcx
	testq	%rcx, %rcx
	je	.LBB32_5
	movl	$16, %r14d
	subq	%rcx, %r14
	cmpq	%rsi, %r14
	cmovaeq	%rsi, %r14
	leaq	(%r14,%rcx), %rdx
	cmpq	%rcx, %rdx
	jb	.LBB32_3
	cmpq	$17, %rdx
	jae	.LBB32_3
	leaq	16(%rdi), %rax
	addq	%rcx, %rax
	movq	%rax, %rcx
	movq	%rbx, %rdx
	movq	%r14, %r8
	callq	memcpy
	movq	112(%rdi), %rax
	addq	%r14, %rax
	movq	%rax, 112(%rdi)
	subq	%r14, %rsi
	addq	%r14, %rbx
	cmpq	$16, %rax
	jne	.LBB32_5
	movzbl	16(%rdi), %eax
	movzbl	17(%rdi), %edx
	movzbl	18(%rdi), %ecx
	movzbl	19(%rdi), %r8d
	movzbl	20(%rdi), %r9d
	movzbl	21(%rdi), %r10d
	movzbl	22(%rdi), %r11d
	movzbl	23(%rdi), %r14d
	shlq	$56, %r14
	shlq	$48, %r11
	orq	%r14, %r11
	shlq	$40, %r10
	orq	%r11, %r10
	shlq	$32, %r9
	orq	%r10, %r9
	shll	$24, %r8d
	orq	%r9, %r8
	shll	$16, %ecx
	orq	%r8, %rcx
	shll	$8, %edx
	orq	%rcx, %rdx
	orq	%rax, %rdx
	movq	24(%rdi), %r8
	movq	%rdi, %rcx
	movb	$1, %r9b
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056absorb
	movb	$0, 55(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rdi)
.LBB32_5:
	cmpq	$16, %rsi
	jb	.LBB32_6
	.p2align	4
.LBB32_14:
	movq	(%rbx), %rdx
	movq	8(%rbx), %r8
	movq	%rdi, %rcx
	movb	$1, %r9b
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056absorb
	addq	$-16, %rsi
	addq	$16, %rbx
	cmpq	$15, %rsi
	ja	.LBB32_14
.LBB32_6:
	testq	%rsi, %rsi
	je	.LBB32_13
	movq	112(%rdi), %rcx
	leaq	(%rcx,%rsi), %rdx
	cmpq	%rcx, %rdx
	jb	.LBB32_9
	cmpq	$17, %rdx
	jae	.LBB32_9
	addq	%rdi, %rcx
	addq	$16, %rcx
	movq	%rbx, %rdx
	movq	%rsi, %r8
	callq	memcpy
	addq	%rsi, 112(%rdi)
.LBB32_13:
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq
.LBB32_3:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.23(%rip), %r9
	movl	$16, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB32_9:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.22(%rip), %r9
	movl	$16, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_,unique,33
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$64, %rsp
	movq	(%r8), %rsi
	addq	(%r9), %rsi
	movq	8(%r8), %r11
	adcq	$0, %r11
	setb	%al
	addq	8(%r9), %r11
	movzbl	%al, %r10d
	adcq	16(%r8), %r10
	setb	%al
	addq	16(%r9), %r10
	movzbl	%al, %eax
	adcq	24(%r8), %rax
	setb	%r8b
	movzbl	%r8b, %r14d
	addq	24(%r9), %rax
	adcq	$0, %r14
	movq	%rsi, %rdi
	subq	(%rdx), %rdi
	movl	$1, %r9d
	sbbq	$0, %r9
	movq	%r11, %r8
	subq	8(%rdx), %r8
	movl	$1, %ebx
	sbbq	$0, %rbx
	addq	%r9, %r8
	adcq	$0, %rbx
	movq	%rsi, 32(%rsp)
	addq	$-1, %r8
	adcq	$-1, %rbx
	xorq	$-2, %rbx
	movq	%r10, %r9
	subq	16(%rdx), %r9
	movl	$1, %r12d
	movl	$1, %r15d
	sbbq	$0, %r15
	addq	%rbx, %r9
	adcq	$-1, %r15
	addq	$1, %r9
	adcq	$0, %r15
	xorq	$-2, %r15
	movq	%rax, %rbx
	subq	24(%rdx), %rbx
	sbbq	$0, %r12
	movq	%r11, 24(%rsp)
	addq	%r15, %rbx
	adcq	$-1, %r12
	movq	%r10, 16(%rsp)
	addq	$1, %rbx
	adcq	$0, %r12
	movq	%rax, 8(%rsp)
	xorl	%r15d, %r15d
	orq	%r14, %r12
	setne	%r15b
	movq	%r15, (%rsp)
	movq	(%rsp), %rdx
	movq	%rdx, %r14
	negq	%r14
	andq	%rdi, %r14
	decq	%rdx
	andq	%rsi, %rdx
	orq	%r14, %rdx
	movq	%r15, (%rsp)
	movq	(%rsp), %rsi
	movq	%rsi, %rdi
	negq	%rdi
	andq	%r8, %rdi
	decq	%rsi
	andq	%r11, %rsi
	orq	%rdi, %rsi
	movq	%r15, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %r11
	negq	%r11
	andq	%r9, %r11
	decq	%r8
	andq	%r10, %r8
	orq	%r11, %r8
	movq	%r15, (%rsp)
	movq	(%rsp), %r9
	movq	%r9, %r10
	negq	%r10
	andq	%rbx, %r10
	decq	%r9
	andq	%rax, %r9
	orq	%r10, %r9
	movq	%rdx, (%rcx)
	movq	%rsi, 8(%rcx)
	movq	%r8, 16(%rcx)
	movq	%r9, 24(%rcx)
	movq	$0, (%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	#MEMBARRIER
	addq	$64, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_,unique,34
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$264, %rsp
	movq	%rdx, 192(%rsp)
	movq	(%r8), %r11
	movq	%r8, 176(%rsp)
	movq	(%r9), %rsi
	movq	%rsi, %rax
	movq	%rsi, 168(%rsp)
	mulq	%r11
	movq	%rax, 184(%rsp)
	movq	%rdx, 128(%rsp)
	movq	8(%r9), %r15
	movq	%r15, %rax
	mulq	%r11
	movq	%rax, %r10
	movq	%rdx, %rdi
	movq	16(%r9), %r14
	movq	%r14, %rax
	movq	%r14, 160(%rsp)
	mulq	%r11
	movq	%rax, %r12
	movq	%rdx, %r13
	movq	24(%r9), %rax
	movq	%rax, 152(%rsp)
	mulq	%r11
	movq	%rax, %rbp
	movq	%rdx, 144(%rsp)
	movq	8(%r8), %rbx
	movq	%rsi, %rax
	mulq	%rbx
	movq	%rdx, %r11
	movq	%rax, %r8
	movq	%r15, %rax
	mulq	%rbx
	addq	128(%rsp), %r10
	adcq	%rdi, %r12
	adcq	%r13, %rbp
	setb	%sil
	addq	%r8, %r10
	movq	%r10, 128(%rsp)
	adcq	%r11, %r12
	setb	%r8b
	addq	%rax, %r12
	movzbl	%r8b, %r8d
	adcq	%rdx, %r8
	movq	%r14, %rax
	mulq	%rbx
	xorl	%r11d, %r11d
	addq	%rbp, %r8
	setb	%r11b
	addq	%rax, %r8
	adcq	%rdx, %r11
	addb	$255, %sil
	adcq	144(%rsp), %r11
	setb	%sil
	movq	152(%rsp), %rdi
	movq	%rdi, %rax
	mulq	%rbx
	movq	%rax, %rbp
	addq	%r11, %rbp
	movzbl	%sil, %r11d
	adcq	%rdx, %r11
	movq	176(%rsp), %r10
	movq	16(%r10), %rsi
	movq	168(%rsp), %rax
	mulq	%rsi
	movq	%rdx, %r13
	movq	%rax, %r14
	movq	%r15, %rax
	mulq	%rsi
	addq	%r12, %r14
	adcq	%r8, %r13
	setb	%r8b
	addq	%rax, %r13
	movzbl	%r8b, %r15d
	adcq	%rdx, %r15
	movq	160(%rsp), %rax
	mulq	%rsi
	xorl	%ebx, %ebx
	addq	%rbp, %r15
	setb	%bl
	addq	%rax, %r15
	adcq	%rdx, %rbx
	movq	%rdi, %rax
	mulq	%rsi
	xorl	%edi, %edi
	addq	%r11, %rbx
	setb	%dil
	addq	%rax, %rbx
	adcq	%rdx, %rdi
	movq	24(%r10), %r8
	movq	%r8, %rax
	mulq	(%r9)
	movq	%rax, %r11
	movq	%rdx, %rsi
	movq	128(%rsp), %rax
	movq	%rax, 120(%rsp)
	addq	%r13, %r11
	adcq	%r15, %rsi
	setb	%bpl
	movq	%r8, %rax
	mulq	8(%r9)
	movq	%rax, %r10
	movq	%r14, 96(%rsp)
	movq	184(%rsp), %r15
	movq	%r15, 136(%rsp)
	movzbl	%bpl, %r14d
	addq	%rsi, %r10
	adcq	%rdx, %r14
	movq	%r8, %rax
	mulq	16(%r9)
	movq	%r11, 56(%rsp)
	movq	%r10, 48(%rsp)
	xorl	%r10d, %r10d
	addq	%rbx, %r14
	setb	%r10b
	addq	%rax, %r14
	adcq	%rdx, %r10
	movq	%r14, 80(%rsp)
	movq	%r8, %rax
	mulq	24(%r9)
	xorl	%r8d, %r8d
	addq	%rdi, %r10
	setb	%r8b
	addq	%rax, %r10
	adcq	%rdx, %r8
	movq	%r10, 88(%rsp)
	movq	%r8, 112(%rsp)
	movq	192(%rsp), %rax
	movq	96(%rax), %rbx
	movq	(%rax), %r11
	movq	8(%rax), %r10
	movq	16(%rax), %r9
	movq	24(%rax), %r8
	movq	%rbx, %r14
	imulq	%r15, %r14
	movq	%r11, %rax
	mulq	%r14
	movq	%rdx, %rdi
	movq	%rax, %rsi
	movq	%r10, %rax
	mulq	%r14
	addq	%r15, %rsi
	adcq	120(%rsp), %rdi
	movq	%rsi, 136(%rsp)
	setb	%sil
	movzbl	%sil, %esi
	addq	%rax, %rdi
	adcq	%rdx, %rsi
	movq	%r9, %rax
	mulq	%r14
	xorl	%r15d, %r15d
	addq	96(%rsp), %rsi
	setb	%r15b
	addq	%rax, %rsi
	adcq	%rdx, %r15
	movq	%r8, %rax
	mulq	%r14
	xorl	%r14d, %r14d
	addq	56(%rsp), %r15
	setb	%r14b
	addq	%rax, %r15
	adcq	%rdx, %r14
	addq	%r14, 48(%rsp)
	movq	$0, 104(%rsp)
	adcq	$0, 80(%rsp)
	adcq	$0, 88(%rsp)
	adcq	$0, 112(%rsp)
	adcq	$0, 104(%rsp)
	movq	%rdi, 120(%rsp)
	movq	%rsi, 96(%rsp)
	movq	%r15, 56(%rsp)
	setb	%al
	movzbl	%al, %eax
	movq	%rax, 64(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 72(%rsp)
	jb	.LBB34_5
	movq	120(%rsp), %r15
	movq	%rbx, %r14
	imulq	%r15, %r14
	movq	%r11, %rax
	mulq	%r14
	movq	%rdx, %rsi
	movq	%rax, %rdi
	movq	%r10, %rax
	mulq	%r14
	addq	%r15, %rdi
	adcq	96(%rsp), %rsi
	setb	%bpl
	movzbl	%bpl, %r15d
	addq	%rax, %rsi
	adcq	%rdx, %r15
	movq	%r9, %rax
	mulq	%r14
	movq	%rdi, 120(%rsp)
	xorl	%edi, %edi
	addq	56(%rsp), %r15
	movq	%rsi, 96(%rsp)
	setb	%dil
	addq	%rax, %r15
	adcq	%rdx, %rdi
	movq	%r15, 56(%rsp)
	movq	%r8, %rax
	mulq	%r14
	xorl	%esi, %esi
	addq	48(%rsp), %rdi
	setb	%sil
	addq	%rax, %rdi
	adcq	%rdx, %rsi
	movq	%rdi, 48(%rsp)
	addq	%rsi, 80(%rsp)
	adcq	$0, 88(%rsp)
	adcq	$0, 112(%rsp)
	adcq	$0, 104(%rsp)
	setb	%al
	movzbl	%al, %eax
	movq	%rax, 64(%rsp)
	movq	$0, 72(%rsp)
	jb	.LBB34_5
	movq	96(%rsp), %r15
	movq	%rbx, %r14
	imulq	%r15, %r14
	movq	%r11, %rax
	mulq	%r14
	movq	%rdx, %rsi
	movq	%rax, %rdi
	movq	%r10, %rax
	mulq	%r14
	addq	%r15, %rdi
	adcq	56(%rsp), %rsi
	setb	%bpl
	movzbl	%bpl, %r15d
	addq	%rax, %rsi
	adcq	%rdx, %r15
	movq	%r9, %rax
	mulq	%r14
	movq	%rdi, 96(%rsp)
	xorl	%edi, %edi
	addq	48(%rsp), %r15
	movq	%rsi, 56(%rsp)
	setb	%dil
	addq	%rax, %r15
	adcq	%rdx, %rdi
	movq	%r15, 48(%rsp)
	movq	%r8, %rax
	mulq	%r14
	xorl	%esi, %esi
	addq	80(%rsp), %rdi
	setb	%sil
	addq	%rax, %rdi
	adcq	%rdx, %rsi
	movq	%rdi, 80(%rsp)
	addq	%rsi, 88(%rsp)
	adcq	$0, 112(%rsp)
	adcq	$0, 104(%rsp)
	setb	%al
	movzbl	%al, %eax
	movq	%rax, 64(%rsp)
	movq	$0, 72(%rsp)
	jb	.LBB34_5
	movq	56(%rsp), %r14
	imulq	%r14, %rbx
	movq	%r11, %rax
	mulq	%rbx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	movq	%r10, %rax
	mulq	%rbx
	addq	%r14, %rdi
	adcq	48(%rsp), %rsi
	setb	%bpl
	movzbl	%bpl, %r14d
	addq	%rax, %rsi
	adcq	%rdx, %r14
	movq	%r9, %rax
	mulq	%rbx
	movq	%rdi, 56(%rsp)
	xorl	%edi, %edi
	addq	80(%rsp), %r14
	movq	%rsi, 48(%rsp)
	setb	%dil
	addq	%rax, %r14
	adcq	%rdx, %rdi
	movq	%r14, 80(%rsp)
	movq	%r8, %rax
	mulq	%rbx
	xorl	%esi, %esi
	addq	88(%rsp), %rdi
	setb	%sil
	addq	%rax, %rdi
	adcq	%rdx, %rsi
	movq	%rdi, 88(%rsp)
	addq	%rsi, 112(%rsp)
	adcq	$0, 104(%rsp)
	setb	%al
	movzbl	%al, %eax
	movq	%rax, 64(%rsp)
	movq	$0, 72(%rsp)
	jb	.LBB34_5
	movq	48(%rsp), %rsi
	movq	%rsi, %rdi
	subq	%r11, %rdi
	movl	$1, %edx
	sbbq	$0, %rdx
	movq	80(%rsp), %rax
	movq	%rax, %r11
	subq	%r10, %r11
	movl	$1, %ebx
	sbbq	$0, %rbx
	addq	%rdx, %r11
	adcq	$0, %rbx
	addq	$-1, %r11
	adcq	$-1, %rbx
	movl	$1, %r15d
	xorq	$-2, %rbx
	movq	88(%rsp), %rdx
	movq	%rdx, %r10
	subq	%r9, %r10
	movl	$1, %r14d
	sbbq	$0, %r14
	addq	%rbx, %r10
	adcq	$-1, %r14
	addq	$1, %r10
	adcq	$0, %r14
	xorq	$-2, %r14
	movq	112(%rsp), %r9
	movq	%r9, %rbx
	subq	%r8, %rbx
	sbbq	$0, %r15
	addq	%r14, %rbx
	adcq	$-1, %r15
	addq	$1, %rbx
	adcq	$0, %r15
	xorl	%r14d, %r14d
	orq	104(%rsp), %r15
	setne	%r14b
	movq	%r14, 64(%rsp)
	movq	64(%rsp), %r8
	movq	%r8, %r15
	negq	%r15
	andq	%rdi, %r15
	decq	%r8
	andq	%rsi, %r8
	orq	%r15, %r8
	movq	%r14, 64(%rsp)
	movq	64(%rsp), %rsi
	movq	%rsi, %rdi
	negq	%rdi
	andq	%r11, %rdi
	decq	%rsi
	andq	%rax, %rsi
	orq	%rdi, %rsi
	movq	%r14, 64(%rsp)
	movq	64(%rsp), %rax
	movq	%rax, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%rax
	andq	%rdx, %rax
	orq	%r11, %rax
	movq	%r14, 64(%rsp)
	movq	64(%rsp), %rdx
	movq	%rdx, %r10
	negq	%r10
	andq	%rbx, %r10
	decq	%rdx
	andq	%r9, %rdx
	orq	%r10, %rdx
	movq	%r8, (%rcx)
	movq	%rsi, 8(%rcx)
	movq	%rax, 16(%rcx)
	movq	%rdx, 24(%rcx)
	movq	$0, 64(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
	addq	$264, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB34_5:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.24(%rip), %rax
	movq	%rax, 40(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.18(%rip), %r8
	leaq	64(%rsp), %rdx
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	callq	_RINvNtCsbOZu4GxVKn0_4core9panicking13assert_failedooECs3ONsSsjNgxw_12toyos_crypto
	ud2

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_,unique,35
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$264, %rsp
	movq	%rcx, %rdi
	movq	(%rdx), %rax
	cmpq	$0, 24(%rdx)
	setns	%cl
	testb	$1, %al
	je	.LBB35_1
	testb	%cl, %cl
	jne	.LBB35_6
.LBB35_3:
	movl	$2, %ecx
	movl	$2, %r8d
	subq	%rax, %r8
	movq	%r8, %r9
	imulq	%rax, %r9
	movl	$2, %r10d
	subq	%r9, %r10
	imulq	%r8, %r10
	movq	%r10, %r8
	imulq	%rax, %r8
	movl	$2, %r9d
	subq	%r8, %r9
	imulq	%r10, %r9
	movq	%r9, %r8
	imulq	%rax, %r8
	movl	$2, %r10d
	subq	%r8, %r10
	imulq	%r9, %r10
	movq	%r10, %r8
	imulq	%rax, %r8
	subq	%r8, %rcx
	imulq	%r10, %rcx
	imulq	%rcx, %rax
	addq	$-2, %rax
	imulq	%rcx, %rax
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	(%rdx), %rcx
	movq	8(%rdx), %r8
	movq	%rcx, 128(%rsp)
	movq	%r8, 136(%rsp)
	movq	16(%rdx), %rcx
	movq	%rcx, 144(%rsp)
	movq	24(%rdx), %rcx
	movq	%rcx, 152(%rsp)
	movq	%rax, 224(%rsp)
	leaq	160(%rsp), %rsi
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$1, 64(%rsp)
	movl	$512, %r12d
	leaq	32(%rsp), %rbx
	leaq	128(%rsp), %r14
	leaq	64(%rsp), %r15
	.p2align	4
.LBB35_4:
	movq	%rbx, %rcx
	movq	%r14, %rdx
	movq	%r15, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	56(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 64(%rsp)
	decq	%r12
	jne	.LBB35_4
	movq	88(%rsp), %rax
	movq	%rax, 56(%rsp)
	movq	80(%rsp), %rax
	movq	%rax, 48(%rsp)
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rcx, 40(%rsp)
	movq	%rax, 32(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	56(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	48(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	movq	256(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	240(%rsp), %rax
	movq	248(%rsp), %rcx
	movq	%rcx, 112(%rsp)
	movq	%rax, 104(%rsp)
	movq	$1, 96(%rsp)
	leaq	32(%rsp), %rcx
	leaq	128(%rsp), %rbx
	leaq	96(%rsp), %r8
	movq	%rbx, %rdx
	movq	%rsi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	56(%rsp), %rax
	movq	%rax, 216(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 208(%rsp)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 200(%rsp)
	movq	%rax, 192(%rsp)
	movl	$13, %ecx
	movq	%rbx, %rsi
	rep;movsq (%rsi), %es:(%rdi)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	addq	$264, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq
.LBB35_1:
	movb	$1, %cl
	testb	%cl, %cl
	je	.LBB35_3
.LBB35_6:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.25(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.26(%rip), %r8
	movl	$76, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking5panic
	ud2

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_,unique,36
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$176, %rsp
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movq	(%rdx), %rax
	movq	8(%rdx), %rcx
	movq	%rax, 80(%rsp)
	movq	%rcx, 88(%rsp)
	movq	16(%rdx), %rdx
	movq	%rdx, 96(%rsp)
	movq	24(%rbx), %r8
	movq	%r8, 104(%rsp)
	addq	$-2, %rax
	movq	%rax, 80(%rsp)
	movl	$1, %eax
	movl	$1, %r9d
	sbbq	$0, %r9
	subq	%r9, %rcx
	movl	$1, %r9d
	sbbq	$0, %r9
	movq	%rcx, 88(%rsp)
	xorq	$1, %r9
	subq	%r9, %rdx
	sbbq	$0, %rax
	movq	%rdx, 96(%rsp)
	xorq	$1, %rax
	subq	%rax, %r8
	movq	%r8, 104(%rsp)
	movq	88(%rbx), %rax
	movq	%rax, 72(%rsp)
	movq	80(%rbx), %rax
	movq	%rax, 64(%rsp)
	movq	64(%rbx), %rax
	movq	72(%rbx), %rcx
	movq	%rcx, 56(%rsp)
	movq	%rax, 48(%rsp)
	movl	$255, %r13d
	leaq	112(%rsp), %r14
	leaq	48(%rsp), %r15
	leaq	144(%rsp), %r12
	.p2align	4
.LBB36_1:
	movq	%r14, %rcx
	movq	%rbx, %rdx
	movq	%r15, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	%r12, %rcx
	movq	%rbx, %rdx
	movq	%r14, %r8
	movq	%rdi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	%r13, %rax
	shrq	$6, %rax
	movq	80(%rsp,%rax,8), %rax
	xorl	%ecx, %ecx
	btq	%r13, %rax
	setb	%cl
	movq	112(%rsp), %rdx
	movq	120(%rsp), %r8
	movq	144(%rsp), %r9
	movq	152(%rsp), %r10
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, %r11
	negq	%r11
	andq	%r9, %r11
	decq	%rax
	andq	%rdx, %rax
	orq	%r11, %rax
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rdx
	movq	%rdx, %r9
	negq	%r9
	andq	%r10, %r9
	decq	%rdx
	andq	%r8, %rdx
	orq	%r9, %rdx
	movq	128(%rsp), %r9
	movq	160(%rsp), %r10
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %r8
	movq	%r8, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%r8
	andq	%r9, %r8
	orq	%r11, %r8
	movq	136(%rsp), %r9
	movq	168(%rsp), %r10
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rcx
	movq	%rcx, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%rcx
	andq	%r9, %rcx
	orq	%r11, %rcx
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%r8, 64(%rsp)
	movq	%rcx, 72(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	addq	$-1, %r13
	jb	.LBB36_1
	movq	72(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	64(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	48(%rsp), %rax
	movq	56(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	addq	$176, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_,unique,37
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$200, %rsp
	movq	%rdx, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	(%r9), %r15
	movq	8(%r9), %r10
	movq	16(%r9), %r11
	movq	24(%r9), %rsi
	movq	32(%r9), %rdi
	movq	40(%r9), %rbx
	xorl	%r13d, %r13d
	xorl	%ebp, %ebp
	.p2align	4
.LBB37_1:
	movq	(%r8,%rbp,8), %r14
	movq	%r15, %rax
	mulq	%r14
	movq	%rdx, %r9
	movq	%rax, %r12
	movq	%r10, %rax
	mulq	%r14
	addq	%r12, 56(%rsp,%rbp,8)
	adcq	64(%rsp,%rbp,8), %r9
	setb	%r12b
	movzbl	%r12b, %r12d
	addq	%rax, %r9
	adcq	%rdx, %r12
	movq	%r11, %rax
	mulq	%r14
	movq	%r9, 64(%rsp,%rbp,8)
	xorl	%r9d, %r9d
	addq	72(%rsp,%rbp,8), %r12
	setb	%r9b
	addq	%rax, %r12
	adcq	%rdx, %r9
	movq	%r12, 72(%rsp,%rbp,8)
	movq	%rsi, %rax
	mulq	%r14
	xorl	%r12d, %r12d
	addq	80(%rsp,%rbp,8), %r9
	setb	%r12b
	addq	%rax, %r9
	adcq	%rdx, %r12
	movq	%rdi, %rax
	mulq	%r14
	movq	%r9, 80(%rsp,%rbp,8)
	xorl	%r9d, %r9d
	addq	88(%rsp,%rbp,8), %r12
	setb	%r9b
	addq	%rax, %r12
	adcq	%rdx, %r9
	movq	%r12, 88(%rsp,%rbp,8)
	movq	%rbx, %rax
	mulq	%r14
	xorl	%r14d, %r14d
	addq	%r13, %r9
	setb	%r14b
	addq	%rax, %r9
	adcq	%rdx, %r14
	movq	%r9, 96(%rsp,%rbp,8)
	movq	%r14, 104(%rsp,%rbp,8)
	incq	%rbp
	movq	%r14, %r13
	cmpq	$6, %rbp
	jne	.LBB37_1
	movq	168(%rsp), %rax
	movq	144(%rax), %r12
	movq	(%rax), %r9
	movq	8(%rax), %r10
	movq	16(%rax), %r11
	movq	24(%rax), %rsi
	movq	32(%rax), %rdi
	movq	40(%rax), %rbx
	xorl	%ebp, %ebp
	.p2align	4
.LBB37_3:
	movq	56(%rsp,%rbp), %r14
	movq	%r12, %r13
	imulq	%r14, %r13
	movq	%r9, %rax
	mulq	%r13
	movq	%rdx, %r8
	movq	%rax, %r15
	movq	%r10, %rax
	mulq	%r13
	addq	%r14, %r15
	movq	%r15, 56(%rsp,%rbp)
	adcq	64(%rsp,%rbp), %r8
	setb	%r14b
	movzbl	%r14b, %r15d
	addq	%rax, %r8
	adcq	%rdx, %r15
	movq	%r8, 64(%rsp,%rbp)
	movq	%r11, %rax
	mulq	%r13
	xorl	%r14d, %r14d
	addq	72(%rsp,%rbp), %r15
	setb	%r14b
	addq	%rax, %r15
	adcq	%rdx, %r14
	movq	%rsi, %rax
	mulq	%r13
	movq	%r15, 72(%rsp,%rbp)
	xorl	%r8d, %r8d
	addq	80(%rsp,%rbp), %r14
	setb	%r8b
	addq	%rax, %r14
	adcq	%rdx, %r8
	movq	%r14, 80(%rsp,%rbp)
	movq	%rdi, %rax
	mulq	%r13
	xorl	%r14d, %r14d
	addq	88(%rsp,%rbp), %r8
	setb	%r14b
	addq	%rax, %r8
	adcq	%rdx, %r14
	movq	%rbx, %rax
	mulq	%r13
	movq	%r8, 88(%rsp,%rbp)
	xorl	%r8d, %r8d
	addq	96(%rsp,%rbp), %r14
	setb	%r8b
	addq	%rax, %r14
	adcq	%rdx, %r8
	movq	%r14, 96(%rsp,%rbp)
	xorl	%eax, %eax
	addq	%r8, 104(%rsp,%rbp)
	setb	%al
	cmpq	$48, %rbp
	je	.LBB37_16
	cmpq	$56, %rbp
	je	.LBB37_16
	addq	%rax, 112(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$40, %rbp
	je	.LBB37_16
	cmpq	$48, %rbp
	je	.LBB37_16
	addq	%rax, 120(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$32, %rbp
	je	.LBB37_16
	cmpq	$40, %rbp
	je	.LBB37_16
	addq	%rax, 128(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$24, %rbp
	je	.LBB37_16
	cmpq	$32, %rbp
	je	.LBB37_16
	addq	%rax, 136(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$16, %rbp
	je	.LBB37_16
	cmpq	$24, %rbp
	je	.LBB37_16
	addq	%rax, 144(%rsp,%rbp)
	setb	%dl
	xorl	%eax, %eax
	movb	%dl, %al
	cmpq	$8, %rbp
	je	.LBB37_16
	cmpq	$16, %rbp
	je	.LBB37_16
	xorl	%edx, %edx
	addq	%rax, 152(%rsp,%rbp)
	setb	%dl
	movq	%rdx, %rax
	.p2align	4
.LBB37_16:
	movq	%rax, 176(%rsp)
	movq	$0, 184(%rsp)
	testq	%rax, %rax
	jne	.LBB37_19
	addq	$8, %rbp
	cmpq	$48, %rbp
	jne	.LBB37_3
	leaq	104(%rsp), %r8
	movq	152(%rsp), %r9
	movq	168(%rsp), %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	leaq	56(%rsp), %rax
	movq	$0, (%rax)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	addq	$200, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB37_19:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.24(%rip), %rax
	movq	%rax, 40(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.18(%rip), %r8
	leaq	176(%rsp), %rdx
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	callq	_RINvNtCsbOZu4GxVKn0_4core9panicking13assert_failedooECs3ONsSsjNgxw_12toyos_crypto
	ud2

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_,unique,38
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$328, %rsp
	movq	%rcx, %rsi
	movq	(%rdx), %rax
	cmpq	$0, 40(%rdx)
	setns	%cl
	testb	$1, %al
	je	.LBB38_1
	testb	%cl, %cl
	jne	.LBB38_6
.LBB38_3:
	movl	$2, %ecx
	movl	$2, %r8d
	subq	%rax, %r8
	movq	%r8, %r9
	imulq	%rax, %r9
	movl	$2, %r10d
	subq	%r9, %r10
	imulq	%r8, %r10
	movq	%r10, %r8
	imulq	%rax, %r8
	movl	$2, %r9d
	subq	%r8, %r9
	imulq	%r10, %r9
	movq	%r9, %r8
	imulq	%rax, %r8
	movl	$2, %r10d
	subq	%r8, %r10
	imulq	%r9, %r10
	movq	%r10, %r8
	imulq	%rax, %r8
	subq	%r8, %rcx
	imulq	%r10, %rcx
	imulq	%rcx, %rax
	addq	$-2, %rax
	imulq	%rcx, %rax
	movq	40(%rdx), %rcx
	movq	%rcx, 216(%rsp)
	movq	32(%rdx), %rcx
	movq	%rcx, 208(%rsp)
	movq	24(%rdx), %rcx
	movq	%rcx, 200(%rsp)
	movq	16(%rdx), %rcx
	movq	%rcx, 192(%rsp)
	movq	(%rdx), %rcx
	movq	8(%rdx), %rdx
	movq	%rdx, 184(%rsp)
	movq	%rcx, 176(%rsp)
	movq	%rax, 320(%rsp)
	leaq	224(%rsp), %rdi
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$1, 168(%rsp)
	movl	$1, %eax
	movl	$768, %r12d
	xorl	%r9d, %r9d
	leaq	32(%rsp), %rbx
	leaq	176(%rsp), %r14
	leaq	80(%rsp), %r15
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	xorl	%r8d, %r8d
	xorl	%r10d, %r10d
	.p2align	4
.LBB38_4:
	leaq	(%rax,%rax), %r11
	movq	%r11, 80(%rsp)
	shrdq	$63, %r10, %rax
	shrdq	$63, %r8, %r10
	movq	%rax, 88(%rsp)
	movq	%r10, 96(%rsp)
	shrdq	$63, %rdx, %r8
	movq	%r8, 104(%rsp)
	shrdq	$63, %rcx, %rdx
	movq	%rdx, 112(%rsp)
	shrdq	$63, %r9, %rcx
	movq	%rcx, 120(%rsp)
	shrq	$63, %r9
	movq	%rbx, %rcx
	movq	%r14, %rdx
	movq	%r15, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	32(%rsp), %rax
	movq	40(%rsp), %r10
	movq	%rax, 168(%rsp)
	movq	%r10, 160(%rsp)
	movq	48(%rsp), %r8
	movq	%r8, 152(%rsp)
	movq	56(%rsp), %rdx
	movq	%rdx, 144(%rsp)
	movq	64(%rsp), %rcx
	movq	%rcx, 136(%rsp)
	movq	72(%rsp), %r9
	movq	%r9, 128(%rsp)
	decq	%r12
	jne	.LBB38_4
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	%rax, 224(%rsp)
	movq	%r10, 232(%rsp)
	movq	%r8, 240(%rsp)
	movq	%rdx, 248(%rsp)
	movq	%rcx, 256(%rsp)
	movq	%r9, 264(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$1, 32(%rsp)
	leaq	80(%rsp), %rcx
	leaq	176(%rsp), %rbx
	leaq	32(%rsp), %r8
	movq	%rbx, %rdx
	movq	%rdi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	120(%rsp), %rax
	movq	%rax, 312(%rsp)
	movq	112(%rsp), %rax
	movq	%rax, 304(%rsp)
	movq	104(%rsp), %rax
	movq	%rax, 296(%rsp)
	movq	96(%rsp), %rax
	movq	%rax, 288(%rsp)
	movq	80(%rsp), %rax
	movq	88(%rsp), %rcx
	movq	%rcx, 280(%rsp)
	movq	%rax, 272(%rsp)
	movl	$152, %r8d
	movq	%rsi, %rcx
	movq	%rbx, %rdx
	callq	memcpy
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	addq	$328, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq
.LBB38_1:
	movb	$1, %cl
	testb	%cl, %cl
	je	.LBB38_3
.LBB38_6:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.25(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.26(%rip), %r8
	movl	$76, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking5panic
	ud2

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_,unique,39
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3subB7_:
	pushq	%r15
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	pushq	%rax
	movq	32(%r8), %rax
	movq	24(%r8), %r10
	movq	(%r8), %rsi
	movq	8(%r8), %r11
	subq	(%r9), %rsi
	movl	$1, %edi
	sbbq	$0, %rdi
	xorq	$1, %rdi
	xorl	%ebx, %ebx
	addq	8(%r9), %rdi
	setb	%bl
	subq	%rdi, %r11
	movl	$1, %r14d
	sbbq	%rbx, %r14
	xorq	$1, %r14
	xorl	%ebx, %ebx
	addq	16(%r9), %r14
	movq	16(%r8), %rdi
	setb	%bl
	subq	%r14, %rdi
	movl	$1, %r14d
	sbbq	%rbx, %r14
	xorq	$1, %r14
	xorl	%ebx, %ebx
	addq	24(%r9), %r14
	setb	%bl
	subq	%r14, %r10
	movl	$1, %r14d
	sbbq	%rbx, %r14
	xorq	$1, %r14
	xorl	%ebx, %ebx
	addq	32(%r9), %r14
	setb	%bl
	subq	%r14, %rax
	movl	$1, %r14d
	sbbq	%rbx, %r14
	movl	$1, %ebx
	xorq	$1, %r14
	movq	40(%r8), %r8
	xorl	%r15d, %r15d
	addq	40(%r9), %r14
	setb	%r15b
	subq	%r14, %r8
	sbbq	%r15, %rbx
	xorq	$1, %rbx
	movq	%rbx, (%rsp)
	xorl	%r9d, %r9d
	subq	(%rsp), %r9
	movq	(%rdx), %rbx
	andq	%r9, %rbx
	addq	%rsi, %rbx
	adcq	$0, %r11
	setb	%sil
	movzbl	%sil, %r14d
	movq	8(%rdx), %rsi
	andq	%r9, %rsi
	addq	%r11, %rsi
	adcq	%rdi, %r14
	setb	%r11b
	movzbl	%r11b, %edi
	movq	16(%rdx), %r11
	andq	%r9, %r11
	addq	%r14, %r11
	adcq	%r10, %rdi
	setb	%r10b
	movzbl	%r10b, %r10d
	movq	24(%rdx), %r14
	andq	%r9, %r14
	addq	%rdi, %r14
	adcq	%rax, %r10
	setb	%al
	movq	32(%rdx), %rdi
	andq	%r9, %rdi
	andq	40(%rdx), %r9
	movzbl	%al, %eax
	addq	%r10, %rdi
	adcq	%r8, %rax
	addq	%r9, %rax
	movq	%rbx, (%rcx)
	movq	%rsi, 8(%rcx)
	movq	%r11, 16(%rcx)
	movq	%r14, 24(%rcx)
	movq	%rdi, 32(%rcx)
	movq	%rax, 40(%rcx)
	addq	$8, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_,unique,40
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$248, %rsp
	movq	%r8, %rsi
	movq	%rdx, %rdi
	movq	(%rdx), %rdx
	movq	8(%rdi), %r8
	movq	%rdx, 96(%rsp)
	movq	%r8, 104(%rsp)
	movq	16(%rdi), %r9
	movq	%r9, 112(%rsp)
	movq	24(%rdi), %rax
	movq	%rax, 120(%rsp)
	movq	40(%rdi), %r10
	movq	%r10, 136(%rsp)
	movq	32(%rdi), %r10
	movq	%r10, 128(%rsp)
	addq	$-2, %rdx
	movq	%rdx, 96(%rsp)
	movl	$1, %edx
	sbbq	$0, %rdx
	subq	%rdx, %r8
	movl	$1, %edx
	sbbq	$0, %rdx
	xorq	$1, %rdx
	subq	%rdx, %r9
	movl	$1, %edx
	sbbq	$0, %rdx
	movq	%r8, 104(%rsp)
	movq	%r9, 112(%rsp)
	xorq	$1, %rdx
	subq	%rdx, %rax
	movl	$1, %edx
	sbbq	$0, %rdx
	movq	%rax, 120(%rsp)
	xorq	$1, %rdx
	subq	%rdx, 128(%rsp)
	movq	%rcx, 240(%rsp)
	movl	$1, %eax
	sbbq	$0, %rax
	xorq	$1, %rax
	subq	%rax, 136(%rsp)
	movq	136(%rdi), %rax
	movq	%rax, 88(%rsp)
	movq	128(%rdi), %rax
	movq	%rax, 80(%rsp)
	movq	120(%rdi), %rax
	movq	%rax, 72(%rsp)
	movq	112(%rdi), %rax
	movq	%rax, 64(%rsp)
	movq	96(%rdi), %rax
	movq	104(%rdi), %rcx
	movq	%rcx, 56(%rsp)
	movq	%rax, 48(%rsp)
	movl	$383, %r13d
	leaq	144(%rsp), %r14
	leaq	48(%rsp), %r15
	leaq	192(%rsp), %r12
	.p2align	4
.LBB40_1:
	movq	%r14, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	movq	%rsi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	%r13, %rax
	shrq	$6, %rax
	movq	96(%rsp,%rax,8), %rax
	xorl	%ecx, %ecx
	btq	%r13, %rax
	setb	%cl
	movq	144(%rsp), %rdx
	movq	152(%rsp), %r8
	movq	192(%rsp), %r9
	movq	200(%rsp), %r10
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, %r11
	negq	%r11
	andq	%r9, %r11
	decq	%rax
	andq	%rdx, %rax
	orq	%r11, %rax
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rdx
	movq	%rdx, %r9
	negq	%r9
	andq	%r10, %r9
	decq	%rdx
	andq	%r8, %rdx
	orq	%r9, %rdx
	movq	160(%rsp), %r9
	movq	208(%rsp), %r10
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %r8
	movq	%r8, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%r8
	andq	%r9, %r8
	orq	%r11, %r8
	movq	168(%rsp), %r10
	movq	216(%rsp), %r11
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %r9
	movq	%r9, %rbp
	negq	%rbp
	andq	%r11, %rbp
	decq	%r9
	andq	%r10, %r9
	orq	%rbp, %r9
	movq	176(%rsp), %r11
	movq	224(%rsp), %rbp
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rbx
	movq	%rbx, %r10
	negq	%r10
	andq	%rbp, %r10
	decq	%rbx
	andq	%r11, %rbx
	orq	%r10, %rbx
	movq	184(%rsp), %r10
	movq	232(%rsp), %r11
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rcx
	movq	%rcx, %rbp
	negq	%rbp
	andq	%r11, %rbp
	decq	%rcx
	andq	%r10, %rcx
	orq	%rbp, %rcx
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%r8, 64(%rsp)
	movq	%r9, 72(%rsp)
	movq	%rbx, 80(%rsp)
	movq	%rcx, 88(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	#MEMBARRIER
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	addq	$-1, %r13
	jb	.LBB40_1
	movq	88(%rsp), %rax
	movq	240(%rsp), %rdx
	movq	%rax, 40(%rdx)
	movq	80(%rsp), %rax
	movq	%rax, 32(%rdx)
	movq	72(%rsp), %rax
	movq	%rax, 24(%rdx)
	movq	64(%rsp), %rax
	movq	%rax, 16(%rdx)
	movq	48(%rsp), %rax
	movq	56(%rsp), %rcx
	movq	%rcx, 8(%rdx)
	movq	%rax, (%rdx)
	addq	$248, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_,unique,41
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$72, %rsp
	movq	%r8, %r11
	movq	%rdx, %r8
	movq	(%r11), %rbx
	movq	%rbx, 24(%rsp)
	movq	8(%r11), %r14
	movq	%r14, 16(%rsp)
	subq	(%rdx), %rbx
	movl	$1, %r10d
	sbbq	$0, %r10
	xorq	$1, %r10
	xorl	%esi, %esi
	addq	8(%rdx), %r10
	setb	%sil
	subq	%r10, %r14
	movl	$1, %edi
	sbbq	%rsi, %rdi
	xorq	$1, %rdi
	movq	16(%r11), %r10
	xorl	%esi, %esi
	addq	16(%rdx), %rdi
	setb	%sil
	movq	%r10, %r15
	subq	%rdi, %r15
	movl	$1, %edi
	sbbq	%rsi, %rdi
	xorq	$1, %rdi
	movq	24(%r11), %r12
	movq	%r12, 8(%rsp)
	xorl	%r13d, %r13d
	addq	24(%rdx), %rdi
	setb	%r13b
	subq	%rdi, %r12
	movl	$1, %ebp
	sbbq	%r13, %rbp
	xorq	$1, %rbp
	movq	32(%r11), %rdi
	xorl	%eax, %eax
	addq	32(%rdx), %rbp
	setb	%al
	movq	%rdi, %r13
	subq	%rbp, %r13
	movl	$1, %ebp
	sbbq	%rax, %rbp
	xorq	$1, %rbp
	xorl	%edx, %edx
	addq	40(%r8), %rbp
	movq	40(%r11), %rsi
	setb	%dl
	movq	%rsi, %r8
	subq	%rbp, %r8
	movl	$1, %eax
	sbbq	%rdx, %rax
	xorl	%ebp, %ebp
	orq	%r9, %rax
	setne	%bpl
	movq	%rbp, (%rsp)
	movq	(%rsp), %r9
	movq	%r9, %rax
	negq	%rax
	andq	%rbx, %rax
	decq	%r9
	andq	24(%rsp), %r9
	orq	%rax, %r9
	movq	%rbp, (%rsp)
	movq	(%rsp), %r11
	movq	%r11, %rax
	negq	%rax
	andq	%r14, %rax
	decq	%r11
	andq	16(%rsp), %r11
	orq	%rax, %r11
	movq	%rbp, (%rsp)
	movq	(%rsp), %rax
	movq	%rax, %rdx
	negq	%rdx
	andq	%r15, %rdx
	decq	%rax
	andq	%r10, %rax
	orq	%rdx, %rax
	movq	%rbp, (%rsp)
	movq	(%rsp), %r10
	movq	%r10, %rdx
	negq	%rdx
	andq	%r12, %rdx
	decq	%r10
	andq	8(%rsp), %r10
	orq	%rdx, %r10
	movq	%rbp, (%rsp)
	movq	(%rsp), %rdx
	movq	%rdx, %rbx
	negq	%rbx
	andq	%r13, %rbx
	decq	%rdx
	andq	%rdi, %rdx
	orq	%rbx, %rdx
	movq	%rbp, (%rsp)
	movq	(%rsp), %rdi
	movq	%rdi, %rbx
	negq	%rbx
	andq	%r8, %rbx
	decq	%rdi
	andq	%rsi, %rdi
	orq	%rbx, %rdi
	movq	%r9, (%rcx)
	movq	%r11, 8(%rcx)
	movq	%rax, 16(%rcx)
	movq	%r10, 24(%rcx)
	movq	%rdx, 32(%rcx)
	movq	%rdi, 40(%rcx)
	movq	$0, (%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey13packet_length;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey13packet_length,unique,42
	.globl	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey13packet_length
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey13packet_length:
	subq	$56, %rsp
	movl	%edx, %eax
	movl	%r8d, 52(%rsp)
	addq	$32, %rcx
	bswapl	%eax
	leaq	52(%rsp), %rdx
	movq	%rdx, 32(%rsp)
	movq	$4, 40(%rsp)
	xorl	%edx, %edx
	movl	%eax, %r8d
	xorl	%r9d, %r9d
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha10legacy_xor
	cmpb	$-1, %al
	jne	.LBB42_1
	movl	52(%rsp), %eax
	bswapl	%eax
	addq	$56, %rsp
	retq
.LBB42_1:
	movb	$0, 51(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.28(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.3(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	51(%rsp), %r8
	movl	$43, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey3new;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey3new,unique,43
	.globl	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey3new
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey3new:
	pushq	%rsi
	subq	$32, %rsp
	movq	%rcx, %rsi
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3new
	movq	%rsi, %rax
	addq	$32, %rsp
	popq	%rsi
	retq

	.def	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey4open;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey4open,unique,44
	.globl	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey4open
	.p2align	4
_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB5_10OpeningKey4open:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$104, %rsp
	movq	%r8, %r11
	movl	%edx, %r8d
	movq	%rcx, %rdx
	movq	208(%rsp), %r10
	movq	224(%rsp), %rax
	xorq	$16, %rax
	movq	%r10, %rcx
	shrq	$32, %rcx
	orq	%rax, %rcx
	je	.LBB44_2
	xorl	%eax, %eax
	jmp	.LBB44_6
.LBB44_2:
	movq	216(%rsp), %rbx
	movq	%r10, 40(%rsp)
	movq	%r9, 80(%rsp)
	movq	%r9, 32(%rsp)
	leaq	51(%rsp), %rcx
	movq	%rdx, 72(%rsp)
	movl	%r8d, 68(%rsp)
	movq	%r11, 88(%rsp)
	movq	%r11, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3tag
	movzbl	(%rbx), %esi
	movzbl	1(%rbx), %edx
	movzbl	2(%rbx), %r8d
	movzbl	3(%rbx), %r15d
	movzbl	4(%rbx), %edi
	movzbl	5(%rbx), %r14d
	movzbl	6(%rbx), %r10d
	movzbl	7(%rbx), %r13d
	movzbl	8(%rbx), %r12d
	movzbl	9(%rbx), %ebp
	movzbl	10(%rbx), %eax
	movzbl	11(%rbx), %ecx
	movb	%cl, 67(%rsp)
	movzbl	12(%rbx), %r9d
	movzbl	13(%rbx), %r11d
	movzbl	14(%rbx), %ecx
	xorb	51(%rsp), %sil
	movzbl	15(%rbx), %ebx
	xorb	52(%rsp), %dl
	orb	%sil, %dl
	xorb	53(%rsp), %r8b
	xorb	54(%rsp), %r15b
	orb	%r8b, %r15b
	orb	%dl, %r15b
	xorb	55(%rsp), %dil
	xorb	56(%rsp), %r14b
	xorb	57(%rsp), %r10b
	orb	%dil, %r14b
	orb	%r14b, %r10b
	xorb	58(%rsp), %r13b
	orb	%r15b, %r10b
	xorb	59(%rsp), %r12b
	orb	%r13b, %r12b
	xorb	60(%rsp), %bpl
	xorb	61(%rsp), %al
	orb	%r12b, %bpl
	orb	%bpl, %al
	movzbl	67(%rsp), %edx
	xorb	62(%rsp), %dl
	orb	%r10b, %al
	xorb	63(%rsp), %r9b
	orb	%dl, %r9b
	xorb	64(%rsp), %r11b
	xorb	65(%rsp), %cl
	orb	%r9b, %r11b
	orb	%r11b, %cl
	xorb	66(%rsp), %bl
	orb	%al, %cl
	xorl	%eax, %eax
	orb	%cl, %bl
	setne	%al
	movq	%rax, 96(%rsp)
	cmpq	$0, 96(%rsp)
	movb	$1, %al
	jne	.LBB44_5
	movl	68(%rsp), %r8d
	bswapl	%r8d
	movq	72(%rsp), %rax
	leaq	32(%rax), %rcx
	movq	88(%rsp), %rax
	movq	%rax, 32(%rsp)
	movq	$4, 40(%rsp)
	xorl	%edx, %edx
	movl	%r8d, %esi
	xorl	%r9d, %r9d
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha10legacy_xor
	movl	%eax, %ecx
	xorl	%eax, %eax
	cmpb	$-1, %cl
	jne	.LBB44_5
	movq	208(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	80(%rsp), %rax
	movq	%rax, 32(%rsp)
	movl	$1, %r9d
	movq	72(%rsp), %rcx
	xorl	%edx, %edx
	movl	%esi, %r8d
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha10legacy_xor
.LBB44_5:
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	#MEMBARRIER
.LBB44_6:
	addq	$104, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes,unique,45
	.globl	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes
	.p2align	4
_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey10from_bytes:
	pushq	%rsi
	pushq	%rdi
	subq	$744, %rsp
	movq	%rcx, %rsi
	movq	24(%rdx), %rax
	movq	%rax, 56(%rsp)
	movq	16(%rdx), %rax
	movq	%rax, 48(%rsp)
	movq	(%rdx), %rax
	movq	8(%rdx), %rcx
	movq	%rcx, 40(%rsp)
	movq	%rax, 32(%rsp)
	leaq	104(%rsp), %rdi
	movq	%rdi, %rcx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p256
	leaq	408(%rsp), %rcx
	leaq	32(%rsp), %r8
	movq	%rdi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_
	cmpb	$1, 408(%rsp)
	jne	.LBB45_2
	movzbl	409(%rsp), %eax
	movb	%al, 1(%rsi)
	movb	$1, (%rsi)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	#MEMBARRIER
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	jmp	.LBB45_3
.LBB45_2:
	movq	440(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	432(%rsp), %rcx
	movq	%rcx, 88(%rsp)
	movq	416(%rsp), %rdx
	movq	424(%rsp), %r8
	movq	%r8, 80(%rsp)
	movq	%rdx, 72(%rsp)
	movq	%rax, 432(%rsp)
	movq	%rcx, 424(%rsp)
	movq	%r8, 416(%rsp)
	movq	%rdx, 408(%rsp)
	leaq	440(%rsp), %rcx
	leaq	104(%rsp), %rdx
	movl	$304, %r8d
	callq	memcpy
	leaq	8(%rsi), %rcx
	leaq	408(%rsp), %rdx
	movl	$336, %r8d
	callq	memcpy
	movb	$0, (%rsi)
.LBB45_3:
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$744, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key,unique,46
	.globl	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key
	.p2align	4
_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey10public_key:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$752, %rsp
	movq	%rdx, %r8
	movq	%rcx, %rsi
	leaq	32(%rdx), %rdi
	movq	88(%rdx), %rax
	movq	%rax, 296(%rsp)
	movq	80(%rdx), %rax
	movq	%rax, 288(%rsp)
	movq	64(%rdx), %rax
	movq	72(%rdx), %rcx
	movq	%rcx, 280(%rsp)
	movq	%rax, 272(%rsp)
	movq	96(%rdx), %rax
	movq	104(%rdx), %rcx
	movq	%rax, 304(%rsp)
	movq	%rcx, 312(%rsp)
	movq	112(%rdx), %rax
	movq	%rax, 320(%rsp)
	movq	120(%rdx), %rax
	movq	%rax, 328(%rsp)
	movq	192(%rdx), %rax
	movq	200(%rdx), %rcx
	movq	%rax, 336(%rsp)
	movq	%rcx, 344(%rsp)
	movq	208(%rdx), %rax
	movq	%rax, 352(%rsp)
	movq	216(%rdx), %rax
	movq	%rax, 360(%rsp)
	leaq	160(%rsp), %rbx
	leaq	272(%rsp), %rdx
	movq	%rbx, %rcx
	movq	%rdi, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	leaq	272(%rsp), %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_
	cmpb	$1, 272(%rsp)
	je	.LBB46_1
	movq	280(%rsp), %rcx
	movq	288(%rsp), %rdx
	movq	296(%rsp), %r8
	movq	304(%rsp), %r9
	movq	312(%rsp), %r10
	movq	320(%rsp), %r11
	movq	328(%rsp), %rdi
	movq	336(%rsp), %rax
	movq	%rcx, 80(%rsp)
	movq	%rdx, 72(%rsp)
	movq	%r8, 64(%rsp)
	movq	%r9, 56(%rsp)
	movb	$4, 95(%rsp)
	bswapq	%rcx
	bswapq	%rdx
	movq	%rcx, 120(%rsp)
	movq	%rdx, 112(%rsp)
	bswapq	%r8
	movq	%r8, 104(%rsp)
	bswapq	%r9
	movq	%r9, 96(%rsp)
	bswapq	%r10
	bswapq	%r11
	movq	%r10, 152(%rsp)
	movq	%r11, 144(%rsp)
	bswapq	%rdi
	movq	%rdi, 136(%rsp)
	bswapq	%rax
	movq	%rax, 128(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	272(%rsp), %rcx
	leaq	95(%rsp), %rdx
	movl	$65, %r8d
	callq	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1
	cmpb	$1, 272(%rsp)
	je	.LBB46_4
	leaq	280(%rsp), %rdx
	movl	$472, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$752, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq
.LBB46_4:
	movzbl	273(%rsp), %eax
	movb	%al, 48(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.31(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.29(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	48(%rsp), %r8
	movl	$26, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2
.LBB46_1:
	movzbl	273(%rsp), %eax
	movb	%al, 272(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.31(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.32(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	272(%rsp), %r8
	movl	$26, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2

	.def	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree,unique,47
	.globl	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree
	.p2align	4
_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB5_9SecretKey5agree:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$264, %rsp
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	32(%rdx), %rbx
	leaq	80(%rsp), %r14
	movq	%r14, %rcx
	movq	%r8, %rdx
	movq	%rdi, %r8
	movq	%rbx, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
	leaq	192(%rsp), %rcx
	movq	%r14, %rdx
	movq	%rbx, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_
	cmpb	$1, 192(%rsp)
	je	.LBB47_1
	movq	200(%rsp), %rax
	movq	208(%rsp), %rcx
	movq	216(%rsp), %rdx
	movq	224(%rsp), %r8
	movq	%rax, 64(%rsp)
	movq	%rcx, 56(%rsp)
	movq	%rdx, 48(%rsp)
	movq	%r8, 40(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	#MEMBARRIER
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	movq	64(%rsp), %rax
	bswapq	%rax
	movq	56(%rsp), %rcx
	bswapq	%rcx
	movq	48(%rsp), %rdx
	bswapq	%rdx
	movq	40(%rsp), %r8
	bswapq	%r8
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	%r8, 1(%rsi)
	movq	%rdx, 9(%rsi)
	movq	%rcx, 17(%rsi)
	movq	%rax, 25(%rsi)
	movb	$0, (%rsi)
	movq	$0, 160(%rdi)
	movq	$0, 168(%rdi)
	movq	$0, 176(%rdi)
	movq	$0, 184(%rdi)
	#MEMBARRIER
	movq	$0, 192(%rdi)
	movq	$0, 200(%rdi)
	movq	$0, 208(%rdi)
	movq	$0, 216(%rdi)
	#MEMBARRIER
	movq	$0, 264(%rdi)
	movq	$0, 272(%rdi)
	movq	$0, 280(%rdi)
	movq	$0, 288(%rdi)
	#MEMBARRIER
	movq	$0, 296(%rdi)
	movq	$0, 304(%rdi)
	movq	$0, 312(%rdi)
	movq	$0, 320(%rdi)
	#MEMBARRIER
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	#MEMBARRIER
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	#MEMBARRIER
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	movq	$0, 120(%rdi)
	#MEMBARRIER
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$264, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq
.LBB47_1:
	movzbl	193(%rsp), %eax
	movb	%al, 72(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.60(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.59(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	72(%rsp), %r8
	movl	$46, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2

	.def	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes,unique,48
	.globl	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes
	.p2align	4
_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey10from_bytes:
	pushq	%rsi
	pushq	%rdi
	subq	$1080, %rsp
	movq	%rcx, %rsi
	movq	40(%rdx), %rax
	movq	%rax, 72(%rsp)
	movq	32(%rdx), %rax
	movq	%rax, 64(%rsp)
	movq	24(%rdx), %rax
	movq	%rax, 56(%rsp)
	movq	16(%rdx), %rax
	movq	%rax, 48(%rsp)
	movq	(%rdx), %rax
	movq	8(%rdx), %rcx
	movq	%rcx, 40(%rsp)
	movq	%rax, 32(%rsp)
	leaq	136(%rsp), %rdi
	movq	%rdi, %rcx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p384
	leaq	584(%rsp), %rcx
	leaq	32(%rsp), %r8
	movq	%rdi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_
	cmpb	$1, 584(%rsp)
	jne	.LBB48_2
	movzbl	585(%rsp), %eax
	movb	%al, 1(%rsi)
	movb	$1, (%rsi)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	#MEMBARRIER
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	#MEMBARRIER
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	#MEMBARRIER
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	jmp	.LBB48_3
.LBB48_2:
	movq	632(%rsp), %rax
	movq	%rax, 128(%rsp)
	movq	624(%rsp), %rcx
	movq	%rcx, 120(%rsp)
	movq	616(%rsp), %rdx
	movq	%rdx, 112(%rsp)
	movq	608(%rsp), %r8
	movq	%r8, 104(%rsp)
	movq	592(%rsp), %r9
	movq	600(%rsp), %r10
	movq	%r10, 96(%rsp)
	movq	%r9, 88(%rsp)
	movq	%rax, 1072(%rsp)
	movq	%rcx, 1064(%rsp)
	movq	%rdx, 1056(%rsp)
	movq	%r8, 1048(%rsp)
	movq	%r10, 1040(%rsp)
	movq	%r9, 1032(%rsp)
	leaq	584(%rsp), %rdi
	leaq	136(%rsp), %rdx
	movl	$448, %r8d
	movq	%rdi, %rcx
	callq	memcpy
	leaq	8(%rsi), %rcx
	movl	$496, %r8d
	movq	%rdi, %rdx
	callq	memcpy
	movb	$0, (%rsi)
.LBB48_3:
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$1080, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key,unique,49
	.globl	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key
	.p2align	4
_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey10public_key:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$1080, %rsp
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movq	88(%rdx), %rax
	movq	%rax, 416(%rsp)
	movq	80(%rdx), %rax
	movq	%rax, 408(%rsp)
	movq	72(%rdx), %rax
	movq	%rax, 400(%rsp)
	movq	64(%rdx), %rax
	movq	%rax, 392(%rsp)
	movq	48(%rdx), %rax
	movq	56(%rdx), %rcx
	movq	%rcx, 384(%rsp)
	movq	%rax, 376(%rsp)
	movq	96(%rdx), %rax
	movq	104(%rdx), %rcx
	movq	%rax, 424(%rsp)
	movq	%rcx, 432(%rsp)
	movq	112(%rdx), %rax
	movq	%rax, 440(%rsp)
	movq	120(%rdx), %rax
	movq	%rax, 448(%rsp)
	movq	128(%rdx), %rax
	movq	%rax, 456(%rsp)
	movq	136(%rdx), %rax
	movq	%rax, 464(%rsp)
	movq	240(%rdx), %rax
	movq	248(%rdx), %rcx
	movq	%rax, 472(%rsp)
	movq	%rcx, 480(%rsp)
	movq	256(%rdx), %rax
	movq	%rax, 488(%rsp)
	movq	264(%rdx), %rax
	movq	%rax, 496(%rsp)
	movq	272(%rdx), %rax
	movq	%rax, 504(%rsp)
	movq	280(%rdx), %rax
	movq	%rax, 512(%rsp)
	leaq	448(%rdx), %r8
	leaq	200(%rsp), %rbx
	leaq	376(%rsp), %rdx
	movq	%rbx, %rcx
	movq	%rdi, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	#MEMBARRIER
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	leaq	376(%rsp), %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_
	cmpb	$1, 376(%rsp)
	je	.LBB49_1
	movq	384(%rsp), %rbx
	movq	392(%rsp), %r14
	movq	400(%rsp), %r15
	movq	408(%rsp), %r12
	movq	416(%rsp), %r11
	movq	424(%rsp), %rdi
	movq	432(%rsp), %r10
	movq	440(%rsp), %r9
	movq	448(%rsp), %rdx
	movq	456(%rsp), %r8
	movq	464(%rsp), %rcx
	movq	472(%rsp), %rax
	movq	%rbx, 88(%rsp)
	movq	%r14, 80(%rsp)
	movq	%r15, 72(%rsp)
	movq	%r12, 64(%rsp)
	movq	%r11, 56(%rsp)
	movq	%rdi, 48(%rsp)
	movb	$4, 103(%rsp)
	bswapq	%rbx
	bswapq	%r14
	movq	%rbx, 144(%rsp)
	movq	%r14, 136(%rsp)
	bswapq	%r15
	movq	%r15, 128(%rsp)
	bswapq	%r12
	movq	%r12, 120(%rsp)
	bswapq	%r11
	bswapq	%rdi
	movq	%r11, 112(%rsp)
	movq	%rdi, 104(%rsp)
	bswapq	%r10
	movq	%r10, 192(%rsp)
	bswapq	%r9
	movq	%r9, 184(%rsp)
	bswapq	%rdx
	bswapq	%r8
	movq	%rdx, 176(%rsp)
	movq	%r8, 168(%rsp)
	bswapq	%rcx
	movq	%rcx, 160(%rsp)
	bswapq	%rax
	movq	%rax, 152(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 344(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	leaq	376(%rsp), %rcx
	leaq	103(%rsp), %rdx
	movl	$97, %r8d
	callq	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1
	cmpb	$1, 376(%rsp)
	je	.LBB49_4
	leaq	384(%rsp), %rdx
	movl	$696, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$1080, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq
.LBB49_4:
	movzbl	377(%rsp), %eax
	movb	%al, 40(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.33(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.29(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	40(%rsp), %r8
	movl	$26, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2
.LBB49_1:
	movzbl	377(%rsp), %eax
	movb	%al, 376(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.33(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.32(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	376(%rsp), %r8
	movl	$26, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2

	.def	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree,unique,50
	.globl	_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree
	.p2align	4
_RNvMs0_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB5_9SecretKey5agree:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$384, %rsp
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	448(%rdx), %rax
	leaq	448(%r8), %rdx
	leaq	104(%rsp), %rbx
	movq	%rbx, %rcx
	movq	%rax, %r8
	movq	%rdi, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
	leaq	280(%rsp), %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_
	cmpb	$1, 280(%rsp)
	je	.LBB50_1
	movq	288(%rsp), %rax
	movq	296(%rsp), %rcx
	movq	304(%rsp), %rdx
	movq	312(%rsp), %r8
	movq	320(%rsp), %r9
	movq	328(%rsp), %r10
	movq	%rax, 88(%rsp)
	movq	%rcx, 80(%rsp)
	movq	%rdx, 72(%rsp)
	movq	%r8, 64(%rsp)
	movq	%r9, 56(%rsp)
	movq	%r10, 48(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	#MEMBARRIER
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
	movq	88(%rsp), %rax
	bswapq	%rax
	movq	80(%rsp), %rcx
	bswapq	%rcx
	movq	72(%rsp), %rdx
	bswapq	%rdx
	movq	64(%rsp), %r8
	bswapq	%r8
	movq	56(%rsp), %r9
	bswapq	%r9
	movq	48(%rsp), %r10
	bswapq	%r10
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	movq	%r10, 1(%rsi)
	movq	%r9, 9(%rsi)
	movq	%r8, 17(%rsi)
	movq	%rdx, 25(%rsi)
	movq	%rcx, 33(%rsi)
	movq	%rax, 41(%rsi)
	movb	$0, (%rsi)
	movq	$0, 192(%rdi)
	movq	$0, 200(%rdi)
	movq	$0, 208(%rdi)
	movq	$0, 216(%rdi)
	movq	$0, 224(%rdi)
	movq	$0, 232(%rdi)
	#MEMBARRIER
	movq	$0, 240(%rdi)
	movq	$0, 248(%rdi)
	movq	$0, 256(%rdi)
	movq	$0, 264(%rdi)
	movq	$0, 272(%rdi)
	movq	$0, 280(%rdi)
	#MEMBARRIER
	movq	$0, 344(%rdi)
	movq	$0, 352(%rdi)
	movq	$0, 360(%rdi)
	movq	$0, 368(%rdi)
	movq	$0, 376(%rdi)
	movq	$0, 384(%rdi)
	#MEMBARRIER
	movq	$0, 392(%rdi)
	movq	$0, 400(%rdi)
	movq	$0, 408(%rdi)
	movq	$0, 416(%rdi)
	movq	$0, 424(%rdi)
	movq	$0, 432(%rdi)
	#MEMBARRIER
	movq	$0, (%rdi)
	movq	$0, 8(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 40(%rdi)
	#MEMBARRIER
	movq	$0, 48(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 88(%rdi)
	#MEMBARRIER
	movq	$0, 96(%rdi)
	movq	$0, 104(%rdi)
	movq	$0, 112(%rdi)
	movq	$0, 120(%rdi)
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	#MEMBARRIER
	movq	$0, 448(%rdi)
	movq	$0, 456(%rdi)
	movq	$0, 464(%rdi)
	movq	$0, 472(%rdi)
	movq	$0, 480(%rdi)
	movq	$0, 488(%rdi)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$384, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq
.LBB50_1:
	movzbl	281(%rsp), %eax
	movb	%al, 96(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.60(%rip), %rax
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.59(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	96(%rsp), %r8
	movl	$46, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2

	.def	_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes,unique,51
	.globl	_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes
	.p2align	4
_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey10from_bytes:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$544, %rsp
	movq	%rcx, %rsi
	cmpq	$1184, %r8
	jne	.LBB51_18
	movq	%rdx, %rdi
	leaq	32(%rsp), %rbx
	xorl	%r14d, %r14d
.LBB51_2:
	leaq	(%rdi,%r14), %r15
	movl	$512, %r8d
	movq	%rbx, %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%eax, %eax
	movq	%rbx, %rdx
	.p2align	4
.LBB51_3:
	movq	%rax, %rcx
	shrq	$3, %rcx
	movzbl	(%r15,%rcx), %r11d
	movl	%eax, %ecx
	andb	$4, %cl
	movzbl	%cl, %r8d
	xorl	%r10d, %r10d
	btl	%r8d, %r11d
	setb	%r10b
	leal	1(%r8), %ecx
	movl	%r11d, %ebp
	shrl	%cl, %ebp
	orw	(%rdx), %r10w
	leal	2(%r8), %ecx
	movl	%r11d, %r9d
	shrl	%cl, %r9d
	addl	%ebp, %ebp
	andl	$2, %ebp
	shll	$2, %r9d
	leal	3(%r8), %ecx
	shrl	%cl, %r11d
	andl	$4, %r9d
	orl	%ebp, %r9d
	shll	$3, %r11d
	leaq	4(%rax), %rcx
	movq	%rcx, %r12
	shrq	$3, %r12
	movzbl	(%r15,%r12), %ebp
	andb	$4, %cl
	shrl	%cl, %ebp
	andl	$8, %r11d
	orl	%r9d, %r11d
	shll	$4, %ebp
	leaq	5(%rax), %rcx
	movq	%rcx, %r9
	shrq	$3, %r9
	movzbl	(%r15,%r9), %r9d
	andb	$5, %cl
	shrl	%cl, %r9d
	andl	$16, %ebp
	orl	%r11d, %ebp
	shll	$5, %r9d
	andl	$32, %r9d
	orl	%ebp, %r9d
	orl	%r10d, %r9d
	leaq	6(%rax), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movzbl	(%r15,%r10), %r10d
	andb	$6, %cl
	shrl	%cl, %r10d
	leaq	7(%rax), %rcx
	movq	%rcx, %r11
	shrq	$3, %r11
	movzbl	(%r15,%r11), %r11d
	andb	$7, %cl
	shrb	%cl, %r11b
	shll	$6, %r10d
	andl	$64, %r10d
	shlb	$7, %r11b
	movzbl	%r11b, %ecx
	orl	%r10d, %ecx
	leaq	8(%rax), %r10
	shrq	$3, %r10
	movzbl	(%r15,%r10), %r10d
	xorl	%r11d, %r11d
	btl	%r8d, %r10d
	setb	%r11b
	shll	$8, %r11d
	orl	%ecx, %r11d
	leaq	9(%rax), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%r15,%r8), %r8d
	andl	$5, %ecx
	xorl	%r10d, %r10d
	btl	%ecx, %r8d
	setb	%r10b
	shll	$9, %r10d
	orl	%r11d, %r10d
	leaq	10(%rax), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%r15,%r8), %r8d
	andl	$6, %ecx
	xorl	%r11d, %r11d
	btl	%ecx, %r8d
	setb	%r11b
	shll	$10, %r11d
	orl	%r10d, %r11d
	orl	%r9d, %r11d
	leaq	11(%rax), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%r15,%r8), %r8d
	andl	$7, %ecx
	xorl	%r9d, %r9d
	btl	%ecx, %r8d
	setb	%r9b
	shll	$11, %r9d
	orl	%r11d, %r9d
	movw	%r9w, (%rdx)
	addq	$2, %rdx
	addq	$12, %rax
	cmpq	$3072, %rax
	jne	.LBB51_3
	xorl	%eax, %eax
	.p2align	4
.LBB51_5:
	cmpq	$512, %rax
	je	.LBB51_6
	cmpw	$3328, 32(%rsp,%rax)
	ja	.LBB51_14
	cmpw	$3328, 34(%rsp,%rax)
	ja	.LBB51_14
	cmpw	$3328, 36(%rsp,%rax)
	ja	.LBB51_14
	cmpw	$3328, 38(%rsp,%rax)
	leaq	8(%rax), %rax
	jbe	.LBB51_5
	jmp	.LBB51_14
.LBB51_6:
	xorl	%eax, %eax
	.p2align	4
.LBB51_7:
	movw	$0, 32(%rsp,%rax)
	movw	$0, 34(%rsp,%rax)
	movw	$0, 36(%rsp,%rax)
	movw	$0, 38(%rsp,%rax)
	movw	$0, 40(%rsp,%rax)
	movw	$0, 42(%rsp,%rax)
	movw	$0, 44(%rsp,%rax)
	movw	$0, 46(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB51_7
	addq	$384, %r14
	#MEMBARRIER
	cmpq	$1152, %r14
	jne	.LBB51_2
	leaq	1(%rsi), %rcx
	movl	$1184, %r8d
	movq	%rdi, %rdx
	callq	memcpy
	movb	$0, (%rsi)
	jmp	.LBB51_17
.LBB51_18:
	movw	$1, (%rsi)
	jmp	.LBB51_17
.LBB51_14:
	movw	$513, (%rsi)
	xorl	%eax, %eax
	.p2align	4
.LBB51_15:
	movw	$0, 32(%rsp,%rax)
	movw	$0, 34(%rsp,%rax)
	movw	$0, 36(%rsp,%rax)
	movw	$0, 38(%rsp,%rax)
	movw	$0, 40(%rsp,%rax)
	movw	$0, 42(%rsp,%rax)
	movw	$0, 44(%rsp,%rax)
	movw	$0, 46(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB51_15
	#MEMBARRIER
.LBB51_17:
	movq	%rsi, %rax
	addq	$544, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt,unique,52
	.globl	_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt
	.p2align	4
_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	movl	$7832, %eax
	callq	_RNvCs1njKG4L9aB3_7___rustc17___rust_probestack
	subq	%rax, %rsp
	movq	%r9, %r14
	movq	%r8, 56(%rsp)
	movq	%rcx, 64(%rsp)
	movq	%rdx, 72(%rsp)
	leaq	1152(%rdx), %rax
	movq	%rax, 80(%rsp)
	leaq	4248(%rsp), %rbx
	movq	%rbx, %rcx
	movq	%r9, %rdx
	xorl	%r8d, %r8d
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise
	leaq	1112(%rsp), %r12
	movq	%r12, %rcx
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly3ntt
	leaq	600(%rsp), %r15
	movl	$512, %r8d
	movq	%r15, %rcx
	movq	%r12, %rdx
	callq	memcpy
	leaq	88(%rsp), %r13
	movl	$512, %r8d
	movq	%r13, %rcx
	movq	%r15, %rdx
	callq	memcpy
	leaq	3160(%rsp), %rsi
	movl	$512, %r8d
	movq	%rsi, %rcx
	movq	%r13, %rdx
	callq	memcpy
	leaq	6296(%rsp), %rdi
	movl	$512, %r8d
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	callq	memcpy
	movq	%rbx, %rcx
	movq	%r14, %rdx
	movb	$1, %r8b
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise
	movq	%r12, %rcx
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly3ntt
	movl	$512, %r8d
	movq	%r15, %rcx
	movq	%r12, %rdx
	callq	memcpy
	movl	$512, %r8d
	movq	%r13, %rcx
	movq	%r15, %rdx
	callq	memcpy
	movl	$512, %r8d
	movq	%rsi, %rcx
	movq	%r13, %rdx
	callq	memcpy
	leaq	6808(%rsp), %rcx
	movl	$512, %r8d
	movq	%rsi, %rdx
	callq	memcpy
	movq	%rbx, %rcx
	movq	%r14, 48(%rsp)
	movq	%r14, %rdx
	movb	$2, %r8b
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise
	movq	%r12, %rcx
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly3ntt
	movl	$512, %r8d
	movq	%r15, %rcx
	movq	%r12, %rdx
	callq	memcpy
	movl	$512, %r8d
	movq	%r13, %rcx
	movq	%r15, %rdx
	callq	memcpy
	movl	$512, %r8d
	movq	%rsi, %rcx
	movq	%r13, %rdx
	callq	memcpy
	leaq	7320(%rsp), %rcx
	movl	$512, %r8d
	movq	%rsi, %rdx
	callq	memcpy
	leaq	4248(%rsp), %rcx
	movl	$1536, %r8d
	movq	%rdi, %rdx
	callq	memcpy
	leaq	3160(%rsp), %rcx
	movl	$1088, %r8d
	xorl	%edx, %edx
	callq	memset
	movl	$2642262849, %r15d
	leaq	2136(%rsp), %r14
	movq	$0, 40(%rsp)
	.p2align	4
.LBB52_1:
	movl	$512, %r8d
	leaq	1624(%rsp), %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%r12d, %r12d
	xorl	%ebx, %ebx
	.p2align	4
.LBB52_2:
	leaq	(%rsp,%r12), %rbp
	addq	$4248, %rbp
	leaq	600(%rsp), %rcx
	movq	80(%rsp), %rdx
	movq	%rbx, %r8
	movq	40(%rsp), %r9
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem6sample
	movl	$512, %r8d
	leaq	88(%rsp), %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%eax, %eax
	jmp	.LBB52_3
	.p2align	4
.LBB52_7:
	movzwl	600(%rsp,%rax,4), %r10d
	movzwl	(%rbp,%rax,4), %edx
	movzwl	602(%rsp,%rax,4), %r9d
	movzwl	2(%rbp,%rax,4), %r8d
	movl	%edx, %r11d
	imull	%r10d, %r11d
	imulq	$989558401, %r11, %r13
	shrq	$32, %r13
	movl	%r11d, %esi
	subl	%r13d, %esi
	shrl	%esi
	addl	%r13d, %esi
	shrl	$11, %esi
	imull	$3329, %esi, %esi
	subl	%esi, %r11d
	movl	%r8d, %esi
	imull	%r9d, %esi
	imulq	$989558401, %rsi, %r13
	shrq	$32, %r13
	movl	%esi, %edi
	subl	%r13d, %edi
	shrl	%edi
	addl	%r13d, %edi
	shrl	$11, %edi
	imull	$3329, %edi, %edi
	subl	%edi, %esi
	movzwl	%cx, %ecx
	imull	%esi, %ecx
	imulq	$330282857, %rcx, %rsi
	shrq	$40, %rsi
	imull	$3329, %esi, %esi
	subl	%esi, %ecx
	addl	%r11d, %ecx
	leal	-3329(%rcx), %r11d
	cmpl	$3329, %ecx
	cmovbl	%ecx, %r11d
	movw	%r11w, 88(%rsp,%rax,4)
	imull	%r10d, %r8d
	imulq	$989558401, %r8, %rcx
	shrq	$32, %rcx
	movl	%r8d, %r10d
	subl	%ecx, %r10d
	shrl	%r10d
	addl	%ecx, %r10d
	shrl	$11, %r10d
	imull	$3329, %r10d, %ecx
	subl	%ecx, %r8d
	imull	%r9d, %edx
	imulq	$989558401, %rdx, %rcx
	shrq	$32, %rcx
	movl	%edx, %r9d
	subl	%ecx, %r9d
	shrl	%r9d
	addl	%ecx, %r9d
	shrl	$11, %r9d
	imull	$3329, %r9d, %ecx
	subl	%ecx, %edx
	leal	(%r8,%rdx), %ecx
	cmpl	$3329, %ecx
	leal	-3329(%r8,%rdx), %edx
	cmovbl	%ecx, %edx
	movw	%dx, 90(%rsp,%rax,4)
	incq	%rax
	cmpq	$128, %rax
	je	.LBB52_8
.LBB52_3:
	movl	%eax, %ecx
	rolb	$4, %cl
	orb	$8, %cl
	movl	%ecx, %edx
	andb	$51, %dl
	shlb	$2, %dl
	shrb	$2, %cl
	andb	$51, %cl
	orb	%dl, %cl
	movl	%ecx, %edx
	andb	$85, %dl
	addb	%dl, %dl
	shrb	%cl
	andb	$85, %cl
	orb	%dl, %cl
	movzbl	%cl, %edx
	movw	$1, %cx
	movw	$17, %r8w
	jmp	.LBB52_4
	.p2align	4
.LBB52_6:
	imull	%r8d, %r8d
	movq	%r8, %r9
	imulq	%r15, %r9
	shrq	$43, %r9
	imull	$3329, %r9d, %r9d
	subl	%r9d, %r8d
	shrl	%edx
	je	.LBB52_7
.LBB52_4:
	movzwl	%r8w, %r8d
	testb	$1, %dl
	je	.LBB52_6
	movzwl	%cx, %ecx
	imull	%r8d, %ecx
	imulq	$989558401, %rcx, %r9
	shrq	$32, %r9
	movl	%ecx, %r10d
	subl	%r9d, %r10d
	shrl	%r10d
	addl	%r9d, %r10d
	shrl	$11, %r10d
	imull	$3329, %r10d, %r9d
	subl	%r9d, %ecx
	jmp	.LBB52_6
	.p2align	4
.LBB52_8:
	movl	$1, %eax
	.p2align	4
.LBB52_9:
	movzwl	1622(%rsp,%rax,2), %ecx
	movzwl	86(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1110(%rsp,%rax,2)
	movzwl	1624(%rsp,%rax,2), %ecx
	movzwl	88(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1112(%rsp,%rax,2)
	addq	$2, %rax
	cmpq	$257, %rax
	jne	.LBB52_9
	movl	$512, %r8d
	movq	%r14, %rcx
	leaq	1112(%rsp), %rdx
	callq	memcpy
	movl	$14, %eax
	.p2align	4
.LBB52_11:
	movw	$0, 1610(%rsp,%rax)
	movw	$0, 1612(%rsp,%rax)
	movw	$0, 1614(%rsp,%rax)
	movw	$0, 1616(%rsp,%rax)
	movw	$0, 1618(%rsp,%rax)
	movw	$0, 1620(%rsp,%rax)
	movw	$0, 1622(%rsp,%rax)
	movw	$0, 1624(%rsp,%rax)
	addq	$16, %rax
	cmpq	$526, %rax
	jne	.LBB52_11
	#MEMBARRIER
	movl	$512, %r8d
	leaq	1624(%rsp), %rcx
	movq	%r14, %rdx
	callq	memcpy
	xorl	%eax, %eax
	.p2align	4
.LBB52_13:
	movw	$0, 88(%rsp,%rax)
	movw	$0, 90(%rsp,%rax)
	movw	$0, 92(%rsp,%rax)
	movw	$0, 94(%rsp,%rax)
	movw	$0, 96(%rsp,%rax)
	movw	$0, 98(%rsp,%rax)
	movw	$0, 100(%rsp,%rax)
	movw	$0, 102(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_13
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_15:
	movw	$0, 600(%rsp,%rax)
	movw	$0, 602(%rsp,%rax)
	movw	$0, 604(%rsp,%rax)
	movw	$0, 606(%rsp,%rax)
	movw	$0, 608(%rsp,%rax)
	movw	$0, 610(%rsp,%rax)
	movw	$0, 612(%rsp,%rax)
	movw	$0, 614(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_15
	addq	$512, %r12
	incq	%rbx
	#MEMBARRIER
	cmpq	$1536, %r12
	jne	.LBB52_2
	movl	$512, %r8d
	leaq	1112(%rsp), %rsi
	movq	%rsi, %rcx
	leaq	1624(%rsp), %rdx
	callq	memcpy
	leaq	88(%rsp), %rcx
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly7inverse
	movq	40(%rsp), %rax
	leal	3(%rax), %r8d
	leaq	600(%rsp), %rcx
	movq	48(%rsp), %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise
	movl	$1, %eax
	.p2align	4
.LBB52_18:
	movzwl	86(%rsp,%rax,2), %ecx
	movzwl	598(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1110(%rsp,%rax,2)
	movzwl	88(%rsp,%rax,2), %ecx
	movzwl	600(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1112(%rsp,%rax,2)
	addq	$2, %rax
	cmpq	$257, %rax
	jne	.LBB52_18
	movl	$512, %r8d
	movq	%r14, %rcx
	leaq	1112(%rsp), %rdx
	callq	memcpy
	movl	$2, %eax
	.p2align	4
.LBB52_20:
	movzwl	2134(%rsp,%rax), %ecx
	shll	$10, %ecx
	addl	$1664, %ecx
	imulq	$165141429, %rcx, %rcx
	shrq	$39, %rcx
	andl	$1023, %ecx
	movw	%cx, 2134(%rsp,%rax)
	movzwl	2136(%rsp,%rax), %ecx
	shll	$10, %ecx
	addl	$1664, %ecx
	imulq	$165141429, %rcx, %rcx
	shrq	$39, %rcx
	andl	$1023, %ecx
	movw	%cx, 2136(%rsp,%rax)
	addq	$4, %rax
	cmpq	$514, %rax
	jne	.LBB52_20
	movq	40(%rsp), %rbx
	leaq	1(%rbx), %r12
	movl	$512, %r8d
	leaq	1112(%rsp), %rsi
	movq	%rsi, %rcx
	movq	%r14, %rdx
	callq	memcpy
	leaq	(%rbx,%rbx,4), %rax
	shlq	$6, %rax
	leaq	(%rsp,%rax), %rbx
	addq	$3160, %rbx
	movl	$320, %r8d
	movq	%rbx, %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%edx, %edx
	movq	%rsi, %r8
	.p2align	4
.LBB52_22:
	movzwl	(%r8), %r9d
	movl	%r9d, %r10d
	andb	$1, %r10b
	movl	%edx, %eax
	andb	$6, %al
	movl	%eax, %ecx
	shlb	%cl, %r10b
	movq	%rdx, %r11
	shrq	$3, %r11
	orb	(%rbx,%r11), %r10b
	movl	%r9d, %esi
	shrb	%sil
	andb	$1, %sil
	leal	1(%rax), %ecx
	shlb	%cl, %sil
	orb	%r10b, %sil
	movb	%sil, (%rbx,%r11)
	leaq	2(%rdx), %rcx
	movq	%rcx, %r10
	movl	%r9d, %r11d
	shrb	$2, %r11b
	andb	$1, %r11b
	andb	$6, %cl
	shlb	%cl, %r11b
	shrq	$3, %r10
	orb	%r11b, (%rbx,%r10)
	leaq	3(%rdx), %rcx
	movq	%rcx, %r10
	movl	%r9d, %r11d
	shrb	$3, %r11b
	andb	$1, %r11b
	andb	$7, %cl
	shlb	%cl, %r11b
	shrq	$3, %r10
	orb	%r11b, (%rbx,%r10)
	leaq	4(%rdx), %rcx
	movq	%rcx, %r10
	movl	%r9d, %r11d
	shrb	$4, %r11b
	andb	$1, %r11b
	andb	$6, %cl
	shlb	%cl, %r11b
	shrq	$3, %r10
	orb	%r11b, (%rbx,%r10)
	leaq	5(%rdx), %rcx
	movq	%rcx, %r10
	movl	%r9d, %r11d
	shrb	$5, %r11b
	andb	$1, %r11b
	andb	$7, %cl
	shlb	%cl, %r11b
	shrq	$3, %r10
	orb	%r11b, (%rbx,%r10)
	leaq	6(%rdx), %rcx
	movq	%rcx, %r10
	movl	%r9d, %r11d
	shrb	$6, %r11b
	andb	$1, %r11b
	andb	$6, %cl
	shlb	%cl, %r11b
	shrq	$3, %r10
	orb	%r11b, (%rbx,%r10)
	leaq	7(%rdx), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movl	%r9d, %r11d
	shrb	$7, %r11b
	andb	$7, %cl
	shlb	%cl, %r11b
	orb	%r11b, (%rbx,%r10)
	leaq	8(%rdx), %r10
	shrq	$3, %r10
	movl	%r9d, %r11d
	shrl	$8, %r11d
	andb	$1, %r11b
	movl	%eax, %ecx
	shlb	%cl, %r11b
	orb	%r11b, (%rbx,%r10)
	leaq	9(%rdx), %rcx
	movq	%rcx, %rax
	shrl	$9, %r9d
	andb	$1, %r9b
	andb	$7, %cl
	shlb	%cl, %r9b
	shrq	$3, %rax
	orb	%r9b, (%rbx,%rax)
	addq	$2, %r8
	addq	$10, %rdx
	cmpq	$2560, %rdx
	jne	.LBB52_22
	xorl	%eax, %eax
	.p2align	4
.LBB52_24:
	movw	$0, 1112(%rsp,%rax)
	movw	$0, 1114(%rsp,%rax)
	movw	$0, 1116(%rsp,%rax)
	movw	$0, 1118(%rsp,%rax)
	movw	$0, 1120(%rsp,%rax)
	movw	$0, 1122(%rsp,%rax)
	movw	$0, 1124(%rsp,%rax)
	movw	$0, 1126(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_24
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_26:
	movw	$0, 600(%rsp,%rax)
	movw	$0, 602(%rsp,%rax)
	movw	$0, 604(%rsp,%rax)
	movw	$0, 606(%rsp,%rax)
	movw	$0, 608(%rsp,%rax)
	movw	$0, 610(%rsp,%rax)
	movw	$0, 612(%rsp,%rax)
	movw	$0, 614(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_26
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_28:
	movw	$0, 88(%rsp,%rax)
	movw	$0, 90(%rsp,%rax)
	movw	$0, 92(%rsp,%rax)
	movw	$0, 94(%rsp,%rax)
	movw	$0, 96(%rsp,%rax)
	movw	$0, 98(%rsp,%rax)
	movw	$0, 100(%rsp,%rax)
	movw	$0, 102(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_28
	#MEMBARRIER
	movq	%r12, 40(%rsp)
	cmpq	$3, %r12
	jne	.LBB52_1
	leaq	2648(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	movl	$2642262849, %ebx
	leaq	2136(%rsp), %r12
	xorl	%r14d, %r14d
	xorl	%r15d, %r15d
	.p2align	4
.LBB52_70:
	leaq	(%rsp,%r15), %rbp
	addq	$4248, %rbp
	addq	$512, %r15
	leaq	(%r14,%r14,2), %rdi
	incq	%r14
	shlq	$7, %rdi
	addq	72(%rsp), %rdi
	movl	$512, %r8d
	leaq	600(%rsp), %rsi
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%eax, %eax
	.p2align	4
.LBB52_71:
	movq	%rax, %rcx
	shrq	$3, %rcx
	movzbl	(%rdi,%rcx), %r13d
	movl	%eax, %ecx
	andb	$4, %cl
	movzbl	%cl, %r8d
	xorl	%r10d, %r10d
	btl	%r8d, %r13d
	setb	%r10b
	leal	1(%r8), %ecx
	movl	%r13d, %r11d
	shrl	%cl, %r11d
	orw	(%rsi), %r10w
	leal	2(%r8), %ecx
	movl	%r13d, %r9d
	shrl	%cl, %r9d
	addl	%r11d, %r11d
	andl	$2, %r11d
	shll	$2, %r9d
	leal	3(%r8), %ecx
	shrl	%cl, %r13d
	andl	$4, %r9d
	orl	%r11d, %r9d
	shll	$3, %r13d
	leaq	4(%rax), %rcx
	movq	%rcx, %r11
	shrq	$3, %r11
	movzbl	(%rdi,%r11), %r11d
	andb	$4, %cl
	shrl	%cl, %r11d
	andl	$8, %r13d
	orl	%r9d, %r13d
	shll	$4, %r11d
	leaq	5(%rax), %rcx
	movq	%rcx, %r9
	shrq	$3, %r9
	movzbl	(%rdi,%r9), %r9d
	andb	$5, %cl
	shrl	%cl, %r9d
	andl	$16, %r11d
	orl	%r13d, %r11d
	shll	$5, %r9d
	andl	$32, %r9d
	orl	%r11d, %r9d
	orl	%r10d, %r9d
	leaq	6(%rax), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movzbl	(%rdi,%r10), %r10d
	andb	$6, %cl
	shrl	%cl, %r10d
	leaq	7(%rax), %rcx
	movq	%rcx, %r11
	shrq	$3, %r11
	movzbl	(%rdi,%r11), %r11d
	andb	$7, %cl
	shrb	%cl, %r11b
	shll	$6, %r10d
	andl	$64, %r10d
	shlb	$7, %r11b
	movzbl	%r11b, %ecx
	orl	%r10d, %ecx
	leaq	8(%rax), %r10
	shrq	$3, %r10
	movzbl	(%rdi,%r10), %r10d
	xorl	%r11d, %r11d
	btl	%r8d, %r10d
	setb	%r11b
	shll	$8, %r11d
	orl	%ecx, %r11d
	leaq	9(%rax), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%rdi,%r8), %r8d
	andl	$5, %ecx
	xorl	%r10d, %r10d
	btl	%ecx, %r8d
	setb	%r10b
	shll	$9, %r10d
	orl	%r11d, %r10d
	leaq	10(%rax), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%rdi,%r8), %r8d
	andl	$6, %ecx
	xorl	%r11d, %r11d
	btl	%ecx, %r8d
	setb	%r11b
	shll	$10, %r11d
	orl	%r10d, %r11d
	orl	%r9d, %r11d
	leaq	11(%rax), %rcx
	movq	%rcx, %r8
	shrq	$3, %r8
	movzbl	(%rdi,%r8), %r8d
	andl	$7, %ecx
	xorl	%r9d, %r9d
	btl	%ecx, %r8d
	setb	%r9b
	shll	$11, %r9d
	orl	%r11d, %r9d
	movw	%r9w, (%rsi)
	addq	$2, %rsi
	addq	$12, %rax
	cmpq	$3072, %rax
	jne	.LBB52_71
	movl	$512, %r8d
	leaq	88(%rsp), %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%eax, %eax
	jmp	.LBB52_73
	.p2align	4
.LBB52_60:
	movzwl	600(%rsp,%rax,4), %r10d
	movzwl	(%rbp,%rax,4), %edx
	movzwl	602(%rsp,%rax,4), %r9d
	movzwl	2(%rbp,%rax,4), %r8d
	movl	%edx, %r11d
	imull	%r10d, %r11d
	imulq	$989558401, %r11, %rdi
	shrq	$32, %rdi
	movl	%r11d, %r13d
	subl	%edi, %r13d
	shrl	%r13d
	addl	%edi, %r13d
	shrl	$11, %r13d
	imull	$3329, %r13d, %edi
	subl	%edi, %r11d
	movl	%r8d, %edi
	imull	%r9d, %edi
	imulq	$989558401, %rdi, %r13
	shrq	$32, %r13
	movl	%edi, %esi
	subl	%r13d, %esi
	shrl	%esi
	addl	%r13d, %esi
	shrl	$11, %esi
	imull	$3329, %esi, %esi
	subl	%esi, %edi
	movzwl	%cx, %ecx
	imull	%edi, %ecx
	imulq	$330282857, %rcx, %rsi
	shrq	$40, %rsi
	imull	$3329, %esi, %esi
	subl	%esi, %ecx
	addl	%r11d, %ecx
	leal	-3329(%rcx), %r11d
	cmpl	$3329, %ecx
	cmovbl	%ecx, %r11d
	movw	%r11w, 88(%rsp,%rax,4)
	imull	%r10d, %r8d
	imulq	$989558401, %r8, %rcx
	shrq	$32, %rcx
	movl	%r8d, %r10d
	subl	%ecx, %r10d
	shrl	%r10d
	addl	%ecx, %r10d
	shrl	$11, %r10d
	imull	$3329, %r10d, %ecx
	subl	%ecx, %r8d
	imull	%r9d, %edx
	imulq	$989558401, %rdx, %rcx
	shrq	$32, %rcx
	movl	%edx, %r9d
	subl	%ecx, %r9d
	shrl	%r9d
	addl	%ecx, %r9d
	shrl	$11, %r9d
	imull	$3329, %r9d, %ecx
	subl	%ecx, %edx
	leal	(%r8,%rdx), %ecx
	cmpl	$3329, %ecx
	leal	-3329(%r8,%rdx), %edx
	cmovbl	%ecx, %edx
	movw	%dx, 90(%rsp,%rax,4)
	incq	%rax
	cmpq	$128, %rax
	je	.LBB52_61
.LBB52_73:
	movl	%eax, %ecx
	rolb	$4, %cl
	orb	$8, %cl
	movl	%ecx, %edx
	andb	$51, %dl
	shlb	$2, %dl
	shrb	$2, %cl
	andb	$51, %cl
	orb	%dl, %cl
	movl	%ecx, %edx
	andb	$85, %dl
	addb	%dl, %dl
	shrb	%cl
	andb	$85, %cl
	orb	%dl, %cl
	movzbl	%cl, %edx
	movw	$1, %cx
	movw	$17, %r8w
	jmp	.LBB52_74
	.p2align	4
.LBB52_76:
	imull	%r8d, %r8d
	movq	%r8, %r9
	imulq	%rbx, %r9
	shrq	$43, %r9
	imull	$3329, %r9d, %r9d
	subl	%r9d, %r8d
	shrl	%edx
	je	.LBB52_60
.LBB52_74:
	movzwl	%r8w, %r8d
	testb	$1, %dl
	je	.LBB52_76
	movzwl	%cx, %ecx
	imull	%r8d, %ecx
	imulq	$989558401, %rcx, %r9
	shrq	$32, %r9
	movl	%ecx, %r10d
	subl	%r9d, %r10d
	shrl	%r10d
	addl	%r9d, %r10d
	shrl	$11, %r10d
	imull	$3329, %r10d, %r9d
	subl	%r9d, %ecx
	jmp	.LBB52_76
	.p2align	4
.LBB52_61:
	movl	$1, %eax
	.p2align	4
.LBB52_62:
	movzwl	2646(%rsp,%rax,2), %ecx
	movzwl	86(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1110(%rsp,%rax,2)
	movzwl	2648(%rsp,%rax,2), %ecx
	movzwl	88(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1112(%rsp,%rax,2)
	addq	$2, %rax
	cmpq	$257, %rax
	jne	.LBB52_62
	movl	$512, %r8d
	movq	%r12, %rcx
	leaq	1112(%rsp), %rdx
	callq	memcpy
	movl	$14, %eax
	.p2align	4
.LBB52_64:
	movw	$0, 2634(%rsp,%rax)
	movw	$0, 2636(%rsp,%rax)
	movw	$0, 2638(%rsp,%rax)
	movw	$0, 2640(%rsp,%rax)
	movw	$0, 2642(%rsp,%rax)
	movw	$0, 2644(%rsp,%rax)
	movw	$0, 2646(%rsp,%rax)
	movw	$0, 2648(%rsp,%rax)
	addq	$16, %rax
	cmpq	$526, %rax
	jne	.LBB52_64
	#MEMBARRIER
	movl	$512, %r8d
	leaq	2648(%rsp), %rcx
	movq	%r12, %rdx
	callq	memcpy
	xorl	%eax, %eax
	.p2align	4
.LBB52_66:
	movw	$0, 88(%rsp,%rax)
	movw	$0, 90(%rsp,%rax)
	movw	$0, 92(%rsp,%rax)
	movw	$0, 94(%rsp,%rax)
	movw	$0, 96(%rsp,%rax)
	movw	$0, 98(%rsp,%rax)
	movw	$0, 100(%rsp,%rax)
	movw	$0, 102(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_66
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_68:
	movw	$0, 600(%rsp,%rax)
	movw	$0, 602(%rsp,%rax)
	movw	$0, 604(%rsp,%rax)
	movw	$0, 606(%rsp,%rax)
	movw	$0, 608(%rsp,%rax)
	movw	$0, 610(%rsp,%rax)
	movw	$0, 612(%rsp,%rax)
	movw	$0, 614(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_68
	#MEMBARRIER
	cmpq	$1536, %r15
	jne	.LBB52_70
	leaq	1112(%rsp), %rsi
	leaq	2648(%rsp), %rdx
	movl	$512, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	leaq	2136(%rsp), %rcx
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly7inverse
	leaq	88(%rsp), %rcx
	movq	48(%rsp), %rdx
	movb	$6, %r8b
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise
	movl	$1, %eax
	.p2align	4
.LBB52_32:
	movzwl	2134(%rsp,%rax,2), %ecx
	movzwl	86(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1110(%rsp,%rax,2)
	movzwl	2136(%rsp,%rax,2), %ecx
	movzwl	88(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1112(%rsp,%rax,2)
	addq	$2, %rax
	cmpq	$257, %rax
	jne	.LBB52_32
	leaq	1624(%rsp), %rcx
	leaq	1112(%rsp), %rdx
	movl	$512, %r8d
	callq	memcpy
	xorl	%esi, %esi
	leaq	1112(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	56(%rsp), %r8
	.p2align	4
.LBB52_34:
	movq	%rsi, %rax
	shrq	$3, %rax
	movzbl	(%r8,%rax), %eax
	movl	%esi, %ecx
	andl	$6, %ecx
	xorl	%edx, %edx
	btl	%ecx, %eax
	setb	%dl
	orw	%dx, 1112(%rsp,%rsi,2)
	leal	1(%rsi), %ecx
	movzbl	%cl, %ecx
	andl	$7, %ecx
	xorl	%edx, %edx
	btl	%ecx, %eax
	setb	%dl
	orw	%dx, 1114(%rsp,%rsi,2)
	addq	$2, %rsi
	cmpq	$256, %rsi
	jne	.LBB52_34
	movl	$2, %eax
	.p2align	4
.LBB52_36:
	movzwl	1110(%rsp,%rax), %ecx
	imull	$3329, %ecx, %ecx
	incl	%ecx
	shrl	%ecx
	movw	%cx, 1110(%rsp,%rax)
	movzwl	1112(%rsp,%rax), %ecx
	imull	$3329, %ecx, %ecx
	incl	%ecx
	shrl	%ecx
	movw	%cx, 1112(%rsp,%rax)
	addq	$4, %rax
	cmpq	$514, %rax
	jne	.LBB52_36
	leaq	600(%rsp), %rcx
	leaq	1112(%rsp), %rsi
	movl	$512, %r8d
	movq	%rsi, %rdx
	callq	memcpy
	movl	$1, %eax
	.p2align	4
.LBB52_38:
	movzwl	1622(%rsp,%rax,2), %ecx
	movzwl	598(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 5782(%rsp,%rax,2)
	movzwl	1624(%rsp,%rax,2), %ecx
	movzwl	600(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 5784(%rsp,%rax,2)
	addq	$2, %rax
	cmpq	$257, %rax
	jne	.LBB52_38
	movl	$2, %eax
	.p2align	4
.LBB52_40:
	movzwl	5782(%rsp,%rax), %ecx
	shll	$4, %ecx
	addl	$1664, %ecx
	imulq	$1290168, %rcx, %rcx
	shrq	$32, %rcx
	andl	$15, %ecx
	movw	%cx, 5782(%rsp,%rax)
	movzwl	5784(%rsp,%rax), %ecx
	shll	$4, %ecx
	addl	$1664, %ecx
	imulq	$1290168, %rcx, %rcx
	shrq	$32, %rcx
	andl	$15, %ecx
	movw	%cx, 5784(%rsp,%rax)
	addq	$4, %rax
	cmpq	$514, %rax
	jne	.LBB52_40
	leaq	5784(%rsp), %rdx
	movl	$512, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movq	$0, 4120(%rsp)
	movq	$0, 4128(%rsp)
	movq	$0, 4136(%rsp)
	movq	$0, 4144(%rsp)
	movq	$0, 4152(%rsp)
	movq	$0, 4160(%rsp)
	movq	$0, 4168(%rsp)
	movq	$0, 4176(%rsp)
	movq	$0, 4184(%rsp)
	movq	$0, 4192(%rsp)
	movq	$0, 4200(%rsp)
	movq	$0, 4208(%rsp)
	movq	$0, 4216(%rsp)
	movq	$0, 4224(%rsp)
	movq	$0, 4232(%rsp)
	movq	$0, 4240(%rsp)
	xorl	%edx, %edx
	.p2align	4
.LBB52_42:
	movzbl	(%rsi), %r8d
	movl	%r8d, %r9d
	andb	$1, %r9b
	movl	%edx, %eax
	andb	$4, %al
	movl	%eax, %ecx
	shlb	%cl, %r9b
	movq	%rdx, %r10
	shrq	$3, %r10
	orb	4120(%rsp,%r10), %r9b
	movl	%r8d, %r11d
	shrb	%r11b
	andb	$1, %r11b
	leal	1(%rax), %ecx
	shlb	%cl, %r11b
	movl	%r8d, %ebx
	shrb	$2, %bl
	andb	$1, %bl
	leal	2(%rax), %ecx
	shlb	%cl, %bl
	shrb	$3, %r8b
	andb	$1, %r8b
	orb	$3, %al
	movl	%eax, %ecx
	shlb	%cl, %r8b
	orb	%r11b, %bl
	orb	%bl, %r8b
	orb	%r9b, %r8b
	movb	%r8b, 4120(%rsp,%r10)
	addq	$2, %rsi
	addq	$4, %rdx
	cmpq	$1024, %rdx
	jne	.LBB52_42
	xorl	%eax, %eax
	.p2align	4
.LBB52_44:
	movw	$0, 1112(%rsp,%rax)
	movw	$0, 1114(%rsp,%rax)
	movw	$0, 1116(%rsp,%rax)
	movw	$0, 1118(%rsp,%rax)
	movw	$0, 1120(%rsp,%rax)
	movw	$0, 1122(%rsp,%rax)
	movw	$0, 1124(%rsp,%rax)
	movw	$0, 1126(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_44
	#MEMBARRIER
	xorl	%eax, %eax
	movq	64(%rsp), %rsi
	.p2align	4
.LBB52_46:
	movw	$0, 600(%rsp,%rax)
	movw	$0, 602(%rsp,%rax)
	movw	$0, 604(%rsp,%rax)
	movw	$0, 606(%rsp,%rax)
	movw	$0, 608(%rsp,%rax)
	movw	$0, 610(%rsp,%rax)
	movw	$0, 612(%rsp,%rax)
	movw	$0, 614(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_46
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_48:
	movw	$0, 1624(%rsp,%rax)
	movw	$0, 1626(%rsp,%rax)
	movw	$0, 1628(%rsp,%rax)
	movw	$0, 1630(%rsp,%rax)
	movw	$0, 1632(%rsp,%rax)
	movw	$0, 1634(%rsp,%rax)
	movw	$0, 1636(%rsp,%rax)
	movw	$0, 1638(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_48
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_50:
	movw	$0, 88(%rsp,%rax)
	movw	$0, 90(%rsp,%rax)
	movw	$0, 92(%rsp,%rax)
	movw	$0, 94(%rsp,%rax)
	movw	$0, 96(%rsp,%rax)
	movw	$0, 98(%rsp,%rax)
	movw	$0, 100(%rsp,%rax)
	movw	$0, 102(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_50
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_52:
	movw	$0, 2136(%rsp,%rax)
	movw	$0, 2138(%rsp,%rax)
	movw	$0, 2140(%rsp,%rax)
	movw	$0, 2142(%rsp,%rax)
	movw	$0, 2144(%rsp,%rax)
	movw	$0, 2146(%rsp,%rax)
	movw	$0, 2148(%rsp,%rax)
	movw	$0, 2150(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_52
	#MEMBARRIER
	leaq	3160(%rsp), %rdx
	movl	$1088, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	xorl	%eax, %eax
	.p2align	4
.LBB52_54:
	movw	$0, 4248(%rsp,%rax)
	movw	$0, 4250(%rsp,%rax)
	movw	$0, 4252(%rsp,%rax)
	movw	$0, 4254(%rsp,%rax)
	movw	$0, 4256(%rsp,%rax)
	movw	$0, 4258(%rsp,%rax)
	movw	$0, 4260(%rsp,%rax)
	movw	$0, 4262(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_54
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_56:
	movw	$0, 4760(%rsp,%rax)
	movw	$0, 4762(%rsp,%rax)
	movw	$0, 4764(%rsp,%rax)
	movw	$0, 4766(%rsp,%rax)
	movw	$0, 4768(%rsp,%rax)
	movw	$0, 4770(%rsp,%rax)
	movw	$0, 4772(%rsp,%rax)
	movw	$0, 4774(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_56
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB52_58:
	movw	$0, 5272(%rsp,%rax)
	movw	$0, 5274(%rsp,%rax)
	movw	$0, 5276(%rsp,%rax)
	movw	$0, 5278(%rsp,%rax)
	movw	$0, 5280(%rsp,%rax)
	movw	$0, 5282(%rsp,%rax)
	movw	$0, 5284(%rsp,%rax)
	movw	$0, 5286(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB52_58
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$7832, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs2_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs2_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate,unique,53
	.globl	_RNvMs2_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate
	.p2align	4
_RNvMs2_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16DecapsulationKey11decapsulate:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$3848, %rsp
	movq	%rdx, %rdi
	cmpq	$1088, %r9
	jne	.LBB53_40
	movq	%r8, %rbx
	movq	%rcx, 144(%rsp)
	leaq	2312(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	movl	$2642262849, %esi
	xorl	%ebp, %ebp
	xorl	%eax, %eax
	movq	%rbx, 152(%rsp)
	.p2align	4
.LBB53_2:
	leaq	(%rdi,%rbp), %r14
	addq	$512, %rbp
	leaq	(%rax,%rax,4), %r13
	incq	%rax
	movq	%rax, 160(%rsp)
	shlq	$6, %r13
	addq	%rbx, %r13
	movl	$512, %r8d
	leaq	1224(%rsp), %rbx
	movq	%rbx, %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%edx, %edx
	movq	%rbx, %r8
	.p2align	4
.LBB53_3:
	movq	%rdx, %rax
	shrq	$3, %rax
	movzbl	(%r13,%rax), %r10d
	movl	%edx, %eax
	andb	$6, %al
	movzbl	%al, %r9d
	xorl	%eax, %eax
	btl	%r9d, %r10d
	setb	%al
	orw	(%r8), %ax
	leal	1(%r9), %ecx
	shrl	%cl, %r10d
	leaq	2(%rdx), %rcx
	movq	%rcx, %r11
	shrq	$3, %r11
	movzbl	(%r13,%r11), %r11d
	andb	$6, %cl
	shrl	%cl, %r11d
	addl	%r10d, %r10d
	andl	$2, %r10d
	shll	$2, %r11d
	leaq	3(%rdx), %rcx
	movq	%rcx, %r12
	shrq	$3, %r12
	movzbl	(%r13,%r12), %r12d
	andb	$7, %cl
	shrl	%cl, %r12d
	andl	$4, %r11d
	orl	%r10d, %r11d
	shll	$3, %r12d
	leaq	4(%rdx), %rcx
	movq	%rcx, %r10
	shrq	$3, %r10
	movzbl	(%r13,%r10), %r10d
	andb	$6, %cl
	shrl	%cl, %r10d
	andl	$8, %r12d
	orl	%r11d, %r12d
	shll	$4, %r10d
	andl	$16, %r10d
	orl	%r12d, %r10d
	orl	%eax, %r10d
	leaq	5(%rdx), %rcx
	movq	%rcx, %rax
	shrq	$3, %rax
	movzbl	(%r13,%rax), %r11d
	andb	$7, %cl
	shrl	%cl, %r11d
	leaq	6(%rdx), %r15
	leaq	7(%rdx), %rax
	movq	%rax, %r12
	shrq	$3, %r12
	movzbl	(%r13,%r12), %r12d
	movq	%r15, %rcx
	shrq	$3, %rcx
	movzbl	(%r13,%rcx), %ebx
	andb	$6, %r15b
	movl	%r15d, %ecx
	shrl	%cl, %ebx
	shll	$5, %r11d
	andl	$32, %r11d
	shll	$6, %ebx
	andb	$7, %al
	movl	%eax, %ecx
	shrb	%cl, %r12b
	andl	$64, %ebx
	orl	%r11d, %ebx
	shlb	$7, %r12b
	movzbl	%r12b, %eax
	orl	%ebx, %eax
	leaq	8(%rdx), %rcx
	shrq	$3, %rcx
	movzbl	(%r13,%rcx), %ecx
	xorl	%r11d, %r11d
	btl	%r9d, %ecx
	setb	%r11b
	shll	$8, %r11d
	orl	%eax, %r11d
	leaq	9(%rdx), %rax
	movq	%rax, %rcx
	shrq	$3, %rcx
	movzbl	(%r13,%rcx), %ecx
	andl	$7, %eax
	xorl	%r9d, %r9d
	btl	%eax, %ecx
	setb	%r9b
	shll	$9, %r9d
	orl	%r11d, %r9d
	orl	%r10d, %r9d
	movw	%r9w, (%r8)
	addq	$2, %r8
	addq	$10, %rdx
	cmpq	$2560, %rdx
	jne	.LBB53_3
	movl	$2, %eax
	.p2align	4
.LBB53_5:
	movzwl	1222(%rsp,%rax), %ecx
	imull	$3329, %ecx, %ecx
	addl	$512, %ecx
	shrl	$10, %ecx
	movw	%cx, 1222(%rsp,%rax)
	movzwl	1224(%rsp,%rax), %ecx
	imull	$3329, %ecx, %ecx
	addl	$512, %ecx
	shrl	$10, %ecx
	movw	%cx, 1224(%rsp,%rax)
	addq	$4, %rax
	cmpq	$514, %rax
	jne	.LBB53_5
	movl	$512, %r8d
	leaq	200(%rsp), %rbx
	movq	%rbx, %rcx
	leaq	1224(%rsp), %rdx
	callq	memcpy
	leaq	712(%rsp), %rcx
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly3ntt
	movl	$512, %r8d
	movq	%rbx, %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%eax, %eax
	jmp	.LBB53_7
	.p2align	4
.LBB53_11:
	movzwl	(%r14,%rax,4), %r10d
	movzwl	712(%rsp,%rax,4), %edx
	movzwl	2(%r14,%rax,4), %r9d
	movzwl	714(%rsp,%rax,4), %r8d
	movl	%edx, %r11d
	imull	%r10d, %r11d
	imulq	$989558401, %r11, %rbx
	shrq	$32, %rbx
	movl	%r11d, %r15d
	subl	%ebx, %r15d
	shrl	%r15d
	addl	%ebx, %r15d
	shrl	$11, %r15d
	imull	$3329, %r15d, %ebx
	subl	%ebx, %r11d
	movl	%r8d, %ebx
	imull	%r9d, %ebx
	imulq	$989558401, %rbx, %r15
	shrq	$32, %r15
	movl	%ebx, %r12d
	subl	%r15d, %r12d
	shrl	%r12d
	addl	%r15d, %r12d
	shrl	$11, %r12d
	imull	$3329, %r12d, %r15d
	subl	%r15d, %ebx
	movzwl	%cx, %ecx
	imull	%ebx, %ecx
	imulq	$330282857, %rcx, %rbx
	shrq	$40, %rbx
	imull	$3329, %ebx, %ebx
	subl	%ebx, %ecx
	addl	%r11d, %ecx
	leal	-3329(%rcx), %r11d
	cmpl	$3329, %ecx
	cmovbl	%ecx, %r11d
	movw	%r11w, 200(%rsp,%rax,4)
	imull	%r10d, %r8d
	imulq	$989558401, %r8, %rcx
	shrq	$32, %rcx
	movl	%r8d, %r10d
	subl	%ecx, %r10d
	shrl	%r10d
	addl	%ecx, %r10d
	shrl	$11, %r10d
	imull	$3329, %r10d, %ecx
	subl	%ecx, %r8d
	imull	%r9d, %edx
	imulq	$989558401, %rdx, %rcx
	shrq	$32, %rcx
	movl	%edx, %r9d
	subl	%ecx, %r9d
	shrl	%r9d
	addl	%ecx, %r9d
	shrl	$11, %r9d
	imull	$3329, %r9d, %ecx
	subl	%ecx, %edx
	leal	(%r8,%rdx), %ecx
	cmpl	$3329, %ecx
	leal	-3329(%r8,%rdx), %edx
	cmovbl	%ecx, %edx
	movw	%dx, 202(%rsp,%rax,4)
	incq	%rax
	cmpq	$128, %rax
	je	.LBB53_12
.LBB53_7:
	movl	%eax, %ecx
	rolb	$4, %cl
	orb	$8, %cl
	movl	%ecx, %edx
	andb	$51, %dl
	shlb	$2, %dl
	shrb	$2, %cl
	andb	$51, %cl
	orb	%dl, %cl
	movl	%ecx, %edx
	andb	$85, %dl
	addb	%dl, %dl
	shrb	%cl
	andb	$85, %cl
	orb	%dl, %cl
	movzbl	%cl, %edx
	movw	$1, %cx
	movw	$17, %r8w
	jmp	.LBB53_8
	.p2align	4
.LBB53_10:
	imull	%r8d, %r8d
	movq	%r8, %r9
	imulq	%rsi, %r9
	shrq	$43, %r9
	imull	$3329, %r9d, %r9d
	subl	%r9d, %r8d
	shrl	%edx
	je	.LBB53_11
.LBB53_8:
	movzwl	%r8w, %r8d
	testb	$1, %dl
	je	.LBB53_10
	movzwl	%cx, %ecx
	imull	%r8d, %ecx
	imulq	$989558401, %rcx, %r9
	shrq	$32, %r9
	movl	%ecx, %r10d
	subl	%r9d, %r10d
	shrl	%r10d
	addl	%r9d, %r10d
	shrl	$11, %r10d
	imull	$3329, %r10d, %r9d
	subl	%r9d, %ecx
	jmp	.LBB53_10
	.p2align	4
.LBB53_12:
	movl	$1, %eax
	.p2align	4
.LBB53_13:
	movzwl	2310(%rsp,%rax,2), %ecx
	movzwl	198(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1222(%rsp,%rax,2)
	movzwl	2312(%rsp,%rax,2), %ecx
	movzwl	200(%rsp,%rax,2), %edx
	addl	%ecx, %edx
	imulq	$1290168, %rdx, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %edx
	movw	%dx, 1224(%rsp,%rax,2)
	addq	$2, %rax
	cmpq	$257, %rax
	jne	.LBB53_13
	movl	$512, %r8d
	leaq	3336(%rsp), %r14
	movq	%r14, %rcx
	leaq	1224(%rsp), %rdx
	callq	memcpy
	movl	$14, %eax
	movq	152(%rsp), %rbx
	.p2align	4
.LBB53_15:
	movw	$0, 2298(%rsp,%rax)
	movw	$0, 2300(%rsp,%rax)
	movw	$0, 2302(%rsp,%rax)
	movw	$0, 2304(%rsp,%rax)
	movw	$0, 2306(%rsp,%rax)
	movw	$0, 2308(%rsp,%rax)
	movw	$0, 2310(%rsp,%rax)
	movw	$0, 2312(%rsp,%rax)
	addq	$16, %rax
	cmpq	$526, %rax
	jne	.LBB53_15
	#MEMBARRIER
	movl	$512, %r8d
	leaq	2312(%rsp), %rcx
	movq	%r14, %rdx
	callq	memcpy
	xorl	%eax, %eax
	.p2align	4
.LBB53_17:
	movw	$0, 200(%rsp,%rax)
	movw	$0, 202(%rsp,%rax)
	movw	$0, 204(%rsp,%rax)
	movw	$0, 206(%rsp,%rax)
	movw	$0, 208(%rsp,%rax)
	movw	$0, 210(%rsp,%rax)
	movw	$0, 212(%rsp,%rax)
	movw	$0, 214(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_17
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB53_19:
	movw	$0, 712(%rsp,%rax)
	movw	$0, 714(%rsp,%rax)
	movw	$0, 716(%rsp,%rax)
	movw	$0, 718(%rsp,%rax)
	movw	$0, 720(%rsp,%rax)
	movw	$0, 722(%rsp,%rax)
	movw	$0, 724(%rsp,%rax)
	movw	$0, 726(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_19
	#MEMBARRIER
	cmpq	$1536, %rbp
	movq	160(%rsp), %rax
	jne	.LBB53_2
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	xorl	%esi, %esi
	leaq	1224(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	xorl	%edx, %edx
	.p2align	4
.LBB53_22:
	movq	%rdx, %rax
	shrq	%rax
	movzbl	960(%rbx,%rax), %r8d
	movl	%esi, %eax
	andb	$4, %al
	movzbl	%al, %eax
	xorl	%r9d, %r9d
	btl	%eax, %r8d
	setb	%r9b
	orw	1224(%rsp,%rdx,2), %r9w
	leal	1(%rax), %ecx
	movl	%r8d, %r10d
	shrl	%cl, %r10d
	addl	%r10d, %r10d
	andl	$2, %r10d
	leal	2(%rax), %ecx
	movl	%r8d, %r11d
	shrl	%cl, %r11d
	shll	$2, %r11d
	andl	$4, %r11d
	orl	%r10d, %r11d
	orb	$3, %al
	movl	%eax, %ecx
	shrl	%cl, %r8d
	shll	$3, %r8d
	andl	$8, %r8d
	orl	%r11d, %r8d
	orl	%r9d, %r8d
	movw	%r8w, 1224(%rsp,%rdx,2)
	incq	%rdx
	addb	$4, %sil
	cmpq	$256, %rdx
	jne	.LBB53_22
	movl	$2, %eax
	.p2align	4
.LBB53_24:
	movzwl	1222(%rsp,%rax), %ecx
	imull	$3329, %ecx, %ecx
	addl	$8, %ecx
	shrl	$4, %ecx
	movw	%cx, 1222(%rsp,%rax)
	movzwl	1224(%rsp,%rax), %ecx
	imull	$3329, %ecx, %ecx
	addl	$8, %ecx
	shrl	$4, %ecx
	movw	%cx, 1224(%rsp,%rax)
	addq	$4, %rax
	cmpq	$514, %rax
	jne	.LBB53_24
	leaq	712(%rsp), %rcx
	leaq	1224(%rsp), %rdx
	movl	$512, %r8d
	callq	memcpy
	leaq	1224(%rsp), %r14
	leaq	2312(%rsp), %rdx
	movl	$512, %r8d
	movq	%r14, %rcx
	callq	memcpy
	leaq	200(%rsp), %rcx
	movq	%r14, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly7inverse
	movl	$1, %eax
	.p2align	4
.LBB53_26:
	movzwl	710(%rsp,%rax,2), %ecx
	movzwl	198(%rsp,%rax,2), %edx
	subl	%edx, %ecx
	addl	$3329, %ecx
	imulq	$989558401, %rcx, %rdx
	shrq	$32, %rdx
	movl	%ecx, %r8d
	subl	%edx, %r8d
	shrl	%r8d
	addl	%edx, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %edx
	subl	%edx, %ecx
	movw	%cx, 2822(%rsp,%rax,2)
	movzwl	712(%rsp,%rax,2), %ecx
	movzwl	200(%rsp,%rax,2), %edx
	subl	%edx, %ecx
	addl	$3329, %ecx
	imulq	$989558401, %rcx, %rdx
	shrq	$32, %rdx
	movl	%ecx, %r8d
	subl	%edx, %r8d
	shrl	%r8d
	addl	%edx, %r8d
	shrl	$11, %r8d
	imull	$3329, %r8d, %edx
	subl	%edx, %ecx
	movw	%cx, 2824(%rsp,%rax,2)
	addq	$2, %rax
	cmpq	$257, %rax
	jne	.LBB53_26
	movl	$2, %eax
	.p2align	4
.LBB53_28:
	movzwl	2822(%rsp,%rax), %ecx
	leal	1664(,%rcx,2), %ecx
	imulq	$1290168, %rcx, %rcx
	shrq	$32, %rcx
	andl	$1, %ecx
	movw	%cx, 2822(%rsp,%rax)
	movzwl	2824(%rsp,%rax), %ecx
	leal	1664(,%rcx,2), %ecx
	imulq	$1290168, %rcx, %rcx
	shrq	$32, %rcx
	andl	$1, %ecx
	movw	%cx, 2824(%rsp,%rax)
	addq	$4, %rax
	cmpq	$514, %rax
	jne	.LBB53_28
	leaq	1224(%rsp), %rcx
	leaq	2824(%rsp), %rdx
	movl	$512, %r8d
	callq	memcpy
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	xorl	%edx, %edx
	xorl	%eax, %eax
	.p2align	4
.LBB53_30:
	movzbl	1224(%rsp,%rdx,2), %r8d
	movzbl	1226(%rsp,%rdx,2), %r9d
	andb	$1, %r8b
	movl	%edx, %ecx
	andb	$6, %cl
	shlb	%cl, %r8b
	movq	%rdx, %r10
	shrq	$3, %r10
	orb	48(%rsp,%r10), %r8b
	leal	1(%rdx), %ecx
	addq	$2, %rax
	andb	$1, %r9b
	andb	$7, %cl
	shlb	%cl, %r9b
	orb	%r8b, %r9b
	movb	%r9b, 48(%rsp,%r10)
	movq	%rax, %rdx
	cmpq	$256, %rax
	jne	.LBB53_30
	xorl	%eax, %eax
	.p2align	4
.LBB53_32:
	movw	$0, 1224(%rsp,%rax)
	movw	$0, 1226(%rsp,%rax)
	movw	$0, 1228(%rsp,%rax)
	movw	$0, 1230(%rsp,%rax)
	movw	$0, 1232(%rsp,%rax)
	movw	$0, 1234(%rsp,%rax)
	movw	$0, 1236(%rsp,%rax)
	movw	$0, 1238(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_32
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB53_34:
	movw	$0, 200(%rsp,%rax)
	movw	$0, 202(%rsp,%rax)
	movw	$0, 204(%rsp,%rax)
	movw	$0, 206(%rsp,%rax)
	movw	$0, 208(%rsp,%rax)
	movw	$0, 210(%rsp,%rax)
	movw	$0, 212(%rsp,%rax)
	movw	$0, 214(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_34
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB53_36:
	movw	$0, 712(%rsp,%rax)
	movw	$0, 714(%rsp,%rax)
	movw	$0, 716(%rsp,%rax)
	movw	$0, 718(%rsp,%rax)
	movw	$0, 720(%rsp,%rax)
	movw	$0, 722(%rsp,%rax)
	movw	$0, 724(%rsp,%rax)
	movw	$0, 726(%rsp,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_36
	#MEMBARRIER
	leaq	2720(%rdi), %rax
	leaq	48(%rsp), %rcx
	movq	%rcx, 712(%rsp)
	movq	$32, 720(%rsp)
	movq	%rax, 728(%rsp)
	movq	$32, 736(%rsp)
	leaq	1224(%rsp), %r14
	leaq	712(%rsp), %rdx
	movl	$2, %r8d
	movq	%r14, %rcx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1g
	movq	1280(%rsp), %rax
	movq	%rax, 256(%rsp)
	movq	1272(%rsp), %rax
	movq	%rax, 248(%rsp)
	movq	1264(%rsp), %rax
	movq	%rax, 240(%rsp)
	movq	1256(%rsp), %rax
	movq	%rax, 232(%rsp)
	movq	1248(%rsp), %rax
	movq	%rax, 224(%rsp)
	movq	1240(%rsp), %rax
	movq	%rax, 216(%rsp)
	movq	1224(%rsp), %rax
	movq	1232(%rsp), %rcx
	movq	%rcx, 208(%rsp)
	movq	%rax, 200(%rsp)
	leaq	2752(%rdi), %rsi
	movq	%rsi, 3336(%rsp)
	movq	$32, 3344(%rsp)
	movq	%rbx, 3352(%rsp)
	movq	$1088, 3360(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 712(%rsp)
	movq	$2, 32(%rsp)
	leaq	1224(%rsp), %rcx
	leaq	3336(%rsp), %r9
	movl	$136, %edx
	movb	$31, %r8b
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge3new
	xorl	%r15d, %r15d
	movq	1432(%rsp), %rax
	jmp	.LBB53_38
	.p2align	4
.LBB53_39:
	movq	%r14, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 1432(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB53_48:
	leaq	(%rsp,%rcx,8), %rcx
	addq	$1224, %rcx
	movl	%eax, %edx
	andl	$7, %edx
	movzbl	(%rdx,%rcx), %ecx
	movb	%cl, 712(%rsp,%r15)
	incq	%r15
	incq	%rax
	movq	%rax, 1432(%rsp)
	cmpq	$32, %r15
	je	.LBB53_49
.LBB53_38:
	cmpq	1424(%rsp), %rax
	je	.LBB53_39
	movq	%rax, %rcx
	shrq	$3, %rcx
	cmpq	$199, %rax
	jbe	.LBB53_48
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.71(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB53_40:
	movw	$1, (%rcx)
	xorl	%eax, %eax
	.p2align	4
.LBB53_41:
	movw	$0, (%rdi,%rax)
	movw	$0, 2(%rdi,%rax)
	movw	$0, 4(%rdi,%rax)
	movw	$0, 6(%rdi,%rax)
	movw	$0, 8(%rdi,%rax)
	movw	$0, 10(%rdi,%rax)
	movw	$0, 12(%rdi,%rax)
	movw	$0, 14(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_41
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB53_43:
	movw	$0, 512(%rdi,%rax)
	movw	$0, 514(%rdi,%rax)
	movw	$0, 516(%rdi,%rax)
	movw	$0, 518(%rdi,%rax)
	movw	$0, 520(%rdi,%rax)
	movw	$0, 522(%rdi,%rax)
	movw	$0, 524(%rdi,%rax)
	movw	$0, 526(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_43
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB53_45:
	movw	$0, 1024(%rdi,%rax)
	movw	$0, 1026(%rdi,%rax)
	movw	$0, 1028(%rdi,%rax)
	movw	$0, 1030(%rdi,%rax)
	movw	$0, 1032(%rdi,%rax)
	movw	$0, 1034(%rdi,%rax)
	movw	$0, 1036(%rdi,%rax)
	movw	$0, 1038(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_45
	#MEMBARRIER
	movb	$0, 2752(%rdi)
	jmp	.LBB53_62
.LBB53_49:
	movq	$0, 1224(%rsp)
	movq	$0, 1232(%rsp)
	movq	$0, 1240(%rsp)
	movq	$0, 1248(%rsp)
	movq	$0, 1256(%rsp)
	movq	$0, 1264(%rsp)
	movq	$0, 1272(%rsp)
	movq	$0, 1280(%rsp)
	movq	$0, 1288(%rsp)
	movq	$0, 1296(%rsp)
	movq	$0, 1304(%rsp)
	movq	$0, 1312(%rsp)
	movq	$0, 1320(%rsp)
	movq	$0, 1328(%rsp)
	movq	$0, 1336(%rsp)
	movq	$0, 1344(%rsp)
	movq	$0, 1352(%rsp)
	movq	$0, 1360(%rsp)
	movq	$0, 1368(%rsp)
	movq	$0, 1376(%rsp)
	movq	$0, 1384(%rsp)
	movq	$0, 1392(%rsp)
	movq	$0, 1400(%rsp)
	movq	$0, 1408(%rsp)
	movq	$0, 1416(%rsp)
	#MEMBARRIER
	movq	712(%rsp), %rax
	movq	720(%rsp), %rcx
	movq	%rax, 80(%rsp)
	movq	%rcx, 88(%rsp)
	movq	728(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	736(%rsp), %rax
	movq	%rax, 104(%rsp)
	leaq	232(%rsp), %r9
	leaq	1224(%rsp), %rcx
	leaq	48(%rsp), %r8
	leaq	1536(%rdi), %rdx
	callq	_RNvMs1_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB5_16EncapsulationKey7encrypt
	movl	$3, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB53_50:
	movzbl	1221(%rsp,%rax), %edx
	movzbl	1222(%rsp,%rax), %r8d
	xorb	-3(%rbx,%rax), %dl
	movzbl	%dl, %edx
	orq	%rcx, %rdx
	xorb	-2(%rbx,%rax), %r8b
	movzbl	%r8b, %ecx
	movzbl	1223(%rsp,%rax), %r8d
	xorb	-1(%rbx,%rax), %r8b
	movzbl	%r8b, %r8d
	orq	%rcx, %r8
	orq	%rdx, %r8
	movzbl	1224(%rsp,%rax), %ecx
	xorb	(%rbx,%rax), %cl
	movzbl	%cl, %ecx
	orq	%r8, %rcx
	addq	$4, %rax
	cmpq	$1091, %rax
	jne	.LBB53_50
	movl	$7, %eax
	.p2align	4
.LBB53_52:
	movb	$0, 1217(%rsp,%rax)
	movb	$0, 1218(%rsp,%rax)
	movb	$0, 1219(%rsp,%rax)
	movb	$0, 1220(%rsp,%rax)
	movb	$0, 1221(%rsp,%rax)
	movb	$0, 1222(%rsp,%rax)
	movb	$0, 1223(%rsp,%rax)
	movb	$0, 1224(%rsp,%rax)
	addq	$8, %rax
	cmpq	$1095, %rax
	jne	.LBB53_52
	#MEMBARRIER
	xorl	%eax, %eax
	testq	%rcx, %rcx
	setne	%al
	movq	192(%rsp), %rcx
	movq	%rcx, 136(%rsp)
	movq	184(%rsp), %rcx
	movq	%rcx, 128(%rsp)
	movq	168(%rsp), %rcx
	movq	176(%rsp), %rdx
	movq	%rdx, 120(%rsp)
	movq	%rcx, 112(%rsp)
	movl	$1, %ecx
	.p2align	4
.LBB53_54:
	movzbl	199(%rsp,%rcx), %edx
	movzbl	79(%rsp,%rcx), %r8d
	movq	%rax, 712(%rsp)
	movq	712(%rsp), %r9
	movl	%r9d, %r10d
	negl	%r10d
	andl	%r8d, %r10d
	decl	%r9d
	andl	%edx, %r9d
	orl	%r10d, %r9d
	movb	%r9b, 111(%rsp,%rcx)
	movzbl	200(%rsp,%rcx), %edx
	movzbl	80(%rsp,%rcx), %r8d
	movq	%rax, 712(%rsp)
	movq	712(%rsp), %r9
	movl	%r9d, %r10d
	negl	%r10d
	andl	%r8d, %r10d
	decl	%r9d
	andl	%edx, %r9d
	orl	%r10d, %r9d
	movb	%r9b, 112(%rsp,%rcx)
	addq	$2, %rcx
	cmpq	$33, %rcx
	jne	.LBB53_54
	movq	136(%rsp), %rax
	movq	144(%rsp), %rcx
	movq	%rax, 25(%rcx)
	movq	128(%rsp), %rax
	movq	%rax, 17(%rcx)
	movq	112(%rsp), %rax
	movq	120(%rsp), %rdx
	movq	%rdx, 9(%rcx)
	movq	%rax, 1(%rcx)
	movb	$0, (%rcx)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	movb	$0, 96(%rsp)
	movb	$0, 97(%rsp)
	movb	$0, 98(%rsp)
	movb	$0, 99(%rsp)
	movb	$0, 100(%rsp)
	movb	$0, 101(%rsp)
	movb	$0, 102(%rsp)
	movb	$0, 103(%rsp)
	movb	$0, 104(%rsp)
	movb	$0, 105(%rsp)
	movb	$0, 106(%rsp)
	movb	$0, 107(%rsp)
	movb	$0, 108(%rsp)
	movb	$0, 109(%rsp)
	movb	$0, 110(%rsp)
	movb	$0, 111(%rsp)
	#MEMBARRIER
	movb	$0, 200(%rsp)
	movb	$0, 201(%rsp)
	movb	$0, 202(%rsp)
	movb	$0, 203(%rsp)
	movb	$0, 204(%rsp)
	movb	$0, 205(%rsp)
	movb	$0, 206(%rsp)
	movb	$0, 207(%rsp)
	movb	$0, 208(%rsp)
	movb	$0, 209(%rsp)
	movb	$0, 210(%rsp)
	movb	$0, 211(%rsp)
	movb	$0, 212(%rsp)
	movb	$0, 213(%rsp)
	movb	$0, 214(%rsp)
	movb	$0, 215(%rsp)
	movb	$0, 216(%rsp)
	movb	$0, 217(%rsp)
	movb	$0, 218(%rsp)
	movb	$0, 219(%rsp)
	movb	$0, 220(%rsp)
	movb	$0, 221(%rsp)
	movb	$0, 222(%rsp)
	movb	$0, 223(%rsp)
	movb	$0, 224(%rsp)
	movb	$0, 225(%rsp)
	movb	$0, 226(%rsp)
	movb	$0, 227(%rsp)
	movb	$0, 228(%rsp)
	movb	$0, 229(%rsp)
	movb	$0, 230(%rsp)
	movb	$0, 231(%rsp)
	movb	$0, 232(%rsp)
	movb	$0, 233(%rsp)
	movb	$0, 234(%rsp)
	movb	$0, 235(%rsp)
	movb	$0, 236(%rsp)
	movb	$0, 237(%rsp)
	movb	$0, 238(%rsp)
	movb	$0, 239(%rsp)
	movb	$0, 240(%rsp)
	movb	$0, 241(%rsp)
	movb	$0, 242(%rsp)
	movb	$0, 243(%rsp)
	movb	$0, 244(%rsp)
	movb	$0, 245(%rsp)
	movb	$0, 246(%rsp)
	movb	$0, 247(%rsp)
	movb	$0, 248(%rsp)
	movb	$0, 249(%rsp)
	movb	$0, 250(%rsp)
	movb	$0, 251(%rsp)
	movb	$0, 252(%rsp)
	movb	$0, 253(%rsp)
	movb	$0, 254(%rsp)
	movb	$0, 255(%rsp)
	movb	$0, 256(%rsp)
	movb	$0, 257(%rsp)
	movb	$0, 258(%rsp)
	movb	$0, 259(%rsp)
	movb	$0, 260(%rsp)
	movb	$0, 261(%rsp)
	movb	$0, 262(%rsp)
	movb	$0, 263(%rsp)
	#MEMBARRIER
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB53_56:
	movw	$0, (%rdi,%rax)
	movw	$0, 2(%rdi,%rax)
	movw	$0, 4(%rdi,%rax)
	movw	$0, 6(%rdi,%rax)
	movw	$0, 8(%rdi,%rax)
	movw	$0, 10(%rdi,%rax)
	movw	$0, 12(%rdi,%rax)
	movw	$0, 14(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_56
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB53_58:
	movw	$0, 512(%rdi,%rax)
	movw	$0, 514(%rdi,%rax)
	movw	$0, 516(%rdi,%rax)
	movw	$0, 518(%rdi,%rax)
	movw	$0, 520(%rdi,%rax)
	movw	$0, 522(%rdi,%rax)
	movw	$0, 524(%rdi,%rax)
	movw	$0, 526(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_58
	#MEMBARRIER
	xorl	%eax, %eax
	.p2align	4
.LBB53_60:
	movw	$0, 1024(%rdi,%rax)
	movw	$0, 1026(%rdi,%rax)
	movw	$0, 1028(%rdi,%rax)
	movw	$0, 1030(%rdi,%rax)
	movw	$0, 1032(%rdi,%rax)
	movw	$0, 1034(%rdi,%rax)
	movw	$0, 1036(%rdi,%rax)
	movw	$0, 1038(%rdi,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB53_60
	#MEMBARRIER
	movb	$0, (%rsi)
.LBB53_62:
	movb	$0, 2753(%rdi)
	movb	$0, 2754(%rdi)
	movb	$0, 2755(%rdi)
	movb	$0, 2756(%rdi)
	movb	$0, 2757(%rdi)
	movb	$0, 2758(%rdi)
	movb	$0, 2759(%rdi)
	movb	$0, 2760(%rdi)
	movb	$0, 2761(%rdi)
	movb	$0, 2762(%rdi)
	movb	$0, 2763(%rdi)
	movb	$0, 2764(%rdi)
	movb	$0, 2765(%rdi)
	movb	$0, 2766(%rdi)
	movb	$0, 2767(%rdi)
	movb	$0, 2768(%rdi)
	movb	$0, 2769(%rdi)
	movb	$0, 2770(%rdi)
	movb	$0, 2771(%rdi)
	movb	$0, 2772(%rdi)
	movb	$0, 2773(%rdi)
	movb	$0, 2774(%rdi)
	movb	$0, 2775(%rdi)
	movb	$0, 2776(%rdi)
	movb	$0, 2777(%rdi)
	movb	$0, 2778(%rdi)
	movb	$0, 2779(%rdi)
	movb	$0, 2780(%rdi)
	movb	$0, 2781(%rdi)
	movb	$0, 2782(%rdi)
	movb	$0, 2783(%rdi)
	#MEMBARRIER
	movq	%rcx, %rax
	addq	$3848, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846digest;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846digest,unique,54
	.globl	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846digest
	.p2align	4
_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846digest:
	pushq	%rsi
	pushq	%rdi
	subq	$488, %rsp
	movq	%rcx, %rsi
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movabsq	$-3766243637369397544, %rax
	movq	%rax, 160(%rsp)
	movabsq	$7105036623409894663, %rax
	movq	%rax, 168(%rsp)
	movabsq	$-7973340178411365097, %rax
	movq	%rax, 176(%rsp)
	movabsq	$1526699215303891257, %rax
	movq	%rax, 184(%rsp)
	movabsq	$7436329637833083697, %rax
	movq	%rax, 192(%rsp)
	movabsq	$-8163818279084223215, %rax
	movq	%rax, 200(%rsp)
	movabsq	$-2662702644619276377, %rax
	movq	%rax, 208(%rsp)
	movabsq	$5167115440072839076, %rax
	movq	%rax, 216(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	leaq	32(%rsp), %rcx
	callq	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846update
	cmpb	$-1, %al
	je	.LBB54_4
	movw	$1, (%rsi)
	xorl	%eax, %eax
	.p2align	4
.LBB54_2:
	movb	$0, 32(%rsp,%rax)
	movb	$0, 33(%rsp,%rax)
	movb	$0, 34(%rsp,%rax)
	movb	$0, 35(%rsp,%rax)
	movb	$0, 36(%rsp,%rax)
	movb	$0, 37(%rsp,%rax)
	movb	$0, 38(%rsp,%rax)
	movb	$0, 39(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB54_2
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	jmp	.LBB54_5
.LBB54_4:
	leaq	256(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movl	$224, %r8d
	movq	%rdi, %rcx
	callq	memcpy
	leaq	1(%rsi), %rcx
	movq	%rdi, %rdx
	callq	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3848finalize
	movb	$0, (%rsi)
.LBB54_5:
	movq	%rsi, %rax
	addq	$488, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846update;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846update,unique,55
	.globl	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846update
	.p2align	4
_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846update:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$40, %rsp
	movq	%r8, %rsi
	movq	%rdx, %rbx
	movq	%rcx, %rdi
	movq	200(%rcx), %rax
	movq	192(%rcx), %rcx
	addq	%r8, %rcx
	adcq	$0, %rax
	setb	%dl
	movq	%rax, %r8
	shrq	$61, %r8
	setne	%r8b
	orb	%dl, %r8b
	je	.LBB55_2
	xorl	%eax, %eax
	jmp	.LBB55_13
.LBB55_2:
	movq	%rcx, 192(%rdi)
	movq	%rax, 200(%rdi)
	movq	208(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB55_6
	movl	$128, %r14d
	subq	%rcx, %r14
	cmpq	%rsi, %r14
	cmovaeq	%rsi, %r14
	leaq	(%r14,%rcx), %rdx
	cmpq	%rcx, %rdx
	jb	.LBB55_5
	cmpq	$129, %rdx
	jae	.LBB55_5
	addq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%r14, %r8
	callq	memcpy
	movq	208(%rdi), %rax
	addq	%r14, %rax
	movq	%rax, 208(%rdi)
	subq	%r14, %rsi
	addq	%r14, %rbx
	cmpq	$128, %rax
	jne	.LBB55_6
	leaq	128(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512
	movq	$0, 208(%rdi)
.LBB55_6:
	cmpq	$128, %rsi
	jb	.LBB55_9
	leaq	128(%rdi), %r14
	.p2align	4
.LBB55_8:
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512
	addq	$-128, %rsi
	subq	$-128, %rbx
	cmpq	$127, %rsi
	ja	.LBB55_8
.LBB55_9:
	movb	$-1, %al
	testq	%rsi, %rsi
	je	.LBB55_13
	movq	208(%rdi), %rcx
	leaq	(%rcx,%rsi), %rdx
	cmpq	%rcx, %rdx
	jb	.LBB55_5
	cmpq	$129, %rdx
	jae	.LBB55_5
	addq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movb	$-1, %al
	addq	%rsi, 208(%rdi)
.LBB55_13:
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq
.LBB55_5:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.34(%rip), %r9
	movl	$128, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2

	.def	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3848finalize;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3848finalize,unique,56
	.globl	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3848finalize
	.p2align	4
_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3848finalize:
	pushq	%rsi
	pushq	%rdi
	subq	$40, %rsp
	movq	%rcx, %rsi
	movq	208(%rdx), %rcx
	cmpq	$127, %rcx
	ja	.LBB56_7
	movq	%rdx, %rdi
	movb	$-128, (%rdx,%rcx)
	movq	208(%rdx), %rax
	leaq	1(%rax), %rcx
	movq	%rcx, 208(%rdx)
	cmpq	$128, %rcx
	ja	.LBB56_8
	movl	$127, %r8d
	subq	%rax, %r8
	addq	%rdi, %rcx
	xorl	%edx, %edx
	callq	memset
	cmpq	$112, 208(%rdi)
	jbe	.LBB56_4
	leaq	128(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512
	movq	$0, 104(%rdi)
	movq	$0, 96(%rdi)
	movq	$0, 88(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 8(%rdi)
	movq	$0, (%rdi)
.LBB56_4:
	movq	192(%rdi), %rax
	movq	200(%rdi), %rcx
	shldq	$3, %rax, %rcx
	shlq	$3, %rax
	bswapq	%rcx
	bswapq	%rax
	movq	%rax, 120(%rdi)
	movq	%rcx, 112(%rdi)
	leaq	128(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512
	movq	128(%rdi), %rax
	movq	136(%rdi), %rcx
	bswapq	%rax
	bswapq	%rcx
	movq	144(%rdi), %rdx
	bswapq	%rdx
	movq	152(%rdi), %r8
	bswapq	%r8
	movq	160(%rdi), %r9
	bswapq	%r9
	movq	168(%rdi), %r10
	bswapq	%r10
	movq	%rax, (%rsi)
	movq	%rcx, 8(%rsi)
	movq	%rdx, 16(%rsi)
	movq	%r8, 24(%rsi)
	movq	%r9, 32(%rsi)
	movq	%r10, 40(%rsi)
	xorl	%eax, %eax
	.p2align	4
.LBB56_5:
	movb	$0, (%rdi,%rax)
	movb	$0, 1(%rdi,%rax)
	movb	$0, 2(%rdi,%rax)
	movb	$0, 3(%rdi,%rax)
	movb	$0, 4(%rdi,%rax)
	movb	$0, 5(%rdi,%rax)
	movb	$0, 6(%rdi,%rax)
	movb	$0, 7(%rdi,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB56_5
	#MEMBARRIER
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	movq	$0, 144(%rdi)
	movq	$0, 152(%rdi)
	movq	$0, 160(%rdi)
	movq	$0, 168(%rdi)
	movq	$0, 176(%rdi)
	movq	$0, 184(%rdi)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	retq
.LBB56_8:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.34(%rip), %r9
	movl	$128, %edx
	movl	$128, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB56_7:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.34(%rip), %r8
	movl	$128, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126digest;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126digest,unique,57
	.globl	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126digest
	.p2align	4
_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126digest:
	pushq	%rsi
	pushq	%rdi
	subq	$488, %rsp
	movq	%rcx, %rsi
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movabsq	$7640891576956012808, %rax
	movq	%rax, 160(%rsp)
	movabsq	$-4942790177534073029, %rax
	movq	%rax, 168(%rsp)
	movabsq	$4354685564936845355, %rax
	movq	%rax, 176(%rsp)
	movabsq	$-6534734903238641935, %rax
	movq	%rax, 184(%rsp)
	movabsq	$5840696475078001361, %rax
	movq	%rax, 192(%rsp)
	movabsq	$-7276294671716946913, %rax
	movq	%rax, 200(%rsp)
	movabsq	$2270897969802886507, %rax
	movq	%rax, 208(%rsp)
	movabsq	$6620516959819538809, %rax
	movq	%rax, 216(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	leaq	32(%rsp), %rcx
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update
	cmpb	$-1, %al
	je	.LBB57_4
	movw	$1, (%rsi)
	xorl	%eax, %eax
	.p2align	4
.LBB57_2:
	movb	$0, 32(%rsp,%rax)
	movb	$0, 33(%rsp,%rax)
	movb	$0, 34(%rsp,%rax)
	movb	$0, 35(%rsp,%rax)
	movb	$0, 36(%rsp,%rax)
	movb	$0, 37(%rsp,%rax)
	movb	$0, 38(%rsp,%rax)
	movb	$0, 39(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB57_2
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	jmp	.LBB57_5
.LBB57_4:
	leaq	256(%rsp), %rdi
	leaq	32(%rsp), %rdx
	movl	$224, %r8d
	movq	%rdi, %rcx
	callq	memcpy
	leaq	1(%rsi), %rcx
	movq	%rdi, %rdx
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5128finalize
	movb	$0, (%rsi)
.LBB57_5:
	movq	%rsi, %rax
	addq	$488, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update,unique,58
	.globl	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update
	.p2align	4
_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$40, %rsp
	movq	%r8, %rsi
	movq	%rdx, %rbx
	movq	%rcx, %rdi
	movq	200(%rcx), %rax
	movq	192(%rcx), %rcx
	addq	%r8, %rcx
	adcq	$0, %rax
	setb	%dl
	movq	%rax, %r8
	shrq	$61, %r8
	setne	%r8b
	orb	%dl, %r8b
	je	.LBB58_2
	xorl	%eax, %eax
	jmp	.LBB58_13
.LBB58_2:
	movq	%rcx, 192(%rdi)
	movq	%rax, 200(%rdi)
	movq	208(%rdi), %rcx
	testq	%rcx, %rcx
	je	.LBB58_6
	movl	$128, %r14d
	subq	%rcx, %r14
	cmpq	%rsi, %r14
	cmovaeq	%rsi, %r14
	leaq	(%r14,%rcx), %rdx
	cmpq	%rcx, %rdx
	jb	.LBB58_5
	cmpq	$129, %rdx
	jae	.LBB58_5
	addq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%r14, %r8
	callq	memcpy
	movq	208(%rdi), %rax
	addq	%r14, %rax
	movq	%rax, 208(%rdi)
	subq	%r14, %rsi
	addq	%r14, %rbx
	cmpq	$128, %rax
	jne	.LBB58_6
	leaq	128(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512
	movq	$0, 208(%rdi)
.LBB58_6:
	cmpq	$128, %rsi
	jb	.LBB58_9
	leaq	128(%rdi), %r14
	.p2align	4
.LBB58_8:
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512
	addq	$-128, %rsi
	subq	$-128, %rbx
	cmpq	$127, %rsi
	ja	.LBB58_8
.LBB58_9:
	movb	$-1, %al
	testq	%rsi, %rsi
	je	.LBB58_13
	movq	208(%rdi), %rcx
	leaq	(%rcx,%rsi), %rdx
	cmpq	%rcx, %rdx
	jb	.LBB58_5
	cmpq	$129, %rdx
	jae	.LBB58_5
	addq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movb	$-1, %al
	addq	%rsi, 208(%rdi)
.LBB58_13:
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq
.LBB58_5:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.35(%rip), %r9
	movl	$128, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2

	.def	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5128finalize;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5128finalize,unique,59
	.globl	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5128finalize
	.p2align	4
_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5128finalize:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$32, %rsp
	movq	%rcx, %rsi
	movq	208(%rdx), %rcx
	cmpq	$127, %rcx
	ja	.LBB59_7
	movq	%rdx, %rdi
	movb	$-128, (%rdx,%rcx)
	movq	208(%rdx), %rax
	leaq	1(%rax), %rcx
	movq	%rcx, 208(%rdx)
	cmpq	$128, %rcx
	ja	.LBB59_8
	movl	$127, %r8d
	subq	%rax, %r8
	addq	%rdi, %rcx
	xorl	%edx, %edx
	callq	memset
	cmpq	$112, 208(%rdi)
	jbe	.LBB59_4
	leaq	128(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512
	movq	$0, 104(%rdi)
	movq	$0, 96(%rdi)
	movq	$0, 88(%rdi)
	movq	$0, 80(%rdi)
	movq	$0, 72(%rdi)
	movq	$0, 64(%rdi)
	movq	$0, 56(%rdi)
	movq	$0, 48(%rdi)
	movq	$0, 40(%rdi)
	movq	$0, 32(%rdi)
	movq	$0, 24(%rdi)
	movq	$0, 16(%rdi)
	movq	$0, 8(%rdi)
	movq	$0, (%rdi)
.LBB59_4:
	movq	192(%rdi), %rax
	movq	200(%rdi), %rcx
	shldq	$3, %rax, %rcx
	shlq	$3, %rax
	bswapq	%rcx
	bswapq	%rax
	movq	%rax, 120(%rdi)
	movq	%rcx, 112(%rdi)
	leaq	128(%rdi), %rcx
	movq	%rdi, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512
	movq	128(%rdi), %rax
	movq	136(%rdi), %rcx
	bswapq	%rax
	bswapq	%rcx
	movq	144(%rdi), %rdx
	bswapq	%rdx
	movq	152(%rdi), %r8
	bswapq	%r8
	movq	160(%rdi), %r9
	bswapq	%r9
	movq	168(%rdi), %r10
	bswapq	%r10
	movq	176(%rdi), %r11
	bswapq	%r11
	movq	184(%rdi), %rbx
	bswapq	%rbx
	movq	%rax, (%rsi)
	movq	%rcx, 8(%rsi)
	movq	%rdx, 16(%rsi)
	movq	%r8, 24(%rsi)
	movq	%r9, 32(%rsi)
	movq	%r10, 40(%rsi)
	movq	%r11, 48(%rsi)
	movq	%rbx, 56(%rsi)
	xorl	%eax, %eax
	.p2align	4
.LBB59_5:
	movb	$0, (%rdi,%rax)
	movb	$0, 1(%rdi,%rax)
	movb	$0, 2(%rdi,%rax)
	movb	$0, 3(%rdi,%rax)
	movb	$0, 4(%rdi,%rax)
	movb	$0, 5(%rdi,%rax)
	movb	$0, 6(%rdi,%rax)
	movb	$0, 7(%rdi,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB59_5
	#MEMBARRIER
	movq	$0, 128(%rdi)
	movq	$0, 136(%rdi)
	movq	$0, 144(%rdi)
	movq	$0, 152(%rdi)
	movq	$0, 160(%rdi)
	movq	$0, 168(%rdi)
	movq	$0, 176(%rdi)
	movq	$0, 184(%rdi)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq
.LBB59_8:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.35(%rip), %r9
	movl	$128, %edx
	movl	$128, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB59_7:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.35(%rip), %r8
	movl	$128, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq,unique,60
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F2eq:
	pushq	%rsi
	subq	$112, %rsp
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	leaq	40(%rsp), %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F5bytes
	leaq	72(%rsp), %rcx
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F5bytes
	movzbl	72(%rsp), %edx
	movzbl	73(%rsp), %eax
	movzbl	74(%rsp), %ecx
	xorb	40(%rsp), %dl
	xorb	41(%rsp), %al
	orb	%dl, %al
	movzbl	75(%rsp), %edx
	xorb	42(%rsp), %cl
	xorb	43(%rsp), %dl
	orb	%cl, %dl
	movzbl	76(%rsp), %ecx
	orb	%al, %dl
	movzbl	77(%rsp), %eax
	xorb	44(%rsp), %cl
	xorb	45(%rsp), %al
	orb	%cl, %al
	movzbl	78(%rsp), %ecx
	xorb	46(%rsp), %cl
	orb	%al, %cl
	movzbl	79(%rsp), %eax
	orb	%dl, %cl
	movzbl	80(%rsp), %edx
	xorb	47(%rsp), %al
	xorb	48(%rsp), %dl
	orb	%al, %dl
	movzbl	81(%rsp), %r8d
	xorb	49(%rsp), %r8b
	orb	%dl, %r8b
	movzbl	82(%rsp), %eax
	xorb	50(%rsp), %al
	orb	%r8b, %al
	movzbl	83(%rsp), %edx
	orb	%cl, %al
	movzbl	84(%rsp), %ecx
	xorb	51(%rsp), %dl
	xorb	52(%rsp), %cl
	orb	%dl, %cl
	movzbl	85(%rsp), %edx
	xorb	53(%rsp), %dl
	orb	%cl, %dl
	movzbl	86(%rsp), %r8d
	xorb	54(%rsp), %r8b
	orb	%dl, %r8b
	movzbl	87(%rsp), %ecx
	xorb	55(%rsp), %cl
	orb	%r8b, %cl
	movzbl	88(%rsp), %edx
	orb	%al, %cl
	movzbl	89(%rsp), %eax
	xorb	56(%rsp), %dl
	xorb	57(%rsp), %al
	orb	%dl, %al
	movzbl	90(%rsp), %edx
	xorb	58(%rsp), %dl
	orb	%al, %dl
	movzbl	91(%rsp), %eax
	xorb	59(%rsp), %al
	orb	%dl, %al
	movzbl	92(%rsp), %edx
	xorb	60(%rsp), %dl
	orb	%al, %dl
	movzbl	93(%rsp), %eax
	xorb	61(%rsp), %al
	orb	%dl, %al
	movzbl	94(%rsp), %edx
	orb	%cl, %al
	movzbl	95(%rsp), %ecx
	xorb	62(%rsp), %dl
	xorb	63(%rsp), %cl
	orb	%dl, %cl
	movzbl	96(%rsp), %edx
	xorb	64(%rsp), %dl
	orb	%cl, %dl
	movzbl	97(%rsp), %ecx
	xorb	65(%rsp), %cl
	orb	%dl, %cl
	movzbl	98(%rsp), %edx
	xorb	66(%rsp), %dl
	orb	%cl, %dl
	movzbl	99(%rsp), %ecx
	xorb	67(%rsp), %cl
	orb	%dl, %cl
	movzbl	100(%rsp), %edx
	xorb	68(%rsp), %dl
	orb	%cl, %dl
	movzbl	101(%rsp), %ecx
	orb	%al, %dl
	movzbl	102(%rsp), %eax
	xorb	69(%rsp), %cl
	xorb	70(%rsp), %al
	orb	%cl, %al
	orb	%dl, %al
	movzbl	103(%rsp), %ecx
	xorb	71(%rsp), %cl
	xorl	%edx, %edx
	orb	%al, %cl
	setne	%dl
	movq	%rdx, 104(%rsp)
	xorl	%eax, %eax
	cmpq	$0, 104(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	#MEMBARRIER
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	movb	$0, 96(%rsp)
	movb	$0, 97(%rsp)
	movb	$0, 98(%rsp)
	movb	$0, 99(%rsp)
	movb	$0, 100(%rsp)
	movb	$0, 101(%rsp)
	movb	$0, 102(%rsp)
	movb	$0, 103(%rsp)
	sete	%al
	#MEMBARRIER
	addq	$112, %rsp
	popq	%rsi
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3add;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3add,unique,61
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3add:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$88, %rsp
	movq	(%r8), %rsi
	movq	8(%r8), %rbx
	xorl	%r9d, %r9d
	addq	(%rdx), %rsi
	setb	%r9b
	xorl	%r10d, %r10d
	addq	8(%rdx), %rbx
	setb	%r10b
	movq	16(%r8), %r14
	xorl	%r11d, %r11d
	addq	16(%rdx), %r14
	setb	%r11b
	movq	24(%r8), %r15
	xorl	%edi, %edi
	addq	24(%rdx), %r15
	setb	%dil
	movq	32(%r8), %r12
	xorl	%r8d, %r8d
	addq	32(%rdx), %r12
	setb	%r8b
	movabsq	$2251799813685247, %rax
	shldq	$13, %rsi, %r9
	andq	%rax, %rsi
	addq	%rbx, %r9
	adcq	$0, %r10
	shldq	$13, %r9, %r10
	andq	%rax, %r9
	addq	%r14, %r10
	adcq	$0, %r11
	shldq	$13, %r10, %r11
	andq	%rax, %r10
	addq	%r15, %r11
	adcq	$0, %rdi
	shldq	$13, %r11, %rdi
	andq	%rax, %r11
	addq	%r12, %rdi
	adcl	$0, %r8d
	movq	%rdi, %rdx
	shrq	$51, %rdx
	shll	$13, %r8d
	orq	%rdx, %r8
	andq	%rax, %rdi
	leaq	(%r8,%r8,8), %rdx
	leaq	(%r8,%rdx,2), %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	andq	%rax, %rsi
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %r9
	andq	%rax, %r9
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%rax, %r10
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %r11
	andq	%rax, %r11
	shrq	$51, %rdx
	addq	%rdi, %rdx
	movq	%rdx, %r8
	shrq	$51, %r8
	andq	%rax, %rdx
	leaq	(%r8,%r8,8), %rdi
	leaq	(%r8,%rdi,2), %r8
	addq	%rsi, %r8
	movq	%r8, %rsi
	andq	%rax, %rsi
	shrq	$51, %r8
	addq	%r9, %r8
	movq	%r8, %r9
	shrq	$51, %r9
	addq	%r10, %r9
	movq	%r9, %r10
	shrq	$51, %r10
	addq	%r11, %r10
	movq	%r10, %r11
	shrq	$51, %r11
	addq	%rdx, %r11
	movq	%r11, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %rdi
	leaq	(%rdx,%rdi,2), %rdx
	addq	%rsi, %rdx
	andq	%rax, %r8
	andq	%rax, %r9
	andq	%rax, %r10
	andq	%rax, %r11
	movq	%rdx, (%rcx)
	movq	%r8, 8(%rcx)
	movq	%r9, 16(%rcx)
	movq	%r10, 24(%rcx)
	movq	%r11, 32(%rcx)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	#MEMBARRIER
	addq	$88, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul,unique,62
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$200, %rsp
	movq	%rdx, %r12
	movq	(%r8), %r11
	movq	(%rdx), %r9
	movq	%rdx, 8(%rsp)
	movq	%r9, %rax
	mulq	%r11
	movq	%rax, 16(%rsp)
	movq	%rdx, 24(%rsp)
	movq	8(%r8), %r10
	movq	%r9, %rax
	mulq	%r10
	movq	%rax, %rbx
	movq	%rdx, %rsi
	movq	16(%r8), %r13
	movq	%r9, %rax
	mulq	%r13
	movq	%rax, %r14
	movq	%rdx, %rdi
	movq	24(%r8), %r15
	movq	%r9, %rax
	mulq	%r15
	movq	%r15, 48(%rsp)
	movq	%rax, %rbp
	movq	%rdx, 96(%rsp)
	movq	32(%r8), %r8
	movq	%r9, %rax
	mulq	%r8
	movq	%r8, %r9
	movq	%r8, 56(%rsp)
	movq	%rax, 88(%rsp)
	movq	%rdx, 104(%rsp)
	movq	8(%r12), %r12
	movq	%r12, %rax
	mulq	%r11
	movq	%r11, 72(%rsp)
	addq	%rbx, %rax
	movq	%rax, 40(%rsp)
	adcq	%rsi, %rdx
	movq	%rdx, 32(%rsp)
	movq	%r12, %rax
	movq	%r10, 80(%rsp)
	mulq	%r10
	movq	%rdx, %r8
	movq	%rax, %rbx
	addq	%r14, %rbx
	adcq	%rdi, %r8
	movq	%r12, %rax
	mulq	%r13
	movq	%r13, %rsi
	movq	%r13, 64(%rsp)
	movq	%rdx, %rdi
	movq	%rax, %r14
	addq	%rbp, %r14
	adcq	96(%rsp), %rdi
	movq	%r12, %rax
	mulq	%r15
	movq	%rdx, %r15
	movq	%rax, %rbp
	addq	88(%rsp), %rbp
	adcq	104(%rsp), %r15
	movq	%r12, %rax
	mulq	%r9
	movq	%rdx, %r9
	movl	$19, %edx
	mulq	%rdx
	movq	%rax, %r13
	movq	%rdx, %r12
	leaq	(%r9,%r9,8), %rax
	leaq	(%r9,%rax,2), %rax
	addq	%rax, %r12
	addq	16(%rsp), %r13
	adcq	24(%rsp), %r12
	movq	8(%rsp), %rax
	movq	16(%rax), %r9
	movq	%r9, %rax
	mulq	%r11
	addq	%rbx, %rax
	movq	%rax, 24(%rsp)
	adcq	%r8, %rdx
	movq	%rdx, 16(%rsp)
	movq	%r9, %rax
	mulq	%r10
	movq	%rdx, %rbx
	movq	%rax, %r11
	addq	%r14, %r11
	adcq	%rdi, %rbx
	movq	%r9, %rax
	mulq	%rsi
	movq	%rdx, %r14
	movq	%rax, %rsi
	addq	%rbp, %rsi
	adcq	%r15, %r14
	movq	%r9, %rax
	movl	$19, %edx
	mulq	%rdx
	movq	%rax, %r8
	movq	%rdx, %r9
	movq	%rdx, %r15
	movq	48(%rsp), %rdx
	imulq	%rdx, %r15
	mulq	%rdx
	movq	%rax, %rbp
	movq	%rdx, %rdi
	addq	%r15, %rdi
	addq	%r13, %rbp
	adcq	%r12, %rdi
	movq	%r8, %rax
	movq	56(%rsp), %r10
	mulq	%r10
	movq	%rax, %r8
	movq	%rdx, %r15
	imulq	%r10, %r9
	addq	%r9, %r15
	addq	40(%rsp), %r8
	adcq	32(%rsp), %r15
	movq	8(%rsp), %rax
	movq	24(%rax), %r9
	movq	%r9, %rax
	mulq	72(%rsp)
	addq	%r11, %rax
	movq	%rax, 40(%rsp)
	adcq	%rbx, %rdx
	movq	%rdx, 32(%rsp)
	movq	%r9, %rax
	mulq	80(%rsp)
	movq	%rdx, %r12
	movq	%rax, %r10
	addq	%rsi, %r10
	adcq	%r14, %r12
	movq	%r9, %rax
	movl	$19, %edx
	mulq	%rdx
	movq	%rax, %r9
	movq	%rdx, %r11
	movq	%rdx, %rsi
	movq	64(%rsp), %rdx
	imulq	%rdx, %rsi
	mulq	%rdx
	movq	%rax, %r13
	movq	%rdx, %rbx
	addq	%rsi, %rbx
	addq	%rbp, %r13
	adcq	%rdi, %rbx
	movq	%r11, %rsi
	movq	48(%rsp), %rdx
	imulq	%rdx, %rsi
	movq	%r9, %rax
	mulq	%rdx
	movq	%rax, %rbp
	movq	%rdx, %r14
	addq	%rsi, %r14
	addq	%r8, %rbp
	adcq	%r15, %r14
	movq	%r9, %rax
	movq	56(%rsp), %r8
	mulq	%r8
	movq	%rax, %r9
	movq	%rdx, %r15
	imulq	%r8, %r11
	addq	%r11, %r15
	addq	24(%rsp), %r9
	adcq	16(%rsp), %r15
	movq	8(%rsp), %rax
	movq	32(%rax), %r8
	movq	%r8, %rax
	mulq	72(%rsp)
	movq	%rax, %rdi
	addq	%r10, %rdi
	adcq	%r12, %rdx
	movq	%rdx, 8(%rsp)
	movq	%r8, %rax
	movl	$19, %edx
	mulq	%rdx
	movq	%rax, %r12
	movq	%rdx, %r11
	movq	%rdx, %r10
	movq	80(%rsp), %rdx
	imulq	%rdx, %r10
	mulq	%rdx
	movq	%rax, %rsi
	movq	%rdx, %r8
	addq	%r10, %r8
	addq	%r13, %rsi
	adcq	%rbx, %r8
	movq	%r11, %r10
	movq	64(%rsp), %rdx
	imulq	%rdx, %r10
	movq	%r12, %rax
	mulq	%rdx
	movq	%rax, %r13
	movq	%rdx, %rbx
	addq	%r10, %rbx
	addq	%rbp, %r13
	adcq	%r14, %rbx
	movq	%r11, %r10
	movq	48(%rsp), %rdx
	imulq	%rdx, %r10
	movq	%r12, %rax
	mulq	%rdx
	movq	%rax, %rbp
	movq	%rdx, %r14
	addq	%r10, %r14
	addq	%r9, %rbp
	adcq	%r15, %r14
	movq	%r12, %rax
	movq	56(%rsp), %r9
	mulq	%r9
	imulq	%r9, %r11
	addq	%r11, %rdx
	addq	40(%rsp), %rax
	adcq	32(%rsp), %rdx
	movabsq	$2251799813685247, %r9
	movq	%r8, %r10
	shrq	$51, %r10
	shldq	$13, %rsi, %r8
	andq	%r9, %rsi
	addq	%r13, %r8
	adcq	%rbx, %r10
	movq	%r10, %rbx
	shrq	$51, %rbx
	shldq	$13, %r8, %r10
	andq	%r9, %r8
	addq	%rbp, %r10
	adcq	%r14, %rbx
	movq	%rbx, %r14
	shrq	$51, %r14
	shldq	$13, %r10, %rbx
	andq	%r9, %r10
	addq	%rax, %rbx
	adcq	%rdx, %r14
	movq	%r14, %rdx
	shrq	$51, %rdx
	shldq	$13, %rbx, %r14
	andq	%r9, %rbx
	addq	%rdi, %r14
	adcq	8(%rsp), %rdx
	movq	%rdx, %rax
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r11
	leaq	(%rdx,%r11,2), %r11
	shldq	$13, %r14, %rax
	andq	%r9, %r14
	movl	$19, %edx
	mulq	%rdx
	addq	%rsi, %rax
	adcq	%r11, %rdx
	shldq	$13, %rax, %rdx
	andq	%r9, %rax
	addq	%r8, %rdx
	movq	%rdx, %r11
	andq	%r9, %r11
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%r9, %r10
	shrq	$51, %rdx
	addq	%rbx, %rdx
	movq	%rdx, %rsi
	andq	%r9, %rsi
	shrq	$51, %rdx
	addq	%r14, %rdx
	movq	%rdx, %r8
	shrq	$51, %r8
	andq	%r9, %rdx
	leaq	(%r8,%r8,8), %rdi
	leaq	(%r8,%rdi,2), %r8
	addq	%rax, %r8
	movq	%r8, %rax
	shrq	$51, %r8
	addq	%r11, %r8
	movq	%r8, %r11
	shrq	$51, %r11
	addq	%r10, %r11
	movq	%r11, %r10
	shrq	$51, %r10
	addq	%rsi, %r10
	movq	%r10, %rsi
	shrq	$51, %rsi
	addq	%rdx, %rsi
	movq	%rsi, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %rdi
	leaq	(%rdx,%rdi,2), %rdx
	andq	%r9, %rax
	addq	%rax, %rdx
	andq	%r9, %r8
	andq	%r9, %r11
	andq	%r9, %r10
	andq	%r9, %rsi
	movq	%rdx, (%rcx)
	movq	%r8, 8(%rcx)
	movq	%r11, 16(%rcx)
	movq	%r10, 24(%rcx)
	movq	%rsi, 32(%rcx)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	addq	$200, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3pow;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3pow,unique,63
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3pow:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$168, %rsp
	movq	%r9, %rdi
	movq	%r8, %rbx
	movq	%rdx, %r14
	movq	%rcx, %rsi
	movq	$1, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	decq	%rdi
	leaq	88(%rsp), %r15
	leaq	48(%rsp), %r12
	leaq	128(%rsp), %r13
	.p2align	4
.LBB63_1:
	movq	%r15, %rcx
	movq	%r12, %rdx
	movq	%r12, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	%r13, %rcx
	movq	%r15, %rdx
	movq	%r14, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	%rdi, %rax
	shrq	$3, %rax
	movzbl	(%rbx,%rax), %eax
	movl	%edi, %edx
	andl	$7, %edx
	xorl	%ecx, %ecx
	btl	%edx, %eax
	setb	%cl
	movq	88(%rsp), %rdx
	movq	96(%rsp), %r8
	movq	128(%rsp), %r9
	movq	136(%rsp), %r10
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, %r11
	negq	%r11
	andq	%r9, %r11
	decq	%rax
	andq	%rdx, %rax
	orq	%r11, %rax
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rdx
	movq	%rdx, %r9
	negq	%r9
	andq	%r10, %r9
	decq	%rdx
	andq	%r8, %rdx
	orq	%r9, %rdx
	movq	104(%rsp), %r9
	movq	144(%rsp), %r10
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %r8
	movq	%r8, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%r8
	andq	%r9, %r8
	orq	%r11, %r8
	movq	112(%rsp), %r10
	movq	152(%rsp), %r11
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %r9
	movq	%r9, %rbp
	negq	%rbp
	andq	%r11, %rbp
	decq	%r9
	andq	%r10, %r9
	orq	%rbp, %r9
	movq	120(%rsp), %r10
	movq	160(%rsp), %r11
	movq	%rcx, 40(%rsp)
	movq	40(%rsp), %rcx
	movq	%rcx, %rbp
	negq	%rbp
	andq	%r11, %rbp
	decq	%rcx
	andq	%r10, %rcx
	orq	%rbp, %rcx
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%r8, 64(%rsp)
	movq	%r9, 72(%rsp)
	movq	%rcx, 80(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	addq	$-1, %rdi
	jb	.LBB63_1
	movq	80(%rsp), %rax
	movq	%rax, 32(%rsi)
	movq	72(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	64(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	48(%rsp), %rax
	movq	56(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	addq	$168, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3sub;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3sub,unique,64
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3sub:
	pushq	%r15
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$80, %rsp
	xorl	%eax, %eax
	movq	(%rdx), %r10
	movq	8(%rdx), %rsi
	subq	(%r8), %r10
	movl	$0, %r9d
	sbbq	%r9, %r9
	movabsq	$4503599627370458, %r11
	addq	%r10, %r11
	adcq	$0, %r9
	subq	8(%r8), %rsi
	movl	$0, %edi
	sbbq	%rdi, %rdi
	movq	%r9, %r10
	shldq	$13, %r11, %r9
	shrq	$51, %r10
	addq	%rsi, %r9
	adcq	%rdi, %r10
	movq	16(%rdx), %rdi
	subq	16(%r8), %rdi
	movl	$0, %r14d
	sbbq	%r14, %r14
	movabsq	$4503599627370494, %rbx
	addq	%rbx, %r9
	adcq	$0, %r10
	movq	%r10, %rsi
	shldq	$13, %r9, %r10
	shrq	$51, %rsi
	addq	%rdi, %r10
	adcq	%r14, %rsi
	movq	24(%rdx), %r14
	subq	24(%r8), %r14
	movl	$0, %r15d
	sbbq	%r15, %r15
	addq	%rbx, %r10
	adcq	$0, %rsi
	movq	%rsi, %rdi
	shrq	$51, %rdi
	shldq	$13, %r10, %rsi
	addq	%r14, %rsi
	adcq	%r15, %rdi
	movq	32(%rdx), %rdx
	subq	32(%r8), %rdx
	sbbq	%rax, %rax
	addq	%rbx, %rsi
	adcq	$0, %rdi
	movq	%rdi, %r14
	shldq	$13, %rsi, %rdi
	shrq	$51, %r14
	addq	%rdx, %rdi
	adcq	%rax, %r14
	movabsq	$2251799813685247, %r8
	andq	%r8, %r11
	andq	%r8, %r9
	andq	%r8, %r10
	andq	%r8, %rsi
	addq	%rbx, %rdi
	adcq	$0, %r14
	movq	%r14, %rax
	shldq	$13, %rdi, %rax
	shrq	$51, %r14
	andq	%r8, %rdi
	leaq	(%r14,%r14,8), %rdx
	leaq	(%r14,%rdx,2), %rbx
	movl	$19, %edx
	mulq	%rdx
	addq	%r11, %rax
	adcq	%rbx, %rdx
	shldq	$13, %rax, %rdx
	andq	%r8, %rax
	addq	%r9, %rdx
	movq	%rdx, %r11
	andq	%r8, %r11
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%r8, %r10
	shrq	$51, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	andq	%r8, %rsi
	shrq	$51, %rdx
	addq	%rdi, %rdx
	movq	%rdx, %r9
	shrq	$51, %r9
	andq	%r8, %rdx
	leaq	(%r9,%r9,8), %rdi
	leaq	(%r9,%rdi,2), %r9
	addq	%rax, %r9
	movq	%r9, %rax
	andq	%r8, %rax
	shrq	$51, %r9
	addq	%r11, %r9
	movq	%r9, %r11
	shrq	$51, %r11
	addq	%r10, %r11
	movq	%r11, %r10
	shrq	$51, %r10
	addq	%rsi, %r10
	movq	%r10, %rsi
	shrq	$51, %rsi
	addq	%rdx, %rsi
	movq	%rsi, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %rdi
	leaq	(%rdx,%rdi,2), %rdx
	addq	%rax, %rdx
	andq	%r8, %r9
	andq	%r8, %r11
	andq	%r8, %r10
	andq	%r8, %rsi
	movq	%rdx, (%rcx)
	movq	%r9, 8(%rcx)
	movq	%r11, 16(%rcx)
	movq	%r10, 24(%rcx)
	movq	%rsi, 32(%rcx)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	#MEMBARRIER
	addq	$80, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F5bytes;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F5bytes,unique,65
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F5bytes:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$152, %rsp
	movq	(%rdx), %r9
	movabsq	$2251799813685247, %rax
	movq	%r9, %rsi
	andq	%rax, %rsi
	shrq	$51, %r9
	xorl	%r10d, %r10d
	addq	8(%rdx), %r9
	setb	%r10b
	shldq	$13, %r9, %r10
	andq	%rax, %r9
	xorl	%r11d, %r11d
	addq	16(%rdx), %r10
	movq	%rcx, %r8
	setb	%r11b
	shldq	$13, %r10, %r11
	andq	%rax, %r10
	xorl	%ecx, %ecx
	addq	24(%rdx), %r11
	setb	%cl
	shldq	$13, %r11, %rcx
	andq	%rax, %r11
	xorl	%edi, %edi
	addq	32(%rdx), %rcx
	setb	%dil
	movq	%rcx, %rdx
	shrq	$51, %rdx
	shll	$13, %edi
	orq	%rdx, %rdi
	andq	%rax, %rcx
	leaq	(%rdi,%rdi,8), %rdx
	leaq	(%rdi,%rdx,2), %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rsi
	andq	%rax, %rsi
	shrq	$51, %rdx
	addq	%r9, %rdx
	movq	%rdx, %r9
	andq	%rax, %r9
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%rax, %r10
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %r11
	andq	%rax, %r11
	shrq	$51, %rdx
	addq	%rcx, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%rax, %rdx
	leaq	(%rcx,%rcx,8), %rdi
	leaq	(%rcx,%rdi,2), %rcx
	addq	%rsi, %rcx
	movq	%rcx, %rsi
	andq	%rax, %rsi
	shrq	$51, %rcx
	addq	%r9, %rcx
	movq	%rcx, %r9
	shrq	$51, %r9
	addq	%r10, %r9
	movq	%r9, %r10
	shrq	$51, %r10
	addq	%r11, %r10
	movq	%r10, %r11
	shrq	$51, %r11
	addq	%rdx, %r11
	movq	%r11, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %rdi
	leaq	(%rdx,%rdi,2), %rdx
	addq	%rsi, %rdx
	andq	%rax, %rcx
	andq	%rax, %r9
	andq	%rax, %r10
	andq	%rax, %r11
	movq	%rdx, 72(%rsp)
	movq	%rcx, 64(%rsp)
	movq	%r9, 56(%rsp)
	movq	%r10, 48(%rsp)
	movq	%r11, 40(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	48(%rsp), %rdx
	movq	56(%rsp), %r9
	movq	72(%rsp), %r11
	xorl	%ecx, %ecx
	movq	%r11, %rsi
	addq	$19, %rsi
	setb	%cl
	shldq	$13, %rsi, %rcx
	movq	64(%rsp), %r10
	movl	$1, %edi
	subq	%rcx, %rdi
	xorl	%ecx, %ecx
	movq	%r10, %rbx
	subq	%rdi, %rbx
	movabsq	$-2251799813685247, %r14
	leaq	(%rbx,%r14), %rdi
	movl	$0, %r15d
	sbbq	%r15, %r15
	addq	$1, %rbx
	adcq	$0, %r15
	shldq	$13, %rbx, %r15
	movl	$1, %r12d
	movl	$1, %ebx
	subq	%r15, %rbx
	movq	%r9, %r15
	subq	%rbx, %r15
	movl	$0, %r13d
	sbbq	%r13, %r13
	leaq	(%r15,%r14), %rbx
	addq	$1, %r15
	adcq	$0, %r13
	shldq	$13, %r15, %r13
	subq	%r13, %r12
	movq	%rdx, %r15
	subq	%r12, %r15
	movl	$0, %r13d
	sbbq	%r13, %r13
	addq	%r15, %r14
	addq	$1, %r15
	adcq	$0, %r13
	shldq	$13, %r15, %r13
	andq	%rax, %r14
	andq	%rax, %rbx
	andq	%rax, %rdi
	andq	%rax, %rsi
	movq	40(%rsp), %r15
	movabsq	$-2251799813685248, %r12
	addq	%r15, %r12
	addq	%r13, %r12
	andq	%r12, %rax
	shrq	$51, %r12
	movq	%rsi, 128(%rsp)
	movq	%rdi, 112(%rsp)
	movq	%rbx, 96(%rsp)
	movq	%r14, 80(%rsp)
	movq	%rax, 144(%rsp)
	andl	$1, %r12d
	movq	%r12, (%rsp)
	movq	(%rsp), %rbp
	movq	%rbp, %r13
	negq	%r13
	decq	%rbp
	andq	%rsi, %rbp
	andq	%r11, %r13
	orq	%rbp, %r13
	movq	%r12, (%rsp)
	movq	(%rsp), %rsi
	movq	%rsi, %r11
	negq	%r11
	decq	%rsi
	andq	%rdi, %rsi
	andq	%r10, %r11
	orq	%rsi, %r11
	movq	%r12, (%rsp)
	movq	(%rsp), %rsi
	movq	%rsi, %r10
	negq	%r10
	decq	%rsi
	andq	%rbx, %rsi
	andq	%r9, %r10
	orq	%rsi, %r10
	movq	%r12, (%rsp)
	movq	(%rsp), %r9
	movq	%r9, %rsi
	negq	%rsi
	decq	%r9
	andq	%r14, %r9
	andq	%rdx, %rsi
	orq	%r9, %rsi
	movq	%r12, (%rsp)
	movq	(%rsp), %rdx
	movq	%rdx, %r9
	negq	%r9
	decq	%rdx
	andq	%rax, %rdx
	andq	%r15, %r9
	orq	%rdx, %r9
	movq	%r13, (%rsp)
	movq	%r11, 8(%rsp)
	movq	%r10, 16(%rsp)
	movq	%rsi, 24(%rsp)
	movq	%r9, 32(%rsp)
	movq	$0, 24(%r8)
	movq	$0, 16(%r8)
	movq	$0, 8(%r8)
	movq	$0, (%r8)
	movabsq	$-6872316419617283935, %r9
	.p2align	4
.LBB65_1:
	leaq	1(%rcx), %r10
	movq	%rcx, %rax
	mulq	%r9
	shrl	$5, %edx
	imull	$-51, %edx, %eax
	movq	%rcx, %rdx
	shrq	$3, %rdx
	movzbl	%cl, %r11d
	imull	$161, %r11d, %r11d
	shrl	$13, %r11d
	movq	(%rsp,%r11,8), %r11
	addl	%ecx, %eax
	btq	%rax, %r11
	setb	%al
	andb	$7, %cl
	shlb	%cl, %al
	orb	%al, (%r8,%rdx)
	movq	%r10, %rcx
	cmpq	$255, %r10
	jne	.LBB65_1
	movq	$0, (%rsp)
	movq	$0, 8(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	addq	$152, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto11scalar25519NtB4_1S6reduce;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto11scalar25519NtB4_1S6reduce,unique,66
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto11scalar25519NtB4_1S6reduce:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$104, %rsp
	movq	%rcx, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movl	$511, %eax
	movabsq	$-1503914060200516823, %r9
	movabsq	$-1152921504606846977, %r10
	.p2align	4
.LBB66_1:
	movq	%rax, %r8
	shrq	$3, %r8
	movzbl	(%rdx,%r8), %r8d
	movl	%eax, %r11d
	andl	$7, %r11d
	xorl	%esi, %esi
	btl	%r11d, %r8d
	setb	%sil
	movq	32(%rsp), %rdi
	leaq	(%rsi,%rdi,2), %r8
	movq	%r8, 72(%rsp)
	movq	24(%rsp), %rsi
	shrdq	$63, %rsi, %rdi
	movq	%rdi, 64(%rsp)
	movq	16(%rsp), %rbx
	shrdq	$63, %rbx, %rsi
	movq	%rsi, 56(%rsp)
	movq	8(%rsp), %r11
	shldq	$1, %rbx, %r11
	movq	%r11, 48(%rsp)
	movq	%r8, %r15
	movabsq	$-6346243789798364141, %rcx
	addq	%rcx, %r15
	movq	%rdi, %rbp
	adcq	$0, %rbp
	movl	$0, %ebx
	adcq	$1, %rbx
	addq	%r9, %rbp
	adcq	$-1, %rbx
	xorq	$1, %rbx
	movq	%rsi, %r13
	subq	%rbx, %r13
	movl	$1, %ebx
	sbbq	$0, %rbx
	xorl	%r12d, %r12d
	addq	%r11, %rbx
	setb	%r12b
	addq	%r10, %rbx
	adcq	$0, %r12
	xorq	$1, %r12
	movq	%r12, (%rsp)
	movq	(%rsp), %r14
	movq	%r14, %rcx
	decq	%r14
	andq	%r15, %r14
	negq	%rcx
	andq	%r8, %rcx
	orq	%r14, %rcx
	movq	%r12, (%rsp)
	movq	(%rsp), %r8
	movq	%r8, %r15
	decq	%r8
	andq	%rbp, %r8
	negq	%r15
	andq	%rdi, %r15
	orq	%r8, %r15
	movq	%r12, (%rsp)
	movq	(%rsp), %rdi
	movq	%rdi, %r8
	decq	%rdi
	andq	%r13, %rdi
	negq	%r8
	andq	%rsi, %r8
	orq	%rdi, %r8
	movq	%r12, (%rsp)
	movq	(%rsp), %rsi
	movq	%rsi, %rdi
	decq	%rsi
	andq	%rbx, %rsi
	negq	%rdi
	andq	%r11, %rdi
	orq	%rsi, %rdi
	movq	$0, (%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	#MEMBARRIER
	movq	%rcx, 32(%rsp)
	movq	%r15, 24(%rsp)
	movq	%r8, 16(%rsp)
	movq	%rdi, 8(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	addq	$-1, %rax
	jb	.LBB66_1
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rax, (%rcx)
	movq	24(%rsp), %rax
	movq	%rax, 8(%rcx)
	movq	16(%rsp), %rax
	movq	%rax, 16(%rcx)
	movq	8(%rsp), %rax
	movq	%rax, 24(%rcx)
	addq	$104, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss,unique,67
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey10verify_pss:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$1432, %rsp
	movq	%r9, %rdi
	movq	%r8, %r15
	movl	%edx, %ebx
	movq	%rcx, %r14
	movq	1536(%rsp), %r8
	movq	1544(%rsp), %r9
	leaq	407(%rsp), %rcx
	movq	%r14, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey14representative
	movzbl	408(%rsp), %ebp
	cmpb	$1, 407(%rsp)
	je	.LBB67_10
	leaq	409(%rsp), %rdx
	leaq	921(%rsp), %rcx
	movl	$511, %r8d
	callq	memcpy
	movb	%bpl, 920(%rsp)
	movq	1544(%r14), %rcx
	leaq	-1(%rcx), %rax
	movq	%rax, %r13
	shrq	$3, %r13
	movl	%eax, %edx
	andl	$7, %edx
	cmpq	$1, %rdx
	sbbq	$-1, %r13
	movq	%rcx, %rdx
	shrq	$3, %rdx
	andl	$7, %ecx
	xorl	%r8d, %r8d
	negq	%rcx
	sbbq	%r8, %r8
	subq	%rdx, %r8
	leaq	512(%r8), %rcx
	movl	$512, %edx
	subq	%r13, %rdx
	cmpq	%rcx, %rdx
	jb	.LBB67_35
	cmpq	$513, %rdx
	jae	.LBB67_35
	leaq	(%rsp,%rdx), %r12
	addq	$920, %r12
	movq	%r13, %rcx
	negq	%rcx
	.p2align	4
.LBB67_4:
	cmpq	%r8, %rcx
	je	.LBB67_7
	cmpb	$0, 1432(%rsp,%r8)
	leaq	1(%r8), %r8
	je	.LBB67_4
.LBB67_6:
	movb	$5, %bpl
	jmp	.LBB67_10
.LBB67_7:
	movl	%ebx, %ecx
	shlb	$4, %cl
	addb	$32, %cl
	movzbl	%cl, %esi
	leaq	2(,%rsi,2), %rcx
	movb	$5, %bpl
	cmpq	%rcx, %r13
	jb	.LBB67_10
	cmpb	$-68, 1431(%rsp)
	jne	.LBB67_10
	leaq	(,%r13,8), %rdx
	subq	%rax, %rdx
	movb	$8, %cl
	subb	%dl, %cl
	andb	$15, %cl
	movl	$255, %eax
	shll	%cl, %eax
	testb	%al, (%r12)
	je	.LBB67_11
.LBB67_10:
	movl	%ebp, %eax
	addq	$1432, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB67_11:
	movq	%rdx, 216(%rsp)
	movq	%rsi, %r14
	notq	%r14
	addq	%r13, %r14
	leaq	-1(%r13), %rdx
	cmpq	%r14, %rdx
	jb	.LBB67_36
	leaq	407(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	cmpq	$513, %r14
	jae	.LBB67_37
	movq	%rsi, 128(%rsp)
	movb	%bl, 39(%rsp)
	cmpq	%r13, %r14
	ja	.LBB67_39
	movq	%r15, 200(%rsp)
	movq	%rdi, 208(%rsp)
	leaq	407(%rsp), %r13
	movq	%r13, %rcx
	movq	%r12, 120(%rsp)
	movq	%r12, %rdx
	movq	%r14, %r8
	callq	memcpy
	movq	%r14, 112(%rsp)
	testq	%r14, %r14
	je	.LBB67_22
	movq	112(%rsp), %r14
	addq	%r14, 120(%rsp)
	leaq	42(%rsp), %rsi
	xorl	%edi, %edi
	leaq	344(%rsp), %r12
	jmp	.LBB67_17
	.p2align	4
.LBB67_16:
	testq	%r14, %r14
	je	.LBB67_22
.LBB67_17:
	movq	128(%rsp), %rcx
	cmpq	%r14, %rcx
	movq	%r14, %rbx
	cmovbq	%rcx, %rbx
	movq	%r13, %r15
	movl	%edi, %eax
	bswapl	%eax
	movl	%eax, 224(%rsp)
	movq	120(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	%rcx, 144(%rsp)
	leaq	224(%rsp), %rax
	movq	%rax, 152(%rsp)
	movq	$4, 160(%rsp)
	movl	$2, %r9d
	leaq	40(%rsp), %rcx
	movzbl	39(%rsp), %edx
	leaq	136(%rsp), %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB2_4Hash6digest
	movzbl	41(%rsp), %ebp
	cmpb	$0, 40(%rsp)
	jne	.LBB67_10
	leaq	(%r15,%rbx), %r13
	subq	%rbx, %r14
	incl	%edi
	movq	55(%rsi), %rax
	movq	%rax, 55(%r12)
	movq	48(%rsi), %rax
	movq	%rax, 48(%r12)
	movq	40(%rsi), %rax
	movq	%rax, 40(%r12)
	movq	32(%rsi), %rax
	movq	%rax, 32(%r12)
	movq	24(%rsi), %rax
	movq	%rax, 24(%r12)
	movq	16(%rsi), %rax
	movq	%rax, 16(%r12)
	movq	(%rsi), %rax
	movq	8(%rsi), %rcx
	movq	%rcx, 8(%r12)
	movq	%rax, (%r12)
	movb	%bpl, 343(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB67_19:
	cmpq	$64, %rax
	je	.LBB67_40
	leaq	(%r15,%rax), %rcx
	movzbl	343(%rsp,%rax), %edx
	xorb	%dl, (%rcx)
	incq	%rcx
	cmpq	%r13, %rcx
	je	.LBB67_16
	movzbl	344(%rsp,%rax), %edx
	xorb	%dl, (%rcx)
	addq	$2, %rax
	incq	%rcx
	cmpq	%r13, %rcx
	jne	.LBB67_19
	jmp	.LBB67_16
.LBB67_22:
	movq	216(%rsp), %rcx
	andb	$7, %cl
	movzbl	407(%rsp), %eax
	shlb	%cl, %al
	shrb	%cl, %al
	movb	%al, 407(%rsp)
	movq	112(%rsp), %rdi
	movq	%rdi, %r15
	movq	128(%rsp), %rsi
	subq	%rsi, %r15
	leaq	-1(%r15), %rdx
	cmpq	$513, %rdx
	jae	.LBB67_38
	xorl	%eax, %eax
	.p2align	4
.LBB67_24:
	cmpq	%rax, %rdx
	je	.LBB67_27
	cmpb	$0, 407(%rsp,%rax)
	leaq	1(%rax), %rax
	je	.LBB67_24
	jmp	.LBB67_6
.LBB67_27:
	movb	$5, %bpl
	cmpb	$1, 407(%rsp,%rdx)
	jne	.LBB67_10
	movq	200(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	208(%rsp), %rax
	movq	%rax, 144(%rsp)
	leaq	40(%rsp), %rcx
	leaq	136(%rsp), %r8
	movl	$1, %r9d
	movzbl	39(%rsp), %edx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB2_4Hash6digest
	movzbl	41(%rsp), %ebp
	cmpb	$1, 40(%rsp)
	je	.LBB67_10
	movq	97(%rsp), %rax
	movq	%rax, 280(%rsp)
	movq	90(%rsp), %rax
	movq	%rax, 273(%rsp)
	movq	82(%rsp), %rax
	movq	%rax, 265(%rsp)
	movq	74(%rsp), %rax
	movq	%rax, 257(%rsp)
	movq	66(%rsp), %rax
	movq	%rax, 249(%rsp)
	movq	58(%rsp), %rax
	movq	%rax, 241(%rsp)
	movq	42(%rsp), %rax
	movq	50(%rsp), %rcx
	movq	%rcx, 233(%rsp)
	movq	%rax, 225(%rsp)
	movb	%bpl, 224(%rsp)
	cmpq	%rsi, %rdi
	jb	.LBB67_41
	leaq	(%rsp,%r15), %rax
	addq	$407, %rax
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.37(%rip), %rcx
	movq	%rcx, 288(%rsp)
	movq	$8, 296(%rsp)
	leaq	224(%rsp), %rcx
	movq	%rcx, 304(%rsp)
	movq	%rsi, 312(%rsp)
	movq	%rax, 320(%rsp)
	movq	%rsi, 328(%rsp)
	leaq	40(%rsp), %rcx
	leaq	288(%rsp), %r8
	movl	$3, %r9d
	movzbl	39(%rsp), %ebx
	movl	%ebx, %edx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB2_4Hash6digest
	movzbl	41(%rsp), %ebp
	cmpb	$0, 40(%rsp)
	jne	.LBB67_10
	movq	97(%rsp), %rax
	movq	%rax, 192(%rsp)
	movq	90(%rsp), %rax
	movq	%rax, 185(%rsp)
	movq	82(%rsp), %rax
	movq	%rax, 177(%rsp)
	movq	74(%rsp), %rax
	movq	%rax, 169(%rsp)
	movq	66(%rsp), %rax
	movq	%rax, 161(%rsp)
	movq	58(%rsp), %rax
	movq	%rax, 153(%rsp)
	movq	42(%rsp), %rax
	movq	50(%rsp), %rcx
	movq	%rcx, 145(%rsp)
	movq	%rax, 137(%rsp)
	movb	%bpl, 136(%rsp)
	movzbl	%bl, %ecx
	shll	$4, %ecx
	leaq	920(%rsp), %rax
	subq	%rcx, %rax
	addq	$482, %rax
	xorl	%ecx, %ecx
	xorl	%edx, %edx
.LBB67_32:
	movzbl	136(%rsp,%rcx), %r8d
	xorb	-3(%rax,%rcx), %r8b
	movzbl	137(%rsp,%rcx), %r9d
	movzbl	%r8b, %r8d
	xorb	-2(%rax,%rcx), %r9b
	orq	%rdx, %r8
	movzbl	138(%rsp,%rcx), %edx
	xorb	-1(%rax,%rcx), %dl
	movzbl	%r9b, %r9d
	movzbl	%dl, %r10d
	orq	%r9, %r10
	orq	%r8, %r10
	movzbl	139(%rsp,%rcx), %edx
	xorb	(%rax,%rcx), %dl
	addq	$4, %rcx
	movzbl	%dl, %edx
	orq	%r10, %rdx
	cmpq	%rcx, %rsi
	jne	.LBB67_32
	xorl	%eax, %eax
	testq	%rdx, %rdx
	setne	%al
	movq	%rax, 40(%rsp)
	cmpq	$0, 40(%rsp)
	movb	$5, %bpl
	jne	.LBB67_10
	movb	$-1, %bpl
	jmp	.LBB67_10
.LBB67_35:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.43(%rip), %r9
	movl	$512, %r8d
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB67_36:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.42(%rip), %r9
	movq	%r14, %rcx
	movq	%r13, %r8
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB67_37:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.41(%rip), %r9
	movl	$512, %r8d
	xorl	%ecx, %ecx
	movq	%r14, %rdx
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB67_38:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.39(%rip), %r9
	movl	$512, %r8d
	xorl	%ecx, %ecx
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB67_39:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.36(%rip), %r9
	xorl	%ecx, %ecx
	movq	%r14, %rdx
	movq	%r13, %r8
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB67_40:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.40(%rip), %r8
	movl	$64, %ecx
	movl	$64, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB67_41:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.38(%rip), %r9
	movl	$512, %r8d
	movq	%r15, %rcx
	movq	%rdi, %rdx
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey14representative;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey14representative,unique,68
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey14representative:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$3616, %rsp
	movq	%rcx, %rsi
	movq	1544(%rdx), %rax
	movq	%rax, %rcx
	shrq	$3, %rcx
	andl	$7, %eax
	cmpq	$1, %rax
	sbbq	$-1, %rcx
	cmpq	%rcx, %r9
	jne	.LBB68_21
	movq	%r9, %rbx
	movq	%r8, %r14
	movq	%rdx, %rdi
	leaq	32(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	testq	%rbx, %rbx
	je	.LBB68_6
	decq	%r14
	leaq	-1(%rbx), %rdx
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	.p2align	4
.LBB68_3:
	movq	%r9, %rax
	shrq	$3, %rax
	cmpq	$512, %r9
	je	.LBB68_23
	movzbl	(%r14,%rbx), %r10d
	movl	%r8d, %ecx
	andb	$48, %cl
	shlq	%cl, %r10
	orq	%r10, 32(%rsp,%rax,8)
	cmpq	%r9, %rdx
	je	.LBB68_6
	movzbl	-1(%r14,%rbx), %eax
	movl	%r8d, %ecx
	andb	$48, %cl
	orb	$8, %cl
	shlq	%cl, %rax
	leaq	2(%r9), %rcx
	andq	$-8, %r9
	orq	%rax, 32(%rsp,%r9)
	addq	$16, %r8
	addq	$-2, %r14
	movq	%rcx, %r9
	cmpq	%rcx, %rbx
	jne	.LBB68_3
.LBB68_6:
	leaq	544(%rsp), %rcx
	leaq	32(%rsp), %rdx
	movl	$512, %r8d
	callq	memcpy
	leaq	1056(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	1536(%rdi), %rax
	testq	%rax, %rax
	je	.LBB68_12
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	xorl	%r8d, %r8d
	.p2align	4
.LBB68_8:
	cmpq	$64, %r8
	je	.LBB68_24
	addq	(%rdi,%r8,8), %rcx
	adcq	$0, %rdx
	movq	544(%rsp,%r8,8), %r9
	subq	%rcx, %r9
	movq	%r9, 1056(%rsp,%r8,8)
	leaq	1(%r8), %r8
	movl	$1, %r9d
	sbbq	%rdx, %r9
	movq	%r9, %rcx
	xorq	$1, %rcx
	movl	$0, %edx
	cmpq	%r8, %rax
	jne	.LBB68_8
	testq	%r9, %r9
	jne	.LBB68_12
	leaq	1056(%rsp), %rcx
	leaq	32(%rsp), %rdx
	movl	$512, %r8d
	callq	memcpy
.LBB68_12:
	leaq	32(%rsp), %rcx
	leaq	1056(%rsp), %rdx
	movl	$512, %r8d
	callq	memcmp
	testl	%eax, %eax
	je	.LBB68_13
	movw	$1281, (%rsi)
	jmp	.LBB68_22
.LBB68_21:
	movw	$1, (%rsi)
	jmp	.LBB68_22
.LBB68_13:
	leaq	512(%rdi), %r9
	leaq	3104(%rsp), %rbx
	leaq	32(%rsp), %r8
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey3mul
	leaq	1024(%rdi), %rdx
	leaq	2592(%rsp), %r14
	movl	$512, %r8d
	movq	%r14, %rcx
	callq	memcpy
	movl	1560(%rdi), %ebp
	movl	$33, %r12d
	leaq	544(%rsp), %r15
	jmp	.LBB68_14
	.p2align	4
.LBB68_16:
	decl	%r12d
	cmpl	$1, %r12d
	jbe	.LBB68_17
.LBB68_14:
	movq	%r15, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	movq	%r14, %r9
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey3mul
	movl	$512, %r8d
	movq	%r14, %rcx
	movq	%r15, %rdx
	callq	memcpy
	leal	-2(%r12), %eax
	movzbl	%al, %eax
	btl	%eax, %ebp
	jae	.LBB68_16
	movq	%r15, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	movq	%rbx, %r9
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey3mul
	movl	$512, %r8d
	movq	%r14, %rcx
	movq	%r15, %rdx
	callq	memcpy
	jmp	.LBB68_16
.LBB68_17:
	leaq	2088(%rsp), %rcx
	movl	$504, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 2080(%rsp)
	leaq	544(%rsp), %rcx
	leaq	2592(%rsp), %r8
	leaq	2080(%rsp), %r9
	movq	%rdi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey3mul
	leaq	1568(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	movl	$62, %eax
	leaq	552(%rsp), %rcx
	.p2align	4
.LBB68_18:
	movq	-8(%rcx), %rdx
	bswapq	%rdx
	movq	%rdx, 1576(%rsp,%rax,8)
	movq	(%rcx), %rdx
	bswapq	%rdx
	movq	%rdx, 1568(%rsp,%rax,8)
	addq	$-2, %rax
	addq	$16, %rcx
	cmpq	$-2, %rax
	jne	.LBB68_18
	leaq	1(%rsi), %rcx
	leaq	1568(%rsp), %rdx
	movl	$512, %r8d
	callq	memcpy
	movb	$0, (%rsi)
.LBB68_22:
	addq	$3616, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq
.LBB68_24:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.58(%rip), %r8
	movl	$64, %ecx
	movl	$64, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB68_23:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.73(%rip), %r8
	movl	$64, %edx
	movq	%rax, %rcx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey15from_components;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey15from_components,unique,69
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey15from_components
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey15from_components:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	movl	$4168, %eax
	callq	_RNvCs1njKG4L9aB3_7___rustc17___rust_probestack
	subq	%rax, %rsp
	leaq	-256(%r8), %rax
	cmpq	$257, %rax
	jae	.LBB69_5
	movq	4272(%rsp), %r11
	movzbl	(%rdx), %eax
	testb	%al, %al
	sete	%r10b
	leaq	-5(%r11), %rsi
	cmpq	$-4, %rsi
	setb	%bl
	orb	%r10b, %bl
	jne	.LBB69_5
	cmpb	$0, (%r9)
	je	.LBB69_5
	movzbl	(%r9), %r10d
	cmpq	$1, %r11
	jne	.LBB69_7
	movl	%r10d, %esi
	jmp	.LBB69_11
.LBB69_7:
	movzbl	1(%r9), %edi
	shll	$8, %r10d
	movl	%r10d, %esi
	orl	%edi, %esi
	cmpq	$2, %r11
	jne	.LBB69_9
	movl	%edi, %r10d
	jmp	.LBB69_11
.LBB69_9:
	movzbl	2(%r9), %r10d
	shll	$8, %esi
	orl	%r10d, %esi
	cmpq	$3, %r11
	je	.LBB69_11
	movzbl	3(%r9), %r10d
	shll	$8, %esi
	orl	%r10d, %esi
.LBB69_11:
	testb	$1, %r10b
	je	.LBB69_5
	movzbl	%al, %eax
	movl	$15, %r9d
	bsrl	%eax, %r9d
	xorl	$7, %r9d
	leaq	(,%r8,8), %rdi
	subq	%r9, %rdi
	cmpq	$2048, %rdi
	jb	.LBB69_5
	cmpl	$2, %esi
	jbe	.LBB69_5
	testb	$1, -1(%rdx,%r8)
	jne	.LBB69_16
.LBB69_5:
	movw	$513, (%rcx)
.LBB69_6:
	movq	%rcx, %rax
	addq	$4168, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB69_16:
	movq	%rcx, %r15
	addq	%r8, %rdx
	movq	%rdx, %r14
	leaq	7(%r8), %r12
	shrq	$3, %r12
	xorl	%ebx, %ebx
	leaq	40(%rsp), %rcx
	movq	%r8, %r13
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	cmpq	$1, %r13
	jne	.LBB69_18
	movq	%r14, %rdx
	jmp	.LBB69_21
.LBB69_18:
	movq	%r13, %rax
	movl	%eax, %r8d
	andl	$1022, %r8d
	xorl	%ebx, %ebx
	movq	%r14, %rdx
	.p2align	4
.LBB69_19:
	movzbl	-1(%rdx), %r9d
	leal	(,%rbx,8), %ecx
	andb	$48, %cl
	shlq	%cl, %r9
	movq	%rbx, %r10
	andq	$-8, %r10
	orq	40(%rsp,%r10), %r9
	movq	%r9, 40(%rsp,%r10)
	movzbl	-2(%rdx), %r11d
	addq	$-2, %rdx
	orb	$8, %cl
	shlq	%cl, %r11
	addq	$2, %rbx
	orq	%r9, %r11
	movq	%r11, 40(%rsp,%r10)
	cmpq	%r8, %rbx
	jne	.LBB69_19
	testb	$1, %al
	je	.LBB69_22
.LBB69_21:
	movzbl	-1(%rdx), %eax
	leal	(,%rbx,8), %ecx
	shlq	%cl, %rax
	andq	$-8, %rbx
	orq	%rax, 40(%rsp,%rbx)
.LBB69_22:
	movq	40(%rsp), %rbx
	movl	$2, %eax
	movl	$2, %ecx
	subq	%rbx, %rcx
	movq	%rbx, %rdx
	imulq	%rcx, %rdx
	movl	$2, %r8d
	subq	%rdx, %r8
	imulq	%rcx, %r8
	movq	%rbx, %rcx
	imulq	%r8, %rcx
	movl	$2, %edx
	subq	%rcx, %rdx
	imulq	%r8, %rdx
	movq	%rbx, %rcx
	imulq	%rdx, %rcx
	movl	$2, %r8d
	subq	%rcx, %r8
	imulq	%rdx, %r8
	movq	%rbx, %rcx
	imulq	%r8, %rcx
	subq	%rcx, %rax
	imulq	%r8, %rax
	imulq	%rax, %rbx
	addq	$-2, %rbx
	imulq	%rax, %rbx
	leaq	2088(%rsp), %rcx
	leaq	40(%rsp), %rdx
	movl	$512, %r8d
	callq	memcpy
	movq	%r12, 3624(%rsp)
	movq	%rdi, 3632(%rsp)
	movl	%esi, 3648(%rsp)
	movq	%rbx, 3640(%rsp)
	leaq	2600(%rsp), %rdi
	movl	$1024, %r8d
	movq	%rdi, %rcx
	xorl	%edx, %edx
	callq	memset
	leaq	560(%rsp), %rcx
	movl	$504, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 552(%rsp)
	movq	%r12, %r13
	shlq	$7, %r13
	leaq	1064(%rsp), %rbx
	leaq	552(%rsp), %r14
	xorl	%ebp, %ebp
	jmp	.LBB69_24
	.p2align	4
.LBB69_23:
	cmpq	%r13, %rbp
	je	.LBB69_33
.LBB69_24:
	incq	%rbp
	movl	$512, %r8d
	movq	%rbx, %rcx
	xorl	%edx, %edx
	callq	memset
	movl	$1, %eax
	xorl	%esi, %esi
	xorl	%edx, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB69_25:
	cmpq	$65, %rax
	je	.LBB69_34
	movq	%rcx, %r9
	orq	$1, %r9
	movq	544(%rsp,%rax,8), %r10
	movq	%r10, %r8
	shrq	$63, %r8
	addq	%r10, %r10
	addq	%rsi, %r10
	adcq	%rdx, %r8
	movq	%r10, 1056(%rsp,%rax,8)
	cmpq	%r12, %r9
	je	.LBB69_28
	addq	$2, %rcx
	movq	552(%rsp,%rax,8), %rdx
	movq	%rdx, %rsi
	shrq	$63, %rsi
	addq	%rdx, %rdx
	addq	%r8, %rdx
	adcq	$0, %rsi
	movq	%rdx, 1064(%rsp,%rax,8)
	addq	$2, %rax
	movl	$0, %edx
	cmpq	%r12, %rcx
	jne	.LBB69_25
	jmp	.LBB69_29
	.p2align	4
.LBB69_28:
	movq	%r8, %rsi
.LBB69_29:
	movl	$512, %r8d
	movq	%r14, %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	xorl	%edx, %edx
	.p2align	4
.LBB69_30:
	addq	2088(%rsp,%rdx,8), %rcx
	adcq	$0, %rax
	movq	1064(%rsp,%rdx,8), %r8
	subq	%rcx, %r8
	movq	%r8, 552(%rsp,%rdx,8)
	leaq	1(%rdx), %rdx
	movl	$1, %r8d
	sbbq	%rax, %r8
	movq	%r8, %rcx
	xorq	$1, %rcx
	movl	$0, %eax
	cmpq	%rdx, %r12
	jne	.LBB69_30
	orq	%r8, %rsi
	jne	.LBB69_23
	movl	$512, %r8d
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	memcpy
	jmp	.LBB69_23
.LBB69_33:
	leaq	552(%rsp), %rdx
	movl	$512, %r8d
	movq	%rdi, %rcx
	callq	memcpy
	leaq	1584(%rsp), %rcx
	movl	$504, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 1576(%rsp)
	leaq	3656(%rsp), %rbx
	leaq	2088(%rsp), %r14
	leaq	1576(%rsp), %r8
	movq	%rbx, %rcx
	movq	%r14, %rdx
	movq	%rdi, %r9
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey3mul
	movl	$512, %r8d
	leaq	3112(%rsp), %rcx
	movq	%rbx, %rdx
	callq	memcpy
	leaq	8(%r15), %rcx
	movl	$1568, %r8d
	movq	%r14, %rdx
	callq	memcpy
	movq	%r15, %rcx
	movb	$0, (%r15)
	jmp	.LBB69_6
.LBB69_34:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.44(%rip), %r8
	movl	$64, %ecx
	movl	$64, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5,unique,70
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey17verify_pkcs1_v1_5:
	pushq	%r15
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$1144, %rsp
	movq	%r9, %r14
	movq	%r8, %r15
	movl	%edx, %ebx
	movq	%rcx, %rsi
	movq	1232(%rsp), %r8
	movq	1240(%rsp), %r9
	leaq	119(%rsp), %rcx
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey14representative
	movzbl	120(%rsp), %ebp
	cmpb	$1, 119(%rsp)
	je	.LBB70_35
	leaq	121(%rsp), %rdx
	leaq	633(%rsp), %rcx
	movl	$511, %r8d
	callq	memcpy
	movb	%bpl, 632(%rsp)
	movq	1544(%rsi), %rax
	movq	%rax, %rsi
	shrq	$3, %rsi
	andl	$7, %eax
	cmpq	$1, %rax
	sbbq	$-1, %rsi
	movl	$512, %edi
	subq	%rsi, %rdi
	jb	.LBB70_36
	movq	%r15, 32(%rsp)
	movq	%r14, 40(%rsp)
	leaq	119(%rsp), %rcx
	leaq	32(%rsp), %r8
	movl	$1, %r9d
	movl	%ebx, %edx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB2_4Hash6digest
	movzbl	120(%rsp), %ebp
	cmpb	$0, 119(%rsp)
	jne	.LBB70_35
	movq	176(%rsp), %rax
	movq	%rax, 111(%rsp)
	movq	169(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	161(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	153(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	145(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	137(%rsp), %rax
	movq	%rax, 72(%rsp)
	movq	121(%rsp), %rax
	movq	129(%rsp), %rcx
	movq	%rcx, 64(%rsp)
	movq	%rax, 56(%rsp)
	movb	%bpl, 55(%rsp)
	movb	$48, 119(%rsp)
	movabsq	$92471539387469104, %rax
	movq	%rax, 121(%rsp)
	movl	$33817445, 129(%rsp)
	testb	%bl, %bl
	je	.LBB70_4
	movzbl	%bl, %eax
	cmpl	$1, %eax
	jne	.LBB70_7
	movb	$0, 133(%rsp)
	movb	$2, %al
	movl	$48, %ebx
	movb	$65, %cl
	jmp	.LBB70_8
.LBB70_4:
	movb	$1, %al
	movl	$32, %ebx
	movb	$49, %cl
	jmp	.LBB70_8
.LBB70_7:
	movb	$3, %al
	movl	$64, %ebx
	movb	$81, %cl
.LBB70_8:
	movw	$5, 134(%rsp)
	movb	$4, 136(%rsp)
	movb	%cl, 120(%rsp)
	movb	%al, 133(%rsp)
	movb	%bl, 137(%rsp)
	movq	%rsi, %rcx
	subq	%rbx, %rcx
	leaq	-22(%rcx), %rax
	cmpq	$8, %rax
	jb	.LBB70_19
	cmpq	$1, %rsi
	jbe	.LBB70_10
	leaq	(%rsp,%rdi), %rax
	addq	$632, %rax
	cmpw	$256, (%rax)
	jne	.LBB70_19
	addq	$-19, %rcx
	leaq	-1(%rcx), %rdx
	cmpq	$2, %rdx
	jb	.LBB70_14
	cmpq	%rsi, %rdx
	ja	.LBB70_14
	movq	%rsi, %r8
	negq	%r8
	.p2align	4
.LBB70_17:
	leaq	(%rbx,%r8), %r9
	cmpq	$-22, %r9
	je	.LBB70_20
	cmpb	$-1, 1146(%rsp,%r8)
	leaq	1(%r8), %r8
	je	.LBB70_17
	jmp	.LBB70_19
.LBB70_20:
	cmpq	%rsi, %rdx
	jae	.LBB70_37
	cmpb	$0, (%rax,%rdx)
	jne	.LBB70_19
	leaq	19(%rcx), %rdi
	movq	%rsi, %r14
	subq	%rdi, %r14
	setb	%dl
	cmpq	$-20, %rcx
	ja	.LBB70_23
	testb	%dl, %dl
	jne	.LBB70_25
.LBB70_26:
	addq	%rcx, %rax
	leaq	119(%rsp), %rdx
	movl	$19, %r8d
	movq	%rax, %rcx
	callq	memcmp
	testl	%eax, %eax
	jne	.LBB70_19
	cmpq	%rbx, %r14
	jne	.LBB70_19
	cmpq	%rdi, %rsi
	jne	.LBB70_30
	xorl	%eax, %eax
	jmp	.LBB70_33
.LBB70_30:
	movq	%rbx, %rax
	negq	%rax
	addq	%rsp, %rax
	addq	$1147, %rax
	xorl	%ecx, %ecx
	xorl	%edx, %edx
.LBB70_31:
	movzbl	55(%rsp,%rcx), %r8d
	xorb	-3(%rax,%rcx), %r8b
	movzbl	56(%rsp,%rcx), %r9d
	movzbl	%r8b, %r8d
	xorb	-2(%rax,%rcx), %r9b
	orq	%rdx, %r8
	movzbl	57(%rsp,%rcx), %edx
	xorb	-1(%rax,%rcx), %dl
	movzbl	%r9b, %r9d
	movzbl	%dl, %r10d
	orq	%r9, %r10
	orq	%r8, %r10
	movzbl	58(%rsp,%rcx), %edx
	xorb	(%rax,%rcx), %dl
	addq	$4, %rcx
	movzbl	%dl, %edx
	orq	%r10, %rdx
	cmpq	%rcx, %rbx
	jne	.LBB70_31
	xorl	%eax, %eax
	testq	%rdx, %rdx
	setne	%al
.LBB70_33:
	movq	%rax, 32(%rsp)
	cmpq	$0, 32(%rsp)
	je	.LBB70_34
.LBB70_19:
	movb	$5, %bpl
.LBB70_35:
	movl	%ebp, %eax
	addq	$1144, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	retq
.LBB70_34:
	movb	$-1, %bpl
	jmp	.LBB70_35
.LBB70_36:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.49(%rip), %r9
	movl	$512, %edx
	movl	$512, %r8d
	movq	%rdi, %rcx
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB70_10:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.45(%rip), %r9
	movl	$2, %edx
	xorl	%ecx, %ecx
	movq	%rsi, %r8
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB70_14:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.48(%rip), %r9
	movl	$2, %ecx
	movq	%rsi, %r8
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB70_23:
	movb	$1, %dl
	testb	%dl, %dl
	je	.LBB70_26
.LBB70_25:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.47(%rip), %r9
	movq	%rdi, %rdx
	movq	%rsi, %r8
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB70_37:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.46(%rip), %r8
	movq	%rdx, %rcx
	movq	%rsi, %rdx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey3mul;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey3mul,unique,71
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3rsaNtB4_9PublicKey3mul:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$2136, %rsp
	movq	%r9, %r14
	movq	%r8, %r15
	movq	%rdx, %rbx
	movq	%rcx, %r13
	movq	1536(%rdx), %rdi
	leaq	1096(%rsp), %r12
	movl	$1040, %r8d
	movq	%r12, %rcx
	xorl	%edx, %edx
	callq	memset
	testq	%rdi, %rdi
	je	.LBB71_6
	xorl	%ecx, %ecx
	.p2align	4
.LBB71_2:
	cmpq	$64, %rcx
	je	.LBB71_34
	leaq	1(%rcx), %r9
	movq	(%r15,%rcx,8), %r8
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	xorl	%esi, %esi
	.p2align	4
.LBB71_4:
	cmpq	$64, %rsi
	je	.LBB71_5
	movq	%r8, %rax
	mulq	(%r14,%rsi,8)
	addq	(%r12,%rsi,8), %r10
	adcq	$0, %r11
	addq	%rax, %r10
	movq	%r10, (%r12,%rsi,8)
	movq	%r11, %r10
	adcq	%rdx, %r10
	incq	%rsi
	movl	$0, %r11d
	cmpq	%rsi, %rdi
	jne	.LBB71_4
	addq	%rdi, %rcx
	cmpq	$130, %rcx
	jae	.LBB71_32
	movq	%r10, 1096(%rsp,%rcx,8)
	addq	$8, %r12
	movq	%r9, %rcx
	cmpq	%rdi, %r9
	jne	.LBB71_2
	movq	%r13, 48(%rsp)
	movq	1552(%rbx), %rax
	movq	%rax, 56(%rsp)
	leaq	1096(%rsp), %r14
	movl	$1032, %r15d
	xorl	%r9d, %r9d
	xorl	%r13d, %r13d
	xorl	%ebp, %ebp
	.p2align	4
.LBB71_27:
	cmpq	$130, %rbp
	je	.LBB71_14
	leaq	1(%rbp), %rsi
	movq	1096(%rsp,%rbp,8), %r8
	imulq	56(%rsp), %r8
	leaq	130(%r13), %r11
	movq	%r9, %rcx
	movq	%r9, %r12
	movq	%r9, %r10
	.p2align	4
.LBB71_29:
	cmpq	$64, %rcx
	je	.LBB71_18
	cmpq	%rcx, %r11
	je	.LBB71_25
	movq	%r8, %rax
	mulq	(%rbx,%rcx,8)
	addq	(%r14,%rcx,8), %r12
	adcq	$0, %r10
	addq	%rax, %r12
	movq	%r12, (%r14,%rcx,8)
	movq	%r10, %r12
	adcq	%rdx, %r12
	incq	%rcx
	movl	$0, %r10d
	cmpq	%rcx, %rdi
	jne	.LBB71_29
	leaq	(%rdi,%rbp), %rax
	leaq	(%rdi,%rdi), %rcx
	cmpq	%rax, %rcx
	setb	%cl
	cmpq	$130, %rax
	setae	%al
	orb	%cl, %al
	movq	%rdi, %rax
	leaq	(,%rdi,8), %rcx
	jne	.LBB71_23
	.p2align	4
.LBB71_21:
	addq	%r12, (%r14,%rcx)
	movq	%r9, %r12
	adcq	$0, %r12
	cmpq	%rax, %rbp
	je	.LBB71_23
	decq	%rax
	cmpq	%rcx, %r15
	leaq	8(%rcx), %rcx
	jne	.LBB71_21
.LBB71_23:
	movq	%r12, 64(%rsp)
	movq	$0, 72(%rsp)
	testq	%r12, %r12
	jne	.LBB71_17
	decq	%r13
	addq	$8, %r14
	addq	$-8, %r15
	movq	%rsi, %rbp
	cmpq	%rdi, %rsi
	jne	.LBB71_27
	leaq	584(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	cmpq	$65, %rdi
	movq	48(%rsp), %r13
	jb	.LBB71_7
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.50(%rip), %r9
	movl	$64, %r8d
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2
.LBB71_6:
	leaq	584(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
.LBB71_7:
	leaq	(%rsp,%rdi,8), %rdx
	addq	$1096, %rdx
	leaq	(,%rdi,8), %r8
	leaq	584(%rsp), %r14
	movq	%r14, %rcx
	callq	memcpy
	leaq	64(%rsp), %rcx
	movl	$512, %r8d
	movq	%r14, %rdx
	callq	memcpy
	movq	%rdi, %rax
	shlq	$4, %rax
	movq	1096(%rsp,%rax), %rsi
	movl	$512, %r8d
	movq	%r13, %rcx
	xorl	%edx, %edx
	callq	memset
	testq	%rdi, %rdi
	je	.LBB71_13
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	.p2align	4
.LBB71_9:
	addq	(%rbx,%rdx,8), %rax
	adcq	$0, %rcx
	movq	64(%rsp,%rdx,8), %r8
	subq	%rax, %r8
	movq	%r8, (%r13,%rdx,8)
	leaq	1(%rdx), %rdx
	movl	$1, %r8d
	sbbq	%rcx, %r8
	movq	%r8, %rax
	xorq	$1, %rax
	movl	$0, %ecx
	cmpq	%rdx, %rdi
	jne	.LBB71_9
	testq	%rsi, %rsi
	jne	.LBB71_13
	testq	%r8, %r8
	jne	.LBB71_13
	leaq	584(%rsp), %rdx
	movl	$512, %r8d
	movq	%r13, %rcx
	callq	memcpy
.LBB71_13:
	addq	$2136, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB71_17:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.52(%rip), %rax
	movq	%rax, 40(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.18(%rip), %r8
	leaq	64(%rsp), %rdx
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	callq	_RINvNtCsbOZu4GxVKn0_4core9panicking13assert_failedooECs3ONsSsjNgxw_12toyos_crypto
	ud2
.LBB71_5:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.57(%rip), %r8
	movl	$64, %ecx
	movl	$64, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB71_25:
	subq	%r13, %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.54(%rip), %r8
	movl	$130, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB71_18:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.53(%rip), %r8
	movl	$64, %ecx
	movl	$64, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB71_34:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.56(%rip), %r8
	movl	$64, %ecx
	movl	$64, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB71_32:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.55(%rip), %r8
	movl	$130, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB71_14:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.51(%rip), %r8
	movl	$130, %ecx
	movl	$130, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB4_10SealingKey3new;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB4_10SealingKey3new,unique,72
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB4_10SealingKey3new
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB4_10SealingKey3new:
	pushq	%rsi
	pushq	%rdi
	subq	$40, %rsp
	movl	%r8d, %esi
	movq	%rcx, %rdi
	addq	$8, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3new
	movl	$1, (%rdi)
	movl	%esi, 4(%rdi)
	movq	%rdi, %rax
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB4_10SealingKey4seal;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB4_10SealingKey4seal,unique,73
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB4_10SealingKey4seal
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto3sshNtB4_10SealingKey4seal:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$72, %rsp
	movq	%rcx, %rax
	movq	176(%rsp), %r13
	movq	%r13, %rcx
	shrq	$32, %rcx
	je	.LBB73_1
	movw	$1, (%rax)
	jmp	.LBB73_6
.LBB73_1:
	cmpb	$0, (%rdx)
	je	.LBB73_8
	movq	%r9, %rbp
	movq	%rax, %r15
	movl	4(%rdx), %esi
	movl	%esi, %ebx
	bswapl	%ebx
	movq	%rdx, %r12
	leaq	40(%rdx), %rcx
	movq	%r8, %rdi
	movq	%r8, 32(%rsp)
	movq	$4, 40(%rsp)
	xorl	%edx, %edx
	movl	%ebx, %r8d
	xorl	%r9d, %r9d
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha10legacy_xor
	cmpb	$-1, %al
	jne	.LBB73_4
	leaq	8(%r12), %r14
	movq	%r13, 40(%rsp)
	movq	%rbp, 32(%rsp)
	movl	$1, %r9d
	movq	%r14, %rcx
	xorl	%edx, %edx
	movl	%ebx, %r8d
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha10legacy_xor
	cmpb	$-1, %al
	je	.LBB73_5
.LBB73_4:
	movq	%r15, %rax
	movw	$1, (%r15)
	jmp	.LBB73_6
.LBB73_8:
	movw	$1537, (%rax)
.LBB73_6:
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB73_5:
	movq	%r13, 40(%rsp)
	movq	%rbp, 32(%rsp)
	leaq	56(%rsp), %rcx
	movq	%r14, %rdx
	movl	%esi, %r8d
	movq	%rdi, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3sshNtB2_4Keys3tag
	xorl	%eax, %eax
	movl	%esi, %ecx
	incl	%ecx
	setne	%al
	movl	%eax, (%r12)
	movl	%ecx, 4(%r12)
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	movq	%r15, %rax
	movq	%rdx, 16(%r15)
	movq	%rcx, 8(%r15)
	movl	%esi, 4(%r15)
	movb	$0, (%r15)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	#MEMBARRIER
	jmp	.LBB73_6

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm,unique,74
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey10aes128_gcm:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$592, %rsp
	movq	%rcx, %rsi
	leaq	336(%rsp), %rdi
	movl	$16, %r8d
	movl	$10, %r9d
	movq	%rdi, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes6expand
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	leaq	48(%rsp), %rdx
	movq	%rdi, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt
	movq	48(%rsp), %rax
	movq	56(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 64(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %r8
	cpuid
	xchgq	%rbx, %r8

	#NO_APP
	movl	%ecx, %ebx
	leaq	80(%rsp), %rcx
	movl	$256, %r8d
	movq	%rdi, %rdx
	callq	memcpy
	shrb	%bl
	andb	$1, %bl
	leaq	64(%rsp), %rdx
	movl	$272, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movb	%bl, 272(%rsi)
	movb	$0, 336(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 34(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$592, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm,unique,75
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey10aes256_gcm:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$608, %rsp
	movq	%rcx, %rsi
	leaq	352(%rsp), %rdi
	movl	$32, %r8d
	movl	$14, %r9d
	movq	%rdi, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes6expand
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	leaq	64(%rsp), %rdx
	movq	%rdi, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rcx, 88(%rsp)
	movq	%rax, 80(%rsp)
	movl	$1, %eax
	xorl	%ecx, %ecx
	#APP

	movq	%rbx, %r8
	cpuid
	xchgq	%rbx, %r8

	#NO_APP
	movl	%ecx, %ebx
	leaq	96(%rsp), %rcx
	movl	$256, %r8d
	movq	%rdi, %rdx
	callq	memcpy
	shrb	%bl
	andb	$1, %bl
	leaq	80(%rsp), %rdx
	movl	$272, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movb	%bl, 272(%rsi)
	movb	$0, 352(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 34(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$608, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey4open;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey4open,unique,76
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey4open
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4aeadNtB4_10OpeningKey4open:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$120, %rsp
	cmpq	$16, 248(%rsp)
	jne	.LBB76_4
	movq	240(%rsp), %r15
	movq	232(%rsp), %rbx
	movq	224(%rsp), %r14
	cmpb	$2, 272(%rcx)
	jne	.LBB76_5
	movabsq	$274877906880, %rax
	cmpq	%rax, %rbx
	ja	.LBB76_4
	movq	%rbx, 48(%rsp)
	movq	%r14, 40(%rsp)
	movq	%r9, 32(%rsp)
	movq	%rcx, %r9
	movq	%rcx, 104(%rsp)
	leaq	72(%rsp), %rcx
	movq	%rdx, %rax
	movq	%rdx, 112(%rsp)
	movq	%r9, %rdx
	movq	%r8, %r9
	movq	%rax, %r8
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4aead10chacha_tag
	movzbl	(%r15), %esi
	movzbl	1(%r15), %eax
	movzbl	2(%r15), %r9d
	movzbl	3(%r15), %edx
	movzbl	4(%r15), %ecx
	movb	%cl, 69(%rsp)
	movzbl	5(%r15), %edi
	movzbl	6(%r15), %r10d
	movzbl	7(%r15), %ecx
	movb	%cl, 70(%rsp)
	movzbl	8(%r15), %r12d
	movzbl	9(%r15), %ebp
	movzbl	10(%r15), %r8d
	movzbl	11(%r15), %ecx
	movb	%cl, 71(%rsp)
	movzbl	12(%r15), %r11d
	movzbl	13(%r15), %r13d
	movzbl	14(%r15), %ecx
	xorb	72(%rsp), %sil
	movzbl	15(%r15), %r15d
	xorb	73(%rsp), %al
	orb	%sil, %al
	xorb	74(%rsp), %r9b
	xorb	75(%rsp), %dl
	orb	%r9b, %dl
	orb	%al, %dl
	movzbl	69(%rsp), %eax
	xorb	76(%rsp), %al
	xorb	77(%rsp), %dil
	xorb	78(%rsp), %r10b
	orb	%al, %dil
	orb	%dil, %r10b
	movzbl	70(%rsp), %eax
	xorb	79(%rsp), %al
	orb	%dl, %r10b
	xorb	80(%rsp), %r12b
	orb	%al, %r12b
	xorb	81(%rsp), %bpl
	xorb	82(%rsp), %r8b
	orb	%r12b, %bpl
	orb	%bpl, %r8b
	movzbl	71(%rsp), %eax
	xorb	83(%rsp), %al
	orb	%r10b, %r8b
	xorb	84(%rsp), %r11b
	orb	%al, %r11b
	xorb	85(%rsp), %r13b
	xorb	86(%rsp), %cl
	orb	%r11b, %r13b
	orb	%r13b, %cl
	xorb	87(%rsp), %r15b
	orb	%r8b, %cl
	xorl	%eax, %eax
	orb	%cl, %r15b
	setne	%al
	movq	%rax, 88(%rsp)
	cmpq	$0, 88(%rsp)
	movb	$1, %al
	jne	.LBB76_9
	movq	104(%rsp), %rcx
	movq	112(%rsp), %rdx
	movq	%r14, %r8
	movq	%rbx, %r9
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha3xor
.LBB76_9:
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	jmp	.LBB76_23
.LBB76_5:
	movq	%rcx, %rdi
	movabsq	$68719476704, %rax
	cmpq	%rax, %rbx
	seta	%al
	movq	%r9, %rcx
	shrq	$61, %rcx
	setne	%cl
	orb	%al, %cl
	je	.LBB76_10
.LBB76_4:
	xorl	%eax, %eax
	jmp	.LBB76_24
.LBB76_10:
	movq	%rbx, 48(%rsp)
	movq	%r14, 40(%rsp)
	movq	%r9, 32(%rsp)
	leaq	88(%rsp), %rcx
	movq	%rdx, %rax
	movq	%rdx, 112(%rsp)
	movq	%rdi, %rdx
	movq	%rdi, 104(%rsp)
	movq	%r8, %r9
	movq	%rax, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3gcmNtB2_3Gcm3tag
	movzbl	(%r15), %esi
	movzbl	1(%r15), %eax
	movzbl	2(%r15), %r9d
	movzbl	3(%r15), %edx
	movzbl	4(%r15), %ecx
	movb	%cl, 69(%rsp)
	movzbl	5(%r15), %edi
	movzbl	6(%r15), %r10d
	movzbl	7(%r15), %ecx
	movb	%cl, 70(%rsp)
	movzbl	8(%r15), %r12d
	movzbl	9(%r15), %ebp
	movzbl	10(%r15), %r8d
	movzbl	11(%r15), %ecx
	movb	%cl, 71(%rsp)
	movzbl	12(%r15), %r11d
	movzbl	13(%r15), %r13d
	movzbl	14(%r15), %ecx
	xorb	88(%rsp), %sil
	movzbl	15(%r15), %r15d
	xorb	89(%rsp), %al
	orb	%sil, %al
	xorb	90(%rsp), %r9b
	xorb	91(%rsp), %dl
	orb	%r9b, %dl
	orb	%al, %dl
	movzbl	69(%rsp), %eax
	xorb	92(%rsp), %al
	xorb	93(%rsp), %dil
	xorb	94(%rsp), %r10b
	orb	%al, %dil
	orb	%dil, %r10b
	movzbl	70(%rsp), %eax
	xorb	95(%rsp), %al
	orb	%dl, %r10b
	xorb	96(%rsp), %r12b
	orb	%al, %r12b
	xorb	97(%rsp), %bpl
	xorb	98(%rsp), %r8b
	orb	%r12b, %bpl
	orb	%bpl, %r8b
	movzbl	71(%rsp), %eax
	xorb	99(%rsp), %al
	orb	%r10b, %r8b
	xorb	100(%rsp), %r11b
	orb	%al, %r11b
	xorb	101(%rsp), %r13b
	xorb	102(%rsp), %cl
	orb	%r11b, %r13b
	orb	%r13b, %cl
	xorb	103(%rsp), %r15b
	orb	%r8b, %cl
	xorl	%eax, %eax
	orb	%cl, %r15b
	setne	%al
	movq	%rax, 72(%rsp)
	cmpq	$0, 72(%rsp)
	movb	$1, %al
	jne	.LBB76_22
	testq	%rbx, %rbx
	movq	112(%rsp), %rsi
	movq	104(%rsp), %rdi
	je	.LBB76_21
	addq	$16, %rdi
	xorl	%r12d, %r12d
	leaq	72(%rsp), %r15
	jmp	.LBB76_14
	.p2align	4
.LBB76_13:
	addq	%r13, %r14
	incl	%r12d
	subq	%r13, %rbx
	je	.LBB76_21
.LBB76_14:
	cmpq	$16, %rbx
	movl	$16, %r13d
	cmovbq	%rbx, %r13
	movl	8(%rsi), %eax
	movl	%eax, 80(%rsp)
	movq	(%rsi), %rax
	movq	%rax, 72(%rsp)
	leal	2(%r12), %eax
	bswapl	%eax
	movl	%eax, 84(%rsp)
	movq	%rdi, %rcx
	movq	%r15, %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto3aesNtB2_3Aes7encrypt
	movl	%r13d, %eax
	andl	$3, %eax
	cmpq	$4, %rbx
	jae	.LBB76_16
	xorl	%ecx, %ecx
	jmp	.LBB76_19
	.p2align	4
.LBB76_16:
	movl	%r13d, %edx
	andl	$28, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB76_17:
	movzbl	72(%rsp,%rcx), %r8d
	xorb	%r8b, (%r14,%rcx)
	movzbl	73(%rsp,%rcx), %r8d
	xorb	%r8b, 1(%r14,%rcx)
	movzbl	74(%rsp,%rcx), %r8d
	xorb	%r8b, 2(%r14,%rcx)
	movzbl	75(%rsp,%rcx), %r8d
	xorb	%r8b, 3(%r14,%rcx)
	addq	$4, %rcx
	cmpq	%rcx, %rdx
	jne	.LBB76_17
	testq	%rax, %rax
	je	.LBB76_13
.LBB76_19:
	leaq	(%rsp,%rcx), %rdx
	addq	$72, %rdx
	addq	%r14, %rcx
	xorl	%r8d, %r8d
	.p2align	4
.LBB76_20:
	movzbl	(%rdx,%r8), %r9d
	xorb	%r9b, (%rcx,%r8)
	incq	%r8
	cmpq	%r8, %rax
	jne	.LBB76_20
	jmp	.LBB76_13
.LBB76_21:
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	#MEMBARRIER
	movb	$-1, %al
.LBB76_22:
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	movb	$0, 96(%rsp)
	movb	$0, 97(%rsp)
	movb	$0, 98(%rsp)
	movb	$0, 99(%rsp)
	movb	$0, 100(%rsp)
	movb	$0, 101(%rsp)
	movb	$0, 102(%rsp)
	movb	$0, 103(%rsp)
.LBB76_23:
	#MEMBARRIER
.LBB76_24:
	addq	$120, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_,unique,77
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_:
	pushq	%r15
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$64, %rsp
	movq	24(%r8), %r9
	movq	%r9, %r10
	bswapq	%r10
	movq	16(%r8), %rax
	movq	%rax, %rbx
	bswapq	%rbx
	movq	8(%r8), %r11
	movq	%r11, %rdi
	bswapq	%rdi
	movq	(%r8), %r8
	movq	%r8, %rsi
	bswapq	%rsi
	movq	%rbx, 16(%rsp)
	cmpq	200(%rdx), %r10
	movl	$1, %r14d
	sbbq	$0, %r14
	subq	208(%rdx), %rbx
	movl	$1, %r15d
	sbbq	$0, %r15
	addq	%r14, %rbx
	adcq	$0, %r15
	addq	$-1, %rbx
	adcq	$-1, %r15
	movq	%rdi, 8(%rsp)
	xorq	$-2, %r15
	subq	216(%rdx), %rdi
	movq	%rsi, (%rsp)
	movl	$1, %r14d
	sbbq	$0, %r14
	movl	$1, %ebx
	addq	%r15, %rdi
	adcq	$-1, %r14
	addq	$1, %rdi
	adcq	$0, %r14
	xorq	$-2, %r14
	subq	224(%rdx), %rsi
	sbbq	$0, %rbx
	addq	%r14, %rsi
	adcq	$-1, %rbx
	addq	$1, %rsi
	adcq	$0, %rbx
	movq	%r10, 24(%rsp)
	orq	%r9, %rax
	orq	%r11, %rax
	orq	%r8, %rax
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	#MEMBARRIER
	je	.LBB77_3
	testq	%rbx, %rbx
	jne	.LBB77_3
	movq	24(%rsp), %rax
	movq	16(%rsp), %rdx
	movq	8(%rsp), %r8
	movq	(%rsp), %r9
	movq	%rax, 8(%rcx)
	movq	%rdx, 16(%rcx)
	movq	%r8, 24(%rcx)
	movq	%r9, 32(%rcx)
	movb	$0, (%rcx)
	jmp	.LBB77_4
.LBB77_3:
	movw	$513, (%rcx)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	#MEMBARRIER
.LBB77_4:
	addq	$64, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_,unique,78
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$96, %rsp
	movq	40(%r8), %r11
	movq	%r11, %rax
	bswapq	%rax
	movq	32(%r8), %r10
	movq	%r10, %rdi
	bswapq	%rdi
	movq	24(%r8), %r9
	movq	%r9, %rbx
	bswapq	%rbx
	cmpq	296(%rdx), %rax
	movq	16(%r8), %rsi
	movl	$1, %r14d
	sbbq	$0, %r14
	movq	%rdi, 32(%rsp)
	subq	304(%rdx), %rdi
	movl	$1, %r15d
	sbbq	$0, %r15
	addq	%r14, %rdi
	movq	%rsi, %r14
	bswapq	%r14
	adcq	$0, %r15
	addq	$-1, %rdi
	adcq	$-1, %r15
	movq	%rbx, 24(%rsp)
	xorq	$-2, %r15
	subq	312(%rdx), %rbx
	movl	$1, %r12d
	sbbq	$0, %r12
	addq	%r15, %rbx
	movq	8(%r8), %rdi
	adcq	$-1, %r12
	movq	%r14, 16(%rsp)
	addq	$1, %rbx
	adcq	$0, %r12
	xorq	$-2, %r12
	subq	320(%rdx), %r14
	movl	$1, %ebx
	sbbq	$0, %rbx
	addq	%r12, %r14
	movq	%rdi, %r15
	bswapq	%r15
	adcq	$-1, %rbx
	movq	%r15, 8(%rsp)
	addq	$1, %r14
	adcq	$0, %rbx
	xorq	$-2, %rbx
	subq	328(%rdx), %r15
	movl	$1, %r14d
	sbbq	$0, %r14
	addq	%rbx, %r15
	movq	(%r8), %r8
	adcq	$-1, %r14
	addq	$1, %r15
	movq	%r8, %rbx
	bswapq	%rbx
	adcq	$0, %r14
	movq	%rbx, (%rsp)
	xorq	$-2, %r14
	subq	336(%rdx), %rbx
	movl	$1, %edx
	sbbq	$0, %rdx
	addq	%r14, %rbx
	adcq	$-1, %rdx
	addq	$1, %rbx
	adcq	$0, %rdx
	orq	%r11, %r10
	orq	%rsi, %r9
	orq	%r10, %r9
	orq	%rdi, %r9
	orq	%r8, %r9
	movq	%rax, 40(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	#MEMBARRIER
	je	.LBB78_3
	testq	%rdx, %rdx
	jne	.LBB78_3
	movq	40(%rsp), %rax
	movq	32(%rsp), %rdx
	movq	24(%rsp), %r8
	movq	16(%rsp), %r9
	movq	8(%rsp), %r10
	movq	(%rsp), %r11
	movq	%rax, 8(%rcx)
	movq	%rdx, 16(%rcx)
	movq	%r8, 24(%rcx)
	movq	%r9, 32(%rcx)
	movq	%r10, 40(%rcx)
	movq	%r11, 48(%rcx)
	movb	$0, (%rcx)
	jmp	.LBB78_4
.LBB78_3:
	movw	$513, (%rcx)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	#MEMBARRIER
.LBB78_4:
	addq	$96, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly3ntt;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly3ntt,unique,79
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly3ntt
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly3ntt:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$72, %rsp
	movq	%rdx, 40(%rsp)
	movq	%rcx, 48(%rsp)
	movl	$128, %eax
	movb	$1, %r8b
	movl	$2642262849, %r9d
	jmp	.LBB79_1
	.p2align	4
.LBB79_8:
	movq	%rax, %rcx
	shrq	%rcx
	cmpq	$3, %rax
	movq	%rcx, %rax
	jbe	.LBB79_9
.LBB79_1:
	leaq	(%rax,%rax), %r10
	rep		bsfq	%r10, %rcx
	movl	$256, %edx
	shrq	%cl, %rdx
	leal	-1(%r10), %ecx
	btl	$8, %ecx
	movq	%rdx, %rdi
	adcq	$0, %rdi
	je	.LBB79_8
	addb	%r8b, %dl
	movq	%rdx, 56(%rsp)
	leaq	(,%rax,4), %rbx
	movq	%rax, %r14
	negq	%r14
	movq	40(%rsp), %r15
	movq	%rax, 64(%rsp)
	movq	%rax, %r12
	.p2align	4
.LBB79_3:
	movl	%r8d, %ecx
	rolb	$4, %cl
	movl	%ecx, %esi
	andb	$51, %sil
	shlb	$2, %sil
	shrb	$2, %cl
	andb	$51, %cl
	orb	%sil, %cl
	movl	%ecx, %esi
	andb	$85, %sil
	addb	%sil, %sil
	shrb	%cl
	andb	$84, %cl
	orb	%sil, %cl
	shrb	%cl
	je	.LBB79_4
	movzbl	%cl, %ecx
	movw	$17, %bp
	movw	$1, %r13w
	jmp	.LBB79_15
	.p2align	4
.LBB79_17:
	movzwl	%r13w, %r13d
	movzwl	%bp, %ebp
	imull	%ebp, %r13d
	imulq	$989558401, %r13, %rax
	shrq	$32, %rax
	movl	%r13d, %edx
	subl	%eax, %edx
	shrl	%edx
	addl	%eax, %edx
	shrl	$11, %edx
	imull	$3329, %edx, %eax
	subl	%eax, %r13d
.LBB79_18:
	imull	%ebp, %ebp
	movq	%rbp, %rax
	imulq	%r9, %rax
	shrq	$43, %rax
	imull	$3329, %eax, %eax
	subl	%eax, %ebp
	shrl	%ecx
	je	.LBB79_10
.LBB79_15:
	testb	$1, %cl
	jne	.LBB79_17
	movzwl	%bp, %ebp
	jmp	.LBB79_18
	.p2align	4
.LBB79_10:
	movzwl	%r13w, %ebp
	jmp	.LBB79_11
	.p2align	4
.LBB79_4:
	movl	$1, %ebp
.LBB79_11:
	decq	%rdi
	incb	%r8b
	leaq	(%r15,%r10), %r13
	xorl	%esi, %esi
	.p2align	4
.LBB79_12:
	leaq	(%r12,%rsi), %rcx
	cmpq	$256, %rcx
	jae	.LBB79_13
	movzwl	(%r13,%rsi,2), %ecx
	imull	%ebp, %ecx
	imulq	$989558401, %rcx, %r11
	shrq	$32, %r11
	movl	%ecx, %edx
	subl	%r11d, %edx
	shrl	%edx
	addl	%r11d, %edx
	shrl	$11, %edx
	imull	$3329, %edx, %edx
	subl	%edx, %ecx
	movzwl	(%r15,%rsi,2), %edx
	movl	%edx, %r11d
	subl	%ecx, %r11d
	addl	$3329, %r11d
	imulq	$1290168, %r11, %rax
	shrq	$32, %rax
	imull	$3329, %eax, %eax
	subl	%eax, %r11d
	movw	%r11w, (%r13,%rsi,2)
	addl	%edx, %ecx
	imulq	$1290168, %rcx, %rax
	shrq	$32, %rax
	imull	$3329, %eax, %eax
	subl	%eax, %ecx
	movw	%cx, (%r15,%rsi,2)
	incq	%rsi
	movq	%r14, %rax
	addq	%rsi, %rax
	jne	.LBB79_12
	addq	%r10, %r12
	addq	%rbx, %r15
	testq	%rdi, %rdi
	jne	.LBB79_3
	movq	56(%rsp), %rax
	movl	%eax, %r8d
	movq	64(%rsp), %rax
	jmp	.LBB79_8
.LBB79_9:
	movl	$512, %r8d
	movq	48(%rsp), %rsi
	movq	%rsi, %rcx
	movq	40(%rsp), %rdx
	callq	memcpy
	movq	%rsi, %rax
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB79_13:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.61(%rip), %r8
	movl	$256, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly4plus;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly4plus,unique,80
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly4plus
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly4plus:
	pushq	%rsi
	subq	$544, %rsp
	movq	%rcx, %rsi
	movl	$1, %eax
	.p2align	4
.LBB80_1:
	movzwl	-2(%rdx,%rax,2), %ecx
	movzwl	-2(%r8,%rax,2), %r9d
	addl	%ecx, %r9d
	imulq	$1290168, %r9, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %r9d
	movw	%r9w, 30(%rsp,%rax,2)
	movzwl	(%rdx,%rax,2), %ecx
	movzwl	(%r8,%rax,2), %r9d
	addl	%ecx, %r9d
	imulq	$1290168, %r9, %rcx
	shrq	$32, %rcx
	imull	$3329, %ecx, %ecx
	subl	%ecx, %r9d
	movw	%r9w, 32(%rsp,%rax,2)
	addq	$2, %rax
	cmpq	$257, %rax
	jne	.LBB80_1
	leaq	32(%rsp), %rdx
	movl	$512, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movq	%rsi, %rax
	addq	$544, %rsp
	popq	%rsi
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly6encode;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly6encode,unique,81
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly6encode
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly6encode:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$64, %rsp
	movq	%r9, 48(%rsp)
	movq	%rdx, %rax
	shlq	$5, %rax
	movq	%rax, 56(%rsp)
	cmpq	%rax, %r9
	jne	.LBB81_9
	movq	%r9, %rsi
	movq	%r8, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %r14
	movq	%r8, %rcx
	xorl	%edx, %edx
	movq	%r9, %r8
	callq	memset
	testq	%rbx, %rbx
	je	.LBB81_7
	xorl	%r8d, %r8d
	xorl	%edx, %edx
	.p2align	4
.LBB81_3:
	leaq	1(%r8), %r9
	xorl	%ecx, %ecx
	.p2align	4
.LBB81_4:
	leaq	(%rdx,%rcx), %rax
	shrq	$3, %rax
	cmpq	%rsi, %rax
	jae	.LBB81_8
	leaq	1(%rcx), %r10
	movzwl	(%r14,%r8,2), %r11d
	movl	%ecx, %ebp
	andl	$15, %ebp
	btl	%ebp, %r11d
	setb	%r11b
	addl	%edx, %ecx
	andb	$7, %cl
	shlb	%cl, %r11b
	orb	%r11b, (%rdi,%rax)
	movq	%r10, %rcx
	cmpq	%r10, %rbx
	jne	.LBB81_4
	addq	%rbx, %rdx
	movq	%r9, %r8
	cmpq	$256, %r9
	jne	.LBB81_3
.LBB81_7:
	addq	$64, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq
.LBB81_8:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.63(%rip), %r8
	movq	%rax, %rcx
	movq	%rsi, %rdx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB81_9:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.62(%rip), %rax
	movq	%rax, 40(%rsp)
	leaq	48(%rsp), %rdx
	leaq	56(%rsp), %r8
	xorl	%ecx, %ecx
	xorl	%r9d, %r9d
	callq	_RINvNtCsbOZu4GxVKn0_4core9panicking13assert_failedjjEB4_
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly7inverse;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly7inverse,unique,82
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB4_4Poly7inverse:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$56, %rsp
	movq	%rdx, 32(%rsp)
	movq	%rcx, 48(%rsp)
	movl	$2, %eax
	movq	%rax, 40(%rsp)
	movb	$127, %r8b
	movl	$2642262849, %r10d
	jmp	.LBB82_1
	.p2align	4
.LBB82_2:
	cmpq	$65, %r11
	jae	.LBB82_3
.LBB82_1:
	movq	40(%rsp), %r11
	leaq	(%r11,%r11), %rax
	rep		bsfl	%eax, %ecx
	movl	$256, %esi
	shrl	%cl, %esi
	movq	%rax, 40(%rsp)
	decl	%eax
	btl	$8, %eax
	adcq	$0, %rsi
	je	.LBB82_2
	movq	32(%rsp), %rbx
	xorl	%r14d, %r14d
	.p2align	4
.LBB82_7:
	movl	%r8d, %eax
	rolb	$4, %al
	movl	%eax, %ecx
	andb	$51, %cl
	shlb	$2, %cl
	shrb	$2, %al
	andb	$51, %al
	orb	%cl, %al
	movl	%eax, %ecx
	andb	$85, %cl
	addb	%cl, %cl
	shrb	%al
	andb	$84, %al
	orb	%cl, %al
	shrb	%al
	je	.LBB82_8
	movzbl	%al, %eax
	movw	$17, %r15w
	movw	$1, %cx
	jmp	.LBB82_15
	.p2align	4
.LBB82_20:
	movzwl	%cx, %ecx
	movzwl	%r15w, %r15d
	imull	%r15d, %ecx
	imulq	$989558401, %rcx, %rdx
	shrq	$32, %rdx
	movl	%ecx, %r9d
	subl	%edx, %r9d
	shrl	%r9d
	addl	%edx, %r9d
	shrl	$11, %r9d
	imull	$3329, %r9d, %edx
	subl	%edx, %ecx
.LBB82_21:
	imull	%r15d, %r15d
	movq	%r15, %rdx
	imulq	%r10, %rdx
	shrq	$43, %rdx
	imull	$3329, %edx, %edx
	subl	%edx, %r15d
	shrl	%eax
	je	.LBB82_9
.LBB82_15:
	testb	$1, %al
	jne	.LBB82_20
	movzwl	%r15w, %r15d
	jmp	.LBB82_21
	.p2align	4
.LBB82_9:
	movzwl	%cx, %ebp
	jmp	.LBB82_10
	.p2align	4
.LBB82_8:
	movl	$1, %ebp
.LBB82_10:
	leaq	(%r11,%r11), %rax
	leaq	(%r14,%rax), %r15
	decq	%rsi
	decb	%r8b
	leaq	(%r11,%r14), %r12
	leaq	(%rbx,%rax), %r13
	xorl	%eax, %eax
	.p2align	4
.LBB82_11:
	leaq	(%r14,%rax), %rcx
	cmpq	$255, %rcx
	ja	.LBB82_17
	leaq	(%r12,%rax), %rcx
	cmpq	$256, %rcx
	jae	.LBB82_19
	movzwl	(%rbx,%rax,2), %edi
	movzwl	(%r13,%rax,2), %ecx
	leal	(%rcx,%rdi), %edx
	imulq	$1290168, %rdx, %r9
	shrq	$32, %r9
	imull	$3329, %r9d, %r9d
	subl	%r9d, %edx
	movw	%dx, (%rbx,%rax,2)
	subl	%edi, %ecx
	addl	$3329, %ecx
	imulq	$989558401, %rcx, %rdx
	shrq	$32, %rdx
	movl	%ecx, %r9d
	subl	%edx, %r9d
	shrl	%r9d
	addl	%edx, %r9d
	shrl	$11, %r9d
	imull	$3329, %r9d, %edx
	subl	%edx, %ecx
	imull	%ebp, %ecx
	imulq	$330282857, %rcx, %rdx
	shrq	$40, %rdx
	imull	$3329, %edx, %edx
	subl	%edx, %ecx
	movw	%cx, (%r13,%rax,2)
	incq	%rax
	cmpq	%rax, %r11
	jne	.LBB82_11
	leaq	(,%r11,4), %rax
	addq	%rax, %rbx
	movq	%r15, %r14
	testq	%rsi, %rsi
	jne	.LBB82_7
	jmp	.LBB82_2
.LBB82_3:
	movl	$2, %eax
	movq	32(%rsp), %rdx
	.p2align	4
.LBB82_4:
	movzwl	-2(%rdx,%rax), %ecx
	imull	$3303, %ecx, %ecx
	imulq	$330282857, %rcx, %r8
	shrq	$40, %r8
	imull	$3329, %r8d, %r8d
	subl	%r8d, %ecx
	movw	%cx, -2(%rdx,%rax)
	movzwl	(%rdx,%rax), %ecx
	imull	$3303, %ecx, %ecx
	imulq	$330282857, %rcx, %r8
	shrq	$40, %r8
	imull	$3329, %r8d, %r8d
	subl	%r8d, %ecx
	movw	%cx, (%rdx,%rax)
	addq	$4, %rax
	cmpq	$514, %rax
	jne	.LBB82_4
	movl	$512, %r8d
	movq	48(%rsp), %rcx
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	jmp	memcpy
.LBB82_17:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.64(%rip), %r8
	movl	$256, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB82_19:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.65(%rip), %r8
	movl	$256, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge3new;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge3new,unique,83
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge3new:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$264, %rsp
	movq	%r9, %r14
	movl	%r8d, %ebx
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	cmpq	$72, %rdx
	je	.LBB83_3
	cmpl	$136, %edi
	je	.LBB83_3
	cmpl	$168, %edi
	jne	.LBB83_18
.LBB83_3:
	movq	368(%rsp), %r12
	xorl	%r15d, %r15d
	leaq	48(%rsp), %rcx
	movl	$200, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	%rdi, 248(%rsp)
	movq	$0, 256(%rsp)
	testq	%r12, %r12
	je	.LBB83_4
	movq	%rsi, 40(%rsp)
	shlq	$4, %r12
	addq	%r14, %r12
	xorl	%ecx, %ecx
	leaq	48(%rsp), %r15
	jmp	.LBB83_8
	.p2align	4
.LBB83_7:
	addq	$16, %r14
	cmpq	%r12, %r14
	je	.LBB83_14
.LBB83_8:
	movq	8(%r14), %r13
	testq	%r13, %r13
	je	.LBB83_7
	movq	(%r14), %rbp
	xorl	%esi, %esi
	jmp	.LBB83_10
	.p2align	4
.LBB83_13:
	incq	%rsi
	cmpq	%rsi, %r13
	je	.LBB83_7
.LBB83_10:
	movq	%rcx, %rax
	shrq	$3, %rax
	cmpq	$199, %rcx
	ja	.LBB83_16
	movzbl	(%rbp,%rsi), %edx
	shll	$3, %ecx
	shlq	%cl, %rdx
	xorq	%rdx, 48(%rsp,%rax,8)
	movq	256(%rsp), %rcx
	incq	%rcx
	movq	%rcx, 256(%rsp)
	cmpq	%rdi, %rcx
	jne	.LBB83_13
	movq	%r15, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 256(%rsp)
	xorl	%ecx, %ecx
	jmp	.LBB83_13
.LBB83_14:
	movq	%rcx, %r15
	shrq	$3, %r15
	cmpq	$200, %rcx
	jae	.LBB83_17
	movq	40(%rsp), %rsi
	jmp	.LBB83_5
.LBB83_4:
	xorl	%ecx, %ecx
.LBB83_5:
	movzbl	%bl, %eax
	shll	$3, %ecx
	shlq	%cl, %rax
	xorq	%rax, 48(%rsp,%r15,8)
	decq	%rdi
	leal	(,%rdi,8), %ecx
	movl	$128, %eax
	shlq	%cl, %rax
	andq	$-8, %rdi
	xorq	%rax, 48(%rsp,%rdi)
	leaq	48(%rsp), %rdi
	movq	%rdi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 256(%rsp)
	movl	$216, %r8d
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	memcpy
	addq	$264, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB83_16:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.69(%rip), %r8
	movl	$25, %edx
	movq	%rax, %rcx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB83_17:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.70(%rip), %r8
	movl	$25, %edx
	movq	%r15, %rcx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB83_18:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.66(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.68(%rip), %r8
	movl	$48, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking5panic
	ud2

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute,unique,84
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$936, %rsp
	movq	%rcx, %r13
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 728(%rsp)
	movq	$24, 736(%rsp)
	leaq	744(%rsp), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.72(%rip), %rdx
	movl	$192, %r8d
	callq	memcpy
	movq	(%r13), %rax
	movq	%rax, 32(%rsp)
	movq	8(%r13), %rax
	movq	%rax, 120(%rsp)
	movq	120(%r13), %r8
	movq	160(%r13), %r11
	movq	128(%r13), %rax
	movq	%rax, 72(%rsp)
	movq	168(%r13), %rax
	movq	%rax, 64(%rsp)
	movq	136(%r13), %rax
	movq	%rax, 152(%rsp)
	movq	176(%r13), %rax
	movq	%rax, 144(%rsp)
	movq	104(%r13), %rax
	movq	%rax, 136(%rsp)
	movq	144(%r13), %rax
	movq	%rax, 128(%rsp)
	movq	184(%r13), %rbp
	movq	112(%r13), %rax
	movq	%rax, 112(%rsp)
	movq	152(%r13), %rax
	movq	%rax, 104(%rsp)
	movq	192(%r13), %rax
	movq	%rax, 96(%rsp)
	movq	40(%r13), %rax
	movq	%rax, 160(%rsp)
	movq	80(%r13), %rbx
	movq	48(%r13), %r14
	movq	88(%r13), %rsi
	movq	16(%r13), %rax
	movq	%rax, 176(%rsp)
	movq	56(%r13), %r15
	movq	96(%r13), %rax
	movq	24(%r13), %rcx
	movq	%rcx, 88(%rsp)
	movq	64(%r13), %r12
	movq	32(%r13), %rcx
	movq	%rcx, 80(%rsp)
	movq	%r13, 416(%rsp)
	movq	72(%r13), %r13
	movl	$2, %r10d
	.p2align	4
.LBB84_1:
	movq	%r8, 48(%rsp)
	movq	%rbp, 168(%rsp)
	movq	%r10, 608(%rsp)
	movq	%rbx, 56(%rsp)
	xorq	%r8, %rbx
	movq	%r11, 40(%rsp)
	xorq	32(%rsp), %r11
	xorq	%rbx, %r11
	movq	64(%rsp), %rcx
	xorq	72(%rsp), %rcx
	movq	120(%rsp), %r10
	xorq	%r14, %r10
	xorq	%rcx, %r10
	movq	144(%rsp), %rcx
	xorq	152(%rsp), %rcx
	movq	176(%rsp), %rdi
	movq	%rdi, %r8
	xorq	%r15, %r8
	xorq	%rcx, %r8
	movq	128(%rsp), %rcx
	xorq	136(%rsp), %rcx
	movq	%rbp, %rdx
	xorq	88(%rsp), %rdx
	xorq	%rcx, %rdx
	movq	104(%rsp), %rcx
	xorq	112(%rsp), %rcx
	movq	96(%rsp), %rbp
	xorq	80(%rsp), %rbp
	xorq	%rcx, %rbp
	xorq	160(%rsp), %r11
	xorq	%rsi, %r10
	xorq	%rax, %r8
	xorq	%r12, %rdx
	movq	%r10, %r9
	rolq	%r9
	xorq	%r13, %rbp
	movq	%rdi, %rcx
	movq	%r8, %rdi
	rolq	%rdi
	xorq	%rbp, %r9
	movq	%rdx, %rbx
	rolq	%rbx
	xorq	%r11, %rdi
	movq	%rbp, 560(%rsp)
	rolq	%rbp
	movq	%r10, 584(%rsp)
	xorq	%r10, %rbx
	movq	%r11, 592(%rsp)
	rolq	%r11
	movq	%r8, 576(%rsp)
	xorq	%r8, %rbp
	movq	%rdx, 568(%rsp)
	xorq	%rdx, %r11
	movq	32(%rsp), %rdx
	xorq	%r9, %rdx
	movq	%rdx, 240(%rsp)
	movq	120(%rsp), %rdx
	xorq	%rdi, %rdx
	rolq	%rdx
	movq	%rdx, 232(%rsp)
	xorq	%rbx, %rcx
	rolq	$62, %rcx
	movq	%rcx, 600(%rsp)
	movq	88(%rsp), %rcx
	xorq	%rbp, %rcx
	rolq	$28, %rcx
	movq	80(%rsp), %rdx
	xorq	%r11, %rdx
	rolq	$27, %rdx
	movq	%rdx, 224(%rsp)
	movq	160(%rsp), %rdx
	xorq	%r9, %rdx
	rolq	$36, %rdx
	movq	%rdx, 216(%rsp)
	xorq	%rdi, %r14
	rolq	$44, %r14
	xorq	%rbx, %r15
	rolq	$6, %r15
	movq	%r15, 208(%rsp)
	xorq	%rbp, %r12
	rolq	$55, %r12
	movq	%r12, 184(%rsp)
	xorq	%r11, %r13
	movq	%r13, %rdx
	rolq	$20, %rdx
	movq	56(%rsp), %r12
	xorq	%r9, %r12
	rolq	$3, %r12
	xorq	%rdi, %rsi
	rolq	$10, %rsi
	movq	%rsi, 56(%rsp)
	xorq	%rbx, %rax
	movq	%rax, %rsi
	rolq	$43, %rsi
	movq	136(%rsp), %r10
	xorq	%rbp, %r10
	rolq	$25, %r10
	movq	112(%rsp), %rax
	xorq	%r11, %rax
	rolq	$39, %rax
	movq	%rax, 200(%rsp)
	movq	48(%rsp), %rax
	xorq	%r9, %rax
	rolq	$41, %rax
	movq	%rax, 48(%rsp)
	movq	72(%rsp), %r13
	xorq	%rdi, %r13
	rolq	$45, %r13
	movq	152(%rsp), %rax
	xorq	%rbx, %rax
	rolq	$15, %rax
	movq	%rax, 192(%rsp)
	movq	128(%rsp), %r15
	xorq	%rbp, %r15
	rolq	$21, %r15
	movq	104(%rsp), %r8
	xorq	%r11, %r8
	rolq	$8, %r8
	movq	%r9, 552(%rsp)
	movq	40(%rsp), %rax
	xorq	%r9, %rax
	movq	%rax, %r9
	rolq	$18, %r9
	movq	%rdi, 544(%rsp)
	movq	64(%rsp), %rax
	xorq	%rdi, %rax
	rolq	$2, %rax
	movq	%rax, 40(%rsp)
	movq	%rbx, 528(%rsp)
	movq	144(%rsp), %rax
	xorq	%rbx, %rax
	movq	%rax, %rbx
	rolq	$61, %rbx
	movq	%rbp, 536(%rsp)
	movq	168(%rsp), %rax
	xorq	%rbp, %rax
	movq	%rax, %rbp
	rolq	$56, %rbp
	movq	%r11, 168(%rsp)
	movq	96(%rsp), %rax
	xorq	%r11, %rax
	movq	%rax, %r11
	rolq	$14, %r11
	movq	%r14, %rax
	notq	%rax
	andq	%rsi, %rax
	movq	%rax, 32(%rsp)
	movq	%rsi, %rax
	notq	%rax
	andq	%r15, %rax
	xorq	%r14, %rax
	movq	%rax, 120(%rsp)
	movq	%r15, %rax
	notq	%rax
	andq	%r11, %rax
	movq	%rsi, 488(%rsp)
	xorq	%rsi, %rax
	movq	%rax, 176(%rsp)
	movq	%r11, %rax
	notq	%rax
	movq	240(%rsp), %rsi
	andq	%rsi, %rax
	movq	%r15, 464(%rsp)
	xorq	%r15, %rax
	movq	%rax, 88(%rsp)
	movq	%rsi, %rax
	notq	%rax
	movq	%r14, 512(%rsp)
	andq	%r14, %rax
	movq	%r11, 424(%rsp)
	xorq	%r11, %rax
	movq	%rax, 80(%rsp)
	movq	%rdx, %rax
	notq	%rax
	andq	%r12, %rax
	xorq	%rcx, %rax
	movq	%rax, 160(%rsp)
	movq	%r12, %r14
	notq	%r14
	andq	%r13, %r14
	xorq	%rdx, %r14
	movq	%r13, %r15
	notq	%r15
	andq	%rbx, %r15
	movq	%r12, 496(%rsp)
	xorq	%r12, %r15
	movq	%rbx, %r12
	notq	%r12
	andq	%rcx, %r12
	movq	%r13, 472(%rsp)
	xorq	%r13, %r12
	movq	%rcx, 520(%rsp)
	movq	%rcx, %r13
	notq	%r13
	movq	%rdx, 504(%rsp)
	andq	%rdx, %r13
	movq	%rbx, 440(%rsp)
	xorq	%rbx, %r13
	movq	208(%rsp), %rax
	movq	%rax, %rbx
	notq	%rbx
	andq	%r10, %rbx
	movq	232(%rsp), %rcx
	xorq	%rcx, %rbx
	movq	%r10, %rsi
	notq	%rsi
	andq	%r8, %rsi
	xorq	%rax, %rsi
	movq	%rax, %r11
	movq	%r8, %rax
	notq	%rax
	andq	%r9, %rax
	movq	%r10, 480(%rsp)
	xorq	%r10, %rax
	movq	%r9, %rdx
	notq	%rdx
	andq	%rcx, %rdx
	movq	%r8, 456(%rsp)
	xorq	%r8, %rdx
	movq	%rdx, 136(%rsp)
	movq	%rcx, %rdx
	notq	%rdx
	andq	%r11, %rdx
	movq	%r9, 448(%rsp)
	xorq	%r9, %rdx
	movq	%rdx, 112(%rsp)
	movq	216(%rsp), %r9
	movq	%r9, %r8
	notq	%r8
	movq	56(%rsp), %r10
	andq	%r10, %r8
	movq	224(%rsp), %rcx
	xorq	%rcx, %r8
	movq	%r10, %rdx
	notq	%rdx
	movq	192(%rsp), %r11
	andq	%r11, %rdx
	xorq	%r9, %rdx
	movq	%rdx, 72(%rsp)
	movq	%r11, %rdx
	notq	%rdx
	andq	%rbp, %rdx
	xorq	%r10, %rdx
	movq	%rdx, 152(%rsp)
	movq	%rbp, %rdx
	notq	%rdx
	andq	%rcx, %rdx
	xorq	%r11, %rdx
	movq	%rdx, 128(%rsp)
	movq	%rcx, %rdx
	notq	%rdx
	andq	%r9, %rdx
	movq	%rbp, 432(%rsp)
	xorq	%rbp, %rdx
	movq	%rdx, 104(%rsp)
	movq	184(%rsp), %rcx
	movq	%rcx, %r11
	notq	%r11
	movq	200(%rsp), %rdi
	andq	%rdi, %r11
	movq	600(%rsp), %r9
	xorq	%r9, %r11
	movq	%rdi, %rdx
	notq	%rdx
	movq	48(%rsp), %r10
	andq	%r10, %rdx
	xorq	%rcx, %rdx
	movq	%rdx, 64(%rsp)
	movq	%r10, %rbp
	notq	%rbp
	movq	40(%rsp), %rdx
	andq	%rdx, %rbp
	xorq	%rdi, %rbp
	movq	%rbp, 144(%rsp)
	movq	%rdx, %rbp
	movq	%rdx, %rdi
	notq	%rbp
	andq	%r9, %rbp
	xorq	%r10, %rbp
	movq	%r9, %rdx
	notq	%r9
	andq	%rcx, %r9
	movq	608(%rsp), %rcx
	movq	32(%rsp), %r10
	xorq	728(%rsp,%rcx,8), %r10
	xorq	%rdi, %r9
	movq	%r9, 96(%rsp)
	movq	240(%rsp), %rdi
	xorq	%rdi, %r10
	movq	%r10, 32(%rsp)
	incq	%rcx
	movq	%rcx, %r10
	cmpq	$26, %rcx
	jne	.LBB84_1
	movq	416(%rsp), %r10
	movq	120(%rsp), %rcx
	movq	%rcx, 8(%r10)
	movq	%r14, 48(%r10)
	movq	%rsi, 88(%r10)
	movq	176(%rsp), %rcx
	movq	%rcx, 16(%r10)
	movq	%r15, 56(%r10)
	movq	%rax, 96(%r10)
	movq	88(%rsp), %rax
	movq	%rax, 24(%r10)
	movq	%r12, 64(%r10)
	movq	80(%rsp), %rax
	movq	%rax, 32(%r10)
	movq	%r13, 72(%r10)
	movq	%rbx, 80(%r10)
	movq	136(%rsp), %rax
	movq	%rax, 104(%r10)
	movq	112(%rsp), %rax
	movq	%rax, 112(%r10)
	movq	%r8, 120(%r10)
	movq	72(%rsp), %rax
	movq	%rax, 128(%r10)
	movq	152(%rsp), %rax
	movq	%rax, 136(%r10)
	movq	128(%rsp), %rax
	movq	%rax, 144(%r10)
	movq	104(%rsp), %rax
	movq	%rax, 152(%r10)
	movq	%r11, 160(%r10)
	movq	64(%rsp), %rax
	movq	%rax, 168(%r10)
	movq	144(%rsp), %rax
	movq	%rax, 176(%r10)
	movq	%rbp, 184(%r10)
	movq	96(%rsp), %rax
	movq	%rax, 192(%r10)
	movq	32(%rsp), %rax
	movq	%rax, (%r10)
	movq	160(%rsp), %rax
	movq	%rax, 40(%r10)
	movq	592(%rsp), %rax
	movq	%rax, 280(%rsp)
	movq	584(%rsp), %rax
	movq	%rax, 272(%rsp)
	movq	576(%rsp), %rax
	movq	%rax, 264(%rsp)
	movq	568(%rsp), %rax
	movq	%rax, 256(%rsp)
	movq	560(%rsp), %rax
	movq	%rax, 248(%rsp)
	movq	552(%rsp), %rax
	movq	%rax, 320(%rsp)
	movq	544(%rsp), %rax
	movq	%rax, 312(%rsp)
	movq	528(%rsp), %rax
	movq	%rax, 304(%rsp)
	movq	536(%rsp), %rax
	movq	%rax, 296(%rsp)
	movq	168(%rsp), %rax
	movq	%rax, 288(%rsp)
	movq	%rdi, 408(%rsp)
	movq	232(%rsp), %rax
	movq	%rax, 336(%rsp)
	movq	%rdx, 648(%rsp)
	movq	520(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	224(%rsp), %rax
	movq	%rax, 688(%rsp)
	movq	216(%rsp), %rax
	movq	%rax, 680(%rsp)
	movq	512(%rsp), %rax
	movq	%rax, 400(%rsp)
	movq	208(%rsp), %rax
	movq	%rax, 328(%rsp)
	movq	184(%rsp), %rax
	movq	%rax, 640(%rsp)
	movq	504(%rsp), %rax
	movq	%rax, 360(%rsp)
	movq	496(%rsp), %rax
	movq	%rax, 352(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 672(%rsp)
	movq	488(%rsp), %rax
	movq	%rax, 392(%rsp)
	movq	480(%rsp), %rax
	movq	%rax, 712(%rsp)
	movq	200(%rsp), %rax
	movq	%rax, 632(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 624(%rsp)
	movq	472(%rsp), %rax
	movq	%rax, 344(%rsp)
	movq	192(%rsp), %rax
	movq	%rax, 664(%rsp)
	movq	464(%rsp), %rax
	movq	%rax, 384(%rsp)
	movq	456(%rsp), %rax
	movq	%rax, 704(%rsp)
	movq	448(%rsp), %rax
	movq	%rax, 696(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, 616(%rsp)
	movq	440(%rsp), %rax
	movq	%rax, 720(%rsp)
	movq	432(%rsp), %rax
	movq	%rax, 656(%rsp)
	movq	424(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 616(%rsp)
	#MEMBARRIER
	addq	$936, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6x25519NtB4_9SecretKey10public_key;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6x25519NtB4_9SecretKey10public_key,unique,85
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6x25519NtB4_9SecretKey10public_key
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6x25519NtB4_9SecretKey10public_key:
	pushq	%rsi
	subq	$96, %rsp
	movq	%rcx, %rsi
	movq	$0, 88(%rsp)
	movq	$0, 81(%rsp)
	movq	$0, 73(%rsp)
	movq	$0, 65(%rsp)
	movb	$9, 64(%rsp)
	leaq	32(%rsp), %rcx
	leaq	64(%rsp), %r8
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6x255198multiply
	movq	56(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	48(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$96, %rsp
	popq	%rsi
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6x25519NtB4_9SecretKey5agree;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6x25519NtB4_9SecretKey5agree,unique,86
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6x25519NtB4_9SecretKey5agree
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6x25519NtB4_9SecretKey5agree:
	pushq	%rsi
	pushq	%rdi
	subq	$72, %rsp
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	32(%rsp), %rcx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6x255198multiply
	movzbl	32(%rsp), %eax
	orb	33(%rsp), %al
	orb	34(%rsp), %al
	orb	35(%rsp), %al
	orb	36(%rsp), %al
	orb	37(%rsp), %al
	orb	38(%rsp), %al
	orb	39(%rsp), %al
	orb	40(%rsp), %al
	orb	41(%rsp), %al
	orb	42(%rsp), %al
	orb	43(%rsp), %al
	orb	44(%rsp), %al
	orb	45(%rsp), %al
	orb	46(%rsp), %al
	orb	47(%rsp), %al
	orb	48(%rsp), %al
	orb	49(%rsp), %al
	orb	50(%rsp), %al
	orb	51(%rsp), %al
	orb	52(%rsp), %al
	orb	53(%rsp), %al
	orb	54(%rsp), %al
	orb	55(%rsp), %al
	orb	56(%rsp), %al
	orb	57(%rsp), %al
	orb	58(%rsp), %al
	orb	59(%rsp), %al
	orb	60(%rsp), %al
	orb	61(%rsp), %al
	orb	62(%rsp), %al
	xorl	%ecx, %ecx
	orb	63(%rsp), %al
	setne	%cl
	movq	%rcx, 64(%rsp)
	cmpq	$0, 64(%rsp)
	je	.LBB86_2
	leaq	1(%rsi), %rax
	movq	56(%rsp), %rcx
	movq	%rcx, 24(%rax)
	movq	48(%rsp), %rcx
	movq	%rcx, 16(%rax)
	movq	32(%rsp), %rcx
	movq	40(%rsp), %rdx
	movq	%rdx, 8(%rax)
	movq	%rcx, (%rax)
	movb	$0, (%rsi)
	jmp	.LBB86_3
.LBB86_2:
	movw	$769, (%rsi)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
.LBB86_3:
	movb	$0, (%rdi)
	movb	$0, 1(%rdi)
	movb	$0, 2(%rdi)
	movb	$0, 3(%rdi)
	movb	$0, 4(%rdi)
	movb	$0, 5(%rdi)
	movb	$0, 6(%rdi)
	movb	$0, 7(%rdi)
	movb	$0, 8(%rdi)
	movb	$0, 9(%rdi)
	movb	$0, 10(%rdi)
	movb	$0, 11(%rdi)
	movb	$0, 12(%rdi)
	movb	$0, 13(%rdi)
	movb	$0, 14(%rdi)
	movb	$0, 15(%rdi)
	movb	$0, 16(%rdi)
	movb	$0, 17(%rdi)
	movb	$0, 18(%rdi)
	movb	$0, 19(%rdi)
	movb	$0, 20(%rdi)
	movb	$0, 21(%rdi)
	movb	$0, 22(%rdi)
	movb	$0, 23(%rdi)
	movb	$0, 24(%rdi)
	movb	$0, 25(%rdi)
	movb	$0, 26(%rdi)
	movb	$0, 27(%rdi)
	movb	$0, 28(%rdi)
	movb	$0, 29(%rdi)
	movb	$0, 30(%rdi)
	movb	$0, 31(%rdi)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes,unique,87
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB4_9PublicKey10from_bytes:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$552, %rsp
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	192(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point6decode
	cmpb	$1, 192(%rsp)
	jne	.LBB87_2
	movzbl	193(%rsp), %eax
	movb	%al, 1(%rsi)
	movb	$1, (%rsi)
	jmp	.LBB87_5
.LBB87_2:
	leaq	200(%rsp), %rdx
	leaq	392(%rsp), %rbx
	movl	$160, %r8d
	movq	%rbx, %rcx
	callq	memcpy
	leaq	32(%rsp), %r14
	movl	$160, %r8d
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	memcpy
	movq	%r14, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point11small_order
	testb	%al, %al
	je	.LBB87_3
	movw	$513, (%rsi)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	jmp	.LBB87_5
.LBB87_3:
	leaq	224(%rsp), %rcx
	leaq	32(%rsp), %rdx
	movl	$160, %r8d
	callq	memcpy
	movq	(%rdi), %rax
	movq	8(%rdi), %rcx
	movq	%rax, 192(%rsp)
	movq	%rcx, 200(%rsp)
	movq	16(%rdi), %rax
	movq	%rax, 208(%rsp)
	movq	24(%rdi), %rax
	movq	%rax, 216(%rsp)
	leaq	8(%rsi), %rcx
	leaq	192(%rsp), %rdx
	movl	$192, %r8d
	callq	memcpy
	movb	$0, (%rsi)
.LBB87_5:
	movq	%rsi, %rax
	addq	$552, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq

	.def	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB4_9PublicKey6verify;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB4_9PublicKey6verify,unique,88
	.globl	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB4_9PublicKey6verify
	.p2align	4
_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB4_9PublicKey6verify:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$1336, %rsp
	cmpq	$64, 1440(%rsp)
	jne	.LBB88_1
	movq	%rdx, %rbx
	movq	%r8, %rdi
	movq	%rcx, 72(%rsp)
	leaq	560(%rsp), %rcx
	movq	%r9, %r12
	movq	%r9, %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point6decode
	cmpb	$1, 560(%rsp)
	jne	.LBB88_4
	movzbl	561(%rsp), %eax
	jmp	.LBB88_15
.LBB88_1:
	xorl	%eax, %eax
	jmp	.LBB88_15
.LBB88_4:
	leaq	568(%rsp), %rdx
	leaq	182(%rsp), %r14
	movl	$160, %r8d
	movq	%r14, %rcx
	callq	memcpy
	leaq	400(%rsp), %r15
	movl	$160, %r8d
	movq	%r15, %rcx
	movq	%r14, %rdx
	callq	memcpy
	movq	%r15, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point11small_order
	movl	%eax, %ecx
	movb	$5, %al
	testb	%cl, %cl
	jne	.LBB88_10
	movq	%r12, %rdx
	movq	32(%r12), %r10
	movq	40(%r12), %r9
	movq	48(%r12), %r8
	movq	56(%r12), %rcx
	movq	%r10, 168(%rsp)
	movq	%r9, 160(%rsp)
	movq	%r8, 152(%rsp)
	movq	%rcx, 144(%rsp)
	xorl	%r11d, %r11d
	movabsq	$-6346243789798364141, %rbp
	addq	%r10, %rbp
	movq	%r9, %r14
	adcq	$0, %r14
	adcq	$1, %r11
	movabsq	$-1503914060200516823, %r13
	addq	%r14, %r13
	adcq	$-1, %r11
	xorq	$1, %r11
	movq	%r8, %r15
	subq	%r11, %r15
	movl	$1, %r12d
	sbbq	$0, %r12
	xorl	%r14d, %r14d
	addq	%rcx, %r12
	setb	%r14b
	movabsq	$-1152921504606846977, %r11
	addq	%r12, %r11
	adcq	$0, %r14
	xorq	$1, %r14
	movq	%r14, 560(%rsp)
	movq	560(%rsp), %r12
	movq	%r12, %rsi
	decq	%r12
	andq	%rbp, %r12
	negq	%rsi
	andq	%r10, %rsi
	orq	%r12, %rsi
	movq	%r14, 560(%rsp)
	movq	560(%rsp), %r12
	movq	%r12, %r10
	decq	%r12
	andq	%r13, %r12
	negq	%r10
	andq	%r9, %r10
	orq	%r12, %r10
	movq	%r14, 560(%rsp)
	movq	560(%rsp), %r9
	movq	%r9, %r12
	decq	%r9
	andq	%r15, %r9
	negq	%r12
	andq	%r8, %r12
	orq	%r9, %r12
	movq	%r14, 560(%rsp)
	movq	560(%rsp), %r8
	movq	%r8, %r9
	negq	%r9
	decq	%r8
	andq	%r11, %r8
	andq	%rcx, %r9
	orq	%r8, %r9
	movq	%rsi, 856(%rsp)
	movq	%r10, 792(%rsp)
	movq	%r12, 112(%rsp)
	movq	%r9, 80(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 1176(%rsp)
	movq	$0, 1016(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	856(%rsp), %rcx
	movq	792(%rsp), %r8
	movq	112(%rsp), %r9
	movq	80(%rsp), %r10
	movl	%ecx, %ebp
	shrl	$8, %ebp
	movl	%ecx, %r14d
	shrl	$16, %r14d
	movl	%ecx, %r11d
	shrl	$24, %r11d
	movzbl	32(%rdx), %esi
	xorb	%cl, %sil
	xorb	33(%rdx), %bpl
	orb	%sil, %bpl
	movq	%rcx, %rsi
	xorb	34(%rdx), %r14b
	xorb	35(%rdx), %r11b
	shrq	$32, %rsi
	orb	%r14b, %r11b
	movq	%rcx, %r15
	shrq	$40, %r15
	orb	%bpl, %r11b
	movq	%rcx, %r14
	xorb	36(%rdx), %sil
	shrq	$48, %r14
	xorb	37(%rdx), %r15b
	orb	%sil, %r15b
	movq	%rcx, %rsi
	shrq	$56, %rsi
	xorb	38(%rdx), %r14b
	orb	%r15b, %r14b
	movl	%r8d, %ebp
	shrl	$8, %ebp
	orb	%r11b, %r14b
	xorb	39(%rdx), %sil
	movzbl	40(%rdx), %r15d
	xorb	%r8b, %r15b
	orb	%sil, %r15b
	movl	%r8d, %r11d
	xorb	41(%rdx), %bpl
	shrl	$16, %r11d
	orb	%r15b, %bpl
	movl	%r8d, %esi
	shrl	$24, %esi
	xorb	42(%rdx), %r11b
	orb	%bpl, %r11b
	movq	%r8, %r15
	shrq	$32, %r15
	orb	%r14b, %r11b
	movq	%r8, %r12
	shrq	$40, %r12
	xorb	43(%rdx), %sil
	xorb	44(%rdx), %r15b
	orb	%sil, %r15b
	movq	%r8, %rsi
	xorb	45(%rdx), %r12b
	shrq	$48, %rsi
	orb	%r15b, %r12b
	movq	%r8, %r14
	shrq	$56, %r14
	xorb	46(%rdx), %sil
	orb	%r12b, %sil
	movl	%r9d, %ebp
	shrl	$8, %ebp
	xorb	47(%rdx), %r14b
	orb	%sil, %r14b
	movl	%r9d, %esi
	shrl	$16, %esi
	orb	%r11b, %r14b
	movzbl	48(%rdx), %r11d
	xorb	%r9b, %r11b
	xorb	49(%rdx), %bpl
	orb	%r11b, %bpl
	movl	%r9d, %r15d
	shrl	$24, %r15d
	xorb	50(%rdx), %sil
	orb	%bpl, %sil
	movq	%r9, %r12
	xorb	51(%rdx), %r15b
	shrq	$32, %r12
	orb	%sil, %r15b
	movq	%r9, %r11
	shrq	$40, %r11
	xorb	52(%rdx), %r12b
	orb	%r15b, %r12b
	movq	%r9, %rsi
	shrq	$48, %rsi
	xorb	53(%rdx), %r11b
	orb	%r12b, %r11b
	movq	%r9, %r15
	shrq	$56, %r15
	orb	%r14b, %r11b
	movl	%r10d, %ebp
	xorb	54(%rdx), %sil
	xorb	55(%rdx), %r15b
	shrl	$8, %ebp
	orb	%sil, %r15b
	movzbl	56(%rdx), %esi
	xorb	%r10b, %sil
	orb	%r15b, %sil
	movl	%r10d, %r14d
	xorb	57(%rdx), %bpl
	shrl	$16, %r14d
	orb	%sil, %bpl
	movl	%r10d, %esi
	shrl	$24, %esi
	xorb	58(%rdx), %r14b
	xorb	59(%rdx), %sil
	orb	%bpl, %r14b
	orb	%r14b, %sil
	movq	%r10, %r14
	shrq	$32, %r14
	xorb	60(%rdx), %r14b
	orb	%sil, %r14b
	movq	%r10, %rsi
	shrq	$40, %rsi
	orb	%r11b, %r14b
	movq	%r10, %r11
	shrq	$48, %r11
	xorb	61(%rdx), %sil
	xorb	62(%rdx), %r11b
	orb	%sil, %r11b
	movq	%r10, %rsi
	shrq	$56, %rsi
	orb	%r14b, %r11b
	xorb	63(%rdx), %sil
	xorl	%r14d, %r14d
	orb	%r11b, %sil
	setne	%r14b
	movq	%r14, 560(%rsp)
	cmpq	$0, 560(%rsp)
	je	.LBB88_6
	movq	$0, 856(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 80(%rsp)
	#MEMBARRIER
	jmp	.LBB88_10
.LBB88_6:
	movq	%rcx, 64(%rsp)
	movq	%r8, 56(%rsp)
	movq	%r9, 48(%rsp)
	movq	%r10, 40(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movabsq	$7640891576956012808, %rax
	movq	%rax, 304(%rsp)
	movabsq	$-4942790177534073029, %rax
	movq	%rax, 312(%rsp)
	movabsq	$4354685564936845355, %rax
	movq	%rax, 320(%rsp)
	movabsq	$-6534734903238641935, %rax
	movq	%rax, 328(%rsp)
	movabsq	$5840696475078001361, %rax
	movq	%rax, 336(%rsp)
	movabsq	$-7276294671716946913, %rax
	movq	%rax, 344(%rsp)
	movabsq	$2270897969802886507, %rax
	movq	%rax, 352(%rsp)
	movabsq	$6620516959819538809, %rax
	movq	%rax, 360(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 368(%rsp)
	leaq	176(%rsp), %rcx
	movl	$32, %r8d
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update
	cmpb	$-1, %al
	jne	.LBB88_7
	leaq	176(%rsp), %rcx
	movl	$32, %r8d
	movq	72(%rsp), %rdx
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update
	cmpb	$-1, %al
	jne	.LBB88_7
	leaq	176(%rsp), %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update
	cmpb	$-1, %al
	je	.LBB88_14
.LBB88_7:
	xorl	%eax, %eax
	.p2align	4
.LBB88_8:
	movb	$0, 176(%rsp,%rax)
	movb	$0, 177(%rsp,%rax)
	movb	$0, 178(%rsp,%rax)
	movb	$0, 179(%rsp,%rax)
	movb	$0, 180(%rsp,%rax)
	movb	$0, 181(%rsp,%rax)
	movb	$0, 182(%rsp,%rax)
	movb	$0, 183(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB88_8
	#MEMBARRIER
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	xorl	%eax, %eax
.LBB88_10:
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	#MEMBARRIER
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	#MEMBARRIER
.LBB88_15:
	addq	$1336, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB88_14:
	leaq	560(%rsp), %rdi
	leaq	176(%rsp), %rdx
	movl	$224, %r8d
	movq	%rdi, %rcx
	callq	memcpy
	leaq	792(%rsp), %rbx
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5128finalize
	leaq	80(%rsp), %r14
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto11scalar25519NtB4_1S6reduce
	leaq	1016(%rsp), %rdi
	movq	%rdi, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point4base
	movq	64(%rsp), %rax
	movq	%rax, 112(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 120(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 128(%rsp)
	movq	40(%rsp), %rax
	movq	%rax, 136(%rsp)
	leaq	856(%rsp), %rbx
	leaq	112(%rsp), %r8
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3mul
	movq	72(%rsp), %rdx
	addq	$32, %rdx
	leaq	560(%rsp), %r15
	movq	%r15, %rcx
	movq	%r14, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3mul
	leaq	1176(%rsp), %r12
	leaq	400(%rsp), %rsi
	movq	%r12, %rcx
	movq	%rsi, %rdx
	movq	%r15, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point3add
	movq	%rbx, %rcx
	movq	%r12, %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto7ed25519NtB2_5Point2eq
	movq	%rax, %r14
	movq	%r12, %rcx
	callq	_RINvNtCsbOZu4GxVKn0_4core3ptr9drop_glueNtNtCs3ONsSsjNgxw_12toyos_crypto7ed255195PointEBF_
	movq	%r15, %rcx
	callq	_RINvNtCsbOZu4GxVKn0_4core3ptr9drop_glueNtNtCs3ONsSsjNgxw_12toyos_crypto7ed255195PointEBF_
	movq	%rbx, %rcx
	callq	_RINvNtCsbOZu4GxVKn0_4core3ptr9drop_glueNtNtCs3ONsSsjNgxw_12toyos_crypto7ed255195PointEBF_
	movq	%rdi, %rcx
	callq	_RINvNtCsbOZu4GxVKn0_4core3ptr9drop_glueNtNtCs3ONsSsjNgxw_12toyos_crypto7ed255195PointEBF_
	negb	%r14b
	orb	$5, %r14b
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	movq	%rsi, %rcx
	callq	_RINvNtCsbOZu4GxVKn0_4core3ptr9drop_glueNtNtCs3ONsSsjNgxw_12toyos_crypto7ed255195PointEBF_
	movq	%r14, %rax
	jmp	.LBB88_15

	.def	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest,unique,89
	.globl	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest
	.p2align	4
_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$888, %rsp
	movb	$4, %al
	cmpq	$6, %r9
	jb	.LBB89_31
	cmpb	$48, (%r8)
	jne	.LBB89_31
	movzbl	1(%r8), %r10d
	leaq	-2(%r9), %r11
	cmpq	%r10, %r11
	jne	.LBB89_31
	cmpb	$2, 2(%r8)
	jne	.LBB89_31
	movzbl	3(%r8), %r12d
	leaq	4(%r12), %r13
	cmpq	%r9, %r13
	ja	.LBB89_31
	testq	%r12, %r12
	je	.LBB89_31
	leaq	96(%rcx), %rsi
	leaq	4(%r8), %r10
	cmpb	$0, (%r10)
	js	.LBB89_31
	movq	%r12, %r11
	jne	.LBB89_11
	cmpl	$1, %r12d
	je	.LBB89_10
	cmpb	$0, 5(%r8)
	jns	.LBB89_31
.LBB89_10:
	leaq	-1(%r12), %r11
	leaq	5(%r8), %r10
.LBB89_11:
	movb	$5, %al
	cmpl	$33, %r11d
	jae	.LBB89_31
	movq	%r8, %rbx
	movq	%rdx, %r14
	movq	%rcx, 640(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	leaq	32(%rsp), %rdi
	movq	%rdi, %rcx
	subq	%r11, %rcx
	addq	$32, %rcx
	movq	%r10, %rdx
	movq	%r11, %r8
	movq	%r9, %r15
	callq	memcpy
	movzbl	32(%rsp), %ebp
	movq	33(%rsp), %rax
	movq	%rax, 256(%rsp)
	movq	41(%rsp), %rax
	movq	%rax, 264(%rsp)
	movq	49(%rsp), %rax
	movq	%rax, 272(%rsp)
	movq	57(%rsp), %rax
	movq	%rax, 280(%rsp)
	movq	65(%rsp), %rax
	movq	%rax, 288(%rsp)
	movq	72(%rsp), %rax
	movq	%rax, 295(%rsp)
	movb	$4, %al
	cmpq	%r15, %r13
	jae	.LBB89_31
	cmpb	$2, (%rbx,%r13)
	jne	.LBB89_31
	movq	%r15, %rcx
	leaq	5(%r12), %r8
	cmpq	%r15, %r8
	jae	.LBB89_31
	movzbl	5(%rbx,%r12), %r8d
	leaq	(%r12,%r8), %r13
	addq	$6, %r13
	cmpq	%rcx, %r13
	ja	.LBB89_31
	testq	%r8, %r8
	je	.LBB89_31
	addq	$6, %r12
	addq	%r12, %rbx
	cmpb	$0, (%rbx)
	js	.LBB89_31
	jne	.LBB89_22
	cmpl	$1, %r8d
	je	.LBB89_21
	cmpb	$0, 1(%rbx)
	jns	.LBB89_31
.LBB89_21:
	decq	%r8
	incq	%rbx
.LBB89_22:
	movb	$5, %al
	cmpl	$33, %r8d
	jae	.LBB89_31
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	subq	%r8, %rdi
	addq	$32, %rdi
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	callq	memcpy
	movzbl	32(%rsp), %ecx
	movq	33(%rsp), %rax
	movq	%rax, 128(%rsp)
	movq	41(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	49(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	57(%rsp), %rax
	movq	%rax, 152(%rsp)
	movq	65(%rsp), %rax
	movq	%rax, 160(%rsp)
	movq	72(%rsp), %rax
	movq	%rax, 167(%rsp)
	movb	$4, %al
	cmpq	%r15, %r13
	jne	.LBB89_31
	movq	295(%rsp), %rax
	movq	%rax, 752(%rsp)
	movq	288(%rsp), %rax
	movq	%rax, 745(%rsp)
	movq	280(%rsp), %rax
	movq	%rax, 737(%rsp)
	movq	272(%rsp), %rax
	movq	%rax, 729(%rsp)
	movq	256(%rsp), %rax
	movq	264(%rsp), %rdx
	movq	%rdx, 721(%rsp)
	movq	%rax, 713(%rsp)
	movq	167(%rsp), %rax
	movq	%rax, 800(%rsp)
	movq	160(%rsp), %rax
	movq	%rax, 793(%rsp)
	movq	152(%rsp), %rax
	movq	%rax, 785(%rsp)
	movq	144(%rsp), %rax
	movq	%rax, 777(%rsp)
	movq	128(%rsp), %rax
	movq	136(%rsp), %rdx
	movq	%rdx, 769(%rsp)
	movq	%rax, 761(%rsp)
	movb	%bpl, 712(%rsp)
	movb	%cl, 760(%rsp)
	leaq	840(%rsp), %rcx
	leaq	712(%rsp), %r8
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_
	cmpb	$0, 840(%rsp)
	jne	.LBB89_30
	movq	872(%rsp), %rax
	movq	%rax, 248(%rsp)
	movq	864(%rsp), %rax
	movq	%rax, 240(%rsp)
	movq	848(%rsp), %rax
	movq	856(%rsp), %rcx
	movq	%rcx, 232(%rsp)
	movq	%rax, 224(%rsp)
	leaq	672(%rsp), %rcx
	leaq	760(%rsp), %r8
	movq	%rsi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj4_E6scalarB6_
	cmpb	$1, 672(%rsp)
	jne	.LBB89_27
	movw	$1281, 672(%rsp)
	jmp	.LBB89_29
.LBB89_27:
	movq	704(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	696(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	680(%rsp), %rax
	movq	688(%rsp), %rcx
	movq	24(%r14), %rdx
	bswapq	%rdx
	movq	%rcx, 360(%rsp)
	movq	16(%r14), %rcx
	bswapq	%rcx
	movq	%rax, 352(%rsp)
	movq	8(%r14), %rax
	bswapq	%rax
	movq	(%r14), %r8
	bswapq	%r8
	movq	%rdx, 384(%rsp)
	movq	%rcx, 392(%rsp)
	movq	%rax, 400(%rsp)
	movq	%r8, 408(%rsp)
	movq	640(%rsp), %rbx
	leaq	296(%rbx), %rdi
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	leaq	416(%rsp), %r14
	leaq	32(%rsp), %r8
	leaq	384(%rsp), %r9
	movq	%r14, %rcx
	movq	%rdi, %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	328(%rbx), %r15
	leaq	32(%rsp), %r13
	leaq	352(%rsp), %r8
	movq	%r13, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	448(%rsp), %r12
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%r13, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E6invertB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	128(%rsp), %r13
	movq	%r13, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	256(%rsp), %rbp
	movq	%rbp, %rcx
	movq	%rdi, %rdx
	movq	%r13, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$1, 32(%rsp)
	leaq	480(%rsp), %r14
	leaq	32(%rsp), %r9
	movq	%r14, %rcx
	movq	%rdi, %rdx
	movq	%rbp, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	leaq	128(%rsp), %r13
	leaq	224(%rsp), %r8
	movq	%r13, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	256(%rsp), %rbp
	movq	%rbp, %rcx
	movq	%rdi, %rdx
	movq	%r13, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$1, 32(%rsp)
	leaq	512(%rsp), %r15
	leaq	32(%rsp), %r9
	movq	%r15, %rcx
	movq	%rdi, %rdx
	movq	%rbp, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	152(%rbx), %rax
	movq	%rax, 152(%rsp)
	movq	144(%rbx), %rax
	movq	%rax, 144(%rsp)
	movq	128(%rbx), %rax
	movq	136(%rbx), %rcx
	movq	%rcx, 136(%rsp)
	movq	%rax, 128(%rsp)
	movq	160(%rbx), %rax
	movq	168(%rbx), %rcx
	movq	%rax, 160(%rsp)
	movq	%rcx, 168(%rsp)
	movq	176(%rbx), %rax
	movq	%rax, 176(%rsp)
	movq	184(%rbx), %rax
	movq	%rax, 184(%rsp)
	movq	256(%rbx), %rax
	movq	264(%rbx), %rcx
	movq	%rax, 192(%rsp)
	movq	%rcx, 200(%rsp)
	movq	272(%rbx), %rax
	movq	%rax, 208(%rsp)
	movq	280(%rbx), %rax
	movq	%rax, 216(%rsp)
	leaq	256(%rsp), %r12
	leaq	128(%rsp), %rdx
	movq	%r12, %rcx
	movq	%r14, %r8
	movq	%rsi, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
	leaq	32(%rsp), %r14
	movq	%r14, %rcx
	movq	%rbx, %rdx
	movq	%r15, %r8
	movq	%rsi, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3mulB4_
	leaq	544(%rsp), %rbx
	movq	%rbx, %rcx
	movq	%r12, %rdx
	movq	%r14, %r8
	movq	%rsi, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E3addB4_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	leaq	32(%rsp), %rcx
	movq	%rbx, %rdx
	movq	%rsi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj4_E6affineB4_
	cmpb	$1, 32(%rsp)
	jne	.LBB89_32
	movw	$1281, 32(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	#MEMBARRIER
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	#MEMBARRIER
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	#MEMBARRIER
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	#MEMBARRIER
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	#MEMBARRIER
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
.LBB89_29:
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
.LBB89_30:
	movb	$5, %al
.LBB89_31:
	addq	$888, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB89_32:
	movq	64(%rsp), %rax
	movq	%rax, 280(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 272(%rsp)
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 264(%rsp)
	movq	%rax, 256(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 648(%rsp)
	#MEMBARRIER
	leaq	128(%rsp), %rcx
	leaq	808(%rsp), %r8
	leaq	256(%rsp), %r9
	movq	%rdi, %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 880(%rsp)
	#MEMBARRIER
	movq	224(%rsp), %rax
	movq	232(%rsp), %rcx
	movq	240(%rsp), %rdx
	movq	248(%rsp), %r8
	xorq	136(%rsp), %rcx
	xorq	128(%rsp), %rax
	xorq	144(%rsp), %rdx
	orq	%rcx, %rax
	orq	%rax, %rdx
	xorq	152(%rsp), %r8
	orq	%rdx, %r8
	sete	%al
	negb	%al
	orb	$5, %al
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	#MEMBARRIER
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	#MEMBARRIER
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	#MEMBARRIER
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	#MEMBARRIER
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	#MEMBARRIER
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	#MEMBARRIER
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	jmp	.LBB89_31

	.def	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify,unique,90
	.globl	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify
	.p2align	4
_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey6verify:
	pushq	%rsi
	pushq	%rdi
	subq	$104, %rsp
	movq	%r9, %rsi
	movq	%rcx, %rdi
	leaq	39(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566digest
	movzbl	40(%rsp), %eax
	cmpb	$1, 39(%rsp)
	je	.LBB90_2
	movq	160(%rsp), %r9
	movq	64(%rsp), %rcx
	movq	%rcx, 96(%rsp)
	movq	57(%rsp), %rcx
	movq	%rcx, 89(%rsp)
	movq	41(%rsp), %rcx
	movq	49(%rsp), %rdx
	movq	%rdx, 81(%rsp)
	movq	%rcx, 73(%rsp)
	movb	%al, 72(%rsp)
	leaq	72(%rsp), %rdx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey13verify_digest
.LBB90_2:
	addq	$104, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1,unique,91
	.globl	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1
	.p2align	4
_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p256NtB4_9PublicKey9from_sec1:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$712, %rsp
	movq	%r8, %rbx
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	408(%rsp), %rcx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p256
	cmpq	$65, %rbx
	jne	.LBB91_1
	movb	$4, %al
	cmpb	$4, (%rdi)
	jne	.LBB91_10
	movq	25(%rdi), %rcx
	bswapq	%rcx
	movq	17(%rdi), %rbx
	bswapq	%rbx
	movq	1(%rdi), %r9
	movq	9(%rdi), %r11
	bswapq	%r11
	bswapq	%r9
	movq	%rcx, 88(%rsp)
	movq	%rbx, 96(%rsp)
	movq	%r11, 104(%rsp)
	movq	%r9, 112(%rsp)
	movq	57(%rdi), %r10
	bswapq	%r10
	movq	49(%rdi), %r8
	bswapq	%r8
	movq	33(%rdi), %rax
	movq	41(%rdi), %rdx
	bswapq	%rdx
	bswapq	%rax
	movq	%r10, 120(%rsp)
	movq	504(%rsp), %r14
	movq	512(%rsp), %rbp
	cmpq	%r14, %rcx
	movl	$1, %r15d
	sbbq	$0, %r15
	xorl	%ecx, %ecx
	subq	%rbp, %rbx
	movl	$0, %r12d
	sbbq	%r12, %r12
	addq	%r15, %rbx
	adcq	$0, %r12
	addq	$-1, %rbx
	adcq	$0, %r12
	xorq	$-2, %r12
	movq	520(%rsp), %rbx
	subq	%rbx, %r11
	movl	$0, %r15d
	sbbq	%r15, %r15
	addq	%r12, %r11
	adcq	$-1, %r15
	addq	$1, %r11
	adcq	$1, %r15
	xorq	$-2, %r15
	movq	528(%rsp), %r13
	subq	%r13, %r9
	movl	$0, %r11d
	sbbq	%r11, %r11
	movq	%r8, 128(%rsp)
	addq	%r15, %r9
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$1, %r11
	xorq	$1, %r11
	cmpq	%r14, %r10
	movl	$1, %r9d
	sbbq	$0, %r9
	subq	%rbp, %r8
	movl	$0, %r10d
	sbbq	%r10, %r10
	movq	%rdx, 136(%rsp)
	addq	%r9, %r8
	adcq	$0, %r10
	addq	$-1, %r8
	adcq	$0, %r10
	xorq	$-2, %r10
	subq	%rbx, %rdx
	movl	$0, %r8d
	sbbq	%r8, %r8
	movq	%rax, 144(%rsp)
	addq	%r10, %rdx
	adcq	$-1, %r8
	addq	$1, %rdx
	adcq	$1, %r8
	xorq	$-2, %r8
	subq	%r13, %rax
	sbbq	%rcx, %rcx
	addq	%r8, %rax
	adcq	$-1, %rcx
	addq	$1, %rax
	adcq	$1, %rcx
	xorq	$1, %rcx
	testq	%rcx, %r11
	je	.LBB91_9
	leaq	504(%rsp), %r12
	leaq	536(%rsp), %r9
	leaq	216(%rsp), %rcx
	leaq	88(%rsp), %r8
	movq	%r12, %rdx
	movq	%rbp, 72(%rsp)
	movq	%r14, %r15
	movl	$1, %r14d
	movq	%rbx, %rbp
	movq	%r9, %rbx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	248(%rsp), %rcx
	leaq	120(%rsp), %r8
	movq	%r12, %rdx
	movq	%rbx, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	%r13, 80(%rsp)
	leaq	344(%rsp), %r13
	movq	%r13, %rcx
	movq	%r12, %rdx
	leaq	216(%rsp), %r8
	movq	%r8, %r9
	movq	%r8, %rbx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	leaq	280(%rsp), %rcx
	movq	%r12, %rdx
	movq	%r13, %r8
	movq	%rbx, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$3, 40(%rsp)
	leaq	376(%rsp), %r13
	leaq	40(%rsp), %r8
	movq	%r13, %rcx
	movq	%r12, %rdx
	leaq	536(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	leaq	40(%rsp), %rcx
	movq	%r12, %rdx
	movq	%r13, %r8
	movq	%rbx, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	280(%rsp), %rax
	subq	40(%rsp), %rax
	sbbq	$0, %r14
	movq	288(%rsp), %rcx
	xorl	%edx, %edx
	subq	48(%rsp), %rcx
	movl	$0, %r9d
	sbbq	%r9, %r9
	addq	%r14, %rcx
	adcq	$0, %r9
	addq	$-1, %rcx
	adcq	$0, %r9
	movq	296(%rsp), %r8
	xorq	$-2, %r9
	subq	56(%rsp), %r8
	movl	$0, %r10d
	sbbq	%r10, %r10
	addq	%r9, %r8
	adcq	$-1, %r10
	addq	$1, %r8
	adcq	$1, %r10
	xorq	$-2, %r10
	movq	304(%rsp), %r9
	subq	64(%rsp), %r9
	movl	$0, %r11d
	sbbq	%r11, %r11
	addq	%r10, %r9
	adcq	$-1, %r11
	movq	%r9, %r10
	addq	$1, %r10
	adcq	$1, %r11
	xorq	$1, %r11
	movq	%r11, 184(%rsp)
	subq	184(%rsp), %rdx
	andq	%rdx, %r15
	movq	72(%rsp), %r11
	andq	%rdx, %r11
	andq	%rdx, %rbp
	movq	80(%rsp), %r10
	andq	%rdx, %r10
	addq	%rax, %r15
	adcq	%rcx, %r11
	adcq	%r8, %rbp
	adcq	$1, %r9
	addq	%r10, %r9
	movq	%r15, 184(%rsp)
	movq	%r11, 192(%rsp)
	movq	%rbp, 200(%rsp)
	movq	%r9, 208(%rsp)
	leaq	152(%rsp), %rcx
	leaq	184(%rsp), %r8
	leaq	408(%rsp), %r9
	movq	%r12, %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3addB7_
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	#MEMBARRIER
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	leaq	40(%rsp), %rcx
	movq	%r12, %rdx
	leaq	248(%rsp), %r8
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	152(%rsp), %r11
	movq	160(%rsp), %r9
	movq	48(%rsp), %r10
	movq	56(%rsp), %rdx
	movq	168(%rsp), %r8
	movq	64(%rsp), %rax
	movq	176(%rsp), %rcx
	cmpq	40(%rsp), %r11
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	jne	.LBB91_8
	cmpq	%r10, %r9
	jne	.LBB91_8
	cmpq	%rdx, %r8
	jne	.LBB91_8
	cmpq	%rax, %rcx
	jne	.LBB91_8
	leaq	1(%rdi), %rax
	movq	216(%rsp), %rbx
	movq	224(%rsp), %r14
	movq	232(%rsp), %r15
	movq	240(%rsp), %r12
	movq	248(%rsp), %r13
	movq	256(%rsp), %rbp
	movq	264(%rsp), %rcx
	movq	%rcx, 80(%rsp)
	movq	272(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	movq	568(%rsp), %rcx
	movq	%rcx, 336(%rsp)
	movq	576(%rsp), %rcx
	movq	%rcx, 328(%rsp)
	movq	584(%rsp), %rcx
	movq	%rcx, 320(%rsp)
	movq	592(%rsp), %rcx
	movq	%rcx, 312(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	56(%rax), %rcx
	movq	%rcx, 465(%rsi)
	movq	48(%rax), %rcx
	movq	%rcx, 457(%rsi)
	movq	40(%rax), %rcx
	movq	%rcx, 449(%rsi)
	movq	32(%rax), %rcx
	movq	%rcx, 441(%rsi)
	movq	24(%rax), %rcx
	movq	%rcx, 433(%rsi)
	movq	16(%rax), %rcx
	movq	%rcx, 425(%rsi)
	movq	8(%rax), %rcx
	movq	%rcx, 417(%rsi)
	movzbl	(%rdi), %edi
	movq	(%rax), %rax
	movq	%rax, 409(%rsi)
	leaq	104(%rsi), %rcx
	leaq	408(%rsp), %rdx
	movl	$304, %r8d
	callq	memcpy
	movq	%rbx, 8(%rsi)
	movq	%r14, 16(%rsi)
	movq	%r15, 24(%rsi)
	movq	%r12, 32(%rsi)
	movq	%r13, 40(%rsi)
	movq	%rbp, 48(%rsi)
	movq	80(%rsp), %rax
	movq	%rax, 56(%rsi)
	movq	72(%rsp), %rax
	movq	%rax, 64(%rsi)
	movq	336(%rsp), %rax
	movq	%rax, 72(%rsi)
	movq	328(%rsp), %rax
	movq	%rax, 80(%rsi)
	movq	320(%rsp), %rax
	movq	%rax, 88(%rsi)
	movq	312(%rsp), %rax
	movq	%rax, 96(%rsi)
	movb	%dil, 408(%rsi)
	movb	$0, (%rsi)
	jmp	.LBB91_12
.LBB91_1:
	xorl	%eax, %eax
	jmp	.LBB91_10
.LBB91_8:
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	#MEMBARRIER
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	#MEMBARRIER
.LBB91_9:
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	#MEMBARRIER
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movb	$3, %al
.LBB91_10:
	movb	%al, 1(%rsi)
	movb	$1, (%rsi)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	#MEMBARRIER
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	#MEMBARRIER
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	#MEMBARRIER
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	#MEMBARRIER
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	#MEMBARRIER
.LBB91_12:
	movq	%rsi, %rax
	addq	$712, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest,unique,92
	.globl	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest
	.p2align	4
_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$1256, %rsp
	movb	$4, %al
	cmpq	$6, %r9
	jb	.LBB92_31
	cmpb	$48, (%r8)
	jne	.LBB92_31
	movzbl	1(%r8), %r10d
	leaq	-2(%r9), %r11
	cmpq	%r10, %r11
	jne	.LBB92_31
	cmpb	$2, 2(%r8)
	jne	.LBB92_31
	movzbl	3(%r8), %r12d
	leaq	4(%r12), %r13
	cmpq	%r9, %r13
	ja	.LBB92_31
	testq	%r12, %r12
	je	.LBB92_31
	leaq	448(%rcx), %rsi
	leaq	4(%r8), %r10
	cmpb	$0, (%r10)
	js	.LBB92_31
	movq	%r12, %r11
	jne	.LBB92_11
	cmpl	$1, %r12d
	je	.LBB92_10
	cmpb	$0, 5(%r8)
	jns	.LBB92_31
.LBB92_10:
	leaq	-1(%r12), %r11
	leaq	5(%r8), %r10
.LBB92_11:
	movb	$5, %al
	cmpl	$49, %r11d
	jae	.LBB92_31
	movq	%rsi, 1024(%rsp)
	movq	%r8, %rsi
	movq	%rdx, %r14
	movq	%rcx, %rbx
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	leaq	32(%rsp), %rdi
	movq	%rdi, %rcx
	subq	%r11, %rcx
	addq	$48, %rcx
	movq	%r10, %rdx
	movq	%r11, %r8
	movq	%r9, %r15
	callq	memcpy
	movzbl	32(%rsp), %ebp
	movq	33(%rsp), %rax
	movq	%rax, 368(%rsp)
	movq	41(%rsp), %rax
	movq	%rax, 376(%rsp)
	movq	49(%rsp), %rax
	movq	%rax, 384(%rsp)
	movq	57(%rsp), %rax
	movq	%rax, 392(%rsp)
	movq	65(%rsp), %rax
	movq	%rax, 400(%rsp)
	movq	72(%rsp), %rax
	movq	%rax, 407(%rsp)
	movb	$4, %al
	cmpq	%r15, %r13
	jae	.LBB92_31
	cmpb	$2, (%rsi,%r13)
	jne	.LBB92_31
	movq	%r15, %rcx
	leaq	5(%r12), %r8
	cmpq	%r15, %r8
	jae	.LBB92_31
	movzbl	5(%rsi,%r12), %r8d
	leaq	(%r12,%r8), %r13
	addq	$6, %r13
	cmpq	%rcx, %r13
	ja	.LBB92_31
	testq	%r8, %r8
	je	.LBB92_31
	addq	$6, %r12
	addq	%r12, %rsi
	cmpb	$0, (%rsi)
	js	.LBB92_31
	jne	.LBB92_22
	cmpl	$1, %r8d
	je	.LBB92_21
	cmpb	$0, 1(%rsi)
	jns	.LBB92_31
.LBB92_21:
	decq	%r8
	incq	%rsi
.LBB92_22:
	movb	$5, %al
	cmpl	$49, %r8d
	jae	.LBB92_31
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	subq	%r8, %rdi
	addq	$48, %rdi
	movq	%rdi, %rcx
	movq	%rsi, %rdx
	callq	memcpy
	movzbl	32(%rsp), %ecx
	movq	33(%rsp), %rax
	movq	%rax, 176(%rsp)
	movq	41(%rsp), %rax
	movq	%rax, 184(%rsp)
	movq	49(%rsp), %rax
	movq	%rax, 192(%rsp)
	movq	57(%rsp), %rax
	movq	%rax, 200(%rsp)
	movq	65(%rsp), %rax
	movq	%rax, 208(%rsp)
	movq	72(%rsp), %rax
	movq	%rax, 215(%rsp)
	movb	$4, %al
	cmpq	%r15, %r13
	jne	.LBB92_31
	movq	%rbx, %rdx
	movq	407(%rsp), %rax
	movq	%rax, 1088(%rsp)
	movq	400(%rsp), %rax
	movq	%rax, 1081(%rsp)
	movq	392(%rsp), %rax
	movq	%rax, 1073(%rsp)
	movq	384(%rsp), %rax
	movq	%rax, 1065(%rsp)
	movq	368(%rsp), %rax
	movq	376(%rsp), %r8
	movq	%r8, 1057(%rsp)
	movq	%rax, 1049(%rsp)
	movq	215(%rsp), %rax
	movq	%rax, 1136(%rsp)
	movq	208(%rsp), %rax
	movq	%rax, 1129(%rsp)
	movq	200(%rsp), %rax
	movq	%rax, 1121(%rsp)
	movq	192(%rsp), %rax
	movq	%rax, 1113(%rsp)
	movq	176(%rsp), %rax
	movq	184(%rsp), %r8
	movq	%r8, 1105(%rsp)
	movq	%rax, 1097(%rsp)
	movb	%bpl, 1048(%rsp)
	movb	%cl, 1096(%rsp)
	leaq	1200(%rsp), %rcx
	leaq	1048(%rsp), %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_
	cmpb	$0, 1200(%rsp)
	jne	.LBB92_30
	movq	1248(%rsp), %rax
	movq	%rax, 360(%rsp)
	movq	1240(%rsp), %rax
	movq	%rax, 352(%rsp)
	movq	1232(%rsp), %rax
	movq	%rax, 344(%rsp)
	movq	1224(%rsp), %rax
	movq	%rax, 336(%rsp)
	movq	1208(%rsp), %rax
	movq	1216(%rsp), %rcx
	movq	%rcx, 328(%rsp)
	movq	%rax, 320(%rsp)
	leaq	1144(%rsp), %rcx
	leaq	1096(%rsp), %r8
	movq	%rbx, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto4nistINtB4_5CurveKj6_E6scalarB6_
	cmpb	$1, 1144(%rsp)
	jne	.LBB92_27
	movw	$1281, 1144(%rsp)
	jmp	.LBB92_29
.LBB92_27:
	movq	1192(%rsp), %rax
	movq	%rax, 552(%rsp)
	movq	1184(%rsp), %rax
	movq	%rax, 544(%rsp)
	movq	1176(%rsp), %rax
	movq	%rax, 536(%rsp)
	movq	1168(%rsp), %rax
	movq	%rax, 528(%rsp)
	movq	1152(%rsp), %rcx
	movq	1160(%rsp), %rdx
	movq	40(%r14), %rax
	bswapq	%rax
	movq	%rdx, 520(%rsp)
	movq	32(%r14), %rdx
	bswapq	%rdx
	movq	24(%r14), %r8
	bswapq	%r8
	movq	16(%r14), %r9
	bswapq	%r9
	movq	(%r14), %r10
	movq	8(%r14), %r11
	bswapq	%r11
	bswapq	%r10
	movq	%rcx, 512(%rsp)
	movq	%rax, 600(%rsp)
	movq	%rdx, 592(%rsp)
	movq	%r8, 584(%rsp)
	movq	%r9, 576(%rsp)
	movq	%r11, 568(%rsp)
	movq	%r10, 560(%rsp)
	leaq	296(%rbx), %rdi
	movq	$0, 176(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 688(%rsp)
	movq	%rax, 32(%rsp)
	movq	%rdx, 40(%rsp)
	movq	%r8, 48(%rsp)
	movq	%r9, 56(%rsp)
	movq	%r11, 64(%rsp)
	movq	%r10, 72(%rsp)
	leaq	832(%rsp), %r14
	leaq	32(%rsp), %r8
	movq	%r14, %rcx
	movq	%rdi, %rdx
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 688(%rsp)
	#MEMBARRIER
	leaq	344(%rbx), %r15
	leaq	32(%rsp), %r13
	leaq	512(%rsp), %r8
	movq	%r13, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	688(%rsp), %r12
	movq	%r12, %rcx
	movq	%rdi, %rdx
	movq	%r13, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6invertB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	leaq	176(%rsp), %r13
	movq	%r13, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	368(%rsp), %rbp
	movq	%rbp, %rcx
	movq	%rdi, %rdx
	movq	%r13, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$1, 32(%rsp)
	leaq	736(%rsp), %r14
	leaq	32(%rsp), %r9
	movq	%r14, %rcx
	movq	%rdi, %rdx
	movq	%rbp, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	leaq	176(%rsp), %r13
	leaq	320(%rsp), %r8
	movq	%r13, %rcx
	movq	%rdi, %rdx
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	368(%rsp), %rbp
	movq	%rbp, %rcx
	movq	%rdi, %rdx
	movq	%r13, %r8
	movq	%r12, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$1, 32(%rsp)
	leaq	784(%rsp), %r15
	leaq	32(%rsp), %r9
	movq	%r15, %rcx
	movq	%rdi, %rdx
	movq	%rbp, %r8
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	88(%rbx), %rax
	movq	%rax, 216(%rsp)
	movq	80(%rbx), %rax
	movq	%rax, 208(%rsp)
	movq	72(%rbx), %rax
	movq	%rax, 200(%rsp)
	movq	64(%rbx), %rax
	movq	%rax, 192(%rsp)
	movq	48(%rbx), %rax
	movq	56(%rbx), %rcx
	movq	%rcx, 184(%rsp)
	movq	%rax, 176(%rsp)
	movq	96(%rbx), %rax
	movq	104(%rbx), %rcx
	movq	%rax, 224(%rsp)
	movq	%rcx, 232(%rsp)
	movq	112(%rbx), %rax
	movq	%rax, 240(%rsp)
	movq	120(%rbx), %rax
	movq	%rax, 248(%rsp)
	movq	128(%rbx), %rax
	movq	%rax, 256(%rsp)
	movq	136(%rbx), %rax
	movq	%rax, 264(%rsp)
	movq	240(%rbx), %rax
	movq	248(%rbx), %rcx
	movq	%rax, 272(%rsp)
	movq	%rcx, 280(%rsp)
	movq	256(%rbx), %rax
	movq	%rax, 288(%rsp)
	movq	264(%rbx), %rax
	movq	%rax, 296(%rsp)
	movq	272(%rbx), %rax
	movq	%rax, 304(%rsp)
	movq	280(%rbx), %rax
	movq	%rax, 312(%rsp)
	leaq	368(%rsp), %r12
	leaq	176(%rsp), %rdx
	movq	%r12, %rcx
	movq	%r14, %r8
	movq	%rbx, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
	leaq	32(%rsp), %r14
	movq	%r14, %rcx
	movq	1024(%rsp), %rdx
	movq	%r15, %r8
	movq	%rbx, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3mulB4_
	leaq	880(%rsp), %rsi
	movq	%rsi, %rcx
	movq	%r12, %rdx
	movq	%r14, %r8
	movq	%rbx, %r9
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E3addB4_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	#MEMBARRIER
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	#MEMBARRIER
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	#MEMBARRIER
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	#MEMBARRIER
	leaq	32(%rsp), %rcx
	movq	%rsi, %rdx
	movq	%rbx, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4nistINtB2_5PointKj6_E6affineB4_
	cmpb	$1, 32(%rsp)
	jne	.LBB92_32
	movw	$1281, 32(%rsp)
	movq	$0, 880(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 920(%rsp)
	#MEMBARRIER
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 960(%rsp)
	movq	$0, 968(%rsp)
	#MEMBARRIER
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 1008(%rsp)
	movq	$0, 1016(%rsp)
	#MEMBARRIER
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	#MEMBARRIER
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	#MEMBARRIER
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	#MEMBARRIER
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 864(%rsp)
	movq	$0, 872(%rsp)
	#MEMBARRIER
	movq	$0, 600(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	#MEMBARRIER
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	#MEMBARRIER
.LBB92_29:
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
.LBB92_30:
	movb	$5, %al
.LBB92_31:
	addq	$1256, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB92_32:
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	56(%rsp), %rdx
	movq	64(%rsp), %r8
	movq	72(%rsp), %r9
	movq	80(%rsp), %r10
	movq	%rax, 648(%rsp)
	movq	%rcx, 640(%rsp)
	movq	%rdx, 632(%rsp)
	movq	%r8, 624(%rsp)
	movq	%r9, 616(%rsp)
	movq	%r10, 608(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	#MEMBARRIER
	movq	$0, 680(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1032(%rsp)
	movq	648(%rsp), %rax
	movq	%rax, 176(%rsp)
	movq	640(%rsp), %rax
	movq	%rax, 184(%rsp)
	movq	632(%rsp), %rax
	movq	%rax, 192(%rsp)
	movq	624(%rsp), %rax
	movq	%rax, 200(%rsp)
	movq	616(%rsp), %rax
	movq	%rax, 208(%rsp)
	movq	608(%rsp), %rax
	movq	%rax, 216(%rsp)
	leaq	368(%rsp), %rcx
	leaq	176(%rsp), %r8
	movq	%rdi, %rdx
	xorl	%r9d, %r9d
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	#MEMBARRIER
	movq	$0, 680(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1032(%rsp)
	#MEMBARRIER
	movq	320(%rsp), %rax
	movq	328(%rsp), %rcx
	movq	336(%rsp), %rdx
	movq	344(%rsp), %r8
	movq	352(%rsp), %r9
	movq	360(%rsp), %r10
	xorq	376(%rsp), %rcx
	xorq	368(%rsp), %rax
	xorq	384(%rsp), %rdx
	xorq	392(%rsp), %r8
	orq	%rcx, %rax
	orq	%rdx, %r8
	xorq	400(%rsp), %r9
	orq	%rax, %r8
	orq	%r8, %r9
	xorq	408(%rsp), %r10
	orq	%r9, %r10
	sete	%al
	negb	%al
	orb	$5, %al
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movq	$0, 648(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	movq	$0, 880(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 912(%rsp)
	movq	$0, 920(%rsp)
	#MEMBARRIER
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	movq	$0, 960(%rsp)
	movq	$0, 968(%rsp)
	#MEMBARRIER
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	movq	$0, 1008(%rsp)
	movq	$0, 1016(%rsp)
	#MEMBARRIER
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	#MEMBARRIER
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	#MEMBARRIER
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	#MEMBARRIER
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	movq	$0, 856(%rsp)
	movq	$0, 864(%rsp)
	movq	$0, 872(%rsp)
	#MEMBARRIER
	movq	$0, 600(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	#MEMBARRIER
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	#MEMBARRIER
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	#MEMBARRIER
	jmp	.LBB92_31

	.def	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify,unique,93
	.globl	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify
	.p2align	4
_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey6verify:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$544, %rsp
	movq	%r9, %rsi
	movq	%rcx, %rdi
	movq	$0, 216(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movabsq	$-3766243637369397544, %rax
	movq	%rax, 224(%rsp)
	movabsq	$7105036623409894663, %rax
	movq	%rax, 232(%rsp)
	movabsq	$-7973340178411365097, %rax
	movq	%rax, 240(%rsp)
	movabsq	$1526699215303891257, %rax
	movq	%rax, 248(%rsp)
	movabsq	$7436329637833083697, %rax
	movq	%rax, 256(%rsp)
	movabsq	$-8163818279084223215, %rax
	movq	%rax, 264(%rsp)
	movabsq	$-2662702644619276377, %rax
	movq	%rax, 272(%rsp)
	movabsq	$5167115440072839076, %rax
	movq	%rax, 280(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	leaq	96(%rsp), %rcx
	callq	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846update
	cmpb	$-1, %al
	je	.LBB93_5
	movw	$1, 47(%rsp)
	xorl	%eax, %eax
	.p2align	4
.LBB93_2:
	movb	$0, 96(%rsp,%rax)
	movb	$0, 97(%rsp,%rax)
	movb	$0, 98(%rsp,%rax)
	movb	$0, 99(%rsp,%rax)
	movb	$0, 100(%rsp,%rax)
	movb	$0, 101(%rsp,%rax)
	movb	$0, 102(%rsp,%rax)
	movb	$0, 103(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB93_2
	#MEMBARRIER
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	#MEMBARRIER
	cmpb	$1, 47(%rsp)
	jne	.LBB93_6
	movzbl	48(%rsp), %eax
	jmp	.LBB93_7
.LBB93_5:
	leaq	320(%rsp), %rbx
	leaq	96(%rsp), %rdx
	movl	$224, %r8d
	movq	%rbx, %rcx
	callq	memcpy
	leaq	48(%rsp), %rcx
	movq	%rbx, %rdx
	callq	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3848finalize
.LBB93_6:
	movq	608(%rsp), %r9
	movzbl	48(%rsp), %eax
	movq	49(%rsp), %rcx
	movq	%rcx, 321(%rsp)
	movq	57(%rsp), %rcx
	movq	%rcx, 329(%rsp)
	movq	65(%rsp), %rcx
	movq	%rcx, 337(%rsp)
	movq	73(%rsp), %rcx
	movq	%rcx, 345(%rsp)
	movq	81(%rsp), %rcx
	movq	%rcx, 353(%rsp)
	movq	88(%rsp), %rcx
	movq	%rcx, 360(%rsp)
	movb	%al, 320(%rsp)
	leaq	320(%rsp), %rdx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey13verify_digest
.LBB93_7:
	addq	$544, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1,unique,94
	.globl	_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1
	.p2align	4
_RNvMs_NtNtCs3ONsSsjNgxw_12toyos_crypto3ecc4p384NtB4_9PublicKey9from_sec1:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$1112, %rsp
	movq	%r8, %rbx
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	568(%rsp), %rcx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p384
	cmpq	$97, %rbx
	jne	.LBB94_1
	movb	$4, %al
	cmpb	$4, (%rdi)
	jne	.LBB94_12
	movq	41(%rdi), %rax
	bswapq	%rax
	movq	33(%rdi), %r15
	bswapq	%r15
	movq	25(%rdi), %r14
	bswapq	%r14
	movq	17(%rdi), %rbx
	bswapq	%rbx
	movq	9(%rdi), %r11
	bswapq	%r11
	movq	1(%rdi), %r9
	bswapq	%r9
	movq	%rax, 120(%rsp)
	movq	%r15, 128(%rsp)
	movq	89(%rdi), %r10
	bswapq	%r10
	movq	%r14, 136(%rsp)
	movq	81(%rdi), %r8
	bswapq	%r8
	movq	%rbx, 144(%rsp)
	movq	73(%rdi), %rdx
	bswapq	%rdx
	movq	%r11, 152(%rsp)
	movq	65(%rdi), %rcx
	bswapq	%rcx
	movq	%r9, 160(%rsp)
	movq	712(%rsp), %rbp
	movq	720(%rsp), %r13
	movq	%r13, 112(%rsp)
	cmpq	%rbp, %rax
	movl	$1, %r12d
	sbbq	$0, %r12
	xorl	%eax, %eax
	subq	%r13, %r15
	movl	$0, %r13d
	sbbq	%r13, %r13
	addq	%r12, %r15
	adcq	$0, %r13
	addq	$-1, %r15
	adcq	$0, %r13
	xorq	$-2, %r13
	movq	728(%rsp), %r12
	subq	%r12, %r14
	movl	$0, %r15d
	sbbq	%r15, %r15
	addq	%r13, %r14
	adcq	$-1, %r15
	addq	$1, %r14
	adcq	$1, %r15
	xorq	$-2, %r15
	movq	736(%rsp), %r14
	subq	%r14, %rbx
	movl	$0, %r13d
	sbbq	%r13, %r13
	addq	%r15, %rbx
	adcq	$-1, %r13
	addq	$1, %rbx
	adcq	$1, %r13
	xorq	$-2, %r13
	movq	744(%rsp), %r15
	subq	%r15, %r11
	movl	$0, %ebx
	sbbq	%rbx, %rbx
	addq	%r13, %r11
	adcq	$-1, %rbx
	addq	$1, %r11
	adcq	$1, %rbx
	xorq	$-2, %rbx
	movq	752(%rsp), %r13
	subq	%r13, %r9
	movl	$0, %r11d
	sbbq	%r11, %r11
	addq	%rbx, %r9
	movq	57(%rdi), %rbx
	bswapq	%rbx
	movq	%r10, 168(%rsp)
	movq	%r8, 176(%rsp)
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$1, %r11
	xorq	$1, %r11
	movq	%rbp, 104(%rsp)
	cmpq	%rbp, %r10
	movq	112(%rsp), %rbp
	movl	$1, %r9d
	sbbq	$0, %r9
	subq	%rbp, %r8
	movl	$0, %r10d
	sbbq	%r10, %r10
	addq	%r9, %r8
	movq	%rdx, 184(%rsp)
	adcq	$0, %r10
	addq	$-1, %r8
	adcq	$0, %r10
	xorq	$-2, %r10
	movq	%r12, 96(%rsp)
	subq	%r12, %rdx
	movl	$0, %r8d
	sbbq	%r8, %r8
	addq	%r10, %rdx
	movq	%rcx, 192(%rsp)
	adcq	$-1, %r8
	addq	$1, %rdx
	adcq	$1, %r8
	xorq	$-2, %r8
	subq	%r14, %rcx
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%r8, %rcx
	movq	%rbx, 200(%rsp)
	adcq	$-1, %rdx
	addq	$1, %rcx
	adcq	$1, %rdx
	xorq	$-2, %rdx
	movq	%r15, 88(%rsp)
	subq	%r15, %rbx
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%rdx, %rbx
	adcq	$-1, %rcx
	addq	$1, %rbx
	movq	49(%rdi), %rdx
	bswapq	%rdx
	movq	%rdx, 208(%rsp)
	adcq	$1, %rcx
	xorq	$-2, %rcx
	subq	%r13, %rdx
	sbbq	%rax, %rax
	addq	%rcx, %rdx
	adcq	$-1, %rax
	addq	$1, %rdx
	movl	$1, %ebx
	adcq	$1, %rax
	xorq	$1, %rax
	testq	%rax, %r11
	je	.LBB94_11
	movq	%r14, %r12
	movq	%r13, 80(%rsp)
	leaq	712(%rsp), %r13
	leaq	760(%rsp), %r14
	leaq	312(%rsp), %r15
	leaq	120(%rsp), %r8
	movq	%r15, %rcx
	movq	%r13, %rdx
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	264(%rsp), %rcx
	leaq	168(%rsp), %r8
	movq	%r13, %rdx
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	1016(%rsp), %r14
	movq	%r14, %rcx
	movq	%r13, %rdx
	movq	%r15, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	leaq	360(%rsp), %rcx
	movq	%r13, %rdx
	movq	%r14, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$3, 32(%rsp)
	leaq	1064(%rsp), %r14
	leaq	32(%rsp), %r8
	movq	%r14, %rcx
	movq	%r13, %rdx
	leaq	760(%rsp), %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	leaq	408(%rsp), %rcx
	movq	%r13, %rdx
	movq	%r14, %r8
	movq	%r15, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	360(%rsp), %r13
	subq	408(%rsp), %r13
	sbbq	$0, %rbx
	movq	368(%rsp), %rdx
	xorl	%r8d, %r8d
	subq	416(%rsp), %rdx
	movl	$0, %eax
	sbbq	%rax, %rax
	addq	%rbx, %rdx
	adcq	$0, %rax
	addq	$-1, %rdx
	adcq	$0, %rax
	movq	376(%rsp), %r9
	xorq	$-2, %rax
	subq	424(%rsp), %r9
	movl	$0, %r11d
	sbbq	%r11, %r11
	addq	%rax, %r9
	adcq	$-1, %r11
	addq	$1, %r9
	adcq	$1, %r11
	movq	384(%rsp), %r10
	xorq	$-2, %r11
	subq	432(%rsp), %r10
	movl	$0, %eax
	sbbq	%rax, %rax
	addq	%r11, %r10
	adcq	$-1, %rax
	addq	$1, %r10
	adcq	$1, %rax
	movq	392(%rsp), %r11
	xorq	$-2, %rax
	subq	440(%rsp), %r11
	movl	$0, %ebx
	sbbq	%rbx, %rbx
	addq	%rax, %r11
	adcq	$-1, %rbx
	addq	$1, %r11
	adcq	$1, %rbx
	xorq	$-2, %rbx
	movq	400(%rsp), %rax
	subq	448(%rsp), %rax
	movl	$0, %r15d
	sbbq	%r15, %r15
	addq	%rbx, %rax
	adcq	$-1, %r15
	movq	%rax, %rbx
	addq	$1, %rbx
	adcq	$1, %r15
	xorq	$1, %r15
	movq	%r15, 32(%rsp)
	subq	32(%rsp), %r8
	movq	104(%rsp), %rbx
	andq	%r8, %rbx
	andq	%r8, %rbp
	movq	96(%rsp), %r15
	andq	%r8, %r15
	andq	%r8, %r12
	movq	88(%rsp), %r14
	andq	%r8, %r14
	movq	80(%rsp), %rcx
	andq	%r8, %rcx
	addq	%r13, %rbx
	adcq	%rdx, %rbp
	adcq	%r9, %r15
	adcq	%r10, %r12
	adcq	%r11, %r14
	adcq	$1, %rax
	addq	%rcx, %rax
	movq	%rbx, 560(%rsp)
	movq	%rbp, 552(%rsp)
	movq	%r15, 544(%rsp)
	movq	%r12, 536(%rsp)
	movq	%r14, 528(%rsp)
	movq	%rax, 520(%rsp)
	addq	568(%rsp), %rbx
	movq	%rbx, 32(%rsp)
	adcq	$0, %rbp
	setb	%cl
	movq	576(%rsp), %rdx
	leaq	(%rdx,%rbp), %r8
	xorl	%r9d, %r9d
	addq	584(%rsp), %r15
	movq	%r8, 40(%rsp)
	setb	%r9b
	addq	%rdx, %rbp
	movzbl	%cl, %ecx
	adcq	%r15, %rcx
	setb	%dl
	movq	%rcx, 48(%rsp)
	xorl	%ecx, %ecx
	addq	592(%rsp), %r12
	setb	%cl
	addb	$255, %dl
	adcq	%r12, %r9
	setb	%dl
	movq	%r9, 56(%rsp)
	xorl	%r8d, %r8d
	addq	600(%rsp), %r14
	setb	%r8b
	addb	$255, %dl
	adcq	%r14, %rcx
	setb	%dl
	xorl	%r9d, %r9d
	addq	608(%rsp), %rax
	setb	%r9b
	addb	$255, %dl
	adcq	%rax, %r8
	movq	%rcx, 64(%rsp)
	adcq	$0, %r9
	movq	%r8, 72(%rsp)
	leaq	216(%rsp), %rcx
	leaq	32(%rsp), %r8
	leaq	712(%rsp), %rbx
	movq	%rbx, %rdx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E6reduceB7_
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 520(%rsp)
	#MEMBARRIER
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	#MEMBARRIER
	movq	$0, 1064(%rsp)
	movq	$0, 1072(%rsp)
	movq	$0, 1080(%rsp)
	movq	$0, 1088(%rsp)
	movq	$0, 1096(%rsp)
	movq	$0, 1104(%rsp)
	#MEMBARRIER
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	#MEMBARRIER
	movq	$0, 1016(%rsp)
	movq	$0, 1024(%rsp)
	movq	$0, 1032(%rsp)
	movq	$0, 1040(%rsp)
	movq	$0, 1048(%rsp)
	movq	$0, 1056(%rsp)
	#MEMBARRIER
	leaq	32(%rsp), %rcx
	movq	%rbx, %rdx
	leaq	264(%rsp), %r8
	movq	%r8, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	216(%rsp), %r12
	movq	224(%rsp), %r14
	movq	40(%rsp), %r15
	movq	48(%rsp), %r11
	movq	232(%rsp), %rbx
	movq	56(%rsp), %r9
	movq	240(%rsp), %r10
	movq	64(%rsp), %rdx
	movq	248(%rsp), %r8
	movq	72(%rsp), %rax
	movq	256(%rsp), %rcx
	cmpq	32(%rsp), %r12
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	jne	.LBB94_10
	cmpq	%r15, %r14
	jne	.LBB94_10
	cmpq	%r11, %rbx
	jne	.LBB94_10
	cmpq	%r9, %r10
	jne	.LBB94_10
	cmpq	%rdx, %r8
	jne	.LBB94_10
	cmpq	%rax, %rcx
	jne	.LBB94_10
	movq	312(%rsp), %rax
	movq	%rax, 112(%rsp)
	movq	320(%rsp), %r14
	movq	328(%rsp), %r15
	movq	336(%rsp), %r12
	movq	344(%rsp), %r13
	movq	352(%rsp), %rbp
	movq	264(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	272(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	280(%rsp), %rax
	movq	%rax, 88(%rsp)
	movq	288(%rsp), %rax
	movq	%rax, 80(%rsp)
	movq	296(%rsp), %rax
	movq	%rax, 512(%rsp)
	movq	304(%rsp), %rax
	movq	%rax, 504(%rsp)
	movq	808(%rsp), %rax
	movq	%rax, 496(%rsp)
	movq	816(%rsp), %rax
	movq	%rax, 488(%rsp)
	movq	824(%rsp), %rax
	movq	%rax, 480(%rsp)
	movq	832(%rsp), %rax
	movq	%rax, 472(%rsp)
	movq	840(%rsp), %rax
	movq	%rax, 464(%rsp)
	movq	848(%rsp), %rax
	movq	%rax, 456(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movzbl	(%rdi), %ebx
	leaq	1(%rdi), %rdx
	leaq	601(%rsi), %rcx
	movl	$96, %r8d
	callq	memcpy
	leaq	8(%rsi), %rcx
	leaq	568(%rsp), %rdx
	movl	$448, %r8d
	callq	memcpy
	movq	112(%rsp), %rax
	movq	%rax, 456(%rsi)
	movq	%r14, 464(%rsi)
	movq	%r15, 472(%rsi)
	movq	%r12, 480(%rsi)
	movq	%r13, 488(%rsi)
	movq	%rbp, 496(%rsi)
	movq	104(%rsp), %rax
	movq	%rax, 504(%rsi)
	movq	96(%rsp), %rax
	movq	%rax, 512(%rsi)
	movq	88(%rsp), %rax
	movq	%rax, 520(%rsi)
	movq	80(%rsp), %rax
	movq	%rax, 528(%rsi)
	movq	512(%rsp), %rax
	movq	%rax, 536(%rsi)
	movq	504(%rsp), %rax
	movq	%rax, 544(%rsi)
	movq	496(%rsp), %rax
	movq	%rax, 552(%rsi)
	movq	488(%rsp), %rax
	movq	%rax, 560(%rsi)
	movq	480(%rsp), %rax
	movq	%rax, 568(%rsi)
	movq	472(%rsp), %rax
	movq	%rax, 576(%rsi)
	movq	464(%rsp), %rax
	movq	%rax, 584(%rsi)
	movq	456(%rsp), %rax
	movq	%rax, 592(%rsi)
	movb	%bl, 600(%rsi)
	movb	$0, (%rsi)
	jmp	.LBB94_14
.LBB94_1:
	xorl	%eax, %eax
	jmp	.LBB94_12
.LBB94_10:
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	#MEMBARRIER
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	#MEMBARRIER
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	#MEMBARRIER
.LBB94_11:
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movb	$3, %al
.LBB94_12:
	movb	%al, 1(%rsi)
	movb	$1, (%rsi)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	#MEMBARRIER
	movq	$0, 808(%rsp)
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	#MEMBARRIER
	movq	$0, 912(%rsp)
	movq	$0, 920(%rsp)
	movq	$0, 928(%rsp)
	movq	$0, 936(%rsp)
	movq	$0, 944(%rsp)
	movq	$0, 952(%rsp)
	#MEMBARRIER
	movq	$0, 960(%rsp)
	movq	$0, 968(%rsp)
	movq	$0, 976(%rsp)
	movq	$0, 984(%rsp)
	movq	$0, 992(%rsp)
	movq	$0, 1000(%rsp)
	#MEMBARRIER
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	#MEMBARRIER
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	#MEMBARRIER
.LBB94_14:
	movq	%rsi, %rax
	addq	$1112, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto2ct5equal;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto2ct5equal,unique,95
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto2ct5equal
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto2ct5equal:
	pushq	%rsi
	pushq	%rbx
	pushq	%rax
	cmpq	%r9, %rdx
	jne	.LBB95_4
	testq	%rdx, %rdx
	je	.LBB95_6
	movl	%edx, %eax
	andl	$3, %eax
	cmpq	$4, %rdx
	jae	.LBB95_7
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	jmp	.LBB95_10
.LBB95_4:
	xorl	%eax, %eax
	addq	$8, %rsp
	popq	%rbx
	popq	%rsi
	retq
.LBB95_6:
	xorl	%eax, %eax
	jmp	.LBB95_13
.LBB95_7:
	movabsq	$9223372036854775804, %r9
	andq	%r9, %rdx
	xorl	%r9d, %r9d
	xorl	%r10d, %r10d
	.p2align	4
.LBB95_8:
	movzbl	(%r8,%r10), %r11d
	movzbl	1(%r8,%r10), %ebx
	xorb	(%rcx,%r10), %r11b
	movzbl	%r11b, %r11d
	orq	%r9, %r11
	xorb	1(%rcx,%r10), %bl
	movzbl	%bl, %r9d
	movzbl	2(%r8,%r10), %ebx
	xorb	2(%rcx,%r10), %bl
	movzbl	%bl, %esi
	orq	%r9, %rsi
	orq	%r11, %rsi
	movzbl	3(%r8,%r10), %r9d
	xorb	3(%rcx,%r10), %r9b
	addq	$4, %r10
	movzbl	%r9b, %r9d
	orq	%rsi, %r9
	cmpq	%r10, %rdx
	jne	.LBB95_8
	testq	%rax, %rax
	je	.LBB95_12
.LBB95_10:
	addq	%r10, %r8
	addq	%r10, %rcx
	xorl	%edx, %edx
	.p2align	4
.LBB95_11:
	movzbl	(%r8,%rdx), %r10d
	xorb	(%rcx,%rdx), %r10b
	movzbl	%r10b, %r10d
	orq	%r10, %r9
	incq	%rdx
	cmpq	%rdx, %rax
	jne	.LBB95_11
.LBB95_12:
	xorl	%eax, %eax
	testq	%r9, %r9
	setne	%al
.LBB95_13:
	movq	%rax, (%rsp)
	cmpq	$0, (%rsp)
	sete	%al
	addq	$8, %rsp
	popq	%rbx
	popq	%rsi
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul,unique,96
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul:
	pushq	%rax
	movl	%edx, %eax
	andb	$1, %al
	movzbl	%al, %eax
	movq	%rax, (%rsp)
	movq	(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	leal	(%rcx,%rcx), %r10d
	shrb	$7, %cl
	movzbl	%cl, %eax
	movq	%rax, (%rsp)
	movq	(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%r10b, %al
	movl	%edx, %ecx
	shrb	%cl
	andb	$1, %cl
	movzbl	%cl, %ecx
	movq	%rcx, (%rsp)
	movq	(%rsp), %r9
	negb	%r9b
	andb	%al, %r9b
	xorb	%r8b, %r9b
	addb	%al, %al
	shrb	$7, %r10b
	movzbl	%r10b, %ecx
	movq	%rcx, (%rsp)
	movq	(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%edx, %r8d
	shrb	$2, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, (%rsp)
	movq	(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, (%rsp)
	movq	(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%edx, %r9d
	shrb	$3, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, (%rsp)
	movq	(%rsp), %r9
	negb	%r9b
	andb	%al, %r9b
	xorb	%r8b, %r9b
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, (%rsp)
	movq	(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%edx, %r8d
	shrb	$4, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, (%rsp)
	movq	(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, (%rsp)
	movq	(%rsp), %rax
	negb	%al
	andb	$27, %al
	xorb	%cl, %al
	movl	%edx, %r9d
	shrb	$5, %r9b
	andb	$1, %r9b
	movzbl	%r9b, %r9d
	movq	%r9, (%rsp)
	movq	(%rsp), %r9
	negb	%r9b
	andb	%al, %r9b
	xorb	%r8b, %r9b
	addb	%al, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, (%rsp)
	movq	(%rsp), %rcx
	negb	%cl
	andb	$27, %cl
	xorb	%al, %cl
	movl	%edx, %r8d
	shrb	$6, %r8b
	andb	$1, %r8b
	movzbl	%r8b, %r8d
	movq	%r8, (%rsp)
	movq	(%rsp), %r8
	negb	%r8b
	andb	%cl, %r8b
	xorb	%r9b, %r8b
	addb	%cl, %cl
	shrb	$7, %al
	movzbl	%al, %eax
	movq	%rax, (%rsp)
	movq	(%rsp), %r9
	negb	%r9b
	andb	$27, %r9b
	xorb	%cl, %r9b
	shrb	$7, %dl
	movzbl	%dl, %eax
	movq	%rax, (%rsp)
	movq	(%rsp), %rax
	negb	%al
	andb	%r9b, %al
	xorb	%r8b, %al
	shrb	$7, %cl
	movzbl	%cl, %ecx
	movq	%rcx, (%rsp)
	movq	(%rsp), %rcx
	popq	%rcx
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox,unique,97
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes4sbox:
	pushq	%r15
	pushq	%r14
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$32, %rsp
	movl	%ecx, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %ebx
	movl	%eax, %ecx
	movl	%eax, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %esi
	movl	%eax, %ecx
	movl	%eax, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %edi
	movl	%eax, %ecx
	movl	%eax, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %ebp
	movl	%eax, %ecx
	movl	%eax, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %r14d
	movl	%eax, %ecx
	movl	%eax, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %r15d
	movl	%eax, %ecx
	movl	%eax, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %r12d
	movl	%ebx, %ecx
	movl	%esi, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %ecx
	movl	%edi, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %ecx
	movl	%ebp, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %ecx
	movl	%r14d, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %ecx
	movl	%r15d, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %ecx
	movl	%r12d, %edx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto3aes3mul
	movl	%eax, %ecx
	rolb	%cl
	movl	%eax, %edx
	rolb	$2, %dl
	xorb	%cl, %dl
	movl	%eax, %ecx
	rolb	$3, %cl
	movl	%eax, %r8d
	rolb	$4, %r8b
	xorb	%cl, %r8b
	xorb	%dl, %r8b
	xorb	%r8b, %al
	xorb	$99, %al
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4aead10chacha_tag;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto4aead10chacha_tag,unique,98
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto4aead10chacha_tag:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$360, %rsp
	movq	%r9, %rdi
	movq	%rcx, 232(%rsp)
	movabsq	$7719281312240119090, %rax
	movq	%rax, 120(%rsp)
	movabsq	$3684054920433006693, %rax
	movq	%rax, 112(%rsp)
	movq	(%rdx), %rax
	movq	8(%rdx), %rcx
	movq	%rax, 128(%rsp)
	movq	%rcx, 136(%rsp)
	movq	16(%rdx), %rax
	movq	%rax, 144(%rsp)
	movq	24(%rdx), %rax
	movq	%rax, 152(%rsp)
	movl	$0, 160(%rsp)
	movq	(%r8), %rax
	movq	%rax, 164(%rsp)
	movl	8(%r8), %eax
	movl	%eax, 172(%rsp)
	leaq	32(%rsp), %rcx
	leaq	112(%rsp), %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha6rounds
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	movl	$0, 144(%rsp)
	movl	$0, 148(%rsp)
	movl	$0, 152(%rsp)
	movl	$0, 156(%rsp)
	movl	$0, 160(%rsp)
	movl	$0, 164(%rsp)
	movl	$0, 168(%rsp)
	movl	$0, 172(%rsp)
	#MEMBARRIER
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movzwl	32(%rsp), %r10d
	movzbl	34(%rsp), %eax
	movzbl	36(%rsp), %r9d
	movzbl	37(%rsp), %r8d
	movzbl	38(%rsp), %edx
	movzbl	35(%rsp), %ebp
	movzbl	39(%rsp), %r15d
	movzbl	40(%rsp), %r11d
	movzwl	41(%rsp), %r12d
	shll	$8, %r12d
	movzbl	43(%rsp), %r14d
	movzbl	44(%rsp), %r13d
	movzbl	45(%rsp), %ecx
	movzbl	46(%rsp), %esi
	movzbl	47(%rsp), %ebx
	andb	$15, %bpl
	andb	$15, %r15b
	andb	$15, %r14b
	andb	$15, %bl
	movzbl	%bl, %ebx
	shlq	$56, %rbx
	shlq	$48, %rsi
	orq	%rbx, %rsi
	shlq	$40, %rcx
	orq	%rsi, %rcx
	andl	$-4, %r13d
	shlq	$32, %r13
	movzbl	%r14b, %r14d
	shll	$24, %r14d
	orq	%r13, %r14
	orq	%r12, %r14
	movzbl	%r15b, %esi
	shlq	$56, %rsi
	shlq	$48, %rdx
	orq	%rsi, %rdx
	shlq	$40, %r8
	andl	$-4, %r9d
	shlq	$32, %r9
	movzbl	%bpl, %esi
	shll	$24, %esi
	shll	$16, %eax
	orq	%r10, %rax
	orq	%rsi, %rax
	movq	464(%rsp), %rsi
	orq	%r9, %rax
	orq	%r8, %rax
	leal	(%r14,%r11), %r8d
	orq	%rdx, %rax
	movq	48(%rsp), %r9
	movq	56(%rsp), %r10
	movq	%r10, 248(%rsp)
	movq	%r9, 240(%rsp)
	movl	%eax, %r9d
	andl	$67108863, %r9d
	shrq	$26, %rax
	shldq	$12, %rdx, %r8
	andl	$67108863, %eax
	andl	$67092735, %r8d
	shrq	$14, %r14
	movl	%r14d, %edx
	shrq	$40, %rcx
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 312(%rsp)
	movq	%r9, 272(%rsp)
	movq	%rax, 280(%rsp)
	movq	%r8, 288(%rsp)
	movq	%rdx, 296(%rsp)
	movq	%rcx, 304(%rsp)
	movq	$0, 352(%rsp)
	movb	$0, 112(%rsp)
	movb	$0, 111(%rsp)
	movb	$0, 110(%rsp)
	movb	$0, 109(%rsp)
	movb	$0, 108(%rsp)
	movb	$0, 107(%rsp)
	movb	$0, 106(%rsp)
	movb	$0, 105(%rsp)
	movb	$0, 104(%rsp)
	movb	$0, 103(%rsp)
	movb	$0, 102(%rsp)
	movb	$0, 101(%rsp)
	movb	$0, 100(%rsp)
	movb	$0, 99(%rsp)
	movb	$0, 98(%rsp)
	movb	$0, 97(%rsp)
	#MEMBARRIER
	leaq	240(%rsp), %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update
	movq	352(%rsp), %rax
	testq	%rax, %rax
	je	.LBB98_3
	movl	$16, %r8d
	subq	%rax, %r8
	cmpq	$17, %r8
	jae	.LBB98_7
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.18(%rip), %rdx
	leaq	240(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update
.LBB98_3:
	movq	480(%rsp), %rdi
	movq	472(%rsp), %rdx
	leaq	240(%rsp), %rcx
	movq	%rdi, %r8
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update
	movq	352(%rsp), %rax
	testq	%rax, %rax
	je	.LBB98_6
	movl	$16, %r8d
	subq	%rax, %r8
	cmpq	$17, %r8
	jae	.LBB98_7
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.18(%rip), %rdx
	leaq	240(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update
.LBB98_6:
	movq	%rsi, 112(%rsp)
	leaq	240(%rsp), %rsi
	leaq	112(%rsp), %rdx
	movl	$8, %r8d
	movq	%rsi, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update
	movq	%rdi, 112(%rsp)
	leaq	112(%rsp), %rdx
	movl	$8, %r8d
	movq	%rsi, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056update
	leaq	112(%rsp), %rdx
	movl	$15, %ecx
	movq	%rdx, %rdi
	rep;movsq (%rsi), %es:(%rdi)
	movq	232(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB2_8Poly13056finish
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	#MEMBARRIER
	addq	$360, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq
.LBB98_7:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.19(%rip), %r9
	movq	%r8, %rdx
	movl	$16, %r8d
	xorl	%ecx, %ecx
	callq	_RNvNtNtCsbOZu4GxVKn0_4core5slice5index16slice_index_fail
	ud2

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress256;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress256,unique,99
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress256:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$360, %rsp
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	168(%rsp), %rcx
	movl	$192, %r8d
	xorl	%edx, %edx
	callq	memset
	movl	(%rdi), %eax
	bswapl	%eax
	movl	%eax, 104(%rsp)
	movl	4(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 108(%rsp)
	movl	8(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 112(%rsp)
	movl	12(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 116(%rsp)
	movl	16(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 120(%rsp)
	movl	20(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 124(%rsp)
	movl	24(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 128(%rsp)
	movl	28(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 132(%rsp)
	movl	32(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 136(%rsp)
	movl	36(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 140(%rsp)
	movl	40(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 144(%rsp)
	movl	44(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 148(%rsp)
	movl	48(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 152(%rsp)
	movl	52(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 156(%rsp)
	movl	56(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 160(%rsp)
	movl	60(%rdi), %ecx
	bswapl	%ecx
	movl	%ecx, 164(%rsp)
	movl	$16, %ecx
	.p2align	4
.LBB99_1:
	movl	44(%rsp,%rcx,4), %edx
	movl	%edx, %r8d
	roll	$25, %r8d
	movl	%edx, %r9d
	roll	$14, %r9d
	movl	96(%rsp,%rcx,4), %r10d
	movl	%r10d, %r11d
	roll	$15, %r11d
	movl	%r10d, %edi
	roll	$13, %edi
	xorl	%r8d, %r9d
	xorl	%r11d, %edi
	movl	%edx, %r8d
	shrl	$3, %r8d
	xorl	%r9d, %r8d
	shrl	$10, %r10d
	addl	76(%rsp,%rcx,4), %eax
	xorl	%edi, %r10d
	addl	%r10d, %eax
	addl	%r8d, %eax
	movl	%eax, 104(%rsp,%rcx,4)
	incq	%rcx
	movl	%edx, %eax
	cmpq	$64, %rcx
	jne	.LBB99_1
	movl	(%rsi), %r13d
	movl	4(%rsi), %r15d
	movl	8(%rsi), %ebp
	movl	12(%rsi), %eax
	movl	16(%rsi), %edx
	movl	20(%rsi), %r11d
	movl	24(%rsi), %r12d
	movl	28(%rsi), %r14d
	xorl	%r8d, %r8d
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.74(%rip), %rbx
	movl	%r13d, %r9d
	movl	%r15d, 44(%rsp)
	movl	%ebp, 48(%rsp)
	movl	%eax, 52(%rsp)
	movl	%edx, 56(%rsp)
	movl	%r11d, 60(%rsp)
	movl	%r12d, 64(%rsp)
	movl	%r14d, 68(%rsp)
	.p2align	4
.LBB99_3:
	movl	%r14d, %edi
	movl	%r12d, %r14d
	movl	%r11d, %r12d
	movl	%edx, %r11d
	movl	%eax, %ecx
	movl	%ebp, %eax
	movl	%edx, %r10d
	roll	$26, %r10d
	movl	%r15d, %ebp
	movl	%edx, %r15d
	roll	$21, %r15d
	xorl	%r10d, %r15d
	movl	%edx, %r10d
	roll	$7, %r10d
	xorl	%r15d, %r10d
	movl	%r12d, %r15d
	andl	%edx, %r15d
	addl	%edi, %r15d
	notl	%edx
	andl	%r14d, %edx
	addl	%r15d, %edx
	addl	%r10d, %edx
	addl	(%r8,%rbx), %edx
	addl	104(%rsp,%r8), %edx
	movl	%r9d, %r15d
	roll	$30, %r9d
	movl	%r15d, %r10d
	roll	$19, %r10d
	xorl	%r9d, %r10d
	movl	%r15d, %edi
	roll	$10, %edi
	xorl	%r10d, %edi
	movl	%eax, %r10d
	xorl	%ebp, %r10d
	andl	%r15d, %r10d
	movl	%eax, %r9d
	andl	%ebp, %r9d
	xorl	%r10d, %r9d
	addl	%edi, %r9d
	addl	%edx, %r9d
	addl	%ecx, %edx
	addq	$4, %r8
	cmpq	$256, %r8
	jne	.LBB99_3
	addl	%r9d, %r13d
	movl	%r13d, (%rsi)
	movl	44(%rsp), %ecx
	addl	%r15d, %ecx
	movl	%ecx, 4(%rsi)
	movl	48(%rsp), %ecx
	addl	%ebp, %ecx
	movl	%ecx, 8(%rsi)
	movl	52(%rsp), %ecx
	addl	%eax, %ecx
	movl	%ecx, 12(%rsi)
	movl	56(%rsp), %ecx
	addl	%edx, %ecx
	movl	%ecx, 16(%rsi)
	movl	60(%rsp), %ecx
	addl	%r11d, %ecx
	movl	%ecx, 20(%rsi)
	movl	64(%rsp), %ecx
	addl	%r12d, %ecx
	movl	%ecx, 24(%rsi)
	movl	68(%rsp), %ecx
	addl	%r14d, %ecx
	movl	%ecx, 28(%rsi)
	movl	%r9d, 100(%rsp)
	movl	%r15d, 96(%rsp)
	movl	%ebp, 92(%rsp)
	movl	%eax, 88(%rsp)
	movl	%edx, 84(%rsp)
	movl	%r11d, 80(%rsp)
	movl	%r12d, 76(%rsp)
	movl	%r14d, 72(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	movl	$0, 144(%rsp)
	movl	$0, 148(%rsp)
	movl	$0, 152(%rsp)
	movl	$0, 156(%rsp)
	movl	$0, 160(%rsp)
	movl	$0, 164(%rsp)
	movl	$0, 168(%rsp)
	movl	$0, 172(%rsp)
	movl	$0, 176(%rsp)
	movl	$0, 180(%rsp)
	movl	$0, 184(%rsp)
	movl	$0, 188(%rsp)
	movl	$0, 192(%rsp)
	movl	$0, 196(%rsp)
	movl	$0, 200(%rsp)
	movl	$0, 204(%rsp)
	movl	$0, 208(%rsp)
	movl	$0, 212(%rsp)
	movl	$0, 216(%rsp)
	movl	$0, 220(%rsp)
	movl	$0, 224(%rsp)
	movl	$0, 228(%rsp)
	movl	$0, 232(%rsp)
	movl	$0, 236(%rsp)
	movl	$0, 240(%rsp)
	movl	$0, 244(%rsp)
	movl	$0, 248(%rsp)
	movl	$0, 252(%rsp)
	movl	$0, 256(%rsp)
	movl	$0, 260(%rsp)
	movl	$0, 264(%rsp)
	movl	$0, 268(%rsp)
	movl	$0, 272(%rsp)
	movl	$0, 276(%rsp)
	movl	$0, 280(%rsp)
	movl	$0, 284(%rsp)
	movl	$0, 288(%rsp)
	movl	$0, 292(%rsp)
	movl	$0, 296(%rsp)
	movl	$0, 300(%rsp)
	movl	$0, 304(%rsp)
	movl	$0, 308(%rsp)
	movl	$0, 312(%rsp)
	movl	$0, 316(%rsp)
	movl	$0, 320(%rsp)
	movl	$0, 324(%rsp)
	movl	$0, 328(%rsp)
	movl	$0, 332(%rsp)
	movl	$0, 336(%rsp)
	movl	$0, 340(%rsp)
	movl	$0, 344(%rsp)
	movl	$0, 348(%rsp)
	movl	$0, 352(%rsp)
	movl	$0, 356(%rsp)
	#MEMBARRIER
	movl	$0, 100(%rsp)
	movl	$0, 96(%rsp)
	movl	$0, 92(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 80(%rsp)
	movl	$0, 76(%rsp)
	movl	$0, 72(%rsp)
	#MEMBARRIER
	addq	$360, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512,unique,100
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto4hash11compress512:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$792, %rsp
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	leaq	280(%rsp), %rcx
	movl	$512, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	(%rdi), %rax
	bswapq	%rax
	movq	%rax, 152(%rsp)
	movq	8(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 160(%rsp)
	movq	16(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 168(%rsp)
	movq	24(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 176(%rsp)
	movq	32(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 184(%rsp)
	movq	40(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 192(%rsp)
	movq	48(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 200(%rsp)
	movq	56(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 208(%rsp)
	movq	64(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 216(%rsp)
	movq	72(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 224(%rsp)
	movq	80(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 232(%rsp)
	movq	88(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 240(%rsp)
	movq	96(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 248(%rsp)
	movq	104(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 256(%rsp)
	movq	112(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 264(%rsp)
	movq	120(%rdi), %rcx
	bswapq	%rcx
	movq	%rcx, 272(%rsp)
	movl	$16, %ecx
	.p2align	4
.LBB100_1:
	movq	32(%rsp,%rcx,8), %rdx
	movq	%rdx, %r8
	rorq	%r8
	movq	%rdx, %r9
	rolq	$56, %r9
	movq	136(%rsp,%rcx,8), %r10
	movq	%r10, %r11
	rolq	$45, %r11
	movq	%r10, %rdi
	rolq	$3, %rdi
	xorq	%r8, %r9
	xorq	%r11, %rdi
	movq	%rdx, %r8
	shrq	$7, %r8
	xorq	%r9, %r8
	shrq	$6, %r10
	addq	96(%rsp,%rcx,8), %rax
	xorq	%rdi, %r10
	addq	%r10, %rax
	addq	%r8, %rax
	movq	%rax, 152(%rsp,%rcx,8)
	incq	%rcx
	movq	%rdx, %rax
	cmpq	$80, %rcx
	jne	.LBB100_1
	movq	(%rsi), %rbp
	movq	8(%rsi), %r12
	movq	16(%rsi), %r14
	movq	24(%rsi), %rax
	movq	32(%rsi), %rdx
	movq	40(%rsi), %r11
	movq	48(%rsi), %r13
	movq	56(%rsi), %r15
	xorl	%r8d, %r8d
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.75(%rip), %rbx
	movq	%rbp, %r9
	movq	%r12, 32(%rsp)
	movq	%r14, 40(%rsp)
	movq	%rax, 48(%rsp)
	movq	%rdx, 56(%rsp)
	movq	%r11, 64(%rsp)
	movq	%r13, 72(%rsp)
	movq	%r15, 80(%rsp)
	.p2align	4
.LBB100_3:
	movq	%r15, %rdi
	movq	%r13, %r15
	movq	%r11, %r13
	movq	%rdx, %r11
	movq	%rax, %rcx
	movq	%r14, %rax
	movq	%rdx, %r10
	rolq	$50, %r10
	movq	%r12, %r14
	movq	%rdx, %r12
	rolq	$46, %r12
	xorq	%r10, %r12
	movq	%rdx, %r10
	rolq	$23, %r10
	xorq	%r12, %r10
	movq	%r13, %r12
	andq	%rdx, %r12
	addq	%rdi, %r12
	notq	%rdx
	andq	%r15, %rdx
	addq	%r12, %rdx
	addq	%r10, %rdx
	addq	(%r8,%rbx), %rdx
	addq	152(%rsp,%r8), %rdx
	movq	%r9, %r12
	rolq	$36, %r9
	movq	%r12, %r10
	rolq	$30, %r10
	xorq	%r9, %r10
	movq	%r12, %rdi
	rolq	$25, %rdi
	xorq	%r10, %rdi
	movq	%rax, %r10
	xorq	%r14, %r10
	andq	%r12, %r10
	movq	%rax, %r9
	andq	%r14, %r9
	xorq	%r10, %r9
	addq	%rdi, %r9
	addq	%rdx, %r9
	addq	%rcx, %rdx
	addq	$8, %r8
	cmpq	$640, %r8
	jne	.LBB100_3
	addq	%r9, %rbp
	movq	%rbp, (%rsi)
	movq	32(%rsp), %rcx
	addq	%r12, %rcx
	movq	%rcx, 8(%rsi)
	movq	40(%rsp), %rcx
	addq	%r14, %rcx
	movq	%rcx, 16(%rsi)
	movq	48(%rsp), %rcx
	addq	%rax, %rcx
	movq	%rcx, 24(%rsi)
	movq	56(%rsp), %rcx
	addq	%rdx, %rcx
	movq	%rcx, 32(%rsi)
	movq	64(%rsp), %rcx
	addq	%r11, %rcx
	movq	%rcx, 40(%rsi)
	movq	72(%rsp), %rcx
	addq	%r13, %rcx
	movq	%rcx, 48(%rsi)
	movq	80(%rsp), %rcx
	addq	%r15, %rcx
	movq	%rcx, 56(%rsi)
	movq	%r9, 144(%rsp)
	movq	%r12, 136(%rsp)
	movq	%r14, 128(%rsp)
	movq	%rax, 120(%rsp)
	movq	%rdx, 112(%rsp)
	movq	%r11, 104(%rsp)
	movq	%r13, 96(%rsp)
	movq	%r15, 88(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	movq	$0, 416(%rsp)
	movq	$0, 424(%rsp)
	movq	$0, 432(%rsp)
	movq	$0, 440(%rsp)
	movq	$0, 448(%rsp)
	movq	$0, 456(%rsp)
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	#MEMBARRIER
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	#MEMBARRIER
	addq	$792, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p256;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p256,unique,101
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p256
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p256:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$536, %rsp
	movq	%rcx, %rbx
	movq	$-1, 128(%rsp)
	movl	$4294967295, %eax
	movq	%rax, 136(%rsp)
	movq	$0, 144(%rsp)
	movabsq	$-4294967296, %rax
	leaq	1(%rax), %rcx
	movq	%rcx, 152(%rsp)
	movabsq	$-884452912994769583, %rcx
	movq	%rcx, 160(%rsp)
	movabsq	$-4834901526196019580, %rcx
	movq	%rcx, 168(%rsp)
	movq	$-1, 176(%rsp)
	movq	%rax, 184(%rsp)
	movabsq	$4309448131093880907, %rax
	movq	%rax, 192(%rsp)
	movabsq	$7285987128567378166, %rax
	movq	%rax, 200(%rsp)
	movabsq	$-5482079946633869636, %rax
	movq	%rax, 208(%rsp)
	movabsq	$6540974713487397863, %rax
	movq	%rax, 216(%rsp)
	movabsq	$-819310685055303018, %rax
	movq	%rax, 224(%rsp)
	movabsq	$8575836109218198432, %rax
	movq	%rax, 232(%rsp)
	movabsq	$-523289583788211982, %rax
	movq	%rax, 240(%rsp)
	movabsq	$7716867327612699207, %rax
	movq	%rax, 248(%rsp)
	movabsq	$-3767753221892779531, %rax
	movq	%rax, 256(%rsp)
	movabsq	$3156516839386865358, %rax
	movq	%rax, 264(%rsp)
	movabsq	$-8149286295562117610, %rax
	movq	%rax, 272(%rsp)
	movabsq	$5756518291402817435, %rax
	movq	%rax, 280(%rsp)
	leaq	328(%rsp), %rsi
	leaq	128(%rsp), %rdx
	movq	%rsi, %rcx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_
	leaq	432(%rsp), %r14
	leaq	160(%rsp), %rdx
	movq	%r14, %rcx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3newB7_
	leaq	360(%rsp), %rdi
	leaq	288(%rsp), %rcx
	leaq	192(%rsp), %r8
	movq	%rsi, %rdx
	movq	%rdi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 64(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	leaq	96(%rsp), %rcx
	leaq	224(%rsp), %r8
	movq	%rsi, %rdx
	movq	%rdi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 64(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 56(%rsp)
	#MEMBARRIER
	leaq	64(%rsp), %rcx
	leaq	256(%rsp), %r8
	movq	%rsi, %rdx
	movq	%rdi, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj4_E3mulB7_
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	leaq	96(%rbx), %rdi
	movl	$13, %ecx
	rep;movsq (%rsi), %es:(%rdi)
	leaq	200(%rbx), %rdi
	movl	$13, %ecx
	movq	%r14, %rsi
	rep;movsq (%rsi), %es:(%rdi)
	movq	312(%rsp), %rax
	movq	%rax, 24(%rbx)
	movq	304(%rsp), %rax
	movq	%rax, 16(%rbx)
	movq	288(%rsp), %rax
	movq	296(%rsp), %rcx
	movq	%rcx, 8(%rbx)
	movq	%rax, (%rbx)
	movq	96(%rsp), %rax
	movq	104(%rsp), %rcx
	movq	%rax, 32(%rbx)
	movq	%rcx, 40(%rbx)
	movq	112(%rsp), %rax
	movq	%rax, 48(%rbx)
	movq	120(%rsp), %rax
	movq	%rax, 56(%rbx)
	movq	64(%rsp), %rax
	movq	72(%rsp), %rcx
	movq	%rax, 64(%rbx)
	movq	%rcx, 72(%rbx)
	movq	80(%rsp), %rax
	movq	%rax, 80(%rbx)
	movq	88(%rsp), %rax
	movq	%rax, 88(%rbx)
	movq	%rbx, %rax
	addq	$536, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p384;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p384,unique,102
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p384
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto4nist4p384:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$776, %rsp
	movq	%rcx, %rsi
	movl	$4294967295, %eax
	movq	%rax, 176(%rsp)
	movabsq	$-4294967296, %rax
	movq	%rax, 184(%rsp)
	movq	$-2, 192(%rsp)
	movq	$-1, 200(%rsp)
	movq	$-1, 208(%rsp)
	movq	$-1, 216(%rsp)
	movabsq	$-1374695839762142861, %rax
	movq	%rax, 224(%rsp)
	movabsq	$6348401684107011962, %rax
	movq	%rax, 232(%rsp)
	movabsq	$-4079331616924160545, %rax
	movq	%rax, 240(%rsp)
	movq	$-1, 248(%rsp)
	movq	$-1, 256(%rsp)
	movq	$-1, 264(%rsp)
	movabsq	$3064076045283764975, %rax
	movq	%rax, 272(%rsp)
	movabsq	$-4155070326131207779, %rax
	movq	%rax, 280(%rsp)
	movabsq	$221811693264799578, %rax
	movq	%rax, 288(%rsp)
	movabsq	$1737717031765098770, %rax
	movq	%rax, 296(%rsp)
	movabsq	$-7454014372307260135, %rax
	movq	%rax, 304(%rsp)
	movabsq	$-5534590068959811612, %rax
	movq	%rax, 312(%rsp)
	movabsq	$4203087948775033527, %rax
	movq	%rax, 320(%rsp)
	movabsq	$6125724927633205612, %rax
	movq	%rax, 328(%rsp)
	movabsq	$6482722621138151992, %rax
	movq	%rax, 336(%rsp)
	movabsq	$7934563412932533144, %rax
	movq	%rax, 344(%rsp)
	movabsq	$-8164525713704047244, %rax
	movq	%rax, 352(%rsp)
	movabsq	$-6158731714831383241, %rax
	movq	%rax, 360(%rsp)
	movabsq	$8809917716911230559, %rax
	movq	%rax, 368(%rsp)
	movabsq	$747793036959711645, %rax
	movq	%rax, 376(%rsp)
	movabsq	$-1595909157222827840, %rax
	movq	%rax, 384(%rsp)
	movabsq	$-507748159718812548, %rax
	movq	%rax, 392(%rsp)
	movabsq	$6745997240412855337, %rax
	movq	%rax, 400(%rsp)
	movabsq	$3897828414440483951, %rax
	movq	%rax, 408(%rsp)
	leaq	472(%rsp), %rbx
	leaq	176(%rsp), %rdx
	movq	%rbx, %rcx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_
	leaq	624(%rsp), %rdi
	leaq	224(%rsp), %rdx
	movq	%rdi, %rcx
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3newB7_
	leaq	520(%rsp), %r14
	leaq	416(%rsp), %rcx
	leaq	272(%rsp), %r8
	movq	%rbx, %rdx
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 80(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	#MEMBARRIER
	leaq	128(%rsp), %rcx
	leaq	320(%rsp), %r8
	movq	%rbx, %rdx
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 80(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 72(%rsp)
	#MEMBARRIER
	leaq	80(%rsp), %rcx
	leaq	368(%rsp), %r8
	movq	%rbx, %rdx
	movq	%r14, %r9
	callq	_RNvMs0_NtCs3ONsSsjNgxw_12toyos_crypto10montgomeryINtB5_3ModKj6_E3mulB7_
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 464(%rsp)
	#MEMBARRIER
	leaq	144(%rsi), %rcx
	movl	$152, %r8d
	movq	%rbx, %rdx
	callq	memcpy
	leaq	296(%rsi), %rcx
	movl	$152, %r8d
	movq	%rdi, %rdx
	callq	memcpy
	movq	456(%rsp), %rax
	movq	%rax, 40(%rsi)
	movq	448(%rsp), %rax
	movq	%rax, 32(%rsi)
	movq	440(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	432(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	416(%rsp), %rax
	movq	424(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	movq	128(%rsp), %rax
	movq	136(%rsp), %rcx
	movq	%rcx, 56(%rsi)
	movq	144(%rsp), %rcx
	movq	%rcx, 64(%rsi)
	movq	152(%rsp), %rcx
	movq	%rcx, 72(%rsi)
	movq	160(%rsp), %rcx
	movq	%rcx, 80(%rsi)
	movq	%rax, 48(%rsi)
	movq	168(%rsp), %rax
	movq	%rax, 88(%rsi)
	movq	96(%rsp), %rax
	movq	%rax, 112(%rsi)
	movq	120(%rsp), %rax
	movq	%rax, 136(%rsi)
	movq	80(%rsp), %rax
	movq	88(%rsp), %rcx
	movq	%rax, 96(%rsi)
	movq	112(%rsp), %rax
	movq	%rax, 128(%rsi)
	movq	104(%rsp), %rax
	movq	%rax, 120(%rsi)
	movq	%rcx, 104(%rsi)
	movq	%rsi, %rax
	addq	$776, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise,unique,103
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem5noise:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$432, %rsp
	movq	%rcx, %rsi
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movb	%r8b, 55(%rsp)
	movq	%rdx, 184(%rsp)
	movq	$32, 192(%rsp)
	leaq	55(%rsp), %rax
	movq	%rax, 200(%rsp)
	movq	$1, 208(%rsp)
	movq	$2, 32(%rsp)
	leaq	216(%rsp), %rdi
	leaq	184(%rsp), %r9
	movl	$136, %edx
	movq	%rdi, %rcx
	movb	$31, %r8b
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge3new
	xorl	%ebx, %ebx
	movq	424(%rsp), %rax
	jmp	.LBB103_1
	.p2align	4
.LBB103_2:
	movq	%rdi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 424(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB103_4:
	leaq	(%rsp,%rcx,8), %rcx
	addq	$216, %rcx
	movl	%eax, %edx
	andl	$7, %edx
	movzbl	(%rdx,%rcx), %ecx
	movb	%cl, 56(%rsp,%rbx)
	incq	%rbx
	incq	%rax
	movq	%rax, 424(%rsp)
	cmpq	$128, %rbx
	je	.LBB103_5
.LBB103_1:
	cmpq	416(%rsp), %rax
	je	.LBB103_2
	movq	%rax, %rcx
	shrq	$3, %rcx
	cmpq	$199, %rax
	jbe	.LBB103_4
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.71(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB103_5:
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	movq	$0, 328(%rsp)
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	movq	$0, 376(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 400(%rsp)
	movq	$0, 408(%rsp)
	#MEMBARRIER
	movl	$512, %r8d
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	memset
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	.p2align	4
.LBB103_6:
	movq	%rax, %rdx
	shrq	%rdx
	movzbl	56(%rsp,%rdx), %r8d
	movzbl	%cl, %edx
	andb	$4, %cl
	movl	%r8d, %r9d
	shrb	%cl, %r9b
	movl	%r9d, %ecx
	shrb	%cl
	andb	$1, %cl
	movl	%edx, %r10d
	andl	$4, %r10d
	btl	%r10d, %r8d
	adcb	$0, %cl
	movzbl	%cl, %ecx
	movzbl	%r9b, %r8d
	shrb	$2, %r9b
	andb	$1, %r9b
	btl	$3, %r8d
	adcb	$0, %r9b
	movzbl	%r9b, %r8d
	subl	%r8d, %ecx
	addl	$3329, %ecx
	movl	%ecx, %r8d
	subw	$3329, %r8w
	cmovbl	%ecx, %r8d
	movw	%r8w, (%rsi,%rax,2)
	incq	%rax
	addb	$4, %dl
	movl	%edx, %ecx
	cmpq	$256, %rax
	jne	.LBB103_6
	xorl	%eax, %eax
	.p2align	4
.LBB103_8:
	movb	$0, 56(%rsp,%rax)
	movb	$0, 57(%rsp,%rax)
	movb	$0, 58(%rsp,%rax)
	movb	$0, 59(%rsp,%rax)
	movb	$0, 60(%rsp,%rax)
	movb	$0, 61(%rsp,%rax)
	movb	$0, 62(%rsp,%rax)
	movb	$0, 63(%rsp,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB103_8
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$432, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem6sample;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem6sample,unique,104
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem6sample
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto5mlkem6sample:
	pushq	%r15
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$304, %rsp
	movq	%rcx, %rsi
	movb	%r9b, 54(%rsp)
	movb	%r8b, 55(%rsp)
	movq	%rdx, 272(%rsp)
	movq	$32, 280(%rsp)
	leaq	54(%rsp), %rax
	movq	%rax, 288(%rsp)
	movq	$2, 296(%rsp)
	movq	$2, 32(%rsp)
	leaq	56(%rsp), %rdi
	leaq	272(%rsp), %r9
	movl	$168, %edx
	movq	%rdi, %rcx
	movb	$31, %r8b
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge3new
	xorl	%ebx, %ebx
	movl	$512, %r8d
	movq	%rsi, %rcx
	xorl	%edx, %edx
	callq	memset
	movq	264(%rsp), %rax
	jmp	.LBB104_1
	.p2align	4
.LBB104_15:
	cmpq	$256, %rbx
	jae	.LBB104_16
.LBB104_1:
	movq	256(%rsp), %rdx
	cmpq	%rdx, %rax
	jne	.LBB104_3
	movq	%rdi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 264(%rsp)
	movq	256(%rsp), %rdx
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	jmp	.LBB104_4
	.p2align	4
.LBB104_3:
	movq	%rax, %rcx
	shrq	$3, %rcx
	cmpq	$199, %rax
	ja	.LBB104_6
.LBB104_4:
	movq	56(%rsp,%rcx,8), %r14
	leal	(,%rax,8), %ecx
	shrq	%cl, %r14
	leaq	1(%rax), %r8
	movq	%r8, 264(%rsp)
	cmpq	%rdx, %r8
	jne	.LBB104_5
	movq	%rdi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 264(%rsp)
	movq	256(%rsp), %rdx
	xorl	%ecx, %ecx
	xorl	%r8d, %r8d
	jmp	.LBB104_8
	.p2align	4
.LBB104_5:
	movq	%r8, %rcx
	shrq	$3, %rcx
	cmpq	$199, %rax
	jae	.LBB104_6
.LBB104_8:
	movq	56(%rsp,%rcx,8), %r15
	leal	(,%r8,8), %ecx
	shrq	%cl, %r15
	leaq	1(%r8), %rax
	movq	%rax, 264(%rsp)
	cmpq	%rdx, %rax
	jne	.LBB104_9
	movq	%rdi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 264(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
	jmp	.LBB104_11
	.p2align	4
.LBB104_9:
	movq	%rax, %rcx
	shrq	$3, %rcx
	cmpq	$199, %r8
	jae	.LBB104_6
.LBB104_11:
	movq	56(%rsp,%rcx,8), %rdx
	leal	(,%rax,8), %ecx
	shrq	%cl, %rdx
	incq	%rax
	movq	%rax, 264(%rsp)
	movzbl	%r14b, %r8d
	movl	%r15d, %ecx
	andl	$15, %ecx
	shll	$8, %ecx
	orl	%r8d, %ecx
	cmpl	$3329, %ecx
	jae	.LBB104_12
	movw	%cx, (%rsi,%rbx,2)
	incq	%rbx
.LBB104_12:
	movzbl	%r15b, %r8d
	shrl	$4, %r8d
	movzbl	%dl, %ecx
	shll	$4, %ecx
	orl	%r8d, %ecx
	movzwl	%cx, %edx
	cmpl	$3328, %edx
	ja	.LBB104_15
	cmpq	$255, %rbx
	ja	.LBB104_15
	movw	%cx, (%rsi,%rbx,2)
	incq	%rbx
	jmp	.LBB104_15
.LBB104_16:
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	#MEMBARRIER
	movq	%rsi, %rax
	addq	$304, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	retq
.LBB104_6:
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.71(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha10legacy_xor;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha10legacy_xor,unique,105
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha10legacy_xor:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$168, %rsp
	movq	%r9, 160(%rsp)
	movq	280(%rsp), %r13
	testq	%r13, %r13
	je	.LBB105_10
	movl	%r8d, %edi
	movl	%edx, %ebx
	movq	%rcx, %r14
	movq	272(%rsp), %rbp
	leaq	112(%rsp), %r15
	xorl	%r12d, %r12d
	jmp	.LBB105_2
	.p2align	4
.LBB105_9:
	addq	%rsi, %rbp
	incq	%r12
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	#MEMBARRIER
	subq	%rsi, %r13
	je	.LBB105_10
.LBB105_2:
	cmpq	$64, %r13
	movl	$64, %esi
	cmovbq	%r13, %rsi
	movq	160(%rsp), %rax
	leaq	(%r12,%rax), %rax
	movabsq	$7719281312240119090, %rcx
	movq	%rcx, 104(%rsp)
	movabsq	$3684054920433006693, %rcx
	movq	%rcx, 96(%rsp)
	movq	24(%r14), %rcx
	movq	%rcx, 24(%r15)
	movq	16(%r14), %rcx
	movq	%rcx, 16(%r15)
	movq	(%r14), %rcx
	movq	8(%r14), %rdx
	movq	%rdx, 8(%r15)
	movq	%rcx, (%r15)
	movq	%rax, 144(%rsp)
	movl	%ebx, 152(%rsp)
	movl	%edi, 156(%rsp)
	leaq	32(%rsp), %rcx
	leaq	96(%rsp), %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha6rounds
	movl	$0, 96(%rsp)
	movl	$0, 100(%rsp)
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	movl	$0, 144(%rsp)
	movl	$0, 148(%rsp)
	movl	$0, 152(%rsp)
	movl	$0, 156(%rsp)
	#MEMBARRIER
	movl	%esi, %eax
	andl	$3, %eax
	cmpq	$4, %r13
	jae	.LBB105_4
	xorl	%ecx, %ecx
	jmp	.LBB105_7
	.p2align	4
.LBB105_4:
	movl	%esi, %edx
	andl	$124, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB105_5:
	movzbl	32(%rsp,%rcx), %r8d
	xorb	%r8b, (%rbp,%rcx)
	movzbl	33(%rsp,%rcx), %r8d
	xorb	%r8b, 1(%rbp,%rcx)
	movzbl	34(%rsp,%rcx), %r8d
	xorb	%r8b, 2(%rbp,%rcx)
	movzbl	35(%rsp,%rcx), %r8d
	xorb	%r8b, 3(%rbp,%rcx)
	addq	$4, %rcx
	cmpq	%rcx, %rdx
	jne	.LBB105_5
	testq	%rax, %rax
	je	.LBB105_9
.LBB105_7:
	leaq	(%rsp,%rcx), %rdx
	addq	$32, %rdx
	addq	%rbp, %rcx
	xorl	%r8d, %r8d
	.p2align	4
.LBB105_8:
	movzbl	(%rdx,%r8), %r9d
	xorb	%r9b, (%rcx,%r8)
	incq	%r8
	cmpq	%r8, %rax
	jne	.LBB105_8
	jmp	.LBB105_9
.LBB105_10:
	movb	$-1, %al
	addq	$168, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha3xor;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha3xor,unique,106
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha3xor:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$168, %rsp
	movabsq	$274877906880, %rax
	cmpq	%rax, %r9
	jbe	.LBB106_3
	xorl	%eax, %eax
	jmp	.LBB106_2
.LBB106_3:
	movq	%r9, %rdi
	movb	$-1, %al
	testq	%r9, %r9
	je	.LBB106_2
	movq	%r8, %rbx
	movq	%rdx, %r14
	movq	%rcx, %r15
	leaq	120(%rsp), %rbp
	xorl	%esi, %esi
	leaq	104(%rsp), %r13
	jmp	.LBB106_5
	.p2align	4
.LBB106_12:
	addq	%r12, %rbx
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	movb	$0, 96(%rsp)
	movb	$0, 97(%rsp)
	movb	$0, 98(%rsp)
	movb	$0, 99(%rsp)
	movb	$0, 100(%rsp)
	movb	$0, 101(%rsp)
	movb	$0, 102(%rsp)
	movb	$0, 103(%rsp)
	#MEMBARRIER
	subq	%r12, %rdi
	je	.LBB106_13
.LBB106_5:
	cmpq	$64, %rdi
	movl	$64, %r12d
	cmovbq	%rdi, %r12
	incl	%esi
	movabsq	$7719281312240119090, %rax
	movq	%rax, 112(%rsp)
	movabsq	$3684054920433006693, %rax
	movq	%rax, 104(%rsp)
	movq	24(%r15), %rax
	movq	%rax, 24(%rbp)
	movq	16(%r15), %rax
	movq	%rax, 16(%rbp)
	movq	(%r15), %rax
	movq	8(%r15), %rcx
	movq	%rcx, 8(%rbp)
	movq	%rax, (%rbp)
	movl	%esi, 152(%rsp)
	movl	8(%r14), %eax
	movl	%eax, 44(%rbp)
	movq	(%r14), %rax
	movq	%rax, 36(%rbp)
	leaq	40(%rsp), %rcx
	movq	%r13, %rdx
	callq	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha6rounds
	movl	$0, 104(%rsp)
	movl	$0, 108(%rsp)
	movl	$0, 112(%rsp)
	movl	$0, 116(%rsp)
	movl	$0, 120(%rsp)
	movl	$0, 124(%rsp)
	movl	$0, 128(%rsp)
	movl	$0, 132(%rsp)
	movl	$0, 136(%rsp)
	movl	$0, 140(%rsp)
	movl	$0, 144(%rsp)
	movl	$0, 148(%rsp)
	movl	$0, 152(%rsp)
	movl	$0, 156(%rsp)
	movl	$0, 160(%rsp)
	movl	$0, 164(%rsp)
	#MEMBARRIER
	movl	%r12d, %eax
	andl	$3, %eax
	cmpq	$4, %rdi
	jae	.LBB106_7
	xorl	%ecx, %ecx
	jmp	.LBB106_10
	.p2align	4
.LBB106_7:
	movl	%r12d, %edx
	andl	$124, %edx
	xorl	%ecx, %ecx
	.p2align	4
.LBB106_8:
	movzbl	40(%rsp,%rcx), %r8d
	xorb	%r8b, (%rbx,%rcx)
	movzbl	41(%rsp,%rcx), %r8d
	xorb	%r8b, 1(%rbx,%rcx)
	movzbl	42(%rsp,%rcx), %r8d
	xorb	%r8b, 2(%rbx,%rcx)
	movzbl	43(%rsp,%rcx), %r8d
	xorb	%r8b, 3(%rbx,%rcx)
	addq	$4, %rcx
	cmpq	%rcx, %rdx
	jne	.LBB106_8
	testq	%rax, %rax
	je	.LBB106_12
.LBB106_10:
	leaq	(%rsp,%rcx), %rdx
	addq	$40, %rdx
	addq	%rbx, %rcx
	xorl	%r8d, %r8d
	.p2align	4
.LBB106_11:
	movzbl	(%rdx,%r8), %r9d
	xorb	%r9b, (%rcx,%r8)
	incq	%r8
	cmpq	%r8, %rax
	jne	.LBB106_11
	jmp	.LBB106_12
.LBB106_13:
	movb	$-1, %al
.LBB106_2:
	addq	$168, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha6rounds;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha6rounds,unique,107
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6chacha6rounds:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$104, %rsp
	movq	%rcx, 32(%rsp)
	movl	(%rdx), %eax
	movl	%eax, 8(%rsp)
	movl	4(%rdx), %r11d
	movl	8(%rdx), %ebp
	movl	12(%rdx), %r13d
	movl	16(%rdx), %r8d
	movl	20(%rdx), %esi
	movl	24(%rdx), %r14d
	movl	28(%rdx), %eax
	movl	32(%rdx), %ebx
	movl	36(%rdx), %ecx
	movl	%ecx, 12(%rsp)
	movl	40(%rdx), %r12d
	movl	44(%rdx), %ecx
	movl	%ecx, 20(%rsp)
	movl	48(%rdx), %r9d
	movl	52(%rdx), %edi
	movl	56(%rdx), %r15d
	movq	%rdx, 24(%rsp)
	movl	60(%rdx), %ecx
	movl	$10, %r10d
	.p2align	4
.LBB107_1:
	movl	%r10d, 4(%rsp)
	movl	8(%rsp), %r10d
	addl	%r8d, %r10d
	xorl	%r10d, %r9d
	roll	$16, %r9d
	addl	%r9d, %ebx
	xorl	%ebx, %r8d
	roll	$12, %r8d
	addl	%r8d, %r10d
	xorl	%r10d, %r9d
	roll	$8, %r9d
	addl	%r9d, %ebx
	movl	%ebx, 16(%rsp)
	xorl	%ebx, %r8d
	roll	$7, %r8d
	addl	%esi, %r11d
	xorl	%r11d, %edi
	roll	$16, %edi
	movl	12(%rsp), %edx
	addl	%edi, %edx
	xorl	%edx, %esi
	roll	$12, %esi
	addl	%esi, %r11d
	xorl	%r11d, %edi
	roll	$8, %edi
	addl	%edi, %edx
	movl	%edx, 12(%rsp)
	xorl	%edx, %esi
	roll	$7, %esi
	addl	%r14d, %ebp
	xorl	%ebp, %r15d
	roll	$16, %r15d
	addl	%r15d, %r12d
	xorl	%r12d, %r14d
	roll	$12, %r14d
	addl	%r14d, %ebp
	xorl	%ebp, %r15d
	roll	$8, %r15d
	addl	%r15d, %r12d
	xorl	%r12d, %r14d
	roll	$7, %r14d
	addl	%eax, %r13d
	xorl	%r13d, %ecx
	roll	$16, %ecx
	movl	20(%rsp), %edx
	addl	%ecx, %edx
	xorl	%edx, %eax
	roll	$12, %eax
	addl	%eax, %r13d
	xorl	%r13d, %ecx
	roll	$8, %ecx
	addl	%ecx, %edx
	xorl	%edx, %eax
	roll	$7, %eax
	addl	%esi, %r10d
	xorl	%r10d, %ecx
	roll	$16, %ecx
	addl	%ecx, %r12d
	xorl	%r12d, %esi
	roll	$12, %esi
	addl	%esi, %r10d
	movl	%r10d, 8(%rsp)
	xorl	%r10d, %ecx
	movl	4(%rsp), %r10d
	roll	$8, %ecx
	addl	%ecx, %r12d
	xorl	%r12d, %esi
	roll	$7, %esi
	addl	%r14d, %r11d
	xorl	%r11d, %r9d
	roll	$16, %r9d
	addl	%r9d, %edx
	xorl	%edx, %r14d
	roll	$12, %r14d
	addl	%r14d, %r11d
	xorl	%r11d, %r9d
	roll	$8, %r9d
	addl	%r9d, %edx
	movl	%edx, 20(%rsp)
	xorl	%edx, %r14d
	movl	16(%rsp), %ebx
	roll	$7, %r14d
	addl	%eax, %ebp
	xorl	%ebp, %edi
	roll	$16, %edi
	addl	%edi, %ebx
	xorl	%ebx, %eax
	roll	$12, %eax
	addl	%eax, %ebp
	xorl	%ebp, %edi
	roll	$8, %edi
	addl	%edi, %ebx
	xorl	%ebx, %eax
	roll	$7, %eax
	addl	%r8d, %r13d
	xorl	%r13d, %r15d
	roll	$16, %r15d
	movl	12(%rsp), %edx
	addl	%r15d, %edx
	xorl	%edx, %r8d
	roll	$12, %r8d
	addl	%r8d, %r13d
	xorl	%r13d, %r15d
	roll	$8, %r15d
	addl	%r15d, %edx
	movl	%edx, 12(%rsp)
	xorl	%edx, %r8d
	roll	$7, %r8d
	decl	%r10d
	jne	.LBB107_1
	movq	24(%rsp), %r10
	movl	%r11d, 4(%rsp)
	movl	8(%rsp), %r11d
	addl	(%r10), %r11d
	movl	%r11d, 8(%rsp)
	movl	4(%rsp), %edx
	addl	4(%r10), %edx
	movl	%edx, 4(%rsp)
	addl	8(%r10), %ebp
	addl	12(%r10), %r13d
	addl	16(%r10), %r8d
	addl	20(%r10), %esi
	addl	24(%r10), %r14d
	addl	28(%r10), %eax
	addl	32(%r10), %ebx
	movl	%ebx, 16(%rsp)
	movl	12(%rsp), %ebx
	addl	36(%r10), %ebx
	addl	40(%r10), %r12d
	movl	20(%rsp), %r11d
	addl	44(%r10), %r11d
	addl	48(%r10), %r9d
	addl	52(%r10), %edi
	addl	56(%r10), %r15d
	addl	60(%r10), %ecx
	movq	32(%rsp), %rdx
	movl	8(%rsp), %r10d
	movl	%r10d, (%rdx)
	movq	%rdx, %r10
	movl	4(%rsp), %edx
	movl	%edx, 4(%r10)
	movl	%ebp, 8(%r10)
	movl	%r13d, 12(%r10)
	movl	%r8d, 16(%r10)
	movl	%esi, 20(%r10)
	movl	%r14d, 24(%r10)
	movl	%eax, 28(%r10)
	movl	16(%rsp), %eax
	movl	%eax, 32(%r10)
	movl	%ebx, 36(%r10)
	movl	%r12d, 40(%r10)
	movl	%r11d, 44(%r10)
	movl	%r9d, 48(%r10)
	movl	%edi, 52(%r10)
	movl	%r15d, 56(%r10)
	movl	%ecx, 60(%r10)
	movl	$0, 100(%rsp)
	movl	$0, 96(%rsp)
	movl	$0, 92(%rsp)
	movl	$0, 88(%rsp)
	movl	$0, 84(%rsp)
	movl	$0, 80(%rsp)
	movl	$0, 76(%rsp)
	movl	$0, 72(%rsp)
	movl	$0, 68(%rsp)
	movl	$0, 64(%rsp)
	movl	$0, 60(%rsp)
	movl	$0, 56(%rsp)
	movl	$0, 52(%rsp)
	movl	$0, 48(%rsp)
	movl	$0, 44(%rsp)
	movl	$0, 40(%rsp)
	#MEMBARRIER
	addq	$104, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6hybrid7for_ssh;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6hybrid7for_ssh,unique,108
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6hybrid7for_ssh
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6hybrid7for_ssh:
	pushq	%r15
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$304, %rsp
	movq	%r8, %r15
	movq	%rdx, %r14
	movq	%rcx, %rbx
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movabsq	$-4942790177982912921, %rax
	movq	%rax, 112(%rsp)
	movabsq	$-6534734903820487822, %rax
	movq	%rax, 120(%rsp)
	movabsq	$-7276294671082564993, %rax
	movq	%rax, 128(%rsp)
	movabsq	$6620516960021240235, %rax
	movq	%rax, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	leaq	48(%rsp), %rcx
	movl	$32, %r8d
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update
	cmpb	$-1, %al
	jne	.LBB108_1
	leaq	48(%rsp), %rcx
	movl	$32, %r8d
	movq	%r15, %rdx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update
	cmpb	$-1, %al
	jne	.LBB108_4
	leaq	176(%rsp), %rdx
	leaq	48(%rsp), %rsi
	movl	$16, %ecx
	movq	%rdx, %rdi
	rep;movsq (%rsi), %es:(%rdi)
	movq	%rbx, %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2568finalize
	movb	$0, (%r15)
	movb	$0, 1(%r15)
	movb	$0, 2(%r15)
	movb	$0, 3(%r15)
	movb	$0, 4(%r15)
	movb	$0, 5(%r15)
	movb	$0, 6(%r15)
	movb	$0, 7(%r15)
	movb	$0, 8(%r15)
	movb	$0, 9(%r15)
	movb	$0, 10(%r15)
	movb	$0, 11(%r15)
	movb	$0, 12(%r15)
	movb	$0, 13(%r15)
	movb	$0, 14(%r15)
	movb	$0, 15(%r15)
	movb	$0, 16(%r15)
	movb	$0, 17(%r15)
	movb	$0, 18(%r15)
	movb	$0, 19(%r15)
	movb	$0, 20(%r15)
	movb	$0, 21(%r15)
	movb	$0, 22(%r15)
	movb	$0, 23(%r15)
	movb	$0, 24(%r15)
	movb	$0, 25(%r15)
	movb	$0, 26(%r15)
	movb	$0, 27(%r15)
	movb	$0, 28(%r15)
	movb	$0, 29(%r15)
	movb	$0, 30(%r15)
	movb	$0, 31(%r15)
	#MEMBARRIER
	movb	$0, (%r14)
	movb	$0, 1(%r14)
	movb	$0, 2(%r14)
	movb	$0, 3(%r14)
	movb	$0, 4(%r14)
	movb	$0, 5(%r14)
	movb	$0, 6(%r14)
	movb	$0, 7(%r14)
	movb	$0, 8(%r14)
	movb	$0, 9(%r14)
	movb	$0, 10(%r14)
	movb	$0, 11(%r14)
	movb	$0, 12(%r14)
	movb	$0, 13(%r14)
	movb	$0, 14(%r14)
	movb	$0, 15(%r14)
	movb	$0, 16(%r14)
	movb	$0, 17(%r14)
	movb	$0, 18(%r14)
	movb	$0, 19(%r14)
	movb	$0, 20(%r14)
	movb	$0, 21(%r14)
	movb	$0, 22(%r14)
	movb	$0, 23(%r14)
	movb	$0, 24(%r14)
	movb	$0, 25(%r14)
	movb	$0, 26(%r14)
	movb	$0, 27(%r14)
	movb	$0, 28(%r14)
	movb	$0, 29(%r14)
	movb	$0, 30(%r14)
	movb	$0, 31(%r14)
	#MEMBARRIER
	movq	%rbx, %rax
	addq	$304, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	retq
.LBB108_1:
	movb	$0, 176(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.80(%rip), %rax
	jmp	.LBB108_2
.LBB108_4:
	movb	$0, 176(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.79(%rip), %rax
.LBB108_2:
	movq	%rax, 32(%rsp)
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.77(%rip), %rcx
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.13(%rip), %r9
	leaq	176(%rsp), %r8
	movl	$24, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core6result13unwrap_failed
	ud2

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6hybrid7for_tls;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6hybrid7for_tls,unique,109
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6hybrid7for_tls
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6hybrid7for_tls:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$64, %rsp
	movq	%rcx, %rax
	movq	24(%rdx), %rcx
	movq	%rcx, 24(%rsp)
	movq	16(%rdx), %r9
	movq	%r9, 16(%rsp)
	movq	(%rdx), %r10
	movq	8(%rdx), %r11
	movq	%r11, 8(%rsp)
	movq	%r10, (%rsp)
	movq	(%r8), %rsi
	movq	8(%r8), %rdi
	movq	%rsi, 32(%rsp)
	movq	%rdi, 40(%rsp)
	movq	16(%r8), %rbx
	movq	%rbx, 48(%rsp)
	movq	24(%r8), %r14
	movq	%r14, 56(%rsp)
	movq	%r14, 56(%rax)
	movq	%rbx, 48(%rax)
	movq	%rdi, 40(%rax)
	movq	%rsi, 32(%rax)
	movq	%rcx, 24(%rax)
	movq	%r9, 16(%rax)
	movq	%r11, 8(%rax)
	movq	%r10, (%rax)
	movb	$0, (%r8)
	movb	$0, 1(%r8)
	movb	$0, 2(%r8)
	movb	$0, 3(%r8)
	movb	$0, 4(%r8)
	movb	$0, 5(%r8)
	movb	$0, 6(%r8)
	movb	$0, 7(%r8)
	movb	$0, 8(%r8)
	movb	$0, 9(%r8)
	movb	$0, 10(%r8)
	movb	$0, 11(%r8)
	movb	$0, 12(%r8)
	movb	$0, 13(%r8)
	movb	$0, 14(%r8)
	movb	$0, 15(%r8)
	movb	$0, 16(%r8)
	movb	$0, 17(%r8)
	movb	$0, 18(%r8)
	movb	$0, 19(%r8)
	movb	$0, 20(%r8)
	movb	$0, 21(%r8)
	movb	$0, 22(%r8)
	movb	$0, 23(%r8)
	movb	$0, 24(%r8)
	movb	$0, 25(%r8)
	movb	$0, 26(%r8)
	movb	$0, 27(%r8)
	movb	$0, 28(%r8)
	movb	$0, 29(%r8)
	movb	$0, 30(%r8)
	movb	$0, 31(%r8)
	#MEMBARRIER
	movb	$0, (%rdx)
	movb	$0, 1(%rdx)
	movb	$0, 2(%rdx)
	movb	$0, 3(%rdx)
	movb	$0, 4(%rdx)
	movb	$0, 5(%rdx)
	movb	$0, 6(%rdx)
	movb	$0, 7(%rdx)
	movb	$0, 8(%rdx)
	movb	$0, 9(%rdx)
	movb	$0, 10(%rdx)
	movb	$0, 11(%rdx)
	movb	$0, 12(%rdx)
	movb	$0, 13(%rdx)
	movb	$0, 14(%rdx)
	movb	$0, 15(%rdx)
	movb	$0, 16(%rdx)
	movb	$0, 17(%rdx)
	movb	$0, 18(%rdx)
	movb	$0, 19(%rdx)
	movb	$0, 20(%rdx)
	movb	$0, 21(%rdx)
	movb	$0, 22(%rdx)
	movb	$0, 23(%rdx)
	movb	$0, 24(%rdx)
	movb	$0, 25(%rdx)
	movb	$0, 26(%rdx)
	movb	$0, 27(%rdx)
	movb	$0, 28(%rdx)
	movb	$0, 29(%rdx)
	movb	$0, 30(%rdx)
	movb	$0, 31(%rdx)
	#MEMBARRIER
	addq	$64, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1g;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1g,unique,110
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1g
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1g:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$320, %rsp
	movq	%rdx, %r9
	movq	%rcx, %rsi
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 72(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	%r8, 32(%rsp)
	leaq	104(%rsp), %rdi
	movl	$72, %edx
	movq	%rdi, %rcx
	movb	$6, %r8b
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge3new
	xorl	%ebx, %ebx
	movq	312(%rsp), %rax
	jmp	.LBB110_1
	.p2align	4
.LBB110_2:
	movq	%rdi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 312(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB110_4:
	leaq	(%rsp,%rcx,8), %rcx
	addq	$104, %rcx
	movl	%eax, %edx
	andl	$7, %edx
	movzbl	(%rdx,%rcx), %ecx
	movb	%cl, 40(%rsp,%rbx)
	incq	%rbx
	incq	%rax
	movq	%rax, 312(%rsp)
	cmpq	$64, %rbx
	je	.LBB110_5
.LBB110_1:
	cmpq	304(%rsp), %rax
	je	.LBB110_2
	movq	%rax, %rcx
	shrq	$3, %rcx
	cmpq	$199, %rax
	jbe	.LBB110_4
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.71(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB110_5:
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	movq	$0, 280(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	#MEMBARRIER
	movq	96(%rsp), %rax
	movq	%rax, 56(%rsi)
	movq	88(%rsp), %rax
	movq	%rax, 48(%rsi)
	movq	80(%rsp), %rax
	movq	%rax, 40(%rsi)
	movq	72(%rsp), %rax
	movq	%rax, 32(%rsi)
	movq	64(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	56(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	movq	%rsi, %rax
	addq	$320, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1h;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1h,unique,111
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1h
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6keccak1h:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$288, %rsp
	movq	%rdx, %r9
	movq	%rcx, %rsi
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	%r8, 32(%rsp)
	leaq	72(%rsp), %rdi
	movl	$136, %edx
	movq	%rdi, %rcx
	movb	$6, %r8b
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge3new
	xorl	%ebx, %ebx
	movq	280(%rsp), %rax
	jmp	.LBB111_1
	.p2align	4
.LBB111_2:
	movq	%rdi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB4_6Sponge7permute
	movq	$0, 280(%rsp)
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB111_4:
	leaq	(%rsp,%rcx,8), %rcx
	addq	$72, %rcx
	movl	%eax, %edx
	andl	$7, %edx
	movzbl	(%rdx,%rcx), %ecx
	movb	%cl, 40(%rsp,%rbx)
	incq	%rbx
	incq	%rax
	movq	%rax, 280(%rsp)
	cmpq	$32, %rbx
	je	.LBB111_5
.LBB111_1:
	cmpq	272(%rsp), %rax
	je	.LBB111_2
	movq	%rax, %rcx
	shrq	$3, %rcx
	cmpq	$199, %rax
	jbe	.LBB111_4
	leaq	anon.b5f26072819afdb16b222aeefaecc0c9.71(%rip), %r8
	movl	$25, %edx
	callq	_RNvNtCsbOZu4GxVKn0_4core9panicking18panic_bounds_check
	ud2
.LBB111_5:
	movq	$0, 72(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 192(%rsp)
	movq	$0, 200(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 232(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	#MEMBARRIER
	movq	64(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	56(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	40(%rsp), %rax
	movq	48(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	movq	%rsi, %rax
	addq	$288, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret4wipe;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret4wipe,unique,112
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret4wipe
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret4wipe:
	testq	%rdx, %rdx
	je	.LBB112_7
	movq	%rdx, %r8
	movq	%rcx, %rax
	andq	$7, %r8
	je	.LBB112_4
	movq	%rcx, %rax
	.p2align	4
.LBB112_3:
	movb	$0, (%rax)
	incq	%rax
	decq	%r8
	jne	.LBB112_3
.LBB112_4:
	cmpq	$8, %rdx
	jb	.LBB112_7
	addq	%rdx, %rcx
	.p2align	4
.LBB112_6:
	movb	$0, (%rax)
	movb	$0, 1(%rax)
	movb	$0, 2(%rax)
	movb	$0, 3(%rax)
	movb	$0, 4(%rax)
	movb	$0, 5(%rax)
	movb	$0, 6(%rax)
	movb	$0, 7(%rax)
	addq	$8, %rax
	cmpq	%rcx, %rax
	jne	.LBB112_6
.LBB112_7:
	#MEMBARRIER
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret6wipe32;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret6wipe32,unique,113
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret6wipe32
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret6wipe32:
	testq	%rdx, %rdx
	je	.LBB113_7
	leaq	(,%rdx,4), %r8
	addq	$-4, %r8
	movl	%r8d, %r9d
	notl	%r9d
	movq	%rcx, %rax
	testb	$28, %r9b
	je	.LBB113_4
	movl	%r8d, %r9d
	shrl	$2, %r9d
	incl	%r9d
	andl	$7, %r9d
	negq	%r9
	movq	%rcx, %rax
	.p2align	4
.LBB113_3:
	movl	$0, (%rax)
	addq	$4, %rax
	incq	%r9
	jne	.LBB113_3
.LBB113_4:
	cmpq	$28, %r8
	jb	.LBB113_7
	leaq	(%rcx,%rdx,4), %rcx
	.p2align	4
.LBB113_6:
	movl	$0, (%rax)
	movl	$0, 4(%rax)
	movl	$0, 8(%rax)
	movl	$0, 12(%rax)
	movl	$0, 16(%rax)
	movl	$0, 20(%rax)
	movl	$0, 24(%rax)
	movl	$0, 28(%rax)
	addq	$32, %rax
	cmpq	%rcx, %rax
	jne	.LBB113_6
.LBB113_7:
	#MEMBARRIER
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret6wipe64;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret6wipe64,unique,114
	.globl	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret6wipe64
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6secret6wipe64:
	testq	%rdx, %rdx
	je	.LBB114_7
	leaq	(,%rdx,8), %r8
	addq	$-8, %r8
	movl	%r8d, %r9d
	notl	%r9d
	movq	%rcx, %rax
	testb	$56, %r9b
	je	.LBB114_4
	movl	%r8d, %r9d
	shrl	$3, %r9d
	incl	%r9d
	andl	$7, %r9d
	negq	%r9
	movq	%rcx, %rax
	.p2align	4
.LBB114_3:
	movq	$0, (%rax)
	addq	$8, %rax
	incq	%r9
	jne	.LBB114_3
.LBB114_4:
	cmpq	$56, %r8
	jb	.LBB114_7
	leaq	(%rcx,%rdx,8), %rcx
	.p2align	4
.LBB114_6:
	movq	$0, (%rax)
	movq	$0, 8(%rax)
	movq	$0, 16(%rax)
	movq	$0, 24(%rax)
	movq	$0, 32(%rax)
	movq	$0, 40(%rax)
	movq	$0, 48(%rax)
	movq	$0, 56(%rax)
	addq	$64, %rax
	cmpq	%rcx, %rax
	jne	.LBB114_6
.LBB114_7:
	#MEMBARRIER
	retq

	.def	_RNvNtCs3ONsSsjNgxw_12toyos_crypto6x255198multiply;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtCs3ONsSsjNgxw_12toyos_crypto6x255198multiply,unique,115
	.p2align	4
_RNvNtCs3ONsSsjNgxw_12toyos_crypto6x255198multiply:
	pushq	%r15
	pushq	%r14
	pushq	%r13
	pushq	%r12
	pushq	%rsi
	pushq	%rdi
	pushq	%rbp
	pushq	%rbx
	subq	$920, %rsp
	movq	%rdx, %rdi
	movq	%rcx, 856(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	xorl	%r9d, %r9d
	movabsq	$-6872316419617283935, %r10
	.p2align	4
.LBB115_1:
	movq	%r9, %rax
	mulq	%r10
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%r9b, %eax
	imull	$161, %eax, %eax
	movq	%r9, %rdx
	shrq	$3, %rdx
	movzbl	(%r8,%rdx), %edx
	movl	%r9d, %r11d
	andl	$7, %r11d
	xorl	%esi, %esi
	btl	%r11d, %edx
	setb	%sil
	addl	%r9d, %ecx
	shlq	%cl, %rsi
	shrl	$13, %eax
	orq	%rsi, 32(%rsp,%rax,8)
	incq	%r9
	cmpq	$255, %r9
	jne	.LBB115_1
	movq	64(%rsp), %rax
	movq	%rax, 688(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 680(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 672(%rsp)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 664(%rsp)
	movq	%rax, 656(%rsp)
	movq	$1, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 64(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	xorl	%r9d, %r9d
	.p2align	4
.LBB115_3:
	movq	%r9, %rax
	mulq	%r10
	shrl	$5, %edx
	imull	$-51, %edx, %ecx
	movzbl	%r9b, %eax
	imull	$161, %eax, %eax
	movq	%r9, %rdx
	shrq	$3, %rdx
	movzbl	(%r8,%rdx), %edx
	movl	%r9d, %r11d
	andl	$7, %r11d
	xorl	%esi, %esi
	btl	%r11d, %edx
	setb	%sil
	addl	%r9d, %ecx
	shlq	%cl, %rsi
	shrl	$13, %eax
	orq	%rsi, 32(%rsp,%rax,8)
	incq	%r9
	cmpq	$255, %r9
	jne	.LBB115_3
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rax, 192(%rsp)
	movq	%rcx, 184(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 176(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 168(%rsp)
	movq	64(%rsp), %rax
	movq	%rax, 160(%rsp)
	movq	$1, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	movl	$254, %eax
	xorl	%ebx, %ebx
	movq	%rdi, 864(%rsp)
	.p2align	4
.LBB115_5:
	movq	%rax, 456(%rsp)
	movq	456(%rsp), %rax
	shrq	$3, %rax
	movzbl	(%rdi,%rax), %eax
	movq	456(%rsp), %rcx
	movl	%ecx, %edx
	andl	$7, %edx
	movq	%rbx, %rcx
	btl	%edx, %eax
	movl	$0, %eax
	setb	%al
	movq	%rax, 872(%rsp)
	xorq	%rax, %rcx
	movq	192(%rsp), %r9
	movq	%r9, 424(%rsp)
	movq	80(%rsp), %rdx
	movq	%rdx, 448(%rsp)
	movq	%rcx, 32(%rsp)
	movq	88(%rsp), %rax
	movq	%rax, 440(%rsp)
	movq	32(%rsp), %r8
	movq	%r8, %r10
	decq	%r8
	negq	%r10
	andq	%rdx, %r8
	movq	184(%rsp), %rdi
	movq	%rcx, 32(%rsp)
	andq	%r9, %r10
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	decq	%r9
	negq	%rdx
	andq	%rax, %r9
	movq	96(%rsp), %rax
	movq	%rax, 432(%rsp)
	movq	176(%rsp), %rsi
	orq	%r8, %r10
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r11
	movq	%r11, %r8
	andq	%rdi, %rdx
	negq	%r8
	decq	%r11
	andq	%rax, %r11
	orq	%r9, %rdx
	andq	%rsi, %r8
	movq	104(%rsp), %r12
	movq	168(%rsp), %r15
	orq	%r11, %r8
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r11
	movq	%r11, %r9
	negq	%r9
	decq	%r11
	andq	%r12, %r11
	andq	%r15, %r9
	orq	%r11, %r9
	movq	112(%rsp), %r13
	movq	%rcx, 32(%rsp)
	movq	160(%rsp), %r14
	movq	32(%rsp), %rbx
	movq	%rbx, %r11
	negq	%r11
	decq	%rbx
	andq	%r13, %rbx
	andq	%r14, %r11
	orq	%rbx, %r11
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rbx
	movq	%rbx, %rbp
	decq	%rbx
	andq	424(%rsp), %rbx
	negq	%rbp
	andq	448(%rsp), %rbp
	orq	%rbx, %rbp
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rbx
	movq	%rbx, %rax
	decq	%rbx
	andq	%rdi, %rbx
	negq	%rax
	andq	440(%rsp), %rax
	orq	%rbx, %rax
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rbx
	movq	%rbx, %rdi
	decq	%rbx
	andq	%rsi, %rbx
	negq	%rdi
	andq	432(%rsp), %rdi
	orq	%rbx, %rdi
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rbx
	movq	%rbx, %rsi
	decq	%rbx
	andq	%r15, %rbx
	negq	%rsi
	andq	%r12, %rsi
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r15
	movq	%r15, %r12
	decq	%r15
	andq	%r14, %r15
	negq	%r12
	orq	%rbx, %rsi
	andq	%r13, %r12
	orq	%r15, %r12
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	%rbp, 192(%rsp)
	movq	%rax, 184(%rsp)
	movq	%rdi, 176(%rsp)
	movq	%rsi, 168(%rsp)
	movq	%r12, 160(%rsp)
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	%r10, 80(%rsp)
	movq	%rdx, 88(%rsp)
	movq	%r8, 96(%rsp)
	movq	%r9, 104(%rsp)
	movq	%r11, 112(%rsp)
	movq	232(%rsp), %r10
	movq	%r10, 424(%rsp)
	movq	120(%rsp), %rdx
	movq	%rdx, 440(%rsp)
	movq	128(%rsp), %r8
	movq	%r8, 448(%rsp)
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, %r13
	negq	%r13
	decq	%rax
	movq	224(%rsp), %rdi
	andq	%rdx, %rax
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %r9
	movq	%r9, %rdx
	andq	%r10, %r13
	negq	%rdx
	decq	%r9
	andq	%r8, %r9
	orq	%rax, %r13
	movq	136(%rsp), %r14
	movq	216(%rsp), %rsi
	movq	%rcx, 32(%rsp)
	andq	%rdi, %rdx
	movq	32(%rsp), %r11
	movq	%r11, %r8
	negq	%r8
	orq	%r9, %rdx
	decq	%r11
	andq	%r14, %r11
	movq	144(%rsp), %rax
	movq	%rax, 432(%rsp)
	andq	%rsi, %r8
	movq	208(%rsp), %r10
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rbx
	orq	%r11, %r8
	movq	%rbx, %r9
	negq	%r9
	decq	%rbx
	andq	%rax, %rbx
	andq	%r10, %r9
	orq	%rbx, %r9
	movq	%rcx, 32(%rsp)
	movq	152(%rsp), %rbp
	movq	200(%rsp), %r11
	movq	32(%rsp), %r12
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rbx
	movq	%rbx, %r15
	decq	%rbx
	andq	424(%rsp), %rbx
	negq	%r15
	andq	440(%rsp), %r15
	orq	%rbx, %r15
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rbx
	movq	%rbx, %rax
	decq	%rbx
	andq	%rdi, %rbx
	negq	%rax
	andq	448(%rsp), %rax
	orq	%rbx, %rax
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rbx
	movq	%rbx, %rdi
	decq	%rbx
	andq	%rsi, %rbx
	negq	%rdi
	andq	%r14, %rdi
	orq	%rbx, %rdi
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rsi
	movq	%rsi, %r14
	decq	%rsi
	andq	%r10, %rsi
	negq	%r14
	andq	432(%rsp), %r14
	movq	%r12, %r10
	negq	%r10
	orq	%rsi, %r14
	movq	%rcx, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	%rcx, %rsi
	andq	%r11, %r10
	decq	%rcx
	andq	%r11, %rcx
	decq	%r12
	andq	%rbp, %r12
	negq	%rsi
	andq	%rbp, %rsi
	orq	%rcx, %rsi
	orq	%r12, %r10
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
	movq	%r15, 232(%rsp)
	movq	%rax, 224(%rsp)
	movq	%rdi, 216(%rsp)
	movq	%r14, 208(%rsp)
	movq	%rsi, 200(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	%r13, 120(%rsp)
	movq	%rdx, 128(%rsp)
	movq	%r8, 136(%rsp)
	movq	%r9, 144(%rsp)
	movq	%r10, 152(%rsp)
	xorl	%eax, %eax
	addq	80(%rsp), %r13
	setb	%al
	xorl	%r11d, %r11d
	addq	88(%rsp), %rdx
	setb	%r11b
	xorl	%edi, %edi
	addq	96(%rsp), %r8
	setb	%dil
	xorl	%esi, %esi
	addq	104(%rsp), %r9
	setb	%sil
	xorl	%ebx, %ebx
	addq	112(%rsp), %r10
	setb	%bl
	shldq	$13, %r13, %rax
	movabsq	$2251799813685247, %r14
	andq	%r14, %r13
	addq	%rdx, %rax
	adcq	$0, %r11
	shldq	$13, %rax, %r11
	andq	%r14, %rax
	addq	%r8, %r11
	adcq	$0, %rdi
	shldq	$13, %r11, %rdi
	andq	%r14, %r11
	addq	%r9, %rdi
	adcq	$0, %rsi
	shldq	$13, %rdi, %rsi
	andq	%r14, %rdi
	addq	%r10, %rsi
	adcl	$0, %ebx
	movq	%rsi, %rcx
	shrq	$51, %rcx
	shll	$13, %ebx
	orq	%rcx, %rbx
	leaq	(%rbx,%rbx,8), %rcx
	leaq	(%rbx,%rcx,2), %rdx
	addq	%r13, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rdx
	addq	%rax, %rdx
	andq	%r14, %rsi
	movq	%rdx, %r8
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %r9
	shrq	$51, %rdx
	addq	%rdi, %rdx
	movq	%rdx, %r10
	shrq	$51, %rdx
	addq	%rsi, %rdx
	movq	%rdx, %rax
	shrq	$51, %rax
	andq	%r14, %rcx
	leaq	(%rax,%rax,8), %r11
	leaq	(%rax,%r11,2), %rax
	addq	%rcx, %rax
	andq	%r14, %r8
	movq	%rax, %r11
	shrq	$51, %rax
	addq	%r8, %rax
	andq	%r14, %r9
	movq	%rax, %rcx
	shrq	$51, %rcx
	addq	%r9, %rcx
	andq	%r14, %r10
	movq	%rcx, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	andq	%r14, %rdx
	movq	%r8, %r9
	shrq	$51, %r9
	addq	%rdx, %r9
	movq	%r9, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r10
	leaq	(%rdx,%r10,2), %rdx
	andq	%r14, %r11
	addq	%r11, %rdx
	movq	%rdx, 576(%rsp)
	andq	%r14, %rax
	movq	%rax, 584(%rsp)
	andq	%r14, %rcx
	movq	%rcx, 592(%rsp)
	andq	%r14, %r8
	movq	%r8, 600(%rsp)
	andq	%r14, %r9
	movq	%r9, 608(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	leaq	464(%rsp), %rcx
	leaq	576(%rsp), %rdx
	movq	%rdx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	80(%rsp), %r9
	movq	88(%rsp), %rax
	subq	120(%rsp), %r9
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	movabsq	$4503599627370458, %r13
	addq	%r13, %r9
	adcq	$0, %rcx
	subq	128(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movq	%rcx, %r8
	shldq	$13, %r9, %rcx
	shrq	$51, %r8
	addq	%rax, %rcx
	adcq	%rdx, %r8
	movq	96(%rsp), %rax
	subq	136(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movabsq	$4503599627370494, %rbp
	addq	%rbp, %rcx
	adcq	$0, %r8
	movq	%r8, %r10
	shldq	$13, %rcx, %r8
	shrq	$51, %r10
	addq	%rax, %r8
	adcq	%rdx, %r10
	movq	104(%rsp), %rax
	subq	144(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %r8
	adcq	$0, %r10
	movq	%r10, %r11
	shldq	$13, %r8, %r10
	shrq	$51, %r11
	addq	%rax, %r10
	adcq	%rdx, %r11
	movq	112(%rsp), %rax
	subq	152(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %r10
	adcq	$0, %r11
	movq	%r11, %rsi
	shldq	$13, %r10, %r11
	shrq	$51, %rsi
	addq	%rax, %r11
	adcq	%rdx, %rsi
	andq	%r14, %r9
	andq	%r14, %rcx
	andq	%r14, %r8
	andq	%r14, %r10
	addq	%rbp, %r11
	adcq	$0, %rsi
	movq	%rsi, %rax
	shldq	$13, %r11, %rax
	shrq	$51, %rsi
	andq	%r14, %r11
	leaq	(%rsi,%rsi,8), %rdx
	leaq	(%rsi,%rdx,2), %rsi
	movl	$19, %edx
	mulq	%rdx
	movl	$19, %edi
	addq	%r9, %rax
	adcq	%rsi, %rdx
	shldq	$13, %rax, %rdx
	andq	%r14, %rax
	addq	%rcx, %rdx
	movq	%rdx, %r9
	andq	%r14, %r9
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r14, %r8
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%r14, %r10
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r14, %rdx
	leaq	(%rcx,%rcx,8), %r11
	leaq	(%rcx,%r11,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	andq	%r14, %rax
	shrq	$51, %rcx
	addq	%r9, %rcx
	movq	%rcx, %r9
	shrq	$51, %r9
	addq	%r8, %r9
	movq	%r9, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	movq	%r8, %r10
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r11
	leaq	(%rdx,%r11,2), %rdx
	addq	%rax, %rdx
	andq	%r14, %rcx
	andq	%r14, %r9
	andq	%r14, %r8
	andq	%r14, %r10
	movq	%rdx, 696(%rsp)
	movq	%rcx, 704(%rsp)
	movq	%r9, 712(%rsp)
	movq	%r8, 720(%rsp)
	movq	%r10, 728(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	leaq	616(%rsp), %rcx
	leaq	696(%rsp), %r15
	movq	%r15, %rdx
	movq	%r15, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	464(%rsp), %r9
	movq	472(%rsp), %rax
	subq	616(%rsp), %r9
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%r13, %r9
	adcq	$0, %rcx
	subq	624(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movq	%rcx, %r8
	shldq	$13, %r9, %rcx
	shrq	$51, %r8
	addq	%rax, %rcx
	adcq	%rdx, %r8
	movq	480(%rsp), %rax
	subq	632(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %rcx
	adcq	$0, %r8
	movq	%r8, %r10
	shldq	$13, %rcx, %r8
	shrq	$51, %r10
	addq	%rax, %r8
	adcq	%rdx, %r10
	movq	488(%rsp), %rax
	subq	640(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %r8
	adcq	$0, %r10
	movq	%r10, %r11
	shldq	$13, %r8, %r10
	shrq	$51, %r11
	addq	%rax, %r10
	adcq	%rdx, %r11
	movq	496(%rsp), %rax
	subq	648(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %r10
	adcq	$0, %r11
	movq	%r11, %rsi
	shldq	$13, %r10, %r11
	shrq	$51, %rsi
	addq	%rax, %r11
	adcq	%rdx, %rsi
	andq	%r14, %r9
	andq	%r14, %rcx
	andq	%r14, %r8
	andq	%r14, %r10
	addq	%rbp, %r11
	adcq	$0, %rsi
	movq	%rsi, %rax
	shldq	$13, %r11, %rax
	shrq	$51, %rsi
	andq	%r14, %r11
	leaq	(%rsi,%rsi,8), %rdx
	leaq	(%rsi,%rdx,2), %rsi
	mulq	%rdi
	movl	$19, %r12d
	addq	%r9, %rax
	adcq	%rsi, %rdx
	shldq	$13, %rax, %rdx
	andq	%r14, %rax
	addq	%rcx, %rdx
	movq	%rdx, %r9
	andq	%r14, %r9
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r14, %r8
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%r14, %r10
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r14, %rdx
	leaq	(%rcx,%rcx,8), %r11
	leaq	(%rcx,%r11,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	andq	%r14, %rax
	shrq	$51, %rcx
	addq	%r9, %rcx
	movq	%rcx, %r9
	shrq	$51, %r9
	addq	%r8, %r9
	movq	%r9, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	movq	%r8, %r10
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r11
	leaq	(%rdx,%r11,2), %rdx
	addq	%rax, %rdx
	andq	%r14, %rcx
	andq	%r14, %r9
	andq	%r14, %r8
	andq	%r14, %r10
	movq	%rdx, 736(%rsp)
	movq	%rcx, 744(%rsp)
	movq	%r9, 752(%rsp)
	movq	%r8, 760(%rsp)
	movq	%r10, 768(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	movq	232(%rsp), %r8
	xorl	%eax, %eax
	addq	192(%rsp), %r8
	setb	%al
	movq	224(%rsp), %r11
	xorl	%ecx, %ecx
	addq	184(%rsp), %r11
	setb	%cl
	movq	216(%rsp), %rsi
	xorl	%edx, %edx
	addq	176(%rsp), %rsi
	setb	%dl
	movq	208(%rsp), %rdi
	xorl	%r9d, %r9d
	addq	168(%rsp), %rdi
	setb	%r9b
	movq	200(%rsp), %rbx
	xorl	%r10d, %r10d
	addq	160(%rsp), %rbx
	setb	%r10b
	shldq	$13, %r8, %rax
	andq	%r14, %r8
	addq	%r11, %rax
	adcq	$0, %rcx
	shldq	$13, %rax, %rcx
	andq	%r14, %rax
	addq	%rsi, %rcx
	adcq	$0, %rdx
	shldq	$13, %rcx, %rdx
	andq	%r14, %rcx
	addq	%rdi, %rdx
	adcq	$0, %r9
	shldq	$13, %rdx, %r9
	andq	%r14, %rdx
	addq	%rbx, %r9
	adcl	$0, %r10d
	movq	%r9, %r11
	shrq	$51, %r11
	shll	$13, %r10d
	orq	%r11, %r10
	andq	%r14, %r9
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r10
	addq	%r8, %r10
	movq	%r10, %r8
	andq	%r14, %r8
	shrq	$51, %r10
	addq	%rax, %r10
	movq	%r10, %r11
	andq	%r14, %r11
	shrq	$51, %r10
	addq	%rcx, %r10
	movq	%r10, %rcx
	andq	%r14, %rcx
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	andq	%r14, %rdx
	shrq	$51, %r10
	addq	%r9, %r10
	movq	%r10, %rax
	shrq	$51, %rax
	andq	%r14, %r10
	leaq	(%rax,%rax,8), %r9
	leaq	(%rax,%r9,2), %rax
	addq	%r8, %rax
	movq	%rax, %r8
	andq	%r14, %r8
	shrq	$51, %rax
	addq	%r11, %rax
	movq	%rax, %r9
	shrq	$51, %r9
	addq	%rcx, %r9
	movq	%r9, %rcx
	shrq	$51, %rcx
	addq	%rdx, %rcx
	movq	%rcx, %rdx
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	shrq	$51, %r10
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r10
	addq	%r8, %r10
	andq	%r14, %rax
	andq	%r14, %r9
	andq	%r14, %rcx
	andq	%r14, %rdx
	movq	%r10, 776(%rsp)
	movq	%rax, 784(%rsp)
	movq	%r9, 792(%rsp)
	movq	%rcx, 800(%rsp)
	movq	%rdx, 808(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	movq	192(%rsp), %r9
	subq	232(%rsp), %r9
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%r13, %r9
	adcq	$0, %rcx
	movq	184(%rsp), %rax
	subq	224(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movq	%rcx, %r8
	shldq	$13, %r9, %rcx
	shrq	$51, %r8
	addq	%rax, %rcx
	adcq	%rdx, %r8
	movq	176(%rsp), %rax
	subq	216(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %rcx
	adcq	$0, %r8
	movq	%r8, %r10
	shldq	$13, %rcx, %r8
	shrq	$51, %r10
	addq	%rax, %r8
	adcq	%rdx, %r10
	movq	168(%rsp), %rax
	subq	208(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %r8
	adcq	$0, %r10
	movq	%r10, %r11
	shldq	$13, %r8, %r10
	shrq	$51, %r11
	addq	%rax, %r10
	adcq	%rdx, %r11
	movq	160(%rsp), %rax
	subq	200(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %r10
	adcq	$0, %r11
	movq	%r11, %rsi
	shldq	$13, %r10, %r11
	shrq	$51, %rsi
	addq	%rax, %r11
	adcq	%rdx, %rsi
	andq	%r14, %r9
	andq	%r14, %rcx
	andq	%r14, %r8
	andq	%r14, %r10
	addq	%rbp, %r11
	adcq	$0, %rsi
	movq	%rsi, %rax
	shldq	$13, %r11, %rax
	shrq	$51, %rsi
	andq	%r14, %r11
	leaq	(%rsi,%rsi,8), %rdx
	leaq	(%rsi,%rdx,2), %rsi
	mulq	%r12
	addq	%r9, %rax
	adcq	%rsi, %rdx
	shldq	$13, %rax, %rdx
	andq	%r14, %rax
	addq	%rcx, %rdx
	movq	%rdx, %r9
	andq	%r14, %r9
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r14, %r8
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%r14, %r10
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r14, %rdx
	leaq	(%rcx,%rcx,8), %r11
	leaq	(%rcx,%r11,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	andq	%r14, %rax
	shrq	$51, %rcx
	addq	%r9, %rcx
	movq	%rcx, %r9
	shrq	$51, %r9
	addq	%r8, %r9
	movq	%r9, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	movq	%r8, %r10
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r11
	leaq	(%rdx,%r11,2), %rdx
	addq	%rax, %rdx
	andq	%r14, %rcx
	andq	%r14, %r9
	andq	%r14, %r8
	andq	%r14, %r10
	movq	%rdx, 816(%rsp)
	movq	%rcx, 824(%rsp)
	movq	%r9, 832(%rsp)
	movq	%r8, 840(%rsp)
	movq	%r10, 848(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 336(%rsp)
	#MEMBARRIER
	leaq	504(%rsp), %rcx
	leaq	816(%rsp), %rdx
	leaq	576(%rsp), %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	336(%rsp), %rcx
	leaq	776(%rsp), %rdx
	movq	%r15, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	336(%rsp), %r8
	movq	344(%rsp), %r11
	xorl	%eax, %eax
	addq	504(%rsp), %r8
	setb	%al
	xorl	%ecx, %ecx
	addq	512(%rsp), %r11
	setb	%cl
	movq	352(%rsp), %rsi
	xorl	%edx, %edx
	addq	520(%rsp), %rsi
	setb	%dl
	movq	360(%rsp), %rdi
	xorl	%r9d, %r9d
	addq	528(%rsp), %rdi
	setb	%r9b
	movq	368(%rsp), %rbx
	xorl	%r10d, %r10d
	addq	536(%rsp), %rbx
	setb	%r10b
	shldq	$13, %r8, %rax
	andq	%r14, %r8
	addq	%r11, %rax
	adcq	$0, %rcx
	shldq	$13, %rax, %rcx
	andq	%r14, %rax
	addq	%rsi, %rcx
	adcq	$0, %rdx
	shldq	$13, %rcx, %rdx
	andq	%r14, %rcx
	addq	%rdi, %rdx
	adcq	$0, %r9
	shldq	$13, %rdx, %r9
	andq	%r14, %rdx
	addq	%rbx, %r9
	adcl	$0, %r10d
	movq	%r9, %r11
	shrq	$51, %r11
	shll	$13, %r10d
	orq	%r11, %r10
	andq	%r14, %r9
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r10
	addq	%r8, %r10
	movq	%r10, %r8
	andq	%r14, %r8
	shrq	$51, %r10
	addq	%rax, %r10
	movq	%r10, %r11
	andq	%r14, %r11
	shrq	$51, %r10
	addq	%rcx, %r10
	movq	%r10, %rcx
	andq	%r14, %rcx
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	andq	%r14, %rdx
	shrq	$51, %r10
	addq	%r9, %r10
	movq	%r10, %rax
	shrq	$51, %rax
	andq	%r14, %r10
	leaq	(%rax,%rax,8), %r9
	leaq	(%rax,%r9,2), %rax
	addq	%r8, %rax
	movq	%rax, %r8
	andq	%r14, %r8
	shrq	$51, %rax
	addq	%r11, %rax
	movq	%rax, %r9
	shrq	$51, %r9
	addq	%rcx, %r9
	movq	%r9, %rcx
	shrq	$51, %rcx
	addq	%rdx, %rcx
	movq	%rcx, %rdx
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	shrq	$51, %r10
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r10
	addq	%r8, %r10
	andq	%r14, %rax
	andq	%r14, %r9
	andq	%r14, %rcx
	andq	%r14, %rdx
	movq	%r10, 32(%rsp)
	movq	%rax, 40(%rsp)
	movq	%r9, 48(%rsp)
	movq	%rcx, 56(%rsp)
	movq	%rdx, 64(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	leaq	240(%rsp), %rdi
	movq	%rdi, %rcx
	leaq	32(%rsp), %rbx
	movq	%rbx, %rdx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	240(%rsp), %rax
	movq	248(%rsp), %rcx
	movq	%rax, 192(%rsp)
	movq	%rcx, 184(%rsp)
	movq	256(%rsp), %rax
	movq	%rax, 176(%rsp)
	movq	264(%rsp), %rax
	movq	%rax, 168(%rsp)
	movq	272(%rsp), %rax
	movq	%rax, 160(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	504(%rsp), %r9
	movq	512(%rsp), %rax
	subq	336(%rsp), %r9
	movl	$0, %ecx
	sbbq	%rcx, %rcx
	addq	%r13, %r9
	adcq	$0, %rcx
	subq	344(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	movq	%rcx, %r8
	shldq	$13, %r9, %rcx
	shrq	$51, %r8
	addq	%rax, %rcx
	adcq	%rdx, %r8
	movq	520(%rsp), %rax
	subq	352(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %rcx
	adcq	$0, %r8
	movq	%r8, %r10
	shldq	$13, %rcx, %r8
	shrq	$51, %r10
	addq	%rax, %r8
	adcq	%rdx, %r10
	movq	528(%rsp), %rax
	subq	360(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %r8
	adcq	$0, %r10
	movq	%r10, %r11
	shldq	$13, %r8, %r10
	shrq	$51, %r11
	addq	%rax, %r10
	adcq	%rdx, %r11
	movq	536(%rsp), %rax
	subq	368(%rsp), %rax
	movl	$0, %edx
	sbbq	%rdx, %rdx
	addq	%rbp, %r10
	adcq	$0, %r11
	movq	%r11, %rsi
	shldq	$13, %r10, %r11
	shrq	$51, %rsi
	addq	%rax, %r11
	adcq	%rdx, %rsi
	andq	%r14, %r9
	andq	%r14, %rcx
	andq	%r14, %r8
	andq	%r14, %r10
	addq	%rbp, %r11
	adcq	$0, %rsi
	movq	%rsi, %rax
	shldq	$13, %r11, %rax
	shrq	$51, %rsi
	andq	%r14, %r11
	leaq	(%rsi,%rsi,8), %rdx
	leaq	(%rsi,%rdx,2), %rsi
	mulq	%r12
	addq	%r9, %rax
	adcq	%rsi, %rdx
	shldq	$13, %rax, %rdx
	andq	%r14, %rax
	addq	%rcx, %rdx
	movq	%rdx, %r9
	andq	%r14, %r9
	shrq	$51, %rdx
	addq	%r8, %rdx
	movq	%rdx, %r8
	andq	%r14, %r8
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	andq	%r14, %r10
	shrq	$51, %rdx
	addq	%r11, %rdx
	movq	%rdx, %rcx
	shrq	$51, %rcx
	andq	%r14, %rdx
	leaq	(%rcx,%rcx,8), %r11
	leaq	(%rcx,%r11,2), %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	andq	%r14, %rax
	shrq	$51, %rcx
	addq	%r9, %rcx
	movq	%rcx, %r9
	shrq	$51, %r9
	addq	%r8, %r9
	movq	%r9, %r8
	shrq	$51, %r8
	addq	%r10, %r8
	movq	%r8, %r10
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	shrq	$51, %rdx
	leaq	(%rdx,%rdx,8), %r11
	leaq	(%rdx,%r11,2), %rdx
	addq	%rax, %rdx
	andq	%r14, %rcx
	andq	%r14, %r9
	andq	%r14, %r8
	andq	%r14, %r10
	movq	%rdx, 32(%rsp)
	movq	%rcx, 40(%rsp)
	movq	%r9, 48(%rsp)
	movq	%r8, 56(%rsp)
	movq	%r10, 64(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 288(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	#MEMBARRIER
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	movq	%rbx, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	leaq	288(%rsp), %r15
	movq	%r15, %rcx
	leaq	656(%rsp), %rdx
	movq	%rdi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
	movq	288(%rsp), %rax
	movq	296(%rsp), %rcx
	movq	%rax, 232(%rsp)
	movq	%rcx, 224(%rsp)
	movq	304(%rsp), %rax
	movq	%rax, 216(%rsp)
	movq	312(%rsp), %rax
	movq	%rax, 208(%rsp)
	movq	320(%rsp), %rax
	movq	%rax, 200(%rsp)
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	%rbx, %rcx
	leaq	464(%rsp), %rdx
	leaq	616(%rsp), %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	64(%rsp), %rax
	movq	%rax, 112(%rsp)
	movq	56(%rsp), %rax
	movq	%rax, 104(%rsp)
	movq	48(%rsp), %rax
	movq	%rax, 96(%rsp)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 88(%rsp)
	movq	%rax, 80(%rsp)
	movq	$121665, 32(%rsp)
	leaq	40(%rsp), %rax
	movq	$0, 24(%rax)
	movq	$0, 16(%rax)
	movq	$0, 8(%rax)
	movq	$0, (%rax)
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	leaq	736(%rsp), %r12
	movq	%r12, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	240(%rsp), %r8
	movq	248(%rsp), %r11
	xorl	%eax, %eax
	addq	464(%rsp), %r8
	setb	%al
	xorl	%ecx, %ecx
	addq	472(%rsp), %r11
	setb	%cl
	movq	256(%rsp), %rsi
	xorl	%edx, %edx
	addq	480(%rsp), %rsi
	setb	%dl
	movq	264(%rsp), %rdi
	xorl	%r9d, %r9d
	addq	488(%rsp), %rdi
	setb	%r9b
	movq	272(%rsp), %rbx
	xorl	%r10d, %r10d
	addq	496(%rsp), %rbx
	setb	%r10b
	shldq	$13, %r8, %rax
	andq	%r14, %r8
	addq	%r11, %rax
	adcq	$0, %rcx
	shldq	$13, %rax, %rcx
	andq	%r14, %rax
	addq	%rsi, %rcx
	adcq	$0, %rdx
	shldq	$13, %rcx, %rdx
	andq	%r14, %rcx
	addq	%rdi, %rdx
	movq	864(%rsp), %rdi
	adcq	$0, %r9
	shldq	$13, %rdx, %r9
	andq	%r14, %rdx
	addq	%rbx, %r9
	movq	872(%rsp), %rbx
	adcl	$0, %r10d
	movq	%r9, %r11
	shrq	$51, %r11
	shll	$13, %r10d
	orq	%r11, %r10
	andq	%r14, %r9
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r10
	addq	%r8, %r10
	movq	%r10, %r8
	andq	%r14, %r8
	shrq	$51, %r10
	addq	%rax, %r10
	movq	%r10, %r11
	andq	%r14, %r11
	shrq	$51, %r10
	addq	%rcx, %r10
	movq	%r10, %rcx
	andq	%r14, %rcx
	shrq	$51, %r10
	addq	%rdx, %r10
	movq	%r10, %rdx
	andq	%r14, %rdx
	shrq	$51, %r10
	addq	%r9, %r10
	movq	%r10, %rax
	shrq	$51, %rax
	andq	%r14, %r10
	leaq	(%rax,%rax,8), %r9
	leaq	(%rax,%r9,2), %rax
	addq	%r8, %rax
	movq	%rax, %r8
	andq	%r14, %r8
	shrq	$51, %rax
	addq	%r11, %rax
	movq	%rax, %r9
	shrq	$51, %r9
	addq	%rcx, %r9
	movq	%r9, %rcx
	shrq	$51, %rcx
	addq	%rdx, %rcx
	movq	%rcx, %rdx
	shrq	$51, %rdx
	addq	%r10, %rdx
	movq	%rdx, %r10
	shrq	$51, %r10
	leaq	(%r10,%r10,8), %r11
	leaq	(%r10,%r11,2), %r10
	addq	%r8, %r10
	andq	%r14, %rax
	andq	%r14, %r9
	andq	%r14, %rcx
	andq	%r14, %rdx
	movq	%r10, 288(%rsp)
	movq	%rax, 296(%rsp)
	movq	%r9, 304(%rsp)
	movq	%rcx, 312(%rsp)
	movq	%rdx, 320(%rsp)
	movq	$0, 392(%rsp)
	movq	$0, 384(%rsp)
	movq	$0, 568(%rsp)
	movq	$0, 560(%rsp)
	movq	$0, 552(%rsp)
	movq	$0, 544(%rsp)
	movq	$0, 904(%rsp)
	movq	$0, 896(%rsp)
	movq	$0, 888(%rsp)
	movq	$0, 880(%rsp)
	#MEMBARRIER
	leaq	384(%rsp), %rcx
	movq	%r12, %rdx
	movq	%r15, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	416(%rsp), %rax
	movq	%rax, 152(%rsp)
	movq	408(%rsp), %rax
	movq	%rax, 144(%rsp)
	movq	400(%rsp), %rax
	movq	%rax, 136(%rsp)
	movq	384(%rsp), %rax
	movq	392(%rsp), %rcx
	movq	%rcx, 128(%rsp)
	movq	%rax, 120(%rsp)
	movq	456(%rsp), %rax
	movq	$0, 288(%rsp)
	movq	$0, 296(%rsp)
	movq	$0, 304(%rsp)
	movq	$0, 312(%rsp)
	movq	$0, 320(%rsp)
	#MEMBARRIER
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 336(%rsp)
	movq	$0, 344(%rsp)
	movq	$0, 352(%rsp)
	movq	$0, 360(%rsp)
	movq	$0, 368(%rsp)
	#MEMBARRIER
	movq	$0, 504(%rsp)
	movq	$0, 512(%rsp)
	movq	$0, 520(%rsp)
	movq	$0, 528(%rsp)
	movq	$0, 536(%rsp)
	#MEMBARRIER
	movq	$0, 816(%rsp)
	movq	$0, 824(%rsp)
	movq	$0, 832(%rsp)
	movq	$0, 840(%rsp)
	movq	$0, 848(%rsp)
	#MEMBARRIER
	movq	$0, 776(%rsp)
	movq	$0, 784(%rsp)
	movq	$0, 792(%rsp)
	movq	$0, 800(%rsp)
	movq	$0, 808(%rsp)
	#MEMBARRIER
	movq	$0, 736(%rsp)
	movq	$0, 744(%rsp)
	movq	$0, 752(%rsp)
	movq	$0, 760(%rsp)
	movq	$0, 768(%rsp)
	#MEMBARRIER
	movq	$0, 616(%rsp)
	movq	$0, 624(%rsp)
	movq	$0, 632(%rsp)
	movq	$0, 640(%rsp)
	movq	$0, 648(%rsp)
	#MEMBARRIER
	movq	$0, 696(%rsp)
	movq	$0, 704(%rsp)
	movq	$0, 712(%rsp)
	movq	$0, 720(%rsp)
	movq	$0, 728(%rsp)
	#MEMBARRIER
	movq	$0, 464(%rsp)
	movq	$0, 472(%rsp)
	movq	$0, 480(%rsp)
	movq	$0, 488(%rsp)
	movq	$0, 496(%rsp)
	#MEMBARRIER
	movq	$0, 576(%rsp)
	movq	$0, 584(%rsp)
	movq	$0, 592(%rsp)
	movq	$0, 600(%rsp)
	movq	$0, 608(%rsp)
	#MEMBARRIER
	addq	$-1, %rax
	jb	.LBB115_5
	movq	192(%rsp), %rcx
	movq	80(%rsp), %rdx
	movq	88(%rsp), %r8
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, %r9
	negq	%r9
	andq	%rcx, %r9
	decq	%rax
	andq	%rdx, %rax
	orq	%r9, %rax
	movq	184(%rsp), %rdx
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	%rcx, %r9
	negq	%r9
	andq	%rdx, %r9
	decq	%rcx
	andq	%r8, %rcx
	orq	%r9, %rcx
	movq	96(%rsp), %r8
	movq	176(%rsp), %r9
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rdx
	movq	%rdx, %r10
	negq	%r10
	andq	%r9, %r10
	decq	%rdx
	andq	%r8, %rdx
	orq	%r10, %rdx
	movq	104(%rsp), %r9
	movq	168(%rsp), %r10
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %r8
	movq	%r8, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%r8
	andq	%r9, %r8
	orq	%r11, %r8
	movq	112(%rsp), %r9
	movq	160(%rsp), %r10
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %r11
	movq	%r11, %rsi
	negq	%rsi
	andq	%r10, %rsi
	decq	%r11
	andq	%r9, %r11
	orq	%rsi, %r11
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	%rax, 80(%rsp)
	movq	%rcx, 88(%rsp)
	movq	%rdx, 96(%rsp)
	movq	%r8, 104(%rsp)
	movq	%r11, 112(%rsp)
	movq	232(%rsp), %rcx
	movq	120(%rsp), %rdx
	movq	128(%rsp), %r8
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rax
	movq	%rax, %r9
	negq	%r9
	andq	%rcx, %r9
	decq	%rax
	andq	%rdx, %rax
	orq	%r9, %rax
	movq	224(%rsp), %rdx
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rcx
	movq	%rcx, %r9
	negq	%r9
	andq	%rdx, %r9
	decq	%rcx
	andq	%r8, %rcx
	orq	%r9, %rcx
	movq	136(%rsp), %r8
	movq	216(%rsp), %r9
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %rdx
	movq	%rdx, %r10
	negq	%r10
	andq	%r9, %r10
	decq	%rdx
	andq	%r8, %rdx
	orq	%r10, %rdx
	movq	144(%rsp), %r9
	movq	208(%rsp), %r10
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %r8
	movq	%r8, %r11
	negq	%r11
	andq	%r10, %r11
	decq	%r8
	andq	%r9, %r8
	orq	%r11, %r8
	movq	152(%rsp), %r9
	movq	200(%rsp), %r10
	movq	%rbx, 32(%rsp)
	movq	32(%rsp), %r11
	movq	%r11, %rsi
	negq	%rsi
	andq	%r10, %rsi
	decq	%r11
	andq	%r9, %r11
	orq	%rsi, %r11
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	%rax, 120(%rsp)
	movq	%rcx, 128(%rsp)
	movq	%rdx, 136(%rsp)
	movq	%r8, 144(%rsp)
	movq	%r11, 152(%rsp)
	movq	$-1, 263(%rsp)
	movq	$-1, 257(%rsp)
	movq	$-1, 249(%rsp)
	movq	$-1, 241(%rsp)
	movb	$-21, 240(%rsp)
	movb	$127, 271(%rsp)
	leaq	32(%rsp), %rsi
	leaq	120(%rsp), %rdx
	leaq	240(%rsp), %r8
	movl	$255, %r9d
	movq	%rsi, %rcx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3pow
	leaq	240(%rsp), %rdi
	leaq	80(%rsp), %rdx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F3mul
	movq	856(%rsp), %rcx
	movq	%rdi, %rdx
	callq	_RNvMs_NtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB4_1F5bytes
	movq	$0, 240(%rsp)
	movq	$0, 248(%rsp)
	movq	$0, 256(%rsp)
	movq	$0, 264(%rsp)
	movq	$0, 272(%rsp)
	#MEMBARRIER
	movq	$0, 32(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 48(%rsp)
	movq	$0, 56(%rsp)
	movq	$0, 64(%rsp)
	#MEMBARRIER
	movq	$0, 232(%rsp)
	movq	$0, 224(%rsp)
	movq	$0, 216(%rsp)
	movq	$0, 208(%rsp)
	movq	$0, 200(%rsp)
	#MEMBARRIER
	movq	$0, 192(%rsp)
	movq	$0, 184(%rsp)
	movq	$0, 176(%rsp)
	movq	$0, 168(%rsp)
	movq	$0, 160(%rsp)
	#MEMBARRIER
	movq	$0, 120(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 152(%rsp)
	#MEMBARRIER
	movq	$0, 80(%rsp)
	movq	$0, 88(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 112(%rsp)
	#MEMBARRIER
	movq	$0, 656(%rsp)
	movq	$0, 664(%rsp)
	movq	$0, 672(%rsp)
	movq	$0, 680(%rsp)
	movq	$0, 688(%rsp)
	#MEMBARRIER
	addq	$920, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	retq

	.def	_RNvNtNtCs3ONsSsjNgxw_12toyos_crypto4arch6x86_645ghash;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvNtNtCs3ONsSsjNgxw_12toyos_crypto4arch6x86_645ghash,unique,116
	.p2align	4
_RNvNtNtCs3ONsSsjNgxw_12toyos_crypto4arch6x86_645ghash:
	pushq	%r14
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$168, %rsp
	bswapq	%rdx
	movq	%rdx, %rax
	shrq	$4, %rax
	movabsq	$1085102592571150095, %r11
	andq	%r11, %rax
	andq	%r11, %rdx
	shlq	$4, %rdx
	orq	%rax, %rdx
	movabsq	$3689348814741910323, %r10
	movq	%rdx, %rax
	andq	%r10, %rax
	shrq	$2, %rdx
	andq	%r10, %rdx
	leaq	(%rdx,%rax,4), %rax
	movabsq	$6148914691236517205, %rdx
	movq	%rax, %rsi
	andq	%rdx, %rsi
	shrq	%rax
	andq	%rdx, %rax
	leaq	(%rax,%rsi,2), %rax
	bswapq	%rcx
	movq	%rcx, %rsi
	shrq	$4, %rsi
	andq	%r11, %rsi
	andq	%r11, %rcx
	shlq	$4, %rcx
	orq	%rsi, %rcx
	movq	%rcx, %rsi
	andq	%r10, %rsi
	shrq	$2, %rcx
	andq	%r10, %rcx
	leaq	(%rcx,%rsi,4), %rcx
	movq	%rcx, %rsi
	andq	%rdx, %rsi
	shrq	%rcx
	andq	%rdx, %rcx
	leaq	(%rcx,%rsi,2), %rcx
	movq	%rcx, 56(%rsp)
	movq	%rax, 48(%rsp)
	bswapq	%r9
	movq	%r9, %rax
	shrq	$4, %rax
	andq	%r11, %rax
	andq	%r11, %r9
	shlq	$4, %r9
	orq	%rax, %r9
	movq	%r9, %rax
	andq	%r10, %rax
	shrq	$2, %r9
	andq	%r10, %r9
	leaq	(%r9,%rax,4), %rax
	movq	%rax, %rcx
	andq	%rdx, %rcx
	shrq	%rax
	andq	%rdx, %rax
	leaq	(%rax,%rcx,2), %rax
	bswapq	%r8
	movq	%r8, %rcx
	shrq	$4, %rcx
	andq	%r11, %rcx
	andq	%r11, %r8
	shlq	$4, %r8
	orq	%rcx, %r8
	movq	%r8, %rcx
	andq	%r10, %rcx
	shrq	$2, %r8
	andq	%r10, %r8
	leaq	(%r8,%rcx,4), %rcx
	movq	%rcx, %r8
	andq	%rdx, %r8
	shrq	%rcx
	andq	%rdx, %rcx
	leaq	(%rcx,%r8,2), %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 64(%rsp)
	movq	$0, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	$0, 24(%rsp)
	movq	$0, 16(%rsp)
	movq	$0, 8(%rsp)
	movq	$0, (%rsp)
	movq	$0, 160(%rsp)
	movq	$0, 152(%rsp)
	movq	$0, 144(%rsp)
	movq	$0, 136(%rsp)
	movq	$0, 128(%rsp)
	movq	$0, 120(%rsp)
	movq	$0, 112(%rsp)
	movq	$0, 104(%rsp)
	movq	$0, 96(%rsp)
	movq	$0, 88(%rsp)
	leaq	88(%rsp), %rax
	leaq	48(%rsp), %rcx
	leaq	64(%rsp), %r8
	movq	%rsp, %r9
	#APP

	movdqu	%xmm0, (%rax)
	movdqu	%xmm1, 16(%rax)
	movdqu	%xmm2, 32(%rax)
	movdqu	%xmm3, 48(%rax)
	movdqu	%xmm4, 64(%rax)
	movdqu	(%rcx), %xmm0
	movdqu	(%r8), %xmm1
	movdqa	%xmm0, %xmm2
	pclmulqdq	$0, %xmm1, %xmm2
	movdqu	%xmm2, (%r9)
	movdqa	%xmm0, %xmm3
	pclmulqdq	$17, %xmm1, %xmm3
	movdqu	%xmm3, 16(%r9)
	pshufd	$78, %xmm0, %xmm4
	pxor	%xmm4, %xmm0
	pshufd	$78, %xmm1, %xmm4
	pxor	%xmm4, %xmm1
	pclmulqdq	$0, %xmm1, %xmm0
	pxor	%xmm2, %xmm0
	pxor	%xmm3, %xmm0
	movdqu	%xmm0, 32(%r9)
	movdqu	(%rax), %xmm0
	movdqu	16(%rax), %xmm1
	movdqu	32(%rax), %xmm2
	movdqu	48(%rax), %xmm3
	movdqu	64(%rax), %xmm4

	#NO_APP
	movq	40(%rsp), %r8
	movq	24(%rsp), %r9
	movq	32(%rsp), %rax
	xorq	8(%rsp), %rax
	xorq	16(%rsp), %r8
	movq	%r9, %rsi
	movq	%r9, %rdi
	shldq	$1, %r8, %rdi
	movq	%r9, %rcx
	movq	%r9, %rbx
	shldq	$2, %r8, %rbx
	xorq	%rax, %rdi
	movq	%r9, %rax
	shldq	$7, %r8, %rax
	xorq	%rbx, %rax
	xorq	%rdi, %rax
	xorq	%r9, %rax
	shrq	$63, %r9
	shrq	$62, %rsi
	xorq	%r9, %rsi
	shrq	$57, %rcx
	xorq	%rsi, %rcx
	leaq	(%r8,%r8), %r9
	leaq	(,%r8,4), %rsi
	leal	(%rcx,%rcx), %edi
	leal	(,%rcx,4), %ebx
	movl	%ecx, %r14d
	xorq	%r8, %rcx
	shlq	$7, %r8
	xorq	%rsi, %r8
	xorq	%r8, %rdi
	xorq	%rdi, %rbx
	shll	$7, %r14d
	xorq	%rbx, %r14
	xorq	(%rsp), %r9
	xorq	%r14, %r9
	xorq	%r9, %rcx
	bswapq	%rax
	movq	%rax, %r8
	shrq	$4, %r8
	andq	%r11, %r8
	andq	%r11, %rax
	shlq	$4, %rax
	orq	%r8, %rax
	movq	%rax, %r8
	andq	%r10, %r8
	shrq	$2, %rax
	andq	%r10, %rax
	leaq	(%rax,%r8,4), %rax
	movq	%rax, %r8
	andq	%rdx, %r8
	shrq	%rax
	andq	%rdx, %rax
	leaq	(%rax,%r8,2), %rax
	bswapq	%rcx
	movq	%rcx, %r8
	shrq	$4, %r8
	andq	%r11, %r8
	andq	%r11, %rcx
	shlq	$4, %rcx
	orq	%r8, %rcx
	movq	%rcx, %r8
	andq	%r10, %r8
	shrq	$2, %rcx
	andq	%r10, %rcx
	leaq	(%rcx,%r8,4), %rcx
	movq	%rcx, %r8
	andq	%rdx, %r8
	shrq	%rcx
	andq	%rdx, %rcx
	leaq	(%rcx,%r8,2), %rdx
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	movb	$0, 96(%rsp)
	movb	$0, 97(%rsp)
	movb	$0, 98(%rsp)
	movb	$0, 99(%rsp)
	movb	$0, 100(%rsp)
	movb	$0, 101(%rsp)
	movb	$0, 102(%rsp)
	movb	$0, 103(%rsp)
	movb	$0, 104(%rsp)
	movb	$0, 105(%rsp)
	movb	$0, 106(%rsp)
	movb	$0, 107(%rsp)
	movb	$0, 108(%rsp)
	movb	$0, 109(%rsp)
	movb	$0, 110(%rsp)
	movb	$0, 111(%rsp)
	movb	$0, 112(%rsp)
	movb	$0, 113(%rsp)
	movb	$0, 114(%rsp)
	movb	$0, 115(%rsp)
	movb	$0, 116(%rsp)
	movb	$0, 117(%rsp)
	movb	$0, 118(%rsp)
	movb	$0, 119(%rsp)
	movb	$0, 120(%rsp)
	movb	$0, 121(%rsp)
	movb	$0, 122(%rsp)
	movb	$0, 123(%rsp)
	movb	$0, 124(%rsp)
	movb	$0, 125(%rsp)
	movb	$0, 126(%rsp)
	movb	$0, 127(%rsp)
	movb	$0, 128(%rsp)
	movb	$0, 129(%rsp)
	movb	$0, 130(%rsp)
	movb	$0, 131(%rsp)
	movb	$0, 132(%rsp)
	movb	$0, 133(%rsp)
	movb	$0, 134(%rsp)
	movb	$0, 135(%rsp)
	movb	$0, 136(%rsp)
	movb	$0, 137(%rsp)
	movb	$0, 138(%rsp)
	movb	$0, 139(%rsp)
	movb	$0, 140(%rsp)
	movb	$0, 141(%rsp)
	movb	$0, 142(%rsp)
	movb	$0, 143(%rsp)
	movb	$0, 144(%rsp)
	movb	$0, 145(%rsp)
	movb	$0, 146(%rsp)
	movb	$0, 147(%rsp)
	movb	$0, 148(%rsp)
	movb	$0, 149(%rsp)
	movb	$0, 150(%rsp)
	movb	$0, 151(%rsp)
	movb	$0, 152(%rsp)
	movb	$0, 153(%rsp)
	movb	$0, 154(%rsp)
	movb	$0, 155(%rsp)
	movb	$0, 156(%rsp)
	movb	$0, 157(%rsp)
	movb	$0, 158(%rsp)
	movb	$0, 159(%rsp)
	movb	$0, 160(%rsp)
	movb	$0, 161(%rsp)
	movb	$0, 162(%rsp)
	movb	$0, 163(%rsp)
	movb	$0, 164(%rsp)
	movb	$0, 165(%rsp)
	movb	$0, 166(%rsp)
	movb	$0, 167(%rsp)
	#MEMBARRIER
	movb	$0, (%rsp)
	movb	$0, 1(%rsp)
	movb	$0, 2(%rsp)
	movb	$0, 3(%rsp)
	movb	$0, 4(%rsp)
	movb	$0, 5(%rsp)
	movb	$0, 6(%rsp)
	movb	$0, 7(%rsp)
	movb	$0, 8(%rsp)
	movb	$0, 9(%rsp)
	movb	$0, 10(%rsp)
	movb	$0, 11(%rsp)
	movb	$0, 12(%rsp)
	movb	$0, 13(%rsp)
	movb	$0, 14(%rsp)
	movb	$0, 15(%rsp)
	movb	$0, 16(%rsp)
	movb	$0, 17(%rsp)
	movb	$0, 18(%rsp)
	movb	$0, 19(%rsp)
	movb	$0, 20(%rsp)
	movb	$0, 21(%rsp)
	movb	$0, 22(%rsp)
	movb	$0, 23(%rsp)
	movb	$0, 24(%rsp)
	movb	$0, 25(%rsp)
	movb	$0, 26(%rsp)
	movb	$0, 27(%rsp)
	movb	$0, 28(%rsp)
	movb	$0, 29(%rsp)
	movb	$0, 30(%rsp)
	movb	$0, 31(%rsp)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	#MEMBARRIER
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	#MEMBARRIER
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	addq	$168, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	retq

	.def	_RNvXNtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB2_1FNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXNtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB2_1FNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop,unique,117
	.globl	_RNvXNtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB2_1FNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
	.p2align	4
_RNvXNtCs3ONsSsjNgxw_12toyos_crypto10field25519NtB2_1FNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop:
	movq	$0, (%rcx)
	movq	$0, 8(%rcx)
	movq	$0, 16(%rcx)
	movq	$0, 24(%rcx)
	movq	$0, 32(%rcx)
	#MEMBARRIER
	retq

	.def	_RNvXNtCs3ONsSsjNgxw_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXNtCs3ONsSsjNgxw_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop,unique,118
	.globl	_RNvXNtCs3ONsSsjNgxw_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
	.p2align	4
_RNvXNtCs3ONsSsjNgxw_12toyos_crypto11scalar25519NtB2_1SNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop:
	movq	$0, (%rcx)
	movq	$0, 8(%rcx)
	movq	$0, 16(%rcx)
	movq	$0, 24(%rcx)
	#MEMBARRIER
	retq

	.def	_RNvXNtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXNtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop,unique,119
	.globl	_RNvXNtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
	.p2align	4
_RNvXNtCs3ONsSsjNgxw_12toyos_crypto5mlkemNtB2_4PolyNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop:
	xorl	%eax, %eax
	.p2align	4
.LBB119_1:
	movw	$0, (%rcx,%rax)
	movw	$0, 2(%rcx,%rax)
	movw	$0, 4(%rcx,%rax)
	movw	$0, 6(%rcx,%rax)
	movw	$0, 8(%rcx,%rax)
	movw	$0, 10(%rcx,%rax)
	movw	$0, 12(%rcx,%rax)
	movw	$0, 14(%rcx,%rax)
	addq	$16, %rax
	cmpq	$512, %rax
	jne	.LBB119_1
	#MEMBARRIER
	retq

	.def	_RNvXNtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXNtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop,unique,120
	.globl	_RNvXNtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
	.p2align	4
_RNvXNtCs3ONsSsjNgxw_12toyos_crypto6keccakNtB2_6SpongeNtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop:
	movq	$0, (%rcx)
	movq	$0, 8(%rcx)
	movq	$0, 16(%rcx)
	movq	$0, 24(%rcx)
	movq	$0, 32(%rcx)
	movq	$0, 40(%rcx)
	movq	$0, 48(%rcx)
	movq	$0, 56(%rcx)
	movq	$0, 64(%rcx)
	movq	$0, 72(%rcx)
	movq	$0, 80(%rcx)
	movq	$0, 88(%rcx)
	movq	$0, 96(%rcx)
	movq	$0, 104(%rcx)
	movq	$0, 112(%rcx)
	movq	$0, 120(%rcx)
	movq	$0, 128(%rcx)
	movq	$0, 136(%rcx)
	movq	$0, 144(%rcx)
	movq	$0, 152(%rcx)
	movq	$0, 160(%rcx)
	movq	$0, 168(%rcx)
	movq	$0, 176(%rcx)
	movq	$0, 184(%rcx)
	movq	$0, 192(%rcx)
	#MEMBARRIER
	retq

	.def	_RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt,unique,121
	.p2align	4
_RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt:
	movq	%rdx, %rax
	movzbl	(%rcx), %ecx
	leaq	switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt(%rip), %rdx
	movq	(%rdx,%rcx,8), %r8
	leaq	switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel(%rip), %r9
	movslq	(%r9,%rcx,4), %rdx
	addq	%r9, %rdx
	movq	%rax, %rcx
	jmp	_RNvMsa_NtCsbOZu4GxVKn0_4core3fmtNtB5_9Formatter9write_str

	.def	_RNvXs1_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs1_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into,unique,122
	.globl	_RNvXs1_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into
	.p2align	4
_RNvXs1_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest11finish_into:
	pushq	%rsi
	pushq	%rdi
	pushq	%rbx
	subq	$192, %rsp
	movq	%rcx, %rsi
	cmpq	$32, %r8
	jne	.LBB122_2
	movq	%rdx, %rbx
	leaq	64(%rsp), %rdx
	movl	$16, %ecx
	movq	%rdx, %rdi
	rep;movsq (%rsi), %es:(%rdi)
	leaq	32(%rsp), %rcx
	callq	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2568finalize
	movq	56(%rsp), %rax
	movq	%rax, 24(%rbx)
	movq	48(%rsp), %rax
	movq	%rax, 16(%rbx)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 8(%rbx)
	movq	%rax, (%rbx)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	#MEMBARRIER
	movb	$-1, %al
	jmp	.LBB122_3
.LBB122_2:
	movb	$0, (%rsi)
	movb	$0, 1(%rsi)
	movb	$0, 2(%rsi)
	movb	$0, 3(%rsi)
	movb	$0, 4(%rsi)
	movb	$0, 5(%rsi)
	movb	$0, 6(%rsi)
	movb	$0, 7(%rsi)
	movb	$0, 8(%rsi)
	movb	$0, 9(%rsi)
	movb	$0, 10(%rsi)
	movb	$0, 11(%rsi)
	movb	$0, 12(%rsi)
	movb	$0, 13(%rsi)
	movb	$0, 14(%rsi)
	movb	$0, 15(%rsi)
	movb	$0, 16(%rsi)
	movb	$0, 17(%rsi)
	movb	$0, 18(%rsi)
	movb	$0, 19(%rsi)
	movb	$0, 20(%rsi)
	movb	$0, 21(%rsi)
	movb	$0, 22(%rsi)
	movb	$0, 23(%rsi)
	movb	$0, 24(%rsi)
	movb	$0, 25(%rsi)
	movb	$0, 26(%rsi)
	movb	$0, 27(%rsi)
	movb	$0, 28(%rsi)
	movb	$0, 29(%rsi)
	movb	$0, 30(%rsi)
	movb	$0, 31(%rsi)
	movb	$0, 32(%rsi)
	movb	$0, 33(%rsi)
	movb	$0, 34(%rsi)
	movb	$0, 35(%rsi)
	movb	$0, 36(%rsi)
	movb	$0, 37(%rsi)
	movb	$0, 38(%rsi)
	movb	$0, 39(%rsi)
	movb	$0, 40(%rsi)
	movb	$0, 41(%rsi)
	movb	$0, 42(%rsi)
	movb	$0, 43(%rsi)
	movb	$0, 44(%rsi)
	movb	$0, 45(%rsi)
	movb	$0, 46(%rsi)
	movb	$0, 47(%rsi)
	movb	$0, 48(%rsi)
	movb	$0, 49(%rsi)
	movb	$0, 50(%rsi)
	movb	$0, 51(%rsi)
	movb	$0, 52(%rsi)
	movb	$0, 53(%rsi)
	movb	$0, 54(%rsi)
	movb	$0, 55(%rsi)
	movb	$0, 56(%rsi)
	movb	$0, 57(%rsi)
	movb	$0, 58(%rsi)
	movb	$0, 59(%rsi)
	movb	$0, 60(%rsi)
	movb	$0, 61(%rsi)
	movb	$0, 62(%rsi)
	movb	$0, 63(%rsi)
	#MEMBARRIER
	movl	$0, 64(%rsi)
	movl	$0, 68(%rsi)
	movl	$0, 72(%rsi)
	movl	$0, 76(%rsi)
	movl	$0, 80(%rsi)
	movl	$0, 84(%rsi)
	movl	$0, 88(%rsi)
	movl	$0, 92(%rsi)
	#MEMBARRIER
	xorl	%eax, %eax
.LBB122_3:
	addq	$192, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvXs1_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs1_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update,unique,123
	.globl	_RNvXs1_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update
	.p2align	4
_RNvXs1_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtB5_6Digest6update:
	jmp	_RNvMNtCs3ONsSsjNgxw_12toyos_crypto4hashNtB2_6Sha2566update

	.def	_RNvXs1g_NtCsbOZu4GxVKn0_4core3fmtRoNtB6_5Debug3fmtCs3ONsSsjNgxw_12toyos_crypto;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs1g_NtCsbOZu4GxVKn0_4core3fmtRoNtB6_5Debug3fmtCs3ONsSsjNgxw_12toyos_crypto,unique,124
	.p2align	4
_RNvXs1g_NtCsbOZu4GxVKn0_4core3fmtRoNtB6_5Debug3fmtCs3ONsSsjNgxw_12toyos_crypto:
	movq	(%rcx), %rcx
	movl	16(%rdx), %eax
	testl	$33554432, %eax
	jne	_RNvXsK_NtNtCsbOZu4GxVKn0_4core3fmt3numoNtB7_8LowerHex3fmt
	testl	$67108864, %eax
	jne	_RNvXsM_NtNtCsbOZu4GxVKn0_4core3fmt3numoNtB7_8UpperHex3fmt
	jmp	_RNvXNtNtCsbOZu4GxVKn0_4core3fmt3numoNtB4_7Display3fmt

	.def	_RNvXs2_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs2_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop,unique,125
	.globl	_RNvXs2_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
	.p2align	4
_RNvXs2_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha256NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop:
	movb	$0, (%rcx)
	movb	$0, 1(%rcx)
	movb	$0, 2(%rcx)
	movb	$0, 3(%rcx)
	movb	$0, 4(%rcx)
	movb	$0, 5(%rcx)
	movb	$0, 6(%rcx)
	movb	$0, 7(%rcx)
	movb	$0, 8(%rcx)
	movb	$0, 9(%rcx)
	movb	$0, 10(%rcx)
	movb	$0, 11(%rcx)
	movb	$0, 12(%rcx)
	movb	$0, 13(%rcx)
	movb	$0, 14(%rcx)
	movb	$0, 15(%rcx)
	movb	$0, 16(%rcx)
	movb	$0, 17(%rcx)
	movb	$0, 18(%rcx)
	movb	$0, 19(%rcx)
	movb	$0, 20(%rcx)
	movb	$0, 21(%rcx)
	movb	$0, 22(%rcx)
	movb	$0, 23(%rcx)
	movb	$0, 24(%rcx)
	movb	$0, 25(%rcx)
	movb	$0, 26(%rcx)
	movb	$0, 27(%rcx)
	movb	$0, 28(%rcx)
	movb	$0, 29(%rcx)
	movb	$0, 30(%rcx)
	movb	$0, 31(%rcx)
	movb	$0, 32(%rcx)
	movb	$0, 33(%rcx)
	movb	$0, 34(%rcx)
	movb	$0, 35(%rcx)
	movb	$0, 36(%rcx)
	movb	$0, 37(%rcx)
	movb	$0, 38(%rcx)
	movb	$0, 39(%rcx)
	movb	$0, 40(%rcx)
	movb	$0, 41(%rcx)
	movb	$0, 42(%rcx)
	movb	$0, 43(%rcx)
	movb	$0, 44(%rcx)
	movb	$0, 45(%rcx)
	movb	$0, 46(%rcx)
	movb	$0, 47(%rcx)
	movb	$0, 48(%rcx)
	movb	$0, 49(%rcx)
	movb	$0, 50(%rcx)
	movb	$0, 51(%rcx)
	movb	$0, 52(%rcx)
	movb	$0, 53(%rcx)
	movb	$0, 54(%rcx)
	movb	$0, 55(%rcx)
	movb	$0, 56(%rcx)
	movb	$0, 57(%rcx)
	movb	$0, 58(%rcx)
	movb	$0, 59(%rcx)
	movb	$0, 60(%rcx)
	movb	$0, 61(%rcx)
	movb	$0, 62(%rcx)
	movb	$0, 63(%rcx)
	#MEMBARRIER
	movl	$0, 64(%rcx)
	movl	$0, 68(%rcx)
	movl	$0, 72(%rcx)
	movl	$0, 76(%rcx)
	movl	$0, 80(%rcx)
	movl	$0, 84(%rcx)
	movl	$0, 88(%rcx)
	movl	$0, 92(%rcx)
	#MEMBARRIER
	retq

	.def	_RNvXs6_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs6_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into,unique,126
	.globl	_RNvXs6_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into
	.p2align	4
_RNvXs6_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest11finish_into:
	pushq	%rsi
	pushq	%rdi
	subq	$312, %rsp
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	cmpq	$48, %r8
	jne	.LBB126_2
	leaq	80(%rsp), %rdi
	movl	$224, %r8d
	movq	%rdi, %rcx
	callq	memcpy
	leaq	32(%rsp), %rcx
	movq	%rdi, %rdx
	callq	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3848finalize
	movq	72(%rsp), %rax
	movq	%rax, 40(%rsi)
	movq	64(%rsp), %rax
	movq	%rax, 32(%rsi)
	movq	56(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	48(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	#MEMBARRIER
	movb	$-1, %al
	addq	$312, %rsp
	popq	%rdi
	popq	%rsi
	retq
.LBB126_2:
	xorl	%eax, %eax
	.p2align	4
.LBB126_3:
	movb	$0, (%rdx,%rax)
	movb	$0, 1(%rdx,%rax)
	movb	$0, 2(%rdx,%rax)
	movb	$0, 3(%rdx,%rax)
	movb	$0, 4(%rdx,%rax)
	movb	$0, 5(%rdx,%rax)
	movb	$0, 6(%rdx,%rax)
	movb	$0, 7(%rdx,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB126_3
	#MEMBARRIER
	movq	$0, 128(%rdx)
	movq	$0, 136(%rdx)
	movq	$0, 144(%rdx)
	movq	$0, 152(%rdx)
	movq	$0, 160(%rdx)
	movq	$0, 168(%rdx)
	movq	$0, 176(%rdx)
	movq	$0, 184(%rdx)
	#MEMBARRIER
	xorl	%eax, %eax
	addq	$312, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvXs6_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs6_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update,unique,127
	.globl	_RNvXs6_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update
	.p2align	4
_RNvXs6_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtB5_6Digest6update:
	jmp	_RNvMs3_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha3846update

	.def	_RNvXs7_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs7_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop,unique,128
	.globl	_RNvXs7_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
	.p2align	4
_RNvXs7_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop:
	xorl	%eax, %eax
	.p2align	4
.LBB128_1:
	movb	$0, (%rcx,%rax)
	movb	$0, 1(%rcx,%rax)
	movb	$0, 2(%rcx,%rax)
	movb	$0, 3(%rcx,%rax)
	movb	$0, 4(%rcx,%rax)
	movb	$0, 5(%rcx,%rax)
	movb	$0, 6(%rcx,%rax)
	movb	$0, 7(%rcx,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB128_1
	#MEMBARRIER
	movq	$0, 128(%rcx)
	movq	$0, 136(%rcx)
	movq	$0, 144(%rcx)
	movq	$0, 152(%rcx)
	movq	$0, 160(%rcx)
	movq	$0, 168(%rcx)
	movq	$0, 176(%rcx)
	movq	$0, 184(%rcx)
	#MEMBARRIER
	retq

	.def	_RNvXs_NtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXs_NtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop,unique,129
	.globl	_RNvXs_NtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
	.p2align	4
_RNvXs_NtCs3ONsSsjNgxw_12toyos_crypto8poly1305NtB4_8Poly1305NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop:
	movq	$0, 32(%rcx)
	movq	$0, 40(%rcx)
	movq	$0, 48(%rcx)
	movq	$0, 56(%rcx)
	movq	$0, 64(%rcx)
	#MEMBARRIER
	movq	$0, 72(%rcx)
	movq	$0, 80(%rcx)
	movq	$0, 88(%rcx)
	movq	$0, 96(%rcx)
	movq	$0, 104(%rcx)
	#MEMBARRIER
	movb	$0, 16(%rcx)
	movb	$0, 17(%rcx)
	movb	$0, 18(%rcx)
	movb	$0, 19(%rcx)
	movb	$0, 20(%rcx)
	movb	$0, 21(%rcx)
	movb	$0, 22(%rcx)
	movb	$0, 23(%rcx)
	movb	$0, 24(%rcx)
	movb	$0, 25(%rcx)
	movb	$0, 26(%rcx)
	movb	$0, 27(%rcx)
	movb	$0, 28(%rcx)
	movb	$0, 29(%rcx)
	movb	$0, 30(%rcx)
	movb	$0, 31(%rcx)
	#MEMBARRIER
	retq

	.def	_RNvXsb_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXsb_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into,unique,130
	.globl	_RNvXsb_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into
	.p2align	4
_RNvXsb_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest11finish_into:
	pushq	%rsi
	pushq	%rdi
	subq	$328, %rsp
	movq	%rdx, %rsi
	movq	%rcx, %rdx
	cmpq	$64, %r8
	jne	.LBB130_2
	leaq	96(%rsp), %rdi
	movl	$224, %r8d
	movq	%rdi, %rcx
	callq	memcpy
	leaq	32(%rsp), %rcx
	movq	%rdi, %rdx
	callq	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5128finalize
	movq	88(%rsp), %rax
	movq	%rax, 56(%rsi)
	movq	80(%rsp), %rax
	movq	%rax, 48(%rsi)
	movq	72(%rsp), %rax
	movq	%rax, 40(%rsi)
	movq	64(%rsp), %rax
	movq	%rax, 32(%rsi)
	movq	56(%rsp), %rax
	movq	%rax, 24(%rsi)
	movq	48(%rsp), %rax
	movq	%rax, 16(%rsi)
	movq	32(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	%rcx, 8(%rsi)
	movq	%rax, (%rsi)
	movb	$0, 32(%rsp)
	movb	$0, 33(%rsp)
	movb	$0, 34(%rsp)
	movb	$0, 35(%rsp)
	movb	$0, 36(%rsp)
	movb	$0, 37(%rsp)
	movb	$0, 38(%rsp)
	movb	$0, 39(%rsp)
	movb	$0, 40(%rsp)
	movb	$0, 41(%rsp)
	movb	$0, 42(%rsp)
	movb	$0, 43(%rsp)
	movb	$0, 44(%rsp)
	movb	$0, 45(%rsp)
	movb	$0, 46(%rsp)
	movb	$0, 47(%rsp)
	movb	$0, 48(%rsp)
	movb	$0, 49(%rsp)
	movb	$0, 50(%rsp)
	movb	$0, 51(%rsp)
	movb	$0, 52(%rsp)
	movb	$0, 53(%rsp)
	movb	$0, 54(%rsp)
	movb	$0, 55(%rsp)
	movb	$0, 56(%rsp)
	movb	$0, 57(%rsp)
	movb	$0, 58(%rsp)
	movb	$0, 59(%rsp)
	movb	$0, 60(%rsp)
	movb	$0, 61(%rsp)
	movb	$0, 62(%rsp)
	movb	$0, 63(%rsp)
	movb	$0, 64(%rsp)
	movb	$0, 65(%rsp)
	movb	$0, 66(%rsp)
	movb	$0, 67(%rsp)
	movb	$0, 68(%rsp)
	movb	$0, 69(%rsp)
	movb	$0, 70(%rsp)
	movb	$0, 71(%rsp)
	movb	$0, 72(%rsp)
	movb	$0, 73(%rsp)
	movb	$0, 74(%rsp)
	movb	$0, 75(%rsp)
	movb	$0, 76(%rsp)
	movb	$0, 77(%rsp)
	movb	$0, 78(%rsp)
	movb	$0, 79(%rsp)
	movb	$0, 80(%rsp)
	movb	$0, 81(%rsp)
	movb	$0, 82(%rsp)
	movb	$0, 83(%rsp)
	movb	$0, 84(%rsp)
	movb	$0, 85(%rsp)
	movb	$0, 86(%rsp)
	movb	$0, 87(%rsp)
	movb	$0, 88(%rsp)
	movb	$0, 89(%rsp)
	movb	$0, 90(%rsp)
	movb	$0, 91(%rsp)
	movb	$0, 92(%rsp)
	movb	$0, 93(%rsp)
	movb	$0, 94(%rsp)
	movb	$0, 95(%rsp)
	#MEMBARRIER
	movb	$-1, %al
	addq	$328, %rsp
	popq	%rdi
	popq	%rsi
	retq
.LBB130_2:
	xorl	%eax, %eax
	.p2align	4
.LBB130_3:
	movb	$0, (%rdx,%rax)
	movb	$0, 1(%rdx,%rax)
	movb	$0, 2(%rdx,%rax)
	movb	$0, 3(%rdx,%rax)
	movb	$0, 4(%rdx,%rax)
	movb	$0, 5(%rdx,%rax)
	movb	$0, 6(%rdx,%rax)
	movb	$0, 7(%rdx,%rax)
	addq	$8, %rax
	cmpq	$128, %rax
	jne	.LBB130_3
	#MEMBARRIER
	movq	$0, 128(%rdx)
	movq	$0, 136(%rdx)
	movq	$0, 144(%rdx)
	movq	$0, 152(%rdx)
	movq	$0, 160(%rdx)
	movq	$0, 168(%rdx)
	movq	$0, 176(%rdx)
	movq	$0, 184(%rdx)
	#MEMBARRIER
	xorl	%eax, %eax
	addq	$328, %rsp
	popq	%rdi
	popq	%rsi
	retq

	.def	_RNvXsb_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_RNvXsb_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update,unique,131
	.globl	_RNvXsb_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update
	.p2align	4
_RNvXsb_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtB5_6Digest6update:
	jmp	_RNvMs8_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha5126update

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.0,unique,132
anon.b5f26072819afdb16b222aeefaecc0c9.0:
	.asciz	"src/nist.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.1,unique,133
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCsbOZu4GxVKn0_4core3fmtRoNtB6_5Debug3fmtCs3ONsSsjNgxw_12toyos_crypto

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.2,unique,134
anon.b5f26072819afdb16b222aeefaecc0c9.2:
	.asciz	"src/montgomery.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.3,unique,135
anon.b5f26072819afdb16b222aeefaecc0c9.3:
	.ascii	"called `Result::unwrap()` on an `Err` value"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.4,unique,136
anon.b5f26072819afdb16b222aeefaecc0c9.4:
	.asciz	"src/mlkem.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.5,unique,137
anon.b5f26072819afdb16b222aeefaecc0c9.5:
	.asciz	"src/aes.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.6,unique,138
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.6:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.5
	.asciz	"\n\000\000\000\000\000\000\000l\000\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.7,unique,139
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.7:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.5
	.asciz	"\n\000\000\000\000\000\000\000J\000\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.8,unique,140
anon.b5f26072819afdb16b222aeefaecc0c9.8:
	.asciz	"src/rsa.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.9,unique,141
anon.b5f26072819afdb16b222aeefaecc0c9.9:
	.asciz	"src/hash.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.10,unique,142
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.10:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.9
	.asciz	"\013\000\000\000\000\000\000\000-\001\000\000\001\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.11,unique,143
anon.b5f26072819afdb16b222aeefaecc0c9.11:
	.ascii	"\243xY\023\312M\353u\253\330AAM\np\000\230\350ywy@\307\214s\376o+\356l\003R"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.12,unique,144
anon.b5f26072819afdb16b222aeefaecc0c9.12:
	.asciz	"src/ed25519.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.13,unique,145
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.13:
	.asciz	"\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.quad	_RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.14,unique,146
anon.b5f26072819afdb16b222aeefaecc0c9.14:
	.ascii	"Ed25519 base point"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.15,unique,147
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.15:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.12
	.asciz	"\016\000\000\000\000\000\000\000$\000\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.16,unique,148
anon.b5f26072819afdb16b222aeefaecc0c9.16:
	.ascii	"\260\240\016J'\033\356\304x\344/\255\006\030C/\247\327\373=\231\000M+\013\337\301O\200$\203+"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.17,unique,149
anon.b5f26072819afdb16b222aeefaecc0c9.17:
	.asciz	"src/poly1305.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.18,unique,150
	.p2align	4, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.18:
	.zero	16

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.19,unique,151
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.19:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.17
	.asciz	"\017\000\000\000\000\000\000\000W\000\000\000!\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.20,unique,152
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.20:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.17
	.asciz	"\017\000\000\000\000\000\000\000\\\000\000\000\r\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.21,unique,153
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.21:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.17
	.asciz	"\017\000\000\000\000\000\000\000]\000\000\000\030\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.22,unique,154
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.22:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.17
	.asciz	"\017\000\000\000\000\000\000\000P\000\000\000\030\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.23,unique,155
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.23:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.17
	.asciz	"\017\000\000\000\000\000\000\000A\000\000\000\030\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.24,unique,156
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.24:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.2
	.asciz	"\021\000\000\000\000\000\000\000\200\000\000\000\r\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.25,unique,157
anon.b5f26072819afdb16b222aeefaecc0c9.25:
	.ascii	"assertion failed: matches!(N, 4 | 6) && p[0] & 1 == 1 && p[N - 1] >> 63 == 1"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.26,unique,158
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.26:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.2
	.asciz	"\021\000\000\000\000\000\000\000$\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.27,unique,159
anon.b5f26072819afdb16b222aeefaecc0c9.27:
	.asciz	"src/ssh.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.28,unique,160
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.28:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.27
	.asciz	"\n\000\000\000\000\000\000\000Q\000\000\000\n\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.29,unique,161
anon.b5f26072819afdb16b222aeefaecc0c9.29:
	.ascii	"curve arithmetic invariant"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.30,unique,162
anon.b5f26072819afdb16b222aeefaecc0c9.30:
	.asciz	"src/ecc.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.31,unique,163
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.31:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.30
	.asciz	"\n\000\000\000\000\000\000\000a\000\000\000\001\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.32,unique,164
anon.b5f26072819afdb16b222aeefaecc0c9.32:
	.ascii	"nonzero prime-order scalar"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.33,unique,165
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.33:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.30
	.asciz	"\n\000\000\000\000\000\000\000b\000\000\000\001\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.34,unique,166
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.34:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.9
	.asciz	"\013\000\000\000\000\000\000\0009\001\000\000\001\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.35,unique,167
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.35:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.9
	.asciz	"\013\000\000\000\000\000\000\000K\001\000\000\001\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.36,unique,168
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.36:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\347\000\000\000.\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.37,unique,169
anon.b5f26072819afdb16b222aeefaecc0c9.37:
	.zero	8

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.38,unique,170
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.38:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\364\000\000\000F\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.39,unique,171
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.39:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\360\000\000\000\016\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.40,unique,172
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.40:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\353\000\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.41,unique,173
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.41:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\347\000\000\000\013\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.42,unique,174
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.42:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\345\000\000\000\031\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.43,unique,175
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.43:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\330\000\000\000\023\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.44,unique,176
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.44:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000b\000\000\000$\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.45,unique,177
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.45:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\310\000\000\000\027\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.46,unique,178
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.46:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\312\000\000\000\020\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.47,unique,179
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.47:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\313\000\000\000\027\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.48,unique,180
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.48:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\311\000\000\000\027\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.49,unique,181
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.49:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\270\000\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.50,unique,182
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.50:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\224\000\000\000\017\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.51,unique,183
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.51:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\205\000\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.52,unique,184
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.52:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\221\000\000\000\r\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.53,unique,185
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.53:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\210\000\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.54,unique,186
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.54:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\210\000\000\000R\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.55,unique,187
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.55:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\202\000\000\000\r\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.56,unique,188
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.56:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000~\000\000\000$\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.57,unique,189
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.57:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000~\000\000\0007\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.58,unique,190
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.58:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000r\000\000\0000\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.59,unique,191
anon.b5f26072819afdb16b222aeefaecc0c9.59:
	.ascii	"validated prime-order point and nonzero scalar"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.60,unique,192
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.60:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.0
	.asciz	"\013\000\000\000\000\000\000\000\256\000\000\000\016\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.61,unique,193
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.61:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.4
	.asciz	"\f\000\000\000\000\000\000\000<\000\000\000$\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.62,unique,194
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.62:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.4
	.asciz	"\f\000\000\000\000\000\000\000o\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.63,unique,195
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.63:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.4
	.asciz	"\f\000\000\000\000\000\000\000t\000\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.64,unique,196
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.64:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.4
	.asciz	"\f\000\000\000\000\000\000\000M\000\000\000\035\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.65,unique,197
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.65:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.4
	.asciz	"\f\000\000\000\000\000\000\000N\000\000\000(\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.66,unique,198
anon.b5f26072819afdb16b222aeefaecc0c9.66:
	.ascii	"assertion failed: [72, 136, 168].contains(&rate)"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.67,unique,199
anon.b5f26072819afdb16b222aeefaecc0c9.67:
	.asciz	"src/keccak.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.68,unique,200
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.68:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.67
	.asciz	"\r\000\000\000\000\000\000\000.\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.69,unique,201
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.69:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.67
	.asciz	"\r\000\000\000\000\000\000\0006\000\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.70,unique,202
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.70:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.67
	.asciz	"\r\000\000\000\000\000\000\000>\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.71,unique,203
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.71:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.67
	.asciz	"\r\000\000\000\000\000\000\000h\000\000\000\026\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.72,unique,204
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.72:
	.ascii	"\001\000\000\000\000\000\000\000\202\200\000\000\000\000\000\000\212\200\000\000\000\000\000\200\000\200\000\200\000\000\000\200\213\200\000\000\000\000\000\000\001\000\000\200\000\000\000\000\201\200\000\200\000\000\000\200\t\200\000\000\000\000\000\200\212\000\000\000\000\000\000\000\210\000\000\000\000\000\000\000\t\200\000\200\000\000\000\000\n\000\000\200\000\000\000\000\213\200\000\200\000\000\000\000\213\000\000\000\000\000\000\200\211\200\000\000\000\000\000\200\003\200\000\000\000\000\000\200\002\200\000\000\000\000\000\200\200\000\000\000\000\000\000\200\n\200\000\000\000\000\000\000\n\000\000\200\000\000\000\200\201\200\000\200\000\000\000\200\200\200\000\000\000\000\000\200\001\000\000\200\000\000\000\000\b\200\000\200\000\000\000\200"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.73,unique,205
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.73:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.8
	.asciz	"\n\000\000\000\000\000\000\000\376\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.74,unique,206
	.p2align	2, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.74:
	.ascii	"\230/\212B\221D7q\317\373\300\265\245\333\265\351[\302V9\361\021\361Y\244\202?\222\325^\034\253\230\252\007\330\001[\203\022\276\2051$\303}\fUt]\276r\376\261\336\200\247\006\334\233t\361\233\301\301i\233\344\206G\276\357\306\235\301\017\314\241\f$o,\351-\252\204tJ\334\251\260\\\332\210\371vRQ>\230m\3061\250\310'\003\260\307\177Y\277\363\013\340\306G\221\247\325Qc\312\006g))\024\205\n\267'8!\033.\374m,M\023\r8STs\ne\273\njv.\311\302\201\205,r\222\241\350\277\242Kf\032\250p\213K\302\243Ql\307\031\350\222\321$\006\231\326\2055\016\364p\240j\020\026\301\244\031\bl7\036LwH'\265\274\2604\263\f\0349J\252\330NO\312\234[\363o.h\356\202\217toc\245x\024x\310\204\b\002\307\214\372\377\276\220\353lP\244\367\243\371\276\362xq\306"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.75,unique,207
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.75:
	.ascii	"\"\256(\327\230/\212B\315e\357#\221D7q/;M\354\317\373\300\265\274\333\211\201\245\333\265\3518\265H\363[\302V9\031\320\005\266\361\021\361Y\233O\031\257\244\202?\222\030\201m\332\325^\034\253B\002\003\243\230\252\007\330\276opE\001[\203\022\214\262\344N\276\2051$\342\264\377\325\303}\fUo\211{\362t]\276r\261\226\026;\376\261\336\2005\022\307%\247\006\334\233\224&i\317t\361\233\301\322J\361\236\301i\233\344\343%O8\206G\276\357\265\325\214\213\306\235\301\017e\234\254w\314\241\f$u\002+Yo,\351-\203\344\246n\252\204tJ\324\373A\275\334\251\260\\\265S\021\203\332\210\371v\253\337f\356RQ>\230\0202\264-m\3061\250?!\373\230\310'\003\260\344\016\357\276\307\177Y\277\302\217\250=\363\013\340\306%\247\n\223G\221\247\325o\202\003\340Qc\312\006pn\016\ng))\024\374/\322F\205\n\267'&\311&\\8!\033.\355*\304Z\374m,M\337\263\225\235\023\r8S\336c\257\213Ts\ne\250\262w<\273\njv\346\256\355G.\311\302\201;5\202\024\205,r\222d\003\361L\241\350\277\242\0010B\274Kf\032\250\221\227\370\320p\213K\3020\276T\006\243Ql\307\030R\357\326\031\350\222\321\020\251eU$\006\231\326* qW\2055\016\364\270\321\2732p\240j\020\310\320\322\270\026\301\244\031S\253AQ\bl7\036\231\353\216\337LwH'\250H\233\341\265\274\2604cZ\311\305\263\f\0349\313\212A\343J\252\330Ns\343cwO\312\234[\243\270\262\326\363o.h\374\262\357]\356\202\217t`/\027Coc\245xr\253\360\241\024x\310\204\3549d\032\b\002\307\214(\036c#\372\377\276\220\351\275\202\336\353lP\244\025y\306\262\367\243\371\276+Sr\343\362xq\306\234a&\352\316>'\312\007\302\300!\307\270\206\321\036\353\340\315\326}\332\352x\321n\356\177O}\365\272o\027r\252g\360\006\246\230\310\242\305}c\n\256\r\371\276\004\230?\021\033G\034\0235\013q\033\204}\004#\365w\333(\223$\307@{\253\3122\274\276\311\025\n\276\236<L\r\020\234\304g\035C\266B>\313\276\324\305L*~e\374\234)\177Y\354\372\326:\253o\313_\027XGJ\214\031Dl"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.76,unique,208
	.p2align	2, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.76:
	.ascii	"expand 32-byte k"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.77,unique,209
anon.b5f26072819afdb16b222aeefaecc0c9.77:
	.ascii	"fixed-size shared secret"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.78,unique,210
anon.b5f26072819afdb16b222aeefaecc0c9.78:
	.asciz	"src/hybrid.rs"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.79,unique,211
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.79:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.78
	.asciz	"\r\000\000\000\000\000\000\000\037\000\000\000\n\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.80,unique,212
	.p2align	3, 0x0
anon.b5f26072819afdb16b222aeefaecc0c9.80:
	.quad	anon.b5f26072819afdb16b222aeefaecc0c9.78
	.asciz	"\r\000\000\000\000\000\000\000\035\000\000\000\n\000\000"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.81,unique,213
anon.b5f26072819afdb16b222aeefaecc0c9.81:
	.ascii	"Length"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.82,unique,214
anon.b5f26072819afdb16b222aeefaecc0c9.82:
	.ascii	"Authentication"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.83,unique,215
anon.b5f26072819afdb16b222aeefaecc0c9.83:
	.ascii	"InvalidKey"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.84,unique,216
anon.b5f26072819afdb16b222aeefaecc0c9.84:
	.ascii	"InvalidPoint"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.85,unique,217
anon.b5f26072819afdb16b222aeefaecc0c9.85:
	.ascii	"InvalidEncoding"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.86,unique,218
anon.b5f26072819afdb16b222aeefaecc0c9.86:
	.ascii	"InvalidSignature"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.87,unique,219
anon.b5f26072819afdb16b222aeefaecc0c9.87:
	.ascii	"CounterExhausted"

	.section	.rdata,"dr",one_only,anon.b5f26072819afdb16b222aeefaecc0c9.88,unique,220
anon.b5f26072819afdb16b222aeefaecc0c9.88:
	.ascii	"Entropy"

	.section	.rdata,"dr",one_only,switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt,unique,221
	.p2align	3, 0x0
switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt:
	.quad	6
	.quad	14
	.quad	10
	.quad	12
	.quad	15
	.quad	16
	.quad	16
	.quad	7

	.section	.rdata,"dr",one_only,switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel,unique,222
	.p2align	2, 0x0
switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel:
	.long	anon.b5f26072819afdb16b222aeefaecc0c9.81-switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel
	.long	anon.b5f26072819afdb16b222aeefaecc0c9.82-switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel
	.long	anon.b5f26072819afdb16b222aeefaecc0c9.83-switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel
	.long	anon.b5f26072819afdb16b222aeefaecc0c9.84-switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel
	.long	anon.b5f26072819afdb16b222aeefaecc0c9.85-switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel
	.long	anon.b5f26072819afdb16b222aeefaecc0c9.86-switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel
	.long	anon.b5f26072819afdb16b222aeefaecc0c9.87-switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel
	.long	anon.b5f26072819afdb16b222aeefaecc0c9.88-switch.table._RNvXs1_Cs3ONsSsjNgxw_12toyos_cryptoNtB5_5ErrorNtNtCsbOZu4GxVKn0_4core3fmt5Debug3fmt.107.rel

	.globl	_RNvXsc_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
	.def	_RNvXsc_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop;
	.scl	2;
	.type	32;
	.endef
_RNvXsc_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha512NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop = _RNvXs7_NtCs3ONsSsjNgxw_12toyos_crypto4hashNtB5_6Sha384NtNtNtCsbOZu4GxVKn0_4core3ops4drop4Drop4drop
